**<center><font face="微软雅黑" size=6>VTRON Technical Documentation</font></center>**




<div align=center>

|Version|Date|Note|Author|
|:-----:|:-----:|:-----:|:-----:|
| v1.0.0 | 2025-08-18 | VTRON Technical Documentation | sun |
|  |  |  |  |

</div>
<br/><br/><br/>

***

**<center><font face="微软雅黑" size=6>Directory</font></center>**
- [1. Project Overview](#1-)
  - [1.1 Basic project information](#11-)
  - [1.2 Project architecture diagram](#12-)
- [2. Technical architecture description](#2-)
  - [2.1 Overall architecture](#21-)
  - [2.2 Main technology stack](#22-)
- [3. Project directory structure](#3-)
- [4. Core Module Description](#4-)

***


# 1. Project Overview

## 1.1 Basic project information
&nbsp;&nbsp;This project is one that provides users with card products for use. The application adopts the Model-View-Controller architecture and is developed using the OC programming language.

- Project Name：VTRON
- Current version：1.0.0
- Development environment：Xcode 16 and above
- Dependency Management：Cocoapods

## 1.2 Project architecture diagram

![](https://p.ipic.vip/qjz61r.png)

<br/>

# 2. Technical architecture description

## 2.1 Overall architecture

- Architectural pattern：Model-View-Controller
- Degree of modularization: Apart from the basic modules, all functional modules are divided into three major modules, namely: Cards, Accounts, and Mine.

## 2.2 Main technology stack

- UI framework: UIKit, which adopts a combination of pure code and Xib.
- Network layer: NSURLSession custom encapsulation.
- Data persistence: NSUserDefaults
- Third-party library: JSONModel，Masonry,etc.


# 3. Project directory structure


```
ProjectName/
├── AppDelegate
├── UITabBar            # Tabbar
├── Base                # Basic components
├── Consts              # Constants and macros
├── Resources/          # Resource file
│   ├── Assets.xcassets
│   ├── Localizable.strings
│   └── ...
├── Sections/            # Functional module
│   ├── Cards/
│   │   ├── View
│   │   ├── ViewModel
│   │   ├── Model
│   └── Accounts/
│   │   ├── View
│   │   ├── ViewModel
│   │   ├── Model
│   └── ..../
├── Tool/             # Public components
│   ├── Extensions
│   ├── Utilities
│   ├── Protocols
│   └── ...
├── Network/           # Service components
│   ├── LoginNetWorkManager
│   ├── HomeCardNetWorkManager
│   ├── ...
├── Vendors/           # Third-party library
│   ├── FWPopupViewOC
│   ├── XDPagesView
│   ├── ...
└── Supporting Files/

```


# 4. Core Module Description

## 4.1 [Sections/Cards]
- Function description: All operations related to cards, such as card application, card transfer, and card record query, are all contained in this module.
- Dependencies: this module will be dependent on the NetWork NetWork request/HomeCardNetWorkManager.


## 4.2 [Sections/Accounts]
- Function description: Wallet-related functions, including recharge, withdrawal, transfer, and collection, etc.
- Dependencies: this module will be dependent on the NetWork NetWork request/AccountNetWorkManager.
