//
//  HostManager.m
//  CregisCard
//
//  Created by sunliang on 2025/5/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "HostManager.h"

@implementation HostManager


+ (instancetype)sharedManager {
    static HostManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

@end
