//
//  HostManager.h
//  CregisCard
//
//  Created by sunliang on 2025/5/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HostManager : NSObject
+ (instancetype)sharedManager;
@property(nonatomic,strong)NSString*host;

@end

NS_ASSUME_NONNULL_END
