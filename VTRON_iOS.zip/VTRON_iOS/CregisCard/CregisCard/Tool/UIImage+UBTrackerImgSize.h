//
//  UIImage+UBTrackerImgSize.h
//  CregisCard
//
//  Created by sunliang on 2022/3/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (UBTrackerImgSize)
/**

*  根据图片url获取网络图片或Gif尺寸

*/
+ (CGSize)getImageSizeWithURL:(id)URL;
// 根据图片url获取图片或Gif尺寸
+(CGSize)getImageKindSizeWithURL:(id)imageURL;
//图片灰色处理
+ (UIImage *)grayImage:(UIImage *)sourceImage;
//裁剪图片
- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize;

//图片设置圆角
- (UIImage *)roundedCornerImageWithRadius:(CGFloat)radius;
@end

NS_ASSUME_NONNULL_END
