//
//  UBTrackerDocumentPickerViewController.m
//  CregisCard
//
//  Created by sunliang on 2022/4/24.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//
//【核心功能】
//重写 UIDocumentPickerViewController，改变系统导航颜色

#import "UBTrackerDocumentPickerViewController.h"

@interface UBTrackerDocumentPickerViewController ()

@end

@implementation UBTrackerDocumentPickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UITabBar appearance] setTranslucent:YES];
    [[UIBarButtonItem appearance] setTintColor:[UIColor blackColor]];
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSForegroundColorAttributeName] = [UIColor blackColor];
    [[UINavigationBar appearance] setTitleTextAttributes:attrs];//设置导航字体颜色
}
 
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[UITabBar appearance] setTranslucent:NO];
    [[UIBarButtonItem appearance] setTintColor:[UIColor whiteColor]];
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [[UINavigationBar appearance] setTitleTextAttributes:attrs];//设置导航字体颜色
}
 
-(void)dealloc
{
    [[UITabBar appearance] setTranslucent:NO];
    [[UIBarButtonItem appearance] setTintColor:[UIColor whiteColor]];
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [[UINavigationBar appearance] setTitleTextAttributes:attrs];//设置导航字体颜色
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
