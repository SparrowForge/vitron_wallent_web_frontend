//
//  CustomSizeButton.h
//  CregisCard
//
//  Created by 孙良 on 2023/5/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomSizeButton : UIButton
typedef NS_ENUM(NSUInteger, CustomButtonImagePosition) {
    CustomButtonImagePositionLeft,   // 图片在左，文字在右，默认
    CustomButtonImagePositionRight,  // 图片在右，文字在左
    CustomButtonImagePositionTop,    // 图片在上，文字在下
    CustomButtonImagePositionBottom, // 图片在下，文字在上
};

// 设置按钮的文字和图片，以及图片的位置
- (void)setTitle:(NSString *)title image:(UIImage *)image imagePosition:(CustomButtonImagePosition)position;
@end

NS_ASSUME_NONNULL_END
