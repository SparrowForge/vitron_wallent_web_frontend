//
//  LeftMenuViewController.h
//  SustainableContract
//
//  Created by sunliang on 2018/1/31.
//  Copyright © 2018年 XinHuoKeJi. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface UIViewController (LeftSlider)<UIGestureRecognizerDelegate>
@property (nonatomic,strong) UIView *maskView;
@property (nonatomic,assign) BOOL isOpen;
-(void)showFromLeft;
-(void)hideToLeft;
-(void)initSlideFoundation;
@end
