//
//  UIView+UBTrackerCornerRedius.m
//  CregisCard
//
//  Created by sunliang on 2022/4/23.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "UIView+UBTrackerCornerRedius.h"

@implementation UIView (UBTrackerCornerRedius)

//UIView切圆角
- (void)maskRoundingCorners:(UIRectCorner)corner cornerRedius:(CGSize)size {
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                                   byRoundingCorners:corner
                                                         cornerRadii:size];
    
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
    maskLayer.frame = self.bounds;
    maskLayer.path = maskPath.CGPath;
    self.layer.mask = maskLayer;
    
}


-(void)setCornerRadius:(CGFloat)cornerRadius{
    
    self.layer.cornerRadius=cornerRadius;
    self.clipsToBounds=YES;
    
}

-(void)setborderColor:(UIColor*)borderColor withborderWidth:(CGFloat)borderWidth{
    
    self.layer.borderColor=borderColor.CGColor;
    self.layer.borderWidth=borderWidth;
    
}



@end
