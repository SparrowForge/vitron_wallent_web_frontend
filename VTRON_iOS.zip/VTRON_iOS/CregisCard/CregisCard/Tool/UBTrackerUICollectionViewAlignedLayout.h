//
//  UBTrackerUICollectionViewAlignedLayout.h
//  CregisCard
//
//  Created by 孙良 on 2023/7/21.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger,AlignType){
    AlignWithLeft,
    AlignWithCenter,
    AlignWithRight
};
NS_ASSUME_NONNULL_BEGIN

@interface UBTrackerUICollectionViewAlignedLayout : UICollectionViewFlowLayout
@property (nonatomic,assign)CGFloat betweenOfCell;
//cell对齐方式
@property (nonatomic,assign)AlignType cellType;
-(instancetype)initWthType : (AlignType)cellType;
//全能初始化方法 其他方式初始化最终都会走到这里
-(instancetype)initWithType:(AlignType) cellType betweenOfCell:(CGFloat)betweenOfCell;
@end

NS_ASSUME_NONNULL_END
