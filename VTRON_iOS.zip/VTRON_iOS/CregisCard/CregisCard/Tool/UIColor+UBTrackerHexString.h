//
//  UIColor+UBTrackerHexString.h
//  CregisCard
//
//  Created by sunliang on 2022/4/20.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (UBTrackerHexString)
//16进制颜色转换为UIColor
+(UIColor *)colorWithHexString:(NSString *)hexColor alpha:(float)opacity;

//十六进制数值转换为UIColor
+(UIColor*)colorWithRGB:(NSUInteger)hex
                  alpha:(CGFloat)alpha;
@end

NS_ASSUME_NONNULL_END
