//
//  SLWriteLogManager.h
//  exchange
//
//  Created by sunliang on 2021/2/20.
//  Copyright © 2021 XinHuoKeJi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface UBTrackerWriteLogManager : NSObject
/**
 * 单例
 * @return 单例对象
 */
+ (UBTrackerWriteLogManager *)writeLog_shareManager;
/**
 * 开启写入Log日志
 */
- (void)writeLog_startWriteLogToFile;
/**
 * 获取log文件路径用于上传或者分享
 * @return log文件路径
 */
- (NSString *)writeLog_logFilePath;
/**
 * 通过社交平台分享log文件
 */
- (void)writeLog_shareLogFile;

@end

NS_ASSUME_NONNULL_END
