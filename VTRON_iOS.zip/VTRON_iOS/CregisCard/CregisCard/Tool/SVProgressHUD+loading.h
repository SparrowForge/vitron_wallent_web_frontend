//
//  SVProgressHUD+loading.h
//  CregisCard
//
//  Created by 孙良 on 2024/10/29.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "SVProgressHUD.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVProgressHUD (loading)

+(void)customShowWithStyle;//带有加载动效
+(void)customShowWithNone;//完全透明不可见
//带有加载动效,带文字
+(void)customShowWithStyleWithStatus:(NSString*)status;
@end

NS_ASSUME_NONNULL_END
