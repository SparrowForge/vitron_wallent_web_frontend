#import <UIKit/UIKit.h>

//@interface RollingNumberLabel : UILabel
//
///// 设置滚动的目标数值（入参为两位小数的字符串）
//- (void)rollToNumberWithString:(NSString *)targetNumberString;
//
//@end

#import "RollingNumberLabel.h"

@interface RollingNumberLabel ()

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) double startNumber;
@property (nonatomic, assign) double targetNumber;
@property (nonatomic, assign) NSTimeInterval duration;
@property (nonatomic, assign) NSTimeInterval elapsedTime;

@end

@implementation RollingNumberLabel

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.duration = 1.0; // 默认动画持续时间
        self.font = [UIFont systemFontOfSize:34];
    }
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.duration = 1.0; // 默认动画持续时间
    self.font = [UIFont systemFontOfSize:34];
    
}
- (void)rollToNumberWithString:(NSString *)targetNumberString {
    // 设置初始数值
    self.startNumber = [self.text doubleValue];
    self.targetNumber = [targetNumberString doubleValue];
    self.elapsedTime = 0; // 确保动画开始时重置

    // 取消之前的定时器
    [self.timer invalidate];
    self.timer = nil;

    // 创建新的定时器，每隔 0.02 秒执行一次 updateNumber
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.02 target:self selector:@selector(updateNumber) userInfo:nil repeats:YES];
}

- (void)updateNumber {
    // 每次更新增加时间
    self.elapsedTime += 0.02;
    
    // 如果动画时间已结束，则停止定时器并设置最终值
    if (self.elapsedTime >= self.duration) {
        [self.timer invalidate];
        self.timer = nil;
        [self updateLabelWithNumber:self.targetNumber];
    } else {
        // 计算当前显示的数字
        double currentNumber = self.startNumber + (self.targetNumber - self.startNumber) * (self.elapsedTime / self.duration);
        [self updateLabelWithNumber:currentNumber];
    }
}

- (void)updateLabelWithNumber:(double)number {
    // 格式化字符串
    NSString *formattedString = [NSString stringWithFormat:@"%.2f", number];

    // 拆分整数和小数部分
    NSArray<NSString *> *components = [formattedString componentsSeparatedByString:@"."];
    NSString *integerPart = components[0];
    NSString *decimalPart = components.count > 1 ? components[1] : @"00";

    // 设置富文本样式
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@.%@", integerPart, decimalPart]];
    [attributedString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Helvetica-Bold" size:34] range:NSMakeRange(0, integerPart.length)];
    [attributedString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Helvetica-Bold" size:25] range:NSMakeRange(integerPart.length + 1, decimalPart.length)];
    
    self.attributedText = attributedString;
}

-(void)setLastTargetNumberString:(NSString*)targetNumberString{
    
    [self updateLabelWithNumber:[targetNumberString doubleValue]];
    
}





@end
