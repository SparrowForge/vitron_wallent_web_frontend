//
//  UIColor+TYColor.h
//  Work
//
//  Created by sunliang on 2021/5/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (TYColor)
#pragma mark 主题颜色
+(UIColor *)baseColor;
#pragma mark 全局主要按钮颜色
+(UIColor *)mainBtnColor;
#pragma mark 错误、警示等颜色
+(UIColor *)alertColor;
#pragma mark 辅色，默认是主题颜色
+(UIColor *)auxiliaryColor;
#pragma mark 行情上涨
+(UIColor *)roseColor;
#pragma mark 行情下跌
+(UIColor *)fallColor;
#pragma mark 警告
+(UIColor *)warningColor;
#pragma mark 主背景
+(UIColor *)mainBackGroundColor;
#pragma mark 次级背景
+(UIColor *)secondaryBackGroundColor;
#pragma mark 主文本颜色
+(UIColor *)mainTextColor;
#pragma mark 次级文本颜色
+(UIColor *)secondaryTextColor;
#pragma mark 线条颜色（较浅的）
+(UIColor *)lineLightColor;
#pragma mark 线条颜色（较深的,用于导航、Tabbar）
+(UIColor *)lineDarkColor;
#pragma mark 阴影描边颜色（较浅的，常规，导航，Tab）
+(UIColor *)shadowLightBorderColor;
#pragma mark 阴影描边颜色（较深的，弹窗）
+(UIColor *)shadowDarkBorderColor;
#pragma mark 全屏背景
+(UIColor *)fullScreenBackgroundColor;
#pragma mark tabbar选中字体颜色
+(UIColor *)tabbarSelectedBtnColor;
#pragma mark tabbar未选中字体颜色
+(UIColor *)tabbarUnSelectedBtnColor;
#pragma mark tableView背景颜色
+(UIColor *)tableViewBackGroundColor;
@end

NS_ASSUME_NONNULL_END
