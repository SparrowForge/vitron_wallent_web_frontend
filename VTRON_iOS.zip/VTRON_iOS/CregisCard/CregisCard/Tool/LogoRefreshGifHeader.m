//
//  LogoRefreshGifHeader.m
//  CregisCard
//
//  Created by sunliang on 2024/12/9.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "LogoRefreshGifHeader.h"

@implementation LogoRefreshGifHeader

#pragma mark - 重写方法
#pragma mark 基本设置
- (void)prepare
{
    [super prepare];
    [self setImages:self.refreshImages duration:2.0 forState:MJRefreshStateRefreshing];
    [self setImages:self.normalImages duration:1.0 forState:MJRefreshStateIdle];
    [self setImages:self.normalImages duration:1.0 forState:MJRefreshStatePulling];
    
}

- (void)placeSubviews {
    [super placeSubviews];
    self.mj_h=60;
    // 自定义布局，调整 gifView 的位置和大小
    self.gifView.frame = CGRectMake(0, 0, self.bounds.size.width, 60);
    self.gifView.contentMode = UIViewContentModeScaleAspectFit;//重要
    //self.gifView.backgroundColor=[UIColor yellowColor];
}



// 普通状态下的图片
- (NSMutableArray *)normalImages
{
 
    if (!_normalImages) {
        // 初始化数组，并设置关联对象
        _normalImages = [NSMutableArray array];
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"mo-0.png"]];
        [_normalImages addObject:image];
      
    }
    return _normalImages;
}

//正在刷新状态下的图片
- (NSMutableArray *)refreshImages
{
   
      if (!_refreshImages) {
          // 初始化数组，并设置关联对象
          _refreshImages = [NSMutableArray array];
          for (NSUInteger i = 0; i<20; i++) {

              NSString*imageName=[NSString stringWithFormat:@"mo-%ld", i];
            //  NSLog(@"正在刷新状态下的图片");
                UIImage *image = [UIImage imageNamed:imageName];
              if (image) {  // 检查 image 是否为 nil
                     [_refreshImages addObject:image];
                  }
                else {
                              NSLog(@"无法找到图片：%@", imageName);  // 输出日志，方便排查问题
                     }
              }
          
 
      }
      return _refreshImages;
}

@end
