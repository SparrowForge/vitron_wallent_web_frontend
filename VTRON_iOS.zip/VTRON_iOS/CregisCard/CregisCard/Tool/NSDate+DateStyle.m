//
//  NSDate+DateStyle.m
//  Work
//
//  Created by sunliang on 2021/10/21.
//

#import "NSDate+DateStyle.h"
static const unsigned componentFlags = (NSCalendarUnitYear| NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekOfMonth |  NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekday | NSCalendarUnitWeekdayOrdinal);

@implementation NSDate (DateStyle)

+ (NSString *)UTdateStyleCommentTimeIntervalToDateString:(NSString *)timeInterval{
   
    if (timeInterval.length<10) {
        return @"";
    }
    NSMutableString  *mutabletimeInterval=[[NSMutableString alloc]initWithString:timeInterval];
    [mutabletimeInterval insertString:@"." atIndex:10];
    NSTimeInterval timeInter = mutabletimeInterval.doubleValue;
    
    NSDate *createDate = [NSDate dateWithTimeIntervalSince1970:timeInter];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";// HH:mm:ss
    NSString *dateStr = [formatter stringFromDate:createDate];
    NSDateComponents *detalCmp = [createDate detalDateWithNow];
    
    if ([createDate isThisYear]) {
        if ([createDate isToday]) {
            if (detalCmp.hour >= 1) { // 大于1小时
                dateStr = [NSString stringWithFormat:@"%ld%@",(long)detalCmp.hour,LocalizationKey(@"小时前")];
            } else if (detalCmp.minute > 1) { // 大于1分钟
                dateStr = [NSString stringWithFormat:@"%ld%@",(long)detalCmp.minute,LocalizationKey(@"分钟前")];
            } else { // 刚刚
                dateStr = LocalizationKey(@"刚刚");
            }
        } else if ([createDate isYesterday]) { //昨天
            formatter.dateFormat = @"HH:mm";
            dateStr = [formatter stringFromDate:createDate];
            dateStr=[NSString stringWithFormat:@"%@%@",LocalizationKey(@"昨天"),dateStr];
            
            
        } else { // 昨天之前
            formatter.dateFormat = @"MM-dd HH:mm";
            dateStr = [formatter stringFromDate:createDate];
        }
    }
    return dateStr;
}

- (NSDateComponents *)detalDateWithNow{
    // 判断下发布日期 与 当前日期 小时，分差值
    NSCalendar *currentCalendar = [NSCalendar currentCalendar];
    NSInteger unit = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    
    // 获取两个日期的差值，获取发布日期与当前日期差值
    return [currentCalendar components:unit  fromDate:self toDate:[NSDate date] options:NSCalendarWrapComponents];
}
- (BOOL) isThisYear{
    NSDateComponents *components1 = [[NSDate currentCalendar] components:NSCalendarUnitYear fromDate:self];
    NSDateComponents *components2 = [[NSDate currentCalendar] components:NSCalendarUnitYear fromDate:[NSDate date]];
    return (components1.year == components2.year);
}
- (BOOL) isToday{
    NSDateComponents *components1 = [[NSDate currentCalendar] components:componentFlags fromDate:self];
    NSDateComponents *components2 = [[NSDate currentCalendar] components:componentFlags fromDate:[NSDate date]];
    return ((components1.year == components2.year) &&
            (components1.month == components2.month) &&
            (components1.day == components2.day));
}

- (BOOL) isYesterday{
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    [dateComponents setDay:-1];
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:[NSDate date] options:0];
    
    NSDateComponents *components1 = [[NSDate currentCalendar] components:componentFlags fromDate:self];
    NSDateComponents *components2 = [[NSDate currentCalendar] components:componentFlags fromDate:newDate];
    return ((components1.year == components2.year) &&
            (components1.month == components2.month) &&
            (components1.day == components2.day));
}
+ (NSCalendar *) currentCalendar{
    static NSCalendar *sharedCalendar = nil;
    if (!sharedCalendar)
        sharedCalendar = [NSCalendar autoupdatingCurrentCalendar];
    return sharedCalendar;
}

@end
