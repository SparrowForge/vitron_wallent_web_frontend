//
//  NSString+URLProcessing.m
//  CregisCard
//
//  Created by sunliang on 2025/5/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "NSString+URLProcessing.h"

@implementation NSString (URLProcessing)
- (NSString *)obfuscatedURLPathComponent {
    // 1. 检查字符串是否为空
    if (self.length == 0) {
        return @"";
    }
    
    // 2. 解析URL
    NSURL *url = [NSURL URLWithString:self];
    if (!url) {
        return @"";
    }
    
    NSString *path = url.path;
    if (path.length == 0) {
        return @"";
    }
    
    // 3. 分割路径组件
    NSArray *pathComponents = [path componentsSeparatedByString:@"/"];
    NSMutableArray *filteredComponents = [NSMutableArray array];
    
    // 过滤掉空字符串
    for (NSString *component in pathComponents) {
        if (component.length > 0) {
            [filteredComponents addObject:component];
        }
    }
    
    // 4. 处理路径组件
    if (filteredComponents.count == 0) {
        return @"";
    }
    
    // 只有一个路径组件的情况
    if (filteredComponents.count == 1) {
        NSString *lastComponent = filteredComponents.lastObject;
        if (lastComponent.length <= 2) {
            return [NSString stringWithFormat:@"%@***", lastComponent];
        } else {
            NSString *prefix = [lastComponent substringToIndex:2];
            NSString *suffix = [lastComponent substringFromIndex:MAX((NSInteger)lastComponent.length-2, 0)];
            return [NSString stringWithFormat:@"%@***%@", prefix, suffix];
        }
    }
    
    // 多个路径组件的情况
    NSString *secondLastComponent = filteredComponents[filteredComponents.count-2];
    NSString *lastComponent = filteredComponents.lastObject;
    
    NSString *prefix = secondLastComponent.length >= 2 ? [secondLastComponent substringToIndex:2] : secondLastComponent;
    NSString *suffix = lastComponent.length >= 2 ? [lastComponent substringFromIndex:MAX((NSInteger)lastComponent.length-2, 0)] : lastComponent;
    
    return [NSString stringWithFormat:@"%@***%@", prefix, suffix];
}
@end
