//
//  NSBundle+ImageBundle.h
//  CregisCard
//
//  Created by sunliang on 2022/4/8.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (UBTrackerImageBundle)

/// 加载Bundle中图片
/// @param name 图片名字
+ (UIImage*)getBundleImageWithName:(NSString*)name;
/// imageNamed方式加载图片
/// @param name 图片名字
+ (UIImage*)bundleImageNamed:(NSString*)name;
@end

NS_ASSUME_NONNULL_END
