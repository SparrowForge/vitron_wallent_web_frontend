//
//  UIColor+TYColor.m
//  Work
//
//  Created by sunliang on 2021/5/10.
//

#import "UIColor+TYColor.h"

@implementation UIColor (TYColor)

#pragma mark 黑夜模式颜色选择
+ (UIColor *)darkModeLightColor:(UIColor *)lightColor withDarkColor:(UIColor *)darkColor {
    if(IsDarkMode) {
        
        return darkColor;
    } else {
        
        return lightColor;
    }
}
#pragma mark 主题颜色
+(UIColor *)baseColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0xE11D53, 1) withDarkColor:UIColorFromHexWithAlpha(0xE11D53, 1)];
}

#pragma mark 全局主要按钮颜色
+(UIColor *)mainBtnColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0x000000, 1) withDarkColor:UIColorFromHexWithAlpha(0x000000, 1)];
}

#pragma mark 错误、警示等颜色
+(UIColor *)alertColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0xEC312C, 1) withDarkColor:UIColorFromHexWithAlpha(0xEC312C, 1)];
}

#pragma mark 辅色，默认是主题颜色
+(UIColor *)auxiliaryColor
{
    return [UIColor baseColor];
}


#pragma mark 行情上涨
+(UIColor *)roseColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0xD75055, 1) withDarkColor:UIColorFromHexWithAlpha(0xD75055, 1)];
}


#pragma mark 行情下跌
+(UIColor *)fallColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0x0AA06E, 1) withDarkColor:UIColorFromHexWithAlpha(0x0AA06E, 1)];
}

#pragma mark 警告
+(UIColor *)warningColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0xFACD5F, 1) withDarkColor:UIColorFromHexWithAlpha(0xFACD5F, 1)];
}

#pragma mark 主背景
+(UIColor *)mainBackGroundColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0xFFFFFF, 1) withDarkColor:UIColorFromHexWithAlpha(0x141516, 1)];
}

#pragma mark 次级背景
+(UIColor *)secondaryBackGroundColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0xFFFFFF, 1) withDarkColor:UIColorFromHexWithAlpha(0x222324, 1)];
}

#pragma mark 主文本颜色
+(UIColor *)mainTextColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0x000000, 1) withDarkColor:UIColorFromHexWithAlpha(0xFFFFFF, 1)];
}

#pragma mark 次级文本颜色
+(UIColor *)secondaryTextColor
{
    return [self darkModeLightColor:UIColorFromHexWithAlpha(0x000000, 0.6) withDarkColor:UIColorFromHexWithAlpha(0xFFFFFF, 0.6)];
}


#pragma mark 线条颜色（较浅的）
+(UIColor *)lineLightColor
{
    return [self darkModeLightColor:RGB(0, 0, 0, 0.1) withDarkColor:RGB(255, 255, 255, 0.1)];
}

#pragma mark 线条颜色（较深的,用于导航、Tabbar）
+(UIColor *)lineDarkColor
{
    return [self darkModeLightColor:RGB(0, 0, 0, 0.2) withDarkColor:RGB(255, 255, 255, 0.2)];
}

#pragma mark 阴影描边颜色（较浅的，常规，导航，Tab）
+(UIColor *)shadowLightBorderColor
{
    return [self darkModeLightColor:RGB(0, 0, 0, 0.04) withDarkColor:RGB(255, 255, 255, 0.04)];
}

#pragma mark 阴影描边颜色（较深的，弹窗）
+(UIColor *)shadowDarkBorderColor
{
    return [self darkModeLightColor:RGB(0, 0, 0, 0.04) withDarkColor:RGB(255, 255, 255, 0.04)];
}

#pragma mark 全屏背景
+(UIColor *)fullScreenBackgroundColor
{
    return [self darkModeLightColor:RGB(255, 255, 255, 0.1) withDarkColor:RGB(20, 21, 22, 0.1)];
}

#pragma mark tabbar选中字体颜色
+(UIColor *)tabbarSelectedBtnColor
{
    return UIColorFromHexWithAlpha(0x0066FF, 1);
}

#pragma mark tabbar未选中字体颜色
+(UIColor *)tabbarUnSelectedBtnColor
{
    return RGB(1,1,1,1);
  
}

#pragma mark tableView背景颜色
+(UIColor *)tableViewBackGroundColor
{
    return RGB(246,247,247,1);
  
}
@end
