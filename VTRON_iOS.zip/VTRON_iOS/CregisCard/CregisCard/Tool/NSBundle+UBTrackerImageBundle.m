//
//  NSBundle+ImageBundle.m
//  CregisCard
//
//  Created by sunliang on 2022/4/8.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "NSBundle+UBTrackerImageBundle.h"

#define UBTrackerBundleName @"CregisCard"
@implementation NSBundle (UBTrackerImageBundle)

+(NSString*)sdkBundlePath{
   NSString *path = [[NSBundle mainBundle] pathForResource:UBTrackerBundleName
                                                          ofType:@"bundle"];
   return path;
}

+ (UIImage*)getBundleImageWithName:(NSString*)name{
   NSString *path = [[self sdkBundlePath] stringByAppendingPathComponent:[NSString stringWithFormat:@"images/%@",name]];
   UIImage *image = [UIImage imageWithContentsOfFile:path];
   return image;
}

+ (UIImage*)bundleImageNamed:(NSString*)name{

    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.bundle/images/%@",UBTrackerBundleName,name]];
   return image;
}
@end
