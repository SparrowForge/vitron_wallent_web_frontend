//
//  PingManager.h
//  Badtest
//
//  Created by sunliang on 2025/5/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PingManager : NSObject
- (instancetype)initWithHost:(NSString *)host
                       count:(NSInteger)count
                     timeout:(NSTimeInterval)timeout
              resultCallback:(void (^)(NSInteger successCount, double averageDelay))callback;
- (void)startPing;
-(void)stopPing;
@end

NS_ASSUME_NONNULL_END
