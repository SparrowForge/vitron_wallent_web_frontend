#import "PingManager.h"
#import "SimplePing.h"
#import "Toast/UIView+Toast.h"

@interface PingManager () <SimplePingDelegate>

@property (nonatomic, strong) SimplePing *pinger;
@property (nonatomic, copy) NSString *host;
@property (nonatomic, assign) NSInteger pingCount;
@property (nonatomic, assign) NSTimeInterval timeout;

@property (nonatomic, strong) NSMutableArray<NSNumber *> *successDelays;
@property (nonatomic, assign) NSInteger currentCount;
@property (nonatomic, strong) NSDate *startTime;

@property (nonatomic, strong) dispatch_source_t timeoutTimer;
@property (nonatomic, strong) dispatch_source_t startTimeoutTimer;

@property (nonatomic, copy) void (^resultHandler)(NSInteger successCount, double averageDelay);

@end

@implementation PingManager

- (instancetype)initWithHost:(NSString *)host
                       count:(NSInteger)count
                     timeout:(NSTimeInterval)timeout
              resultCallback:(void (^)(NSInteger successCount, double averageDelay))callback {
    if (self = [super init]) {
        self.host = host;
        self.pingCount = count;
        self.timeout = timeout;
        self.successDelays = [NSMutableArray array];
        self.resultHandler = callback;
    }
    return self;
}

- (void)startPing {
    self.pinger = [[SimplePing alloc] initWithHostName:self.host];
    self.pinger.delegate = self;
    self.pinger.addressStyle = SimplePingAddressStyleAny;
    [self.pinger start];
    
    [self startPingStartTimeoutMonitor];
}

- (void)sendOnePing {
    NSLog(@"发送第 %ld 次 ping", (long)self.currentCount + 1);
    self.startTime = [NSDate date];
    [self.pinger sendPingWithData:nil];

    [self startTimeoutMonitor];
}

- (void)startTimeoutMonitor {
    [self cancelTimeoutMonitor];

    dispatch_queue_t queue = dispatch_get_main_queue();
    self.timeoutTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(self.timeoutTimer, dispatch_time(DISPATCH_TIME_NOW, self.timeout * NSEC_PER_SEC), DISPATCH_TIME_FOREVER, 0);
    dispatch_source_set_event_handler(self.timeoutTimer, ^{
        NSLog(@"第 %ld 次 ping 超时", (long)self.currentCount + 1);
        [self checkIfFinished]; // 注意：未添加延迟
    });
    dispatch_resume(self.timeoutTimer);
}

- (void)cancelTimeoutMonitor {
    if (self.timeoutTimer) {
        dispatch_source_cancel(self.timeoutTimer);
        self.timeoutTimer = nil;
    }
}
//添加的全局超时监听机制，防止没有失败回调时候的兜底操作
- (void)startPingStartTimeoutMonitor {
    [self cancelPingStartTimeoutMonitor];

    dispatch_queue_t queue = dispatch_get_main_queue();
    self.startTimeoutTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(self.startTimeoutTimer, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.timeout * NSEC_PER_SEC)), DISPATCH_TIME_FOREVER, 0);
    dispatch_source_set_event_handler(self.startTimeoutTimer, ^{
        NSLog(@"启动阶段超时，未进入 didStartWithAddress 或 didFailWithError");
        [self.pinger stop];
        if (self.resultHandler) {
            self.resultHandler(0, 0);
        }
    });
    dispatch_resume(self.startTimeoutTimer);
}

- (void)cancelPingStartTimeoutMonitor {
    if (self.startTimeoutTimer) {
        dispatch_source_cancel(self.startTimeoutTimer);
        self.startTimeoutTimer = nil;
    }
}

- (void)checkIfFinished {
    self.currentCount++;
    [self cancelTimeoutMonitor];

    if (self.currentCount >= self.pingCount) {
        [self.pinger stop];
        [self printResult];
    } else {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self sendOnePing];
        });
    }
}

- (void)printResult {
    double total = 0;
    for (NSNumber *delay in self.successDelays) {
        total += delay.doubleValue;
    }
    NSInteger successCount = self.successDelays.count;
    double avg = successCount > 0 ? total / successCount : 0;
    
    NSLog(@"✅ ping成功次数: %ld, 平均延迟: %.2f ms", (long)successCount, avg);
    
    if (self.resultHandler) {
        self.resultHandler(successCount, avg);
    }
    
   // [[UIApplication sharedApplication].keyWindow makeToast:[NSString stringWithFormat:@"✅ 成功次数: %ld, 平均延迟: %.2f ms", (long)successCount, avg]];
}

#pragma mark - SimplePingDelegate

- (void)simplePing:(SimplePing *)pinger didStartWithAddress:(NSData *)address {
    NSLog(@"开始ping %@", self.host);
    [self cancelPingStartTimeoutMonitor];
    [self sendOnePing];
}

- (void)simplePing:(SimplePing *)pinger didFailWithError:(NSError *)error {
    NSLog(@"Ping失败: %@", error.localizedDescription);
    //[[UIApplication sharedApplication].keyWindow makeToast:[NSString stringWithFormat:@"Ping失败--%ld--%@", (long)self.currentCount,self.resultHandler]];
    [self.pinger stop];
    [self cancelPingStartTimeoutMonitor];

    if (self.currentCount == 0 && self.resultHandler) {
        self.resultHandler(0, 0);
    }
}

- (void)simplePing:(SimplePing *)pinger didSendPacket:(NSData *)packet sequenceNumber:(uint16_t)sequenceNumber {
    NSLog(@"已发送 Ping 序号: %u", sequenceNumber);
}

- (void)simplePing:(SimplePing *)pinger didReceivePingResponsePacket:(NSData *)packet sequenceNumber:(uint16_t)sequenceNumber {
    NSTimeInterval delay = [[NSDate date] timeIntervalSinceDate:self.startTime] * 1000; // ms
    NSLog(@"收到 ping 响应，序号: %u，延迟: %.2f ms", sequenceNumber, delay);
  //  [[UIApplication sharedApplication].keyWindow makeToast:[NSString stringWithFormat:@"收到 ping 响应，序号: %u，延迟: %.2f ms", sequenceNumber, delay] duration:1 position:CSToastPositionTop];
    
    [self.successDelays addObject:@(delay)];
    [self checkIfFinished];
}
//主动停止Ping
-(void)stopPing{
    
    if (self.pinger) {
            [self.pinger stop];
            self.pinger = nil;
        }
        [self cancelTimeoutMonitor];
        [self cancelPingStartTimeoutMonitor];
        self.resultHandler = nil; // 解除 block 引用，避免循环引用
}
@end
