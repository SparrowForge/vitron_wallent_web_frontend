//
//  UIViewController+UBTrackerStyle.h
//  CregisCard
//
//  Created by sunliang on 2022/4/26.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (UBTrackerStyle)
//系统提示框
-(void)addUIAlertControlWithTileString:(NSString *)titleStr WithSubString:(NSString *)subString withActionBlock:(void(^)(void))actionBlock WithActionString:(NSString *)actionTitleStr andCancel:(void(^)(void))cancelBlock WithCancelString:(NSString *)cancelTitleStr;
//自定义弹出框
-(void)addCustomUIAlertControlWithString:(NSString *)titleString  WithSubString:(NSString *)subString Withalignment:(NSTextAlignment)alignment withActionBlock:(void(^)(void))actionBlock WithActionString:(NSString *)actionTitleStr  andCancel:(void(^)(void))cancelBlock WithCancelString:(NSString *)cancelTitleStr;
@end

NS_ASSUME_NONNULL_END
