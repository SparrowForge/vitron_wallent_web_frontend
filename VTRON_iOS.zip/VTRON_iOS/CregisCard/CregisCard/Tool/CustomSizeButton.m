//
//  CustomSizeButton.m
//  CregisCard
//
//  Created by 孙良 on 2023/5/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CustomSizeButton.h"

@implementation CustomSizeButton

- (void)setTitle:(NSString *)title image:(UIImage *)image imagePosition:(CustomButtonImagePosition)position {
    [self setTitle:title forState:UIControlStateNormal];
    [self setImage:image forState:UIControlStateNormal];
    self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;

    // 设置图片和文字的间距
    CGFloat spacing = 10.0;
    self.imageEdgeInsets = UIEdgeInsetsZero;
    self.titleEdgeInsets = UIEdgeInsetsZero;
    self.contentEdgeInsets = UIEdgeInsetsZero;
    [self setTitleColor:[UIColor baseColor] forState:UIControlStateNormal];
    self.titleLabel.font=[UIFont systemFontOfSize:15];
    // 根据图片和文字的尺寸自适应按钮的宽度
    CGSize imageSize = image.size;
    CGSize titleSize = [title sizeWithAttributes:@{NSFontAttributeName:self.titleLabel.font}];
    CGFloat buttonWidth = imageSize.width + titleSize.width + spacing;
    CGFloat buttonHeight = MAX(imageSize.height, titleSize.height);
    self.frame = CGRectMake(0, 0, buttonWidth, buttonHeight);
    
    switch (position) {
        case CustomButtonImagePositionLeft: {
            self.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, spacing);
            self.titleEdgeInsets = UIEdgeInsetsMake(0, spacing, 0, 0);
            break;
        }
        case CustomButtonImagePositionRight: {
            self.imageEdgeInsets = UIEdgeInsetsMake(0, titleSize.width + spacing, 0, 0);
            self.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, imageSize.width + spacing);
            break;
        }
        case CustomButtonImagePositionTop: {
            CGFloat totalHeight = imageSize.height + titleSize.height + spacing;
            self.imageEdgeInsets = UIEdgeInsetsMake(-(totalHeight - imageSize.height), 0, 0, -titleSize.width);
            self.titleEdgeInsets = UIEdgeInsetsMake(0, -imageSize.width, -(totalHeight - titleSize.height), 0);
            break;
        }
        case CustomButtonImagePositionBottom: {
            CGFloat totalHeight = imageSize.height + titleSize.height + spacing;
            self.imageEdgeInsets = UIEdgeInsetsMake((totalHeight - imageSize.height), 0, 0, -titleSize.width);
            self.titleEdgeInsets = UIEdgeInsetsMake(-(totalHeight - titleSize.height), -imageSize.width, 0, 0);
            break;
        }
        default:
            break;
    }
}

@end
