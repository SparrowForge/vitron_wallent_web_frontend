//
//  RollingNumberLabel.h
//  CregisCard
//
//  Created by 孙良 on 2024/10/31.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RollingNumberLabel : UILabel
/// 设置滚动的目标数值（支持两位小数）
- (void)rollToNumberWithString:(NSString *)targetNumberString;

-(void)setLastTargetNumberString:(NSString*)targetNumberString;
@end

NS_ASSUME_NONNULL_END
