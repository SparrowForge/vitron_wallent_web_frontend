//
//  UIImageView+UBTrackerGetVideoPreView.m
//  Badtest
//
//  Created by 孙良 on 2023/4/18.
//

#import "UIImageView+UBTrackerGetVideoPreView.h"
#import "NSString+UBTrackerMD5.h"
@implementation UIImageView (UBTrackerGetVideoPreView)
//获取视频第一帧图片优化（异步加载数据）
-(void)getVideoPreViewImageURL:(NSURL *)path forImageView:(UIImageView *)imageView placeHolderImage:(UIImage *_Nullable)placeHolder
{
    
  //  path=[NSURL URLWithString:@"https://23dgj.dgg"];
//    NSString *name = [NSString getmd5Str:[path absoluteString]];//视频链接转MD5作为图片的名字
//    NSString *PATH = [NSString stringWithFormat:@"%@/Documents/UBTrackerFolder/UBTrackervideoFolder/%@.png",NSHomeDirectory(),name];
//    UIImage *imagePath = [[UIImage alloc] initWithContentsOfFile:PATH];
    UIImage *imagePath =[[UBTracker_YYImageCache sharedCache] getImageForKey:path.absoluteString];
    
    if (imagePath) {
        //本地有缓存图片，加载本地图片并return
        imageView.image = imagePath;
        return;
    }else{
        //本地没有缓存图片，先加载占位图
        imageView.image = placeHolder;
    }
    
    dispatch_group_t group = dispatch_group_create();
    __block UIImage *videoImage;
    dispatch_group_async(group, dispatch_get_global_queue(0, 0), ^{
        AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:path options:nil];
        AVAssetImageGenerator *assetGen = [[AVAssetImageGenerator alloc] initWithAsset:asset];
        
        assetGen.appliesPreferredTrackTransform = YES;
        CMTime time = CMTimeMakeWithSeconds(0.0, 2);
        NSError *error = nil;
        CMTime actualTime;
        CGImageRef image = [assetGen copyCGImageAtTime:time actualTime:&actualTime error:&error];
        videoImage = [[UIImage alloc] initWithCGImage:image];
        CGImageRelease(image);
        if(!videoImage){
            return;
        }
        [[UBTracker_YYImageCache sharedCache] setImage:videoImage imageData:nil forKey:path.absoluteString withType:UBTracker_YYImageCacheTypeAll];//用YYWebImage缓存本地
//        //创建文件夹
//        NSString *folder = [NSHomeDirectory() stringByAppendingPathComponent:@"/Documents/UBTrackerFolder/UBTrackervideoFolder"];
//        NSError*error1;
//         [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:&error1];
//
//        NSError*error2;
//        BOOL iScreat= [UIImagePNGRepresentation(videoImage) writeToFile:PATH options:NSAtomicWrite error:&error2];
        //NSLog(@"是否成功--%d--%@",iScreat,error2);
        
    });
    
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        //主线程更新UI
        if(videoImage){
            imageView.image = videoImage;
        }else{
            //加载失败
            imageView.image=UIIMAGE(@"chat_VideoFail");
        }
        
    });
}


//获取本地视频第一帧图片优化（异步加载数据）
-(void)getLocalVideoPreViewImageURL:(NSURL *)path forImageView:(UIImageView *)imageView placeHolderImage:(UIImage *_Nullable)placeHolder  withfromType:(int)fromType
{
//    NSString *name = [NSString getmd5Str:[path absoluteString]];//视频链接转MD5作为图片的名字
//    NSString *PATH = [NSString stringWithFormat:@"%@/Documents/UBTrackerFolder/UBTrackervideoFolder/%@.png",NSHomeDirectory(),name];
//    UIImage *imagePath = [[UIImage alloc] initWithContentsOfFile:PATH];
    UIImage *imagePath =[[UBTracker_YYImageCache sharedCache] getImageForKey:path.absoluteString];
    if (imagePath) {
        //本地有缓存图片，加载本地图片并return
        imageView.image = imagePath;
        return;
    }else{
        //本地没有缓存图片，先加载占位图
        imageView.image = placeHolder;
    }
    
    dispatch_group_t group = dispatch_group_create();
    __block UIImage *videoImage;
    dispatch_group_async(group, dispatch_get_global_queue(0, 0), ^{

           AVAsset *asset = [AVAsset assetWithURL:path];
           AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc]initWithAsset:asset];
           imageGenerator.appliesPreferredTrackTransform = YES;
           CMTime time = CMTimeMake(0, 1);
           NSError *error;
           CGImageRef imageRef = [imageGenerator copyCGImageAtTime:time actualTime:NULL error:&error];
          videoImage = [UIImage imageWithCGImage:imageRef];
           CGImageRelease(imageRef);  // CGImageRef won't be released by ARC
          if(!videoImage){
            return;
         }
        [[UBTracker_YYImageCache sharedCache] setImage:videoImage imageData:nil forKey:path.absoluteString withType:UBTracker_YYImageCacheTypeAll];//用YYWebImage缓存本地
//        //创建文件夹
//        NSString *folder = [NSHomeDirectory() stringByAppendingPathComponent:@"/Documents/UBTrackerFolder/UBTrackervideoFolder"];
//        NSError*error1;
//         [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:&error1];
//
//        NSError*error2;
//        BOOL iScreat= [UIImagePNGRepresentation(videoImage) writeToFile:PATH options:NSAtomicWrite error:&error2];
      //  NSLog(@"是否成功--%d--%@",iScreat,error2);
        
    });
    
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        //主线程更新UI
        if(videoImage){
            imageView.image = videoImage;
        }else{
            //加载失败
            imageView.image=UIIMAGE(@"chat_VideoFail");
        }
    });
}


@end
