//
//  UIView+GetViewController.m
//  UBTrackerAnalytics
//
//  Created by sunliang on 2022/5/19.
//

#import "UIView+GetViewController.h"

@implementation UIView (GetViewController)
-(UIViewController *)getViewController {
   UIResponder *responder = self;
   while ((responder = [responder nextResponder])) {
       if ([responder isKindOfClass:[UIViewController class]]) {
           return (UIViewController *)responder;
       }
   }
   return  nil;
}

@end
