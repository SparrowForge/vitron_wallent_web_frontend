//
//  UIViewController+navStyle.m
//  horizonLoan
//
//  Created by sunliang on 2017/9/30.
//  Copyright © 2017年 XinHuoKeJi. All rights reserved.
//

#import "UIViewController+navStyle.h"
#import <objc/runtime.h>
#import "ToolUtil.h"
#import "LoginController.h"
#import "BaseNavigationController.h"
#import "LogoRefreshGifHeader.h"

@implementation UIViewController (navStyle)

-(void)setNavigationControllerStyle{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];//去除导航栏黑线
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}
-(void)cancelNavigationControllerStyle{
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:nil];
}
static char *BackBtnKey = "backBtnKey";
- (void)setBackBtn:(UIButton *)backBtn {
    objc_setAssociatedObject(self, BackBtnKey, backBtn, OBJC_ASSOCIATION_ASSIGN);
}
- (UIButton *)backBtn {
    return objc_getAssociatedObject(self, BackBtnKey);
}

/// 集成nav上右侧的控件
/// @param pictureName 图片名
/// @param isChange 控件颜色是否随动
-(void)RightsetupNavgationItemWithpictureName:(NSString*)pictureName withColorIsChange:(BOOL)isChange{
    UIImage *aimage = [UIImage imageNamed:pictureName];
    UIImage *image = [aimage imageWithRenderingMode:isChange?UIImageRenderingModeAlwaysTemplate:UIImageRenderingModeAlwaysOriginal];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithImage:image style:UIBarButtonItemStylePlain target:self action:@selector(rightTouchEvent)];
    self.navigationItem.rightBarButtonItem = rightItem;
}
/// 集成nav上右侧的控件
/// @param pictureName 图片名
/// @param color 控件颜色
-(void)RightsetupNavgationItemWithpictureName:(NSString*)pictureName withColor:(UIColor *)color{
    UIImage *aimage = [UIImage imageNamed:pictureName];
    UIImage *image = [aimage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithImage:image style:UIBarButtonItemStylePlain target:self action:@selector(rightTouchEvent)];
    rightItem.tintColor = color;
    self.navigationItem.rightBarButtonItem = rightItem;
}
-(void)RightsetupNavgationItemWithImage:(UIImage*)picImage withColor:(UIColor*)color{
 
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithImage:picImage style:UIBarButtonItemStylePlain target:self action:@selector(rightTouchEvent)];
    rightItem.tintColor=color;
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)LeftsetupNavgationItemWithImage:(UIImage*)picImage withColor:(UIColor*)color{
 
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:picImage style:UIBarButtonItemStylePlain target:self action:@selector(LefttouchEvent)];
    leftItem.tintColor=color;
    self.navigationItem.leftBarButtonItem = leftItem;
}

-(void)rightTouchEvent{
    
    
}

//集成nav上左侧的控件
- (void)LeftsetupNavgationItemWithpictureName:(NSString*)pictureName{

    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(0, 0, 50, 50);
    [leftButton setImage:[UIImage imageNamed:pictureName] forState:UIControlStateNormal];
    leftButton.imageEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    [leftButton addTarget:self action:@selector(LefttouchEvent) forControlEvents:UIControlEventTouchUpInside];
    UIView *menuButtonContainer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    [menuButtonContainer addSubview:leftButton];

    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:menuButtonContainer];
    self.navigationItem.leftBarButtonItem = leftItem;
   
}

-(void)LefttouchEvent{
    
    
}
/** 导航左侧按钮-文字
 */
-(void)leftBarItemWithTitle:(NSString *)title{
    
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStylePlain target:self action:@selector(LefttouchEvent)];
    [item setTintColor:[UIColor whiteColor]];
    [item setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:14],NSFontAttributeName, nil] forState:UIControlStateNormal];
    [item setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:14],NSFontAttributeName, nil] forState:UIControlStateSelected];
    self.navigationItem.leftBarButtonItem = item;
    
}
/** 导航右侧按钮-文字
 */
-(void)rightBarItemWithTitle:(NSString *)title{
    
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStylePlain target:self action:@selector(rightTouchEvent)];
    [item setTintColor:[UIColor whiteColor]];
    [item setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:14],NSFontAttributeName, nil] forState:UIControlStateNormal];
    [item setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:14],NSFontAttributeName, nil] forState:UIControlStateSelected];
    self.navigationItem.rightBarButtonItem = item;
}
/** 导航右侧按钮-文字
 */
-(void)rightBarItemWithTitle:(NSString *)title color:(UIColor *)color;{
    
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStylePlain target:self action:@selector(rightTouchEvent)];
    [item setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:16],NSFontAttributeName,color,NSForegroundColorAttributeName,nil] forState:UIControlStateNormal];
    [item setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:16],NSFontAttributeName,color,NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    self.navigationItem.rightBarButtonItem = item;
}
// 返回按钮：自定义图片
-(void)backBtnNoNavBar:(BOOL)noNavBar normalBack:(BOOL)normalBack
{
    CGFloat ww=25, hh=28;
    //隐藏系统的
    //self.navigationItem.hidesBackButton = YES;
    //返回按钮
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0,0,ww, hh)];
    UIImage *image = [[UIImage imageNamed:@"returnBtn"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [backBtn setImage:image forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backNav:) forControlEvents:UIControlEventTouchUpInside];
    backBtn.tag = normalBack;
    backBtn.backgroundColor = [UIColor clearColor];
    if (noNavBar) {
        backBtn.frame = CGRectMake(10,27,ww, hh);
        [self.view addSubview:backBtn];
        self.backBtn = backBtn;
    }else{
        UIBarButtonItem *leftBarBtn= [[UIBarButtonItem alloc]initWithCustomView:backBtn];
        self.navigationItem.leftBarButtonItem= leftBarBtn;
        self.backBtn = backBtn;
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 11.0) {
            self.backBtn.contentHorizontalAlignment =UIControlContentHorizontalAlignmentLeft;
            [self.backBtn setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
        }
    }
}

// 返回按钮：白色图片
-(void)whitebackBtnNoNavBar:(BOOL)noNavBar normalBack:(BOOL)normalBack{
    
    CGFloat ww=25, hh=28;
    //隐藏系统的
    //self.navigationItem.hidesBackButton = YES;
    //返回按钮
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0,0,ww, hh)];
    [backBtn setImage:[UIImage imageNamed:@"returnBtn_white"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backNav:) forControlEvents:UIControlEventTouchUpInside];
    backBtn.tag = normalBack;
    backBtn.backgroundColor = [UIColor clearColor];
    if (noNavBar) {
        backBtn.frame = CGRectMake(10,27,ww, hh);
        [self.view addSubview:backBtn];
        self.backBtn = backBtn;
    }else{
        UIBarButtonItem *leftBarBtn= [[UIBarButtonItem alloc]initWithCustomView:backBtn];
        self.navigationItem.leftBarButtonItem= leftBarBtn;
        self.backBtn = backBtn;
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 11.0) {
            self.backBtn.contentHorizontalAlignment =UIControlContentHorizontalAlignmentLeft;
            [self.backBtn setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
        }
    }
    
    
}
-(void)backNav:(UIButton *)Btn {
    //正常返回
    if (Btn.tag==1) {
        [self.navigationController popViewControllerAnimated:NO];
    }
   else {
        //其他情况返回
        if (self.backBlock) {
            self.backBlock(Btn);
        }
    }
}

// BackBlock -> backBlock
- (BackBlock)backBlock {
    return objc_getAssociatedObject(self, @selector(backBlock));
}
- (void)setBackBlock:(BackBlock)backBlock {
    objc_setAssociatedObject(self,
                             @selector(backBlock),
                             backBlock,
                             OBJC_ASSOCIATION_COPY_NONATOMIC);
}

/** 下拉加载更多
 */
- (void)customHeadRefreshWithScrollerView:(UIScrollView *)scrol{
    WEAKSELF
    __weak UIScrollView*wealkSelfScrol=scrol;
    MJRefreshNormalHeader*header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf refreshHeaderAction];
            [wealkSelfScrol.mj_header endRefreshing];
        });
    }];
     // 往下拉的时候文字
    [header setTitle:LocalizationKey(@"下拉加载更多...") forState:MJRefreshStateIdle];
    // 松手时候的文字
    [header setTitle:LocalizationKey(@"松开加载更多...") forState:MJRefreshStatePulling];
    [header setTitle:LocalizationKey(@"正在加载更多中...") forState:MJRefreshStateRefreshing];
    [header setTitle:LocalizationKey(@"已经全部加载完毕") forState:MJRefreshStateNoMoreData];
    header.lastUpdatedTimeLabel.hidden = YES;
    scrol.mj_header =header;
    scrol.mj_header.automaticallyChangeAlpha = YES;
   
}


/** 下拉刷新
 */
- (void)headRefreshWithScrollerView:(UIScrollView *)scrol{
  
    [self headGIFRefreshWithScrollerView:scrol];
    return;
    WEAKSELF
    __weak UIScrollView*wealkSelfScrol=scrol;
    MJRefreshNormalHeader*mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf refreshHeaderAction];
            [wealkSelfScrol.mj_header endRefreshing];
        });
    }];
    scrol.mj_header =mj_header;
    // 设置文字
    [mj_header setTitle:LocalizationKey(@"下拉可以刷新") forState:MJRefreshStateIdle];
    [mj_header setTitle:LocalizationKey(@"松开立即刷新") forState:MJRefreshStatePulling];
    [mj_header setTitle:LocalizationKey(@"正在刷新数据中...") forState:MJRefreshStateRefreshing];
    mj_header.lastUpdatedTimeLabel.hidden = YES;//最后更新时间
   
//    mj_header.lastUpdatedTimeText = ^NSString * _Nonnull(NSDate * _Nullable lastUpdatedTime) {
//        return @"当前时间...";
//    };
    scrol.mj_header.automaticallyChangeAlpha = YES;
   
}


/** 下拉刷新
 */
- (void)headGIFRefreshWithScrollerView:(UIScrollView *)scrol{

    WEAKSELF
    __weak UIScrollView*wealkSelfScrol=scrol;
    LogoRefreshGifHeader*mj_header = [LogoRefreshGifHeader headerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf refreshHeaderAction];
            [wealkSelfScrol.mj_header endRefreshing];
        });
    }];

    mj_header.stateLabel.hidden=YES;
    mj_header.lastUpdatedTimeLabel.hidden = YES;//最后更新时间
    scrol.mj_header =mj_header;
    scrol.mj_header.automaticallyChangeAlpha = YES;
}

/** 上拉加载
 */
- (void)footRefreshWithScrollerView:(UIScrollView *)scrol{
    WEAKSELF
    __weak UIScrollView*wealkSelfScrol=scrol;
    MJRefreshBackNormalFooter*mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf refreshFooterAction];
            [wealkSelfScrol.mj_footer endRefreshing];// 结束刷新
        });
    }];
    scrol.mj_footer =mj_footer;
    // 设置文字
    [mj_footer setTitle:LocalizationKey(@"上拉可以加载更多") forState:MJRefreshStateIdle];
    [mj_footer setTitle:LocalizationKey(@"松开立即加载更多") forState:MJRefreshStatePulling];
    [mj_footer setTitle:LocalizationKey(@"正在加载更多的数据...") forState:MJRefreshStateRefreshing];
    [mj_footer setTitle:LocalizationKey(@"已经全部加载完毕") forState:MJRefreshStateNoMoreData];
    scrol.mj_footer.automaticallyHidden = YES;
}

- (void)refreshFooterAction{
    
}
- (void)refreshHeaderAction{
    
    
}

- (void)openLargeTitle {
    self.navigationController.navigationBar.frame = CGRectMake(0, 0, self.navigationController.navigationBar.bounds.size.width, 64);
}

-(void)hideNavBar{
    
    if (![NSProcessInfo.processInfo isOperatingSystemAtLeastVersion:(NSOperatingSystemVersion){9,4,0}]) {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    } else {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    }
    //去掉透明后导航栏下边的黑边
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.translucent = YES;
}
//MARK:--显示导航栏
-(void)showNavBar{
    if (![NSProcessInfo.processInfo isOperatingSystemAtLeastVersion:(NSOperatingSystemVersion){9,4,0}]) {
        [self.navigationController.navigationBar setBackgroundImage:nil forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    } else {
        [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    }
    [self.navigationController.navigationBar setShadowImage:nil];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.translucent = NO;

}


- (void)maskToCorner:(UIView *)view RoundingCorners:(UIRectCorner)corner cornerRedius:(CGSize)size {
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:view.bounds
                                                   byRoundingCorners:corner
                                                         cornerRadii:size];
    
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
    maskLayer.frame = view.bounds;
    maskLayer.path = maskPath.CGPath;
    view.layer.mask = maskLayer;
}
//MARK:隐藏导航栏黑线
-(void)hideNavigationBarBottomLine:(BOOL)hidden{
    //iOS10及以上的隐藏方法
    if ([UIDevice currentDevice].systemVersion.floatValue >= 10.0) {
        if ([self.navigationController.navigationBar respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)]) {
            NSArray *list=self.navigationController.navigationBar.subviews;
            for (id obj in list) {
                //10.0的系统字段不一样
                UIView *view =   (UIView*)obj;
                for (id obj2 in view.subviews) {
                    if ([obj2 isKindOfClass:[UIImageView class]]) {
                        UIImageView *image =  (UIImageView*)obj2;
                        if (image.frame.size.height <= 1) {
                            image.hidden = hidden;
                        }
                    }
                    
                    if ([obj2 isKindOfClass:[UIView class]]) {
                        UIView *view2 = (UIView *)obj2;
                        if (view2.frame.size.height <= 1) {
                            view2.hidden = hidden;
                        }
                    }
                }
            }
            
        }
        
        return;
    }
    //iOS10以下的隐藏方法
    if ([self.navigationController.navigationBar respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)]){
        NSArray *list = self.navigationController.navigationBar.subviews;
        for (id obj in list) {
            if ([obj isKindOfClass:[UIImageView class]]) {
                UIImageView *imageView = (UIImageView *)obj;
                NSArray *list2 = imageView.subviews;
                for (id obj2 in list2) {
                    if ([obj2 isKindOfClass:[UIImageView class]]) {
                        UIImageView *imageView2 = (UIImageView *)obj2;
                        if (imageView2.frame.size.height <= 1) {
                            imageView2.hidden = hidden;
                        }
                    }
                    if ([obj2 isKindOfClass:[UIView class]]) {
                        UIView *view2 = (UIView *)obj2;
                        if (view2.frame.size.height <= 1) {
                            view2.hidden = hidden;
                        }
                    }
                }
            }
        }
    }
}

- (void)makeFrom:(UIViewController *)fromVc toVc:(Class )toVcClass{
    
    MJWeakSelf
    fromVc.backBlock = ^(UIButton * btn) {
        __strong typeof(self) strongSelf = weakSelf;
                
        [strongSelf gobackFromVc:strongSelf toVc:toVcClass];
            
    };
           
        
}

- (void)gobackFromVc:(UIViewController *)fromVc toVc:(Class )toVcClass{
    BOOL isTarget = NO;//是否有需要返回的目标控制器
    for (UIViewController * viewController in fromVc.navigationController.viewControllers) {
        
        // 这里判断是否为你想要跳转的页面
        if ([viewController isKindOfClass:toVcClass]) {
            isTarget = YES;
            [fromVc popToTargetViewController:viewController fromVc:fromVc];
        }
    }
    if (!isTarget) {
        [fromVc.navigationController popViewControllerAnimated:NO];
    }
        
}
/**
 返回当前视图控制器堆栈里的某个控制器
 
 @param targetViewController 目标控制器
 */
- (void)popToTargetViewController:(UIViewController *)targetViewController fromVc:(UIViewController *)fromVc{
            
            UIViewController *targetVC = nil;
            
            // 遍历 ViewController
            for (UIViewController * viewController in fromVc.navigationController.viewControllers) {
                
                // 这里判断是否为你想要跳转的页面
                if ([viewController isKindOfClass:[targetViewController class]]) {
                    
                    targetVC = viewController;
                }
            }
            if (targetVC) {
                // 跳转
                [fromVc.navigationController popToViewController:targetVC animated:YES];
            }
        
    }

-(void)addUIAlertControlWithString:(NSString *)string withActionBlock:(void(^)(void))actionBlock andCancel:(void(^)(void))cancelBlock{
    NSString*titleStr=LocalizationKey(@"温馨提示");
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:titleStr message:string preferredStyle:UIAlertControllerStyleAlert];
    //修改title
        NSMutableAttributedString *alertControllerStr = [[NSMutableAttributedString alloc] initWithString:titleStr];
        [alertControllerStr addAttribute:NSForegroundColorAttributeName value:[UIColor mainTextColor] range:NSMakeRange(0, titleStr.length)];
        [alert setValue:alertControllerStr forKey:@"attributedTitle"];
        //修改message
        NSMutableAttributedString *alertControllerMessageStr = [[NSMutableAttributedString alloc] initWithString:string];
        [alertControllerMessageStr addAttribute:NSForegroundColorAttributeName value:[UIColor mainTextColor] range:NSMakeRange(0, string.length)];
        [alertControllerMessageStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(0, string.length)];

        [alert setValue:alertControllerMessageStr forKey:@"attributedMessage"];
    UIView *firstSubview = alert.view.subviews.firstObject;
    UIView *alertContentView = firstSubview.subviews.firstObject;
    for (UIView *subSubView in alertContentView.subviews) { //This is main catch
        subSubView.backgroundColor = [UIColor secondaryBackGroundColor]; //Here you change background
    }
    [alert addAction:[UIAlertAction actionWithTitle:LocalizationKey(@"确定") style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        actionBlock();
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:LocalizationKey(@"取消") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        cancelBlock();
    }]];
    dispatch_async(dispatch_get_main_queue(), ^{
        [[ToolUtil getCurrentViewController] presentViewController: alert animated: YES completion: nil];
    });
}

-(void)addUIAlertControlForUpdateWithString:(NSString *)string withcanCancle:(BOOL)canCancel withActionBlock:(void(^)(void))actionBlock andCancel:(void(^)(void))cancelBlock{
    NSString*titleStr=@"检查更新";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:titleStr message:string preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        actionBlock();
    }]];
    if (canCancel) {
        [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelBlock();
        }]];
    }
  
    dispatch_async(dispatch_get_main_queue(), ^{
        [[ToolUtil getCurrentViewController] presentViewController: alert animated: YES completion: nil];
    });
}


#pragma mark -若用户未登录，则显示登录界面
-(void)showLoginViewController{
    LoginController*loginVC=[[LoginController alloc]init];
    BaseNavigationController *nav = [[BaseNavigationController alloc]initWithRootViewController:loginVC];
    nav.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:nav animated:YES completion:nil];
}




/**  退出 presentViewController  count：次数*/
- (void)dismissViewControllerWithCount:(NSInteger)count animated:(BOOL)animated{

    count--;
    // 不是自己，并且自己弹出过VC， 递归交给自己弹出的VC处理
    if (count>0 && self.presentingViewController) {
        [self.presentingViewController dismissViewControllerWithCount:count animated:animated];
    }
    else{
        [self dismissViewControllerAnimated:animated completion:nil];
    }
}



/**  退出 presentViewController 到指定的控制器*/
- (void)dismissToViewControllerWithClassName:(NSString *)className animated:(BOOL)animated{

    // 不是自己，并且自己弹出过VC， 递归交给自己弹出的VC处理
    if (![self.class isKindOfClass:NSClassFromString(className)] && self.presentingViewController) {
        [self.presentingViewController dismissToViewControllerWithClassName:className animated:animated];
    }else{
        [self dismissViewControllerAnimated:animated completion:nil];
    }
}




@end
