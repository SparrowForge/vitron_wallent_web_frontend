//
//  NSString+LCJudgeNumber.h
//  ios_demo
//
//  Created by sunliang on 16/6/6.
//  Copyright © 2016年 xinhuo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSString (LCJudgeNumber)

/*
 验证字符串是否为空
 */
+(BOOL)stringIsNull:(NSString *)string;
//空字符串代替null
+(NSString*)repalceNULLWithemptyString:(NSString*)string;
//--代替null
+(NSString*)repalceNULLWithlineString:(NSString*)string;
//如果currency是null，处理为空字符
+(NSString*)dealWithCurrency:(NSString*)currency;
//获取层级path
+(NSString *)viewPath:(UIView *)currentView;
//获取手机信息
+(NSString*)getBrowser;
//MARK: 发送文本消息
+(NSString*)sendTxtWithContent:(NSString*)content;
//MARK: 发送内部文本消息
+(NSString*)sendInsideTxtWithContent:(NSArray*)paragraphArray;
//MARK: 发送图片
+(NSString*)sendImageWithContent:(NSString*)url withImageWidth:(CGFloat)width withImageHeight:(CGFloat)height withfileSize:(NSString*)fileSize;
//MARK: 发送附件
+(NSString*)sendfileWithContent:(NSString*)fileUrl WithName:(NSString*)fileName withImageWidth:(CGFloat)width withImageHeight:(CGFloat)height withfileSize:(NSString*)fileSize;
//MARK: 发送文章
+(NSString*)sendArticleWithDic:(NSDictionary*)dic;
//字符串转字典
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;
//字典转json
+(NSString *)toJsonStrWithDictionary:(NSDictionary *)dic;
//字符串转数组
+ (id)toArrayOrNSDictionary:(NSString *)jsonData;
//MARK:--获取当前时间（毫秒）
+ (NSString *)getCurrentTimeMilliSecond;
//判断是否是一个网址
+ (BOOL)isUrlAddress:(NSString*)url;
/**
*  部分子字符串高亮显示(支持搜索的内容拆分为单个字符串与整体的数据进行比较)
*
*  @param substring  需高亮显示的字符串
*  @param color 高亮颜色
*
*  @return 富文本字符串
*/

- (NSMutableAttributedString *)stringWithPartHighLightSubstring:(NSString *)substring highLightColor:(UIColor *)color;

//将数组转换成json格式字符串,不含 这些符号
+ (NSString *)gs_jsonStringCompactFormatForNSArray:(NSArray *)arrJson;
//去掉字符串中所有空格及换行
+(NSString *)removeSpaceAndNewline:(NSString *)str;
//字节长度转化为KB，MB，GB等
+(NSString *)formattedFileSize:(unsigned long long)size;
//该格式是否支持上传
+ (BOOL)supportedFileformats:(NSString *)formats;
//对传入的double 类型，始终保留两位小数并向下取整
+ (NSString *)formattedStringWithDouble:(double)value;
//对传入的NSString 类型，始终保留两位小数并向下取整
+ (NSString *)formattedStringWithString:(NSString *)inputString;
//对传入的double 类型，始终保留两位小数并向下取整,如果末尾数是0，则去掉
+ (NSString *)formattedStringWithoutZeroWithDouble:(double)value;
//把完整邮箱显示成类似Exam******qq.com样子
+(NSString *)maskEmail:(NSString *)email;
// 日期格式转换工具方法（把日期字符串2024-11-16 23:40:21改成2024.11.16  23:40:21 ）
+ (NSString *)convertDateString:(NSString *)originalDateString;

// 日期格式转换工具方法（把日期字符串2024-11-16改成2024/11/16 ）
+ (NSString *)convertDate2String:(NSString *)originalDateString;
@end
