//
//  UIImageView+UTrackerGetVideoPreView.h
//  Badtest
//
//  Created by 孙良 on 2023/4/18.
//

#import <UIKit/UIKit.h>
//获取视频的图片
#import <AVFoundation/AVAsset.h>
#import <AVFoundation/AVAssetImageGenerator.h>
#import <AVFoundation/AVTime.h>
NS_ASSUME_NONNULL_BEGIN

@interface UIImageView (UBTrackerGetVideoPreView)
//获取视频第一帧图片优化（异步加载数据）
-(void)getVideoPreViewImageURL:(NSURL *)path forImageView:(UIImageView *)imageView placeHolderImage:(UIImage *_Nullable)placeHolder;
//获取本地视频第一帧图片优化（异步加载数据）
-(void)getLocalVideoPreViewImageURL:(NSURL *)path forImageView:(UIImageView *)imageView placeHolderImage:(UIImage *_Nullable)placeHolder  withfromType:(int)fromType;
@end

NS_ASSUME_NONNULL_END
