//
//  ToolUtil.m
//  DynamicTraffic 3.0
//
//  Created by sunliang on 16/6/24.
//  Copyright © 2016年 yundi. All rights reserved.
//

#import "ToolUtil.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonHMAC.h>
#import "NSString+LCJudgeNumber.h"
#import "CustomTabBarController.h"
#import "UIImage+UBTrackerImgSize.h"


#define INT2STRING(intValue) [NSString stringWithFormat:@"%d", intValue]


@implementation ToolUtil
//加载16进制颜色
+ (UIColor *)colorWithHexString:(NSString *)color
{
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:1.0f];
}
//
+ (NSString*)checkNullOrEmpty:(id)obj
{
    if([obj isKindOfClass:[NSNull class]]){
        return @"";
    }
    if(!obj){
        return @"";
    }
    if([obj isKindOfClass:[NSNumber class]])
    {
        NSNumber*number = obj;
        if([number integerValue] == 0)return @"";
        return INT2STRING([number intValue]);
    }
    if([obj isKindOfClass:[NSString class]]){
        return obj;
    }
    if ([obj isEqualToString:@"null"] || [obj isEqualToString:@"NULL"] || [obj isEqualToString:@""]) {
        return @"";
    }
    return @"";
}
//电话号码匹配
+ (BOOL)checkPhoneNumInput:(NSString *)phoneStr
{
    NSString *photoRange = @"^((13[0-9])|(14[5,7])|(15[0-3,5-9])|(16[0-9])|(17[0,1,3,5-8])|(18[0-9])|(19[8,9]))\\d{8}$";//正则表达式
    NSPredicate *regexMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",photoRange];
    BOOL result = [regexMobile evaluateWithObject:phoneStr];
    if (result)
    {
        return YES;
    } else
    {
        return NO;
    }
}

//存
+ (void)save:(NSString *)service data:(id)data {
    //Get search dictionary
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Delete old item before add new item
    SecItemDelete((__bridge CFDictionaryRef)keychainQuery);
    //Add new object to search dictionary(Attention:the data format)
    [keychainQuery setObject:[NSKeyedArchiver archivedDataWithRootObject:data] forKey:(__bridge id)kSecValueData];
    //Add item to keychain with the search dictionary
    SecItemAdd((__bridge CFDictionaryRef)keychainQuery, NULL);
}

+ (NSMutableDictionary *)getKeychainQuery:(NSString *)service {
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:
            (__bridge id)kSecClassGenericPassword,(__bridge id)kSecClass,
            service, (__bridge id)kSecAttrService,
            service, (__bridge id)kSecAttrAccount,
            (__bridge id)kSecAttrAccessibleAfterFirstUnlock,(__bridge id)kSecAttrAccessible,
            nil];
}

//取
+ (id)load:(NSString *)service {
    id ret = nil;
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    //Configure the search setting
    //Since in our simple case we are expecting only a single attribute to be returned (the password) we can set the attribute kSecReturnData to kCFBooleanTrue
    [keychainQuery setObject:(__bridge id)kCFBooleanTrue forKey:(__bridge id)kSecReturnData];
    [keychainQuery setObject:(__bridge id)kSecMatchLimitOne forKey:(__bridge id)kSecMatchLimit];
    CFDataRef keyData = NULL;
    if (SecItemCopyMatching((__bridge CFDictionaryRef)keychainQuery, (CFTypeRef *)&keyData) == noErr) {
        @try {
            ret = [NSKeyedUnarchiver unarchiveObjectWithData:(__bridge NSData *)keyData];
        } @catch (NSException *e) {
            NSLog(@"Unarchive of %@ failed: %@", service, e);
        } @finally {
        }
    }
    if (keyData)
        CFRelease(keyData);
    return ret;
}

+ (void)delete:(NSString *)service {
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service];
    SecItemDelete((__bridge CFDictionaryRef)keychainQuery);
}

+ (NSString *)formatTimeStamp:(NSInteger)stamp withFormat:(NSString *)format
{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:stamp];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:format];
    NSTimeZone *zone = [NSTimeZone defaultTimeZone];
    [dateFormatter setTimeZone:zone];
    NSString *dateStr = [dateFormatter stringFromDate:date];
    return dateStr;
}
//str -> code
+ (NSString *)encodeToPercentEscapeString: (NSString *) input
{
    NSString*
    outputStr = (__bridge NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                             
                                                                             NULL, /* allocator */
                                                                             
                                                                             (__bridge CFStringRef)input,
                                                                             
                                                                             NULL, /* charactersToLeaveUnescaped */
                                                                             
                                                                             (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                             
                                                                             kCFStringEncodingUTF8);
    
    
    return outputStr;
}
//根据当前时间 输出
+ (NSString *)printDateStringWithNowDate:(NSString *)format{
    //    @"YYYYMMDDhhmm"年月日时分 YYYYMMDD年月日
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:format];
    NSTimeZone *zone = [NSTimeZone defaultTimeZone];
    [dateFormatter setTimeZone:zone];
    NSString *dateStr = [dateFormatter stringFromDate:date];
    return dateStr;
}

//截屏
+ (UIImage *)screenShot{
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(kWindowW, kWindowH), YES, 0);
    //设置截屏大小
    [[APPLICATION.window layer] renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return viewImage;
}

+ (BOOL)textfiledOnlyCanInputWithText:(NSString *)text{
    NSString * regex = @"^[A-Za-z0-9]{9,15}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch = [pred evaluateWithObject:text];
    return isMatch;
}
//UTC
+ (NSString *)presentDateTransformUTCdateWithFormat:(NSString *)format{
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:format];
    
    NSTimeZone *zone = [NSTimeZone timeZoneWithName:@"UTC"];
    NSTimeZone* destinationTimeZone = [NSTimeZone localTimeZone];     //得到源日期与世界标准时间的偏移量
    NSInteger sourceGMTOffset = [zone secondsFromGMTForDate:date];     //目标日期与本地时区的偏移量
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:date];     //得到时间偏移量的差值
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;     //转为现在时间
    NSDate* destinationDateNow = [[NSDate alloc] initWithTimeInterval:interval sinceDate:date];
    //    [dateFormatter setTimeZone:zone];
    NSString *dateStr = [dateFormatter stringFromDate:destinationDateNow];
    return dateStr;
}

//MARK:--时间字符串转为时间戳
+ (long long)returnHowManyMintesswithstr:(NSString *)timeStr{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"yyy-MM-dd HH:mm:ss"]; //设置格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone* timeZone = [NSTimeZone systemTimeZone]; //设置时区
    [formatter setTimeZone:timeZone];
    NSDate* date = [formatter dateFromString:timeStr]; //将字符串按formatter转成nsdate
    //时间转时间戳的方法:
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]]; //时间戳的值
    return [timeSp longLongValue];
}
#pragma mark - 匹配6-20位的密码
+ (BOOL)matchPassword:(NSString *)password {
    NSString *pattern = @"^[^s]{6,20}$";
    NSPredicate *regexMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",pattern];
    BOOL result = [regexMobile evaluateWithObject:password];
    if (result)
    {
        return YES;
    } else
    {
        return NO;
    }
}
#pragma mark - 匹配邮箱帐号
+ (BOOL)matchEmail:(NSString *)email {
    NSString *pattern =
    @"^[a-zA-Z0-9]+([\\._\\-]*[a-zA-Z0-9])*@([a-zA-Z0-9]+[-a-zA-Z0-9]*[a-zA-Z0-9]+\\.){1,63}[a-zA-Z0-9]+$";
    NSPredicate *regexMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",pattern];
    BOOL result = [regexMobile evaluateWithObject:email];
    if (result)
    {
        return YES;
    } else
    {
        return NO;
    }
}

+ (BOOL)isValidEmail:(NSString *)email {
    // 使用正则表达式验证邮箱格式
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
+ (BOOL)matchPhone:(NSString *)phone{
    NSString *pattern = @"^(\\+\\d{2}-)?(\\d{2,3}-)?([1][3,4,5,7,8][0-9]\\d{8})$";
//    NSPredicate *regexMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",pattern];
//    BOOL result = [regexMobile evaluateWithObject:phone];
//    if (result)
//    {
//        return YES;
//    } else
//    {
//        return NO;
//    }
    if ([[phone substringToIndex:1] isEqualToString:@"1"]&&phone.length==11) {
        return YES;
    }else{
        return NO;
    }
    
    
}
+ (BOOL)matchWorldPhone:(NSString *)phone{
//    ^((\\+)|(00)|(\\*)|())[0-9]{3,14}((\\#)|())$
    NSString *pattern = @"^((\\+)|(00)|(\\*)|())[0-9]{3,14}((\\#)|())$";
    NSPredicate *regexMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",pattern];
    BOOL result = [regexMobile evaluateWithObject:phone];
    
    if (result)
    {
        return YES;
    } else
    {
        return NO;
    }
}
+(NSString *)stampFormatterWithStamp:(NSInteger)stamp{
    
    NSDateFormatter *stampFormatter = [[NSDateFormatter alloc] init];
    [stampFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    //以 1970/01/01 GMT为基准，然后过了secs秒的时间
    NSDate *stampDate2 = [NSDate dateWithTimeIntervalSince1970:stamp/1000];
    return [stampFormatter stringFromDate:stampDate2];
}
+ (NSDate *)zeroOfDate
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSUIntegerMax fromDate:[NSDate date]];
    components.hour = 0;
    components.minute = 0;
    components.second = 0;
    NSTimeInterval ts = (double)(int)[[calendar dateFromComponents:components] timeIntervalSince1970];
    return [NSDate dateWithTimeIntervalSince1970:ts];
}
//MARK:--判断字符串后有几位小数，超过length位就省略
+(NSString *)judgeStringForDecimalPlaces:(NSString *)string withLength:(int)length{
    NSString *numStr = @"";
    NSArray *array = [string componentsSeparatedByString:@"."];
    if (array.count == 2) {
        NSString *str = array[1];
        if (str.length > length) {
            numStr = [NSString stringWithFormat:@"%@",[self stringFromNumber:[string floatValue] withlimit:length]];
        }else{
            numStr = string;
        }
    }else{
        numStr = string;
    }
    return numStr;
}
//MARK:--科学计数法转具体数字 ,如果传输的就是具体数据，可控制其小数点后面最多保留length位
+(NSString *)formartScientificNotationWithString:(NSString *)str withLength:(int)length{
    NSRange eSite;
    BOOL flag;
    NSString *feeStr;
    if ([str containsString:@"E"]) {
        eSite = [str rangeOfString:@"E"];
        flag = YES;
    }else if ([str containsString:@"e"]){
        eSite = [str rangeOfString:@"e"];
        flag = YES;
    }else{
        flag = NO;
    }
    if (flag) {
        double fund = [[str substringWithRange:NSMakeRange(0, eSite.location)] doubleValue];  //把E前面的数截取下来当底数
        double top = [[str substringFromIndex:eSite.location + 1] doubleValue];   //把E后面的数截取下来当指数
        double result = fund * pow(10.0, top);
        feeStr = [NSString stringWithFormat:@"%@",[self stringFromNumber:result withlimit:length]];
    }else{
        feeStr = [self judgeStringForDecimalPlaces:str withLength:length];
    }
    return feeStr;
}
//MARK:--秒时间戳转 formatterStr为转化格式 yyyy-MM-dd HH:mm:ss HH:mm MM/dd
+ (NSString *)secTimeStampToDateTime:(NSString *)timeStr withFormatterStr:(NSString *)formatterStr{
    long long time=[timeStr longLongValue];
    NSDate *d = [[NSDate alloc]initWithTimeIntervalSince1970:time];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatterStr];
    NSString*timeString=[formatter stringFromDate:d];
    return timeString;
}
//MARK:--毫秒时间戳转 formatterStr为转化格式 yyyy-MM-dd HH:mm:ss HH:mm MM/dd
+ (NSString *)timeStampToDateTime:(NSString *)timeStr withFormatterStr:(NSString *)formatterStr{
    long long time=[timeStr longLongValue];
    NSDate *d = [[NSDate alloc]initWithTimeIntervalSince1970:time/1000.0];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatterStr];
    NSString*timeString=[formatter stringFromDate:d];
    return timeString;
}
//MARK:--时间字符串格式化为 HH:mm MM/dd
+(NSString *)transformForTimeString:(NSString *)timeStr withFormatterStr:(NSString *)formatterStr {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *someDay = [formatter dateFromString:timeStr];
    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    [formatter1 setDateFormat:formatterStr];
    NSString *currentDateString = [formatter1 stringFromDate:someDay];
    return currentDateString;
}

//MARK:--获取当前时间（秒）
+ (NSString *)getCurrentTimeSec {
    NSDate* date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a=[date timeIntervalSince1970]; // *1000 是精确到毫秒，不乘就是精确到秒
    NSString *timeString = [NSString stringWithFormat:@"%.0f", a]; //转为字符型
    return timeString;
}

//MARK:--获取当前时间（毫秒）
+ (NSString *)getCurrentTimeMilliSecond {
    NSDate* date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a=[date timeIntervalSince1970]*1000; // *1000 是精确到毫秒，不乘就是精确到秒
    NSString *timeString = [NSString stringWithFormat:@"%.0f", a]; //转为字符型
    return timeString;
}

//MARK:--获取当前日期 yyyyMMdd yyyy-MM-dd HH:mm:ss HH:mm MM/dd
+ (NSString *)getCurrentTimeWithFormatterStr:(NSString *)formatterStr; {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatterStr];
    NSString *dateTime = [formatter stringFromDate:[NSDate date]];
    return dateTime;
}
//doubleNumber,原数据，decimalNum,保留的小数位数,四舍五入
+(NSString*)stringFromNumber:(double)doubleNumber withlimit:(int)decimalNum{
    NSNumberFormatter *nFormat = [[NSNumberFormatter alloc] init];
    [nFormat setNumberStyle:NSNumberFormatterNoStyle];
    [nFormat setPositiveFormat:@"#####0.000;"];
    [nFormat setMinimumFractionDigits:decimalNum];
    [nFormat setMaximumFractionDigits:decimalNum];
    return [nFormat stringFromNumber:[NSNumber numberWithDouble:doubleNumber]];
}
// 截取小数点后面length  18 <= leng >= 2 isLength:是否只处理保留小数点后两位
+ (NSString *)decimalNumberFromString:(NSString *)number withNormalLength:(BOOL)isLength{
    if ([NSString stringIsNull:number] || [number floatValue] == 0) {
        return @"0.00";
    }
    if (isLength) {
        return [self strRounding:number afterPoint:2];
    }else{
        NSArray *array = [number componentsSeparatedByString:@"."];
        if (array.count > 1) {
            NSString *decimalStr = array[1];
            NSDecimalNumber *subtotal = [NSDecimalNumber decimalNumberWithString:number];
            if (decimalStr.length > 4) {
                return [self strRounding:number afterPoint:4];
            }else{
                if ([[NSString stringWithFormat:@"%@",subtotal] containsString:@"."]) {
                    return [NSString stringWithFormat:@"%@",subtotal];
                }else{
//                    return @"0.00";
                    return [NSString stringWithFormat:@"%.2f",[subtotal floatValue]];
                }
            }
        }else{
            return [self strRounding:number afterPoint:2];
//            return [NSString stringWithFormat:@"%.2f",number.floatValue];
        }
    }
}
//获取当前的时间  YYYY-MM-dd HH:mm:ss
+(NSString*)getCurrentDateString{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    //现在时间,你可以输出来看下是什么格式
    NSDate *datenow = [NSDate date];
    //----------将nsdate按formatter格式转成nsstring
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    NSLog(@"currentTimeString =  %@",currentTimeString);
    return currentTimeString;
}
//MARK:--截取小数点后面length位
+(NSString*)cutOutLengthDecimalPoint:(NSString *)str withLength:(int)length{
    NSString *valueString;
    NSArray *array = [str componentsSeparatedByString:@"."]; //从字符A中分隔成2个元素的数组
    if (array.count > 1) {
        //后面有小数点
        NSString *str = array[1];
        if (str.length >= length ) {
            NSString *str2 = [str substringToIndex:length];
            valueString = [NSString stringWithFormat:@"%@.%@",array[0],str2];
            
        }else{
            valueString = [NSString stringWithFormat:@"%@.%@",array[0],array[1]];
        }
    }
    return valueString;
}
//MARK:--NSData转long long
+(long long) NSDataToUInt:(NSData *)data;
{
    long long datatemplength;
    [data getBytes:&datatemplength length:sizeof(datatemplength)];
    long long result = CFSwapInt64BigToHost(datatemplength);//大小端不一样，需要转化
    return result;
}
//MARK:--浮点数处理并去掉多余的0
+(NSString *)removeFloatAllZeroByString:(NSString *)testNumber
{
    NSString *str = testNumber;
    long len = str.length;
    for (int i = 0; i < len; i++)
    {
        if (![str  hasSuffix:@"0"])
            break;
        else
            str = [str substringToIndex:[str length]-1];
    }
    if ([str hasSuffix:@"."])//避免像2.0000这样的被解析成2.
    {
        //s.substring(0, len - i - 1);
        return [str substringToIndex:[str length]-1];
    }
    else
    {
        return str;
    }
}


//MARK:--密码同时包含8~20位数字和大小写字母，不包含特殊字符的判断方法（正则表达式）
+ (BOOL)isOrNoPasswordStyle:(NSString *)passWordName

{
    
    if (passWordName.length < 8){
        return NO;
    }else if(passWordName.length > 20){
        return NO;
    }
   else if (![self judgePassWordLegal:passWordName])
    {
        return NO;
    }else{
        return YES;
    }
}

//提示标签不能输入特殊字符
+ (BOOL)JudgeTheillegalCharacter:(NSString *)content{
   
    NSString *str =@"^[A-Za-z0-9\\u4e00-\u9fa5]+$";
    NSPredicate* emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", str];
    if (![emailTest evaluateWithObject:content]) {
        return YES;
    }
    return NO;
}

+ (BOOL)judgePassWordLegal:(NSString *)pass{
    BOOL result ;
    // 判断长度大于8位后再接着判断是否同时包含数字和大小写字母
    NSString * regex =@"^(?=.*)(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,20}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    result = [pred evaluateWithObject:pass];
    
    return result;
    
}
//MARK:--判断是否含有表情文字
+ (BOOL)stringContainsEmoji:(NSString *)string
{
    __block BOOL returnValue = NO;
    
    [string enumerateSubstringsInRange:NSMakeRange(0, [string length])
                               options:NSStringEnumerationByComposedCharacterSequences
                            usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
                                const unichar hs = [substring characterAtIndex:0];
                                if (0xd800 <= hs && hs <= 0xdbff) {
                                    if (substring.length > 1) {
                                        const unichar ls = [substring characterAtIndex:1];
                                        const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                                        if (0x1d000 <= uc && uc <= 0x1f77f) {
                                            returnValue = YES;
                                        }
                                    }
                                } else if (substring.length > 1) {
                                    const unichar ls = [substring characterAtIndex:1];
                                    if (ls == 0x20e3) {
                                        returnValue = YES;
                                    }
                                } else {
                                    if (0x2100 <= hs && hs <= 0x27ff) {
                                        returnValue = YES;
                                    } else if (0x2B05 <= hs && hs <= 0x2b07) {
                                        returnValue = YES;
                                    } else if (0x2934 <= hs && hs <= 0x2935) {
                                        returnValue = YES;
                                    } else if (0x3297 <= hs && hs <= 0x3299) {
                                        returnValue = YES;
                                    } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                                        returnValue = YES;
                                    }
                                }
                            }];
    
    return returnValue;
}
+ (CGFloat)caculateWidth:(NSString *)text size:(UIFont *)font height:(CGFloat)height{
    CGSize textBlockMinSize = {CGFLOAT_MAX, height};
    CGSize size;
    static float systemVersion;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        systemVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
    });
    
    size = [text boundingRectWithSize:textBlockMinSize options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                           attributes:@{
                                        NSFontAttributeName:font
                                        }
                              context:nil].size;
    
    return  size.width;
}

//MARK:--重设图片尺寸
+ (UIImage *)imageResize:(UIImage*)img andResizeTo:(CGSize)newSize
{
    CGFloat scale = [[UIScreen mainScreen]scale];
    
    UIGraphicsBeginImageContextWithOptions(newSize, NO, scale);
    [img drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
//截断显示，不四舍五入
+(NSString *)notRounding:(NSDecimalNumber *)price afterPoint:(int)position{
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundDown scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
    NSDecimalNumber *ouncesDecimal;
    NSDecimalNumber *roundedOunces;
    
    ouncesDecimal = price;
    roundedOunces = [ouncesDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    return [NSString stringWithFormat:@"%@",roundedOunces];
}

//截断显示，不四舍五入
+(NSString *)notStrRounding:(NSString *)price afterPoint:(int)position{
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundDown scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
    NSDecimalNumber *ouncesDecimal;
    NSDecimalNumber *roundedOunces;
    
    ouncesDecimal = [[NSDecimalNumber alloc]initWithString:price];
    roundedOunces = [ouncesDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    return [NSString stringWithFormat:@"%@",roundedOunces];
}
//截断显示，四舍五入
+(NSString *)strRounding:(NSString *)price afterPoint:(int)position{
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundUp scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
    NSDecimalNumber *ouncesDecimal;
    NSDecimalNumber *roundedOunces;
    
    ouncesDecimal = [[NSDecimalNumber alloc]initWithString:price];
    roundedOunces = [ouncesDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    NSString *tempNum = [NSString stringWithFormat:@"%@",roundedOunces];
    NSArray *array = [tempNum componentsSeparatedByString:@"."];
    if (array.count > 1) {
        return [NSString stringWithFormat:@"%@",roundedOunces];
    }else{
        return [NSString stringWithFormat:@"%.2f",tempNum.floatValue];
    }
    
}
//截断显示，四舍五入
//NSRoundPlain:四舍五入
//NSRoundDown:只舍不入
//NSRoundUp：只入不舍
//NSRoundBankers: 在四舍五入的基础上加了一个判断：当最后一位为5的时候，只会舍入成偶数。比如：1.25不会返回1.3而是1.2，因为1.3不是偶数。
+(NSString *)rounding:(NSDecimalNumber *)price afterPoint:(int)position{
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundDown scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
    NSDecimalNumber *ouncesDecimal;
    NSDecimalNumber *roundedOunces;
    
    ouncesDecimal = price;
    roundedOunces = [ouncesDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    return [NSString stringWithFormat:@"%@",roundedOunces];
}

+ (NSString *)precisionDecimalWithString:(NSString *)decimalStr scale:(int)scale{
    // 有效数调整:scale:小数位数。 其他参数：都是异常处理 YES 返回异常！ NO 忽略
    NSDecimalNumberHandler *handler = [[NSDecimalNumberHandler alloc] initWithRoundingMode:NSRoundPlain
                                                                                     scale:scale
                                                                          raiseOnExactness:NO
                                                                           raiseOnOverflow:NO
                                                                          raiseOnUnderflow:NO
                                                                       raiseOnDivideByZero:YES];
    NSDecimalNumber *decimal = [NSDecimalNumber decimalNumberWithString:decimalStr];
    NSDecimalNumber *precisionDecimal = [decimal decimalNumberByRoundingAccordingToBehavior:handler];
    NSString *calculate = precisionDecimal.stringValue;
    return calculate;
    
}

//MARK:--获取字符串二维码
+(UIImage *)createNonInterpolatedUIImageForString:(NSString *)qrString withSize:(CGFloat) size{
    NSData *stringData = [qrString dataUsingEncoding:NSUTF8StringEncoding];
    // 创建filter
    CIFilter *qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 设置内容和纠错级别
    [qrFilter setValue:stringData forKey:@"inputMessage"];
    [qrFilter setValue:@"M" forKey:@"inputCorrectionLevel"];
    // 返回CIImage
    CIImage *image = qrFilter.outputImage;
    
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    // 1.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    // 2.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    //原图
    UIImage *outputImage = [UIImage imageWithCGImage:scaledImage];
    UIGraphicsBeginImageContextWithOptions(outputImage.size, NO, [[UIScreen mainScreen] scale]);
    [outputImage drawInRect:CGRectMake(0,0 , size, size)];
    //水印图
    UIImage *waterimage = [UIImage imageNamed:@""];
    [waterimage drawInRect:CGRectMake((size-waterimage.size.width)/2.0, (size-waterimage.size.height)/2.0, waterimage.size.width, waterimage.size.height)];
    UIImage *newPic = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newPic;
}

//MARK:--判断控制器是否显示
+ (BOOL) viewControllerIsShow:(UIViewController *)vc {
    return (vc.isViewLoaded && vc.view.window);
}

////判断当前控制器
+ (UIViewController *)getCurrentViewController{

    UIViewController* currentViewController = [ToolUtil getRootViewController];
    BOOL runLoopFind = YES;
    while (runLoopFind) {
        if (currentViewController.presentedViewController) {

            currentViewController = currentViewController.presentedViewController;
        } else if ([currentViewController isKindOfClass:[UINavigationController class]]) {

            UINavigationController* navigationController = (UINavigationController* )currentViewController;
            currentViewController = [navigationController.childViewControllers lastObject];

        } else if ([currentViewController isKindOfClass:[CustomTabBarController class]]) {

            CustomTabBarController* tabBarController = (CustomTabBarController* )currentViewController;
            currentViewController = tabBarController.selectedViewController;
        } else {

            NSUInteger childViewControllerCount = currentViewController.childViewControllers.count;
            if (childViewControllerCount > 0) {
                currentViewController = currentViewController.childViewControllers.lastObject;

                return currentViewController;
            } else {

                return currentViewController;
            }
        }

    }
    return currentViewController;
}


+ (UIViewController *)getRootViewController{
    
    UIWindow* window = [[[UIApplication sharedApplication] delegate] window];
    NSAssert(window, @"The window is empty");
    return window.rootViewController;
}
+ (BOOL) stringIsNil:(NSString *)string {
    if((![string isKindOfClass:[NSString class]])||
       [string isEqualToString:@""] || (string == nil) ||
       [string isKindOfClass:[NSNull class]]||
       [[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0 ||
       [string isEqual:@"NULL"] ||
       [string isEqual:NULL]||
       [[string class] isSubclassOfClass:[NSNull class]] ||
       string == NULL ||
       [string isEqualToString:@"<null>"] ||
       [string isEqualToString:@"(null)"]) {
        
        return YES;
    } else {
        return NO;
    }
}
+(NSString *)getNowTimeTimestamp{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    //    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss SSS"]; // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    //设置时区,这个对于时间的处理有时很重要
    
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    
    [formatter setTimeZone:timeZone];
    
    NSDate *datenow = [NSDate date];//现在时间,你可以输出来看下是什么格式
    
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]*1000];
    
    return timeSp;
}
//MARK:--NSDate转化为自定义时间
+(NSString *)timeStampForDate:(NSDate *)date withFormatterStr:(NSString *)formatterStr
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:formatterStr];
    
    NSTimeZone *zone = [NSTimeZone timeZoneWithName:@"UTC"];
    NSTimeZone* destinationTimeZone = [NSTimeZone localTimeZone];     //得到源日期与世界标准时间的偏移量
    NSInteger sourceGMTOffset = [zone secondsFromGMTForDate:date];     //目标日期与本地时区的偏移量
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:date];     //得到时间偏移量的差值
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;     //转为现在时间
    NSDate* destinationDateNow = [[NSDate alloc] initWithTimeInterval:interval sinceDate:date];
    
    NSString *dateStr = [formatter stringFromDate:destinationDateNow];
    return dateStr;
}

/**
 比较两个版本号的大小
 
 @param v1 第一个版本号
 @param v2 第二个版本号
 @return 版本号相等,返回0; v1小于v2,返回-1; 否则返回1.
 */
+ (NSInteger)compareVersion:(NSString *)v1 to:(NSString *)v2 {
    // 都为空，相等，返回0
    if (!v1 && !v2) {
        return 0;
    }
    
    // v1为空，v2不为空，返回-1
    if (!v1 && v2) {
        return -1;
    }
    
    // v2为空，v1不为空，返回1
    if (v1 && !v2) {
        return 1;
    }
    
    // 获取版本号字段
    NSArray *v1Array = [v1 componentsSeparatedByString:@"."];
    NSArray *v2Array = [v2 componentsSeparatedByString:@"."];
    // 取字段最大的，进行循环比较
    NSInteger bigCount = (v1Array.count > v2Array.count) ? v1Array.count : v2Array.count;
    
    for (int i = 0; i < bigCount; i++) {
        // 字段有值，取值；字段无值，置0。
        NSInteger value1 = (v1Array.count > i) ? [[v1Array objectAtIndex:i] integerValue] : 0;
        NSInteger value2 = (v2Array.count > i) ? [[v2Array objectAtIndex:i] integerValue] : 0;
        if (value1 > value2) {
            // v1版本字段大于v2版本字段，返回1
            return 1;
        } else if (value1 < value2) {
            // v2版本字段大于v1版本字段，返回-1
            return -1;
        }
        
        // 版本相等，继续循环。
    }
    // 版本号相等
    return 0;
}

//MARK:--浮点数处理并去掉多余的0并且保留8位有效数字
+(NSString *)removeFloatAllZeroAnd8PlaceByString:(NSString *)testNumber
{
//    if ([testNumber isEqualToString:@"0"]) {
//        return @"0";
//    }
//    NSDecimalNumber *a = [NSDecimalNumber decimalNumberWithString:testNumber];
//    NSDecimalNumber *b = [NSDecimalNumber decimalNumberWithString:@"1"];
//    NSString *str = [a decimalNumberByMultiplyingBy:b withBehavior:kDECIMAL(8)].stringValue;
    NSString *str = [NSString stringWithFormat:@"%.8f",testNumber.doubleValue];
    long len = str.length;
    for (int i = 0; i < len; i++)
    {
        if (![str  hasSuffix:@"0"])
            break;
        else
            str = [str substringToIndex:[str length]-1];
    }
    if ([str hasSuffix:@"."])//避免像2.0000这样的被解析成2.
    {
        //s.substring(0, len - i - 1);
        return [str substringToIndex:[str length]-1];
    }
    else
    {
        return str;
    }
}

//资产字符串每三位插入一个逗号
+ (NSString *)insetDouhao:(NSString *)str{
    NSString *intStr;
    NSString *floStr;
    if ([str containsString:@"."]) {
        NSRange range = [str rangeOfString:@"."];
         floStr = [str substringFromIndex:range.location];
         intStr = [str substringToIndex:range.location];
    }else{
        floStr = @"";
        intStr = str;
    }
    //处理为负数时问题
    if ([intStr containsString:@"-"]) {
        if (intStr.length <=4) {
            return [intStr stringByAppendingString:floStr];
        }
    }
    if (intStr.length <=3) {
        return [intStr stringByAppendingString:floStr];
    }else{
        NSInteger length = intStr.length;
        NSInteger count = length/3;
        NSInteger y = length%3;
 
        NSString *tit = [intStr substringToIndex:y] ;
        NSMutableString *det = [[intStr substringFromIndex:y] mutableCopy];
 
        for (int i =0; i < count; i ++) {
            NSInteger index = i + i *3;
            [det insertString:@","atIndex:index];
        }
        if (y ==0) {
            det = [[det substringFromIndex:1]mutableCopy];
        }
        intStr = [tit stringByAppendingString:det];
        return [intStr stringByAppendingString:floStr];
    }
}
//获取实名认证时，手写提示
+(NSString*)getPromptForrealNameAuthenticationWithHost:(NSString*)host{
    
    NSArray *arry = [host componentsSeparatedByString:@"www."];
    
    if (arry.count==2) {
        return [NSString stringWithFormat:@"%@",[arry lastObject]];
    }
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    return [infoDictionary objectForKey:@"CFBundleDisplayName"];
  
    
}
//MARK:--获取数组中最小值
+(int)getMinNumInArr:(NSArray *)array {
    int max_number = 0;          //最大值
    int max_index = 0;           //最大值的下标
    int min_number = 10000;   //最小值
    int min_index = 0;           //最小值下标
    int all = 0;                 //总和
    float mid = 0;                //总和平均值
     
    for (int i=0; i<array.count; i++)
    {
        //取最大值和最大值的对应下标
        int a = [array[i] intValue];
        if (a>max_number)
        {
            max_index=i;
        }
        max_number = a>max_number?a:max_number;
         
        //取最小值和最小值对应的下标
        int b = [array[i] intValue];
        if (b<min_number)
        {
            min_index = i;
        }
        min_number = b>min_number?min_number:b;
         
        //去除数组中所有的值
        int c = [array[i] intValue];
        all = all+c;
         
        //求平均数
        mid = all/array.count;
    }
    return min_index;
}

//计算两个日期的间隔年份(单位：秒)
+ (NSInteger)calculateTimeWithStartTime:(NSString *)startTime{
    
    NSDateFormatter *dateFomatter = [[NSDateFormatter alloc] init];
    [dateFomatter setDateFormat:@"yyyy年MM月d日"];
    // 截止时间字符串格式
    NSString *startDateStr = startTime;
    // 截止时间data格式
    NSDate *startDate = [dateFomatter dateFromString:startDateStr];
    // 当前日历
    NSCalendar *calendar = [NSCalendar currentCalendar];
    // 需要对比的时间数据
    NSCalendarUnit unit = NSCalendarUnitYear | NSCalendarUnitMonth
    | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    // 对比时间差
    NSDateComponents *dateCom = [calendar components:unit fromDate:startDate toDate:[NSDate date] options:0];
    NSLog(@"年份-%ld---月份-%ld",(long)dateCom.year,dateCom.month);

    return (long)dateCom.year;
    
}

//获取某个日期的时间戳
+ (NSString*)getCurrentTimeStampWithFormatterStr:(NSString *)formatterStr WithTime:(NSString *)timeStr{
    NSDateFormatter*formatter =[[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatterStr];
    NSDate*date=[formatter dateFromString:timeStr];
    NSString *time = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]*1000];//毫秒
    return time;
}

//如果想要判断设备是ipad，要用如下方法
+ (BOOL)getIsIpad
{
    NSString *deviceType = [UIDevice currentDevice].model;
    
    if([deviceType isEqualToString:@"iPhone"]) {
        //iPhone
        return NO;
    }
    else if([deviceType isEqualToString:@"iPod touch"]) {
        //iPod Touch
        return NO;
    }
    else if([deviceType isEqualToString:@"iPad"]) {
        //iPad
        return YES;
    }
    return NO;
    
    //这两个防范判断不准，不要用
    //#define is_iPhone (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    //
    //#define is_iPad (UI_USER_INTERFACE_IDIOM()== UIUserInterfaceIdiomPad)
}


//根据文字宽度和行间距，计算高度
+ (CGFloat)getLabelHeightWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font withLineSpacing:(CGFloat)LineSpacing
 
{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:LineSpacing];
    CGRect rect = [text boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
 
                                     options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
 
                                  attributes:@{NSFontAttributeName:font,NSParagraphStyleAttributeName:paragraphStyle} context:nil];
 
    
 
    return rect.size.height;
 
}


//根据文字宽度，计算高度
+ (CGFloat)getLabelHeightWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font
 
{
    
 
    CGRect rect = [text boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
 
                                     options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading 
 
                                  attributes:@{NSFontAttributeName:font} context:nil];
 
    
 
    return rect.size.height;
 
}




//根据文字宽度，计算高度
+ (CGFloat)getTextViewHeightWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font
 
{
 
    UITextView*textView=[[UITextView alloc]initWithFrame:CGRectMake(0, 0, kWindowW-20, 0)];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.lineSpacing = 3;// 字体的行间距
    NSDictionary *attributes = @{
        NSFontAttributeName:font,
        NSParagraphStyleAttributeName:paragraphStyle
        };
    textView.attributedText = [[NSAttributedString alloc] initWithString:text attributes:attributes];
    CGFloat height = ceilf([textView sizeThatFits:CGSizeMake(textView.frame.size.width, MAXFLOAT)].height);
 
    return height;
 
}
//计算尺寸
+ (CGSize)getLabelSizeWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font{
    
    CGRect rect = [text boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
 
                                     options:NSStringDrawingUsesLineFragmentOrigin
 
                                  attributes:@{NSFontAttributeName:font} context:nil];
 
    
 
    return rect.size;
    
}

//压缩图片
+ (NSData *)compressWithOrgImg:(NSData *)imageData
{
    
    float length = imageData.length;
    length = length/1024;
    // 裁剪比例
    CGFloat cout = 0.5;
    // 压缩比例
    CGFloat imgCout = 0.1;
    if(length > 25000){ // 25M以上的图片
        cout = 0.1;
        imgCout = 0;
    }else if(length > 10000){ // 10M以上的图片
        cout = 0.2;
        imgCout = 0;
    }else if (length > 5000) { // 5M以上的图片
        cout = 0.3;
        imgCout = 0;
    }else if (length > 1500) { // 如果原图大于1.5M就换一个压缩级别
        cout = 0.7;
        imgCout = 0.1;
    }else if (length > 1000) {//1M
        cout = 0.8;
        imgCout = 0.2;
    }else if (length > 500) {//0.5M
        cout = 0.8;
        imgCout = 0.3;
    }else{
        cout = 0.9;
        imgCout = 50/length;
    }
    
    UIImage*img=[UIImage imageWithData:imageData];
    
   
    NSLog(@"压缩前的大小：%@-宽-%.2f--高--%.2f",[NSString formattedFileSize:imageData.length],img.size.width,img.size.height);
    
    // 按裁剪比例裁剪
    int imgWidth=ceil(img.size.width * cout);
    int imgHeight=ceil(img.size.height * cout);
    UIImage *compressImage =  [img imageByScalingAndCroppingForSize:CGSizeMake(imgWidth,imgHeight)];//此处填整数防止裁剪后图片底部有白边
    
    
    // 按压缩比例压缩
    imageData = UIImageJPEGRepresentation(compressImage, imgCout);
    
   
    NSLog(@"裁剪比例：%f，压缩比例：%f,压缩后的大小：%@--宽-%.2f--高--%.2f",cout,imgCout,[NSString formattedFileSize:imageData.length],img.size.width * cout,img.size.height *cout);
    return imageData;
}

@end
