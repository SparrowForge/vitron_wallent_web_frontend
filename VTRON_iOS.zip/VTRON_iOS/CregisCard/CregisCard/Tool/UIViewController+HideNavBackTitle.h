//
//  UIViewController+HideNavBackTitle.h
//  CregisCard
//
//  Created by sunliang on 2022/8/20.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (HideNavBackTitle)


@end

NS_ASSUME_NONNULL_END
