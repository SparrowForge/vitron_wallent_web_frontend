//
//  LogoRefreshGifHeader.h
//  CregisCard
//
//  Created by sunliang on 2024/12/9.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "MJRefreshGifHeader.h"

/**
 自定义此类继承MJRefreshGifHeader目的是处理GIF图片大小的问题
 */
NS_ASSUME_NONNULL_BEGIN

@interface LogoRefreshGifHeader : MJRefreshGifHeader
@property (nonatomic,strong) NSMutableArray *refreshImages;//刷新动画的图片数组
@property (nonatomic,strong) NSMutableArray *normalImages;//普通状态下的图片数组
@end

NS_ASSUME_NONNULL_END
