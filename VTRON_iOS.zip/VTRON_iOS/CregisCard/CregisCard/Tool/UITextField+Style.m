//
//  UITextField+Style.m
//  CregisCard
//
//  Created by sunliang on 2025/7/17.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "UITextField+Style.h"

@implementation UITextField (Style)

-(void)setStyleWithPlaceholder:(NSString*)placeholder{
    
    self.font=PingFangMediumFont(15);
    self.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:placeholder
                                                                    attributes:@{
                                                                        NSFontAttributeName:PingFangMediumFont(15)
                                                                    }];
    
}

@end
