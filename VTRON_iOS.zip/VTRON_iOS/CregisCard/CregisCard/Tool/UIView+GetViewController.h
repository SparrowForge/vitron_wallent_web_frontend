//
//  UIView+GetViewController.h
//  UBTrackerAnalytics
//
//  Created by sunliang on 2022/5/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (GetViewController)
-(UIViewController *)getViewController;
@end

NS_ASSUME_NONNULL_END
