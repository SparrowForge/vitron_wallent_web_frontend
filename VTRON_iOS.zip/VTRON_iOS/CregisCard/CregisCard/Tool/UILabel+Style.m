//
//  UILabel+Style.m
//  CregisCard
//
//  Created by sunliang on 2025/7/17.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "UILabel+Style.h"

@implementation UILabel (Style)

//设置中粗黑体
-(void)setMediumFont:(CGFloat)fontSize{
    
    self.font=PingFangMediumFont(fontSize);
    self.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
  
}

//设置普通字体,浅色
-(void)setRegularFont:(CGFloat)fontSize{
    
    self.font=[UIFont systemFontOfSize:fontSize];
    self.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
  
}


@end
