//
//  NSString+UBTrackerMD5.h
//  Badtest
//
//  Created by 孙良 on 2023/4/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (UBTrackerMD5)
+ (NSString *)getmd5Str:(NSString *)str;
@end

NS_ASSUME_NONNULL_END
