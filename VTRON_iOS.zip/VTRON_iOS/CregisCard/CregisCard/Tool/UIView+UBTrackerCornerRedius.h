//
//  UIView+UBTrackerCornerRedius.h
//  CregisCard
//
//  Created by sunliang on 2022/4/23.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (UBTrackerCornerRedius)
//UIView切圆角
-(void)maskRoundingCorners:(UIRectCorner)corner cornerRedius:(CGSize)size;
/**
 设置圆角
 */
-(void)setCornerRadius:(CGFloat)cornerRadius;
/**
 设置边框颜色
 */
-(void)setborderColor:(UIColor*)borderColor withborderWidth:(CGFloat)borderWidth;



@end

NS_ASSUME_NONNULL_END
