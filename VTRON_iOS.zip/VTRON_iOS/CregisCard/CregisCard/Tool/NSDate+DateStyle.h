//
//  NSDate+DateStyle.h
//  Work
//
//  Created by sunliang on 2021/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (DateStyle)


/*
今年今天
一分钟内显示为“刚刚”，
大于1分钟小于1小时显示为“n分钟前”，
大于1小时小于一天显示为“n小时前”，
今年昨天显示"昨天"
今年昨天以前显示"月日
今年以前显示"年月日
*/

//毫秒
+ (NSString *)UTdateStyleCommentTimeIntervalToDateString:(NSString *)timeInterval;
@end

NS_ASSUME_NONNULL_END
