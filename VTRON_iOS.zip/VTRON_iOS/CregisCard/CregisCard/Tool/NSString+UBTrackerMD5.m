//
//  NSString+UBTrackerMD5.m
//  Badtest
//
//  Created by 孙良 on 2023/4/18.
//

#import "NSString+UBTrackerMD5.h"
#import <CommonCrypto/CommonDigest.h>
@implementation NSString (UBTrackerMD5)
+ (NSString *)getmd5Str:(NSString *)str
{
  
    //传入参数,转化成char
    const char *cStr = [str UTF8String];
    //开辟一个16字节的空间
    unsigned char result[16];
    /*
     extern unsigned char * CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把str字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了md这个空间中
     */
    CC_MD5(cStr, (unsigned)strlen(cStr), result);
    return [NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
             result[0], result[1], result[2], result[3],
             result[4], result[5], result[6], result[7],
             result[8], result[9], result[10], result[11],
             result[12], result[13], result[14], result[15]
             ];
}
@end
