//
//  UBTrackerImageView.h
//  CregisCard
//
//  Created by sunliang on 2022/8/3.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UBTrackerImageView : UIImageView
@property(nonatomic,assign) BOOL isRemote;//是否是远程请求的
@property(nonatomic,strong) NSURL*imageUrl;
@property(nonatomic,copy)   NSString*fileSize;//字节长度，单位byte
@property(nonatomic,copy)   NSString*imagePath;
@property (nonatomic,assign) int fromType;//文件来源  1 相册选择的  2 附件选择的
@property (nonatomic,assign) int currentDevice;//是否是当前设备发送的 0 不是 1 是
//@property(nonatomic,strong)  NSData*imageData;
//@property(nonatomic,assign)  BOOL haveImageData;//发送失败的

@end

NS_ASSUME_NONNULL_END
