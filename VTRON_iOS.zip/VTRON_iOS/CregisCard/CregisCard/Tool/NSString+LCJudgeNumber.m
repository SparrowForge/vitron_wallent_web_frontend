//
//  NSString+LCJudgeNumber.m
//  ios_demo
//
//  Created by sunliang on 16/6/6.
//  Copyright © 2016年 xinhuo. All rights reserved.
//
#import "NSString+LCJudgeNumber.h"
//获取手机设备型号
#import <sys/sysctl.h>
#import <sys/utsname.h>
@implementation NSString (LCJudgeNumber)

+ (BOOL)stringIsNull:(NSString *)string{
    if ([string isKindOfClass:[NSNumber class]]) {
        string=[NSString stringWithFormat:@"%@",string];
    }
    //判断用户名是否为空
    if(string == nil||[string isKindOfClass:[NSNull class]]||[string isEqualToString:@"<null>"]){
        
        return YES;
    }
    NSString *str = [string stringByReplacingOccurrencesOfString:@" " withString:@""];//去空格
    str = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];//去换行
    str = [str stringByReplacingOccurrencesOfString:@"\r" withString:@""];//去换行
    
    if ([str isEqualToString:@""]) {
        return YES;
    }
    return NO;//不为空
}


//获取层级path
+(NSString *)viewPath:(UIView *)currentView{
    
    
    __block NSString *viewPath = @"";
    for (UIView *view = currentView;view;view = view.superview) {
        //NSLog(@"获取层级path--%@",view);
        if ([view isKindOfClass:[UICollectionViewCell class]]) {
            // 是一个
            UICollectionViewCell *cell = (UICollectionViewCell *)view;
            UICollectionView *cv = (UICollectionView *)cell.superview;
            NSIndexPath *indexPath = [cv indexPathForCell:cell];
            NSString *className = NSStringFromClass([cell class]);
            viewPath = [NSString stringWithFormat:@"%@[%ld:%ld]/%@",className,indexPath.section,indexPath.row,viewPath];
            continue;
        }
        
        if ([view isKindOfClass:[UITableViewCell class]]) {
            // 是一个
            UITableViewCell *cell = (UITableViewCell *)view;
            UITableView *tb = (UITableView *)cell.superview;
            NSIndexPath *indexPath = [tb indexPathForCell:cell];
            NSString *className = NSStringFromClass([cell class]);
            viewPath = [NSString stringWithFormat:@"%@[%ld:%ld]/%@",className,indexPath.section,indexPath.row,viewPath];
            continue;
        }
        
        
        if ([view isKindOfClass:[UIView class]]) {
            
            NSMutableArray*sameTypeArray=[[NSMutableArray alloc]init];
            [sameTypeArray enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([NSStringFromClass([obj class]) isEqualToString:NSStringFromClass([view class])]) {
                    [sameTypeArray addObject:obj];
                }
            }];
            [view.superview.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj == view) {
                    NSString *className = NSStringFromClass([view class]);
                    viewPath = [NSString stringWithFormat:@"%@[%ld]/%@",className,idx,viewPath];
                    *stop = YES;
                }
            }];
        }
        NSLog(@"这是路径--%@",viewPath);
        UIResponder *responder = [view nextResponder];
        if ([responder isKindOfClass:[UIViewController class]]) {
            
            NSString *className = NSStringFromClass([responder class]);
            viewPath = [NSString stringWithFormat:@"%@/%@",className,viewPath];
            return viewPath;
        }
    }
    return viewPath;
}

//空字符串代替null
+(NSString*)repalceNULLWithemptyString:(NSString*)string
{
    if ([NSString stringIsNull:string]||[string isEqualToString:@" "]) {
        return @"";
    }
    return string;
}
//--代替null
+(NSString*)repalceNULLWithlineString:(NSString*)string{
    
    if ([NSString stringIsNull:string]||[string isEqualToString:@" "]) {
        return @"--";
    }
    return string;
    
}

//如果currency是null，处理为空字符
+(NSString*)dealWithCurrency:(NSString*)currency{
    if ([NSString stringIsNull:currency]) {
        return @"";
    }
    return currency;
    
}
//获取手机信息
+(NSString*)getBrowser
{
    NSString*browser=[NSString stringWithFormat:@"%@ (%@),%@,%@",[NSBundle.mainBundle.infoDictionary objectForKey:@"CFBundleIdentifier"],@"0.1.0",[self getCurrentDeviceModel],UIDevice.currentDevice.systemVersion];
    return browser;
    
}
//获取手机的型号
+(NSString *) deviceModel {
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char answer[size];
    sysctlbyname("hw.machine", answer, &size, NULL, 0);
    NSString *results = @(answer);
    return results;
}


+ (NSString *)getCurrentDeviceModel{
   struct utsname systemInfo;
   uname(&systemInfo);
   
   NSString *deviceModel = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
   
   
if ([deviceModel isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
if ([deviceModel isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
if ([deviceModel isEqualToString:@"iPhone3,3"])    return @"iPhone 4";
if ([deviceModel isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
if ([deviceModel isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
if ([deviceModel isEqualToString:@"iPhone5,2"])    return @"iPhone 5 (GSM+CDMA)";
if ([deviceModel isEqualToString:@"iPhone5,3"])    return @"iPhone 5c (GSM)";
if ([deviceModel isEqualToString:@"iPhone5,4"])    return @"iPhone 5c (GSM+CDMA)";
if ([deviceModel isEqualToString:@"iPhone6,1"])    return @"iPhone 5s (GSM)";
if ([deviceModel isEqualToString:@"iPhone6,2"])    return @"iPhone 5s (GSM+CDMA)";
if ([deviceModel isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
if ([deviceModel isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
if ([deviceModel isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
if ([deviceModel isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
if ([deviceModel isEqualToString:@"iPhone8,4"])    return @"iPhone SE";
// 日行两款手机型号均为日本独占，可能使用索尼FeliCa支付方案而不是苹果支付
if ([deviceModel isEqualToString:@"iPhone9,1"])    return @"iPhone 7";
if ([deviceModel isEqualToString:@"iPhone9,2"])    return @"iPhone 7 Plus";
if ([deviceModel isEqualToString:@"iPhone9,3"])    return @"iPhone 7";
if ([deviceModel isEqualToString:@"iPhone9,4"])    return @"iPhone 7 Plus";
if ([deviceModel isEqualToString:@"iPhone10,1"])   return @"iPhone_8";
if ([deviceModel isEqualToString:@"iPhone10,4"])   return @"iPhone_8";
if ([deviceModel isEqualToString:@"iPhone10,2"])   return @"iPhone_8_Plus";
if ([deviceModel isEqualToString:@"iPhone10,5"])   return @"iPhone_8_Plus";
if ([deviceModel isEqualToString:@"iPhone10,3"])   return @"iPhone X";
if ([deviceModel isEqualToString:@"iPhone10,6"])   return @"iPhone X";
if ([deviceModel isEqualToString:@"iPhone11,8"])   return @"iPhone XR";
if ([deviceModel isEqualToString:@"iPhone11,2"])   return @"iPhone XS";
if ([deviceModel isEqualToString:@"iPhone11,6"])   return @"iPhone XS Max";
if ([deviceModel isEqualToString:@"iPhone11,4"])   return @"iPhone XS Max";
if ([deviceModel isEqualToString:@"iPhone12,1"])   return @"iPhone 11";
if ([deviceModel isEqualToString:@"iPhone12,3"])   return @"iPhone 11 Pro";
if ([deviceModel isEqualToString:@"iPhone12,5"])   return @"iPhone 11 Pro Max";
if ([deviceModel isEqualToString:@"iPhone12,8"])   return @"iPhone SE2";
if ([deviceModel isEqualToString:@"iPhone13,1"])   return @"iPhone 12 mini";
if ([deviceModel isEqualToString:@"iPhone13,2"])   return @"iPhone 12";
if ([deviceModel isEqualToString:@"iPhone13,3"])   return @"iPhone 12 Pro";
if ([deviceModel isEqualToString:@"iPhone13,4"])   return @"iPhone 12 Pro Max";
if ([deviceModel isEqualToString:@"iPhone14,4"])   return @"iPhone 13 mini";
if ([deviceModel isEqualToString:@"iPhone14,5"])   return @"iPhone 13";
if ([deviceModel isEqualToString:@"iPhone14,2"])   return @"iPhone 13 Pro";
if ([deviceModel isEqualToString:@"iPhone14,3"])   return @"iPhone 13 Pro Max";
if ([deviceModel isEqualToString:@"iPhone14,7"])   return @"iPhone 14";
if ([deviceModel isEqualToString:@"iPhone14,8"])   return @"iPhone 14 Plus";
if ([deviceModel isEqualToString:@"iPhone15,2"])   return @"iPhone 14 Pro";
if ([deviceModel isEqualToString:@"iPhone15,3"])   return @"iPhone 14 Pro Max";
if ([deviceModel isEqualToString:@"iPhone15,4"])   return @"iPhone 15";
if ([deviceModel isEqualToString:@"iPhone15,5"])   return @"iPhone 15 Plus";
if ([deviceModel isEqualToString:@"iPhone16,1"])   return @"iPhone 15 Pro";
if ([deviceModel isEqualToString:@"iPhone16,2"])   return @"iPhone 15 Pro Max";
if ([deviceModel isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
if ([deviceModel isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
if ([deviceModel isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
if ([deviceModel isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
if ([deviceModel isEqualToString:@"iPod5,1"])      return @"iPod Touch (5 Gen)";
if ([deviceModel isEqualToString:@"iPad1,1"])      return @"iPad";
if ([deviceModel isEqualToString:@"iPad1,2"])      return @"iPad 3G";
if ([deviceModel isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
if ([deviceModel isEqualToString:@"iPad2,2"])      return @"iPad 2";
if ([deviceModel isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
if ([deviceModel isEqualToString:@"iPad2,4"])      return @"iPad 2";
if ([deviceModel isEqualToString:@"iPad2,5"])      return @"iPad Mini (WiFi)";
if ([deviceModel isEqualToString:@"iPad2,6"])      return @"iPad Mini";
if ([deviceModel isEqualToString:@"iPad2,7"])      return @"iPad Mini (GSM+CDMA)";
if ([deviceModel isEqualToString:@"iPad3,1"])      return @"iPad 3 (WiFi)";
if ([deviceModel isEqualToString:@"iPad3,2"])      return @"iPad 3 (GSM+CDMA)";
if ([deviceModel isEqualToString:@"iPad3,3"])      return @"iPad 3";
if ([deviceModel isEqualToString:@"iPad3,4"])      return @"iPad 4 (WiFi)";
if ([deviceModel isEqualToString:@"iPad3,5"])      return @"iPad 4";
if ([deviceModel isEqualToString:@"iPad3,6"])      return @"iPad 4 (GSM+CDMA)";
if ([deviceModel isEqualToString:@"iPad4,1"])      return @"iPad Air (WiFi)";
if ([deviceModel isEqualToString:@"iPad4,2"])      return @"iPad Air (Cellular)";
if ([deviceModel isEqualToString:@"iPad4,4"])      return @"iPad Mini 2 (WiFi)";
if ([deviceModel isEqualToString:@"iPad4,5"])      return @"iPad Mini 2 (Cellular)";
if ([deviceModel isEqualToString:@"iPad4,6"])      return @"iPad Mini 2";
if ([deviceModel isEqualToString:@"iPad4,7"])      return @"iPad Mini 3";
if ([deviceModel isEqualToString:@"iPad4,8"])      return @"iPad Mini 3";
if ([deviceModel isEqualToString:@"iPad4,9"])      return @"iPad Mini 3";
if ([deviceModel isEqualToString:@"iPad5,1"])      return @"iPad Mini 4 (WiFi)";
if ([deviceModel isEqualToString:@"iPad5,2"])      return @"iPad Mini 4 (LTE)";
if ([deviceModel isEqualToString:@"iPad5,3"])      return @"iPad Air 2";
if ([deviceModel isEqualToString:@"iPad5,4"])      return @"iPad Air 2";
if ([deviceModel isEqualToString:@"iPad6,3"])      return @"iPad Pro 9.7";
if ([deviceModel isEqualToString:@"iPad6,4"])      return @"iPad Pro 9.7";
if ([deviceModel isEqualToString:@"iPad6,7"])      return @"iPad Pro 12.9";
if ([deviceModel isEqualToString:@"iPad6,8"])      return @"iPad Pro 12.9";
 
if ([deviceModel isEqualToString:@"AppleTV2,1"])      return @"Apple TV 2";
if ([deviceModel isEqualToString:@"AppleTV3,1"])      return @"Apple TV 3";
if ([deviceModel isEqualToString:@"AppleTV3,2"])      return @"Apple TV 3";
if ([deviceModel isEqualToString:@"AppleTV5,3"])      return @"Apple TV 4";
 
if ([deviceModel isEqualToString:@"i386"])         return @"Simulator";
if ([deviceModel isEqualToString:@"x86_64"])       return @"Simulator";
    return deviceModel;
}


//MARK: 识别文字中的链接
+(NSString*)sendTxtWithContent:(NSString*)content {
    if([NSString stringIsNull:content]){
        return @"";
    }
    NSError *error;
    NSDataDetector *dataDetector=[NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:&error];
    NSArray *arrayOfAllMatches=[dataDetector matchesInString:content options:NSMatchingReportProgress range:NSMakeRange(0, content.length)];
    NSMutableArray*paragraphArray=[[NSMutableArray alloc]init];
    NSMutableArray*smallArray=[[NSMutableArray alloc]init];
    __block NSString*continueString=content;
    if (arrayOfAllMatches.count>0) {
        [arrayOfAllMatches enumerateObjectsUsingBlock:^(NSTextCheckingResult *match, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString*subString=[content substringWithRange:NSMakeRange(match.range.location, match.range.length)];
            NSArray *brokenByLines=[continueString componentsSeparatedByString:subString];
            NSString*firstString= [brokenByLines firstObject];
            [smallArray addObject:@{@"text":firstString}];
            if (brokenByLines.count<=1) {
                *stop=YES;
            }else{
                continueString= [content substringFromIndex:match.range.location+match.range.length];
                [smallArray addObject: @{@"type": @"link",@"url":[content substringWithRange:NSMakeRange(match.range.location, match.range.length)],@"children":@[@{@"text":[content substringWithRange:NSMakeRange(match.range.location, match.range.length)]}]}];
            }
     
        }];
        
        [smallArray addObject: @{@"text":continueString}];

    }else{
        [smallArray addObject:@{@"text":content}];
    }
    
   

    [paragraphArray addObject:@{@"type":@"paragraph",@"children":smallArray}];
    
    return [self gs_jsonStringCompactFormatForNSArray:paragraphArray];
    
}





//MARK: 发送内部文本消息
+(NSString*)sendInsideTxtWithContent:(NSArray*)paragraphArray{
    
    return [self gs_jsonStringCompactFormatForNSArray:paragraphArray];
}


//MARK: 发送图片
+(NSString*)sendImageWithContent:(NSString*)url withImageWidth:(CGFloat)width withImageHeight:(CGFloat)height withfileSize:(NSString*)fileSize{
   
    NSArray*paragraphArray=@[@{@"type":@"paragraph",@"children":@[@{@"type":@"image",@"src":url,@"width":@(width),@"height":@(height),@"fileSize":fileSize}]}];
    return [self gs_jsonStringCompactFormatForNSArray:paragraphArray];
    
}

//MARK: 发送附件
+(NSString*)sendfileWithContent:(NSString*)fileUrl WithName:(NSString*)fileName withImageWidth:(CGFloat)width withImageHeight:(CGFloat)height withfileSize:(NSString*)fileSize{
   
    NSArray*paragraphArray=@[@{@"type":@"paragraph",@"children":@[@{@"type":@"file",@"fileUrl":fileUrl,@"fileName":fileName,@"width":@(width),@"height":@(height),@"fileSize":fileSize}]}];
    
    return [self gs_jsonStringCompactFormatForNSArray:paragraphArray];
    
}
//MARK: 发送文章
+(NSString*)sendArticleWithDic:(NSDictionary*)dic{
   
    NSArray*paragraphArray=@[@{@"type":@"paragraph",@"children":@[dic]}];
   // NSArray*paragraphArray=@[@{@"type":@"paragraph",@"children":@[dic,@{@"text":@"这是新消息"}]}];
    return [self gs_jsonStringCompactFormatForNSArray:paragraphArray];
    
}
//将数组转换成json格式字符串,不含 这些符号
+ (NSString *)gs_jsonStringCompactFormatForNSArray:(NSArray *)arrJson {

    if (![arrJson isKindOfClass:[NSArray class]] || ![NSJSONSerialization isValidJSONObject:arrJson]) {
        return nil;
    }

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:arrJson options:0 error:nil];

    NSString *strJson = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return strJson;

}
//json 字符串转化为字典
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString
{
    if (jsonString == nil) {
        return nil;
    }

    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err)
    {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
//字典转json
+(NSString *)toJsonStrWithDictionary:(NSDictionary *)dic {
    if ([dic isKindOfClass:[NSString class]]) {
        return (NSString *)dic;
    }
    NSError *parseError = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    NSString *jsonSrt = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    if (parseError) {
        jsonSrt = @"";
    }
    return jsonSrt;
}
//MARK:--获取当前时间（毫秒）
+ (NSString *)getCurrentTimeMilliSecond {
    NSDate* date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a=[date timeIntervalSince1970]*1000; // *1000 是精确到毫秒，不乘就是精确到秒
    NSString *timeString = [NSString stringWithFormat:@"%.0f", a]; //转为字符型
    return timeString;
}

//字符串转数组
+ (id)toArrayOrNSDictionary:(NSString *)jsonData{

    if (jsonData != nil) {

        NSData* data = [jsonData dataUsingEncoding:NSUTF8StringEncoding];

        id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

        if (jsonObject != nil){

            return jsonObject;

        }else{

            // 解析错误

            return nil;

        }

    }

    return nil;

}
//判断是否是一个网址
+ (BOOL)isUrlAddress:(NSString*)url

{
    
    if([url hasPrefix:@"http"]||[url hasPrefix:@"https"]){
        return YES;
    }else{
        return NO;
    }
    
//NSString*reg =@"((http[s]{0,1}|ftp)://[a-zA-Z0-9\\.\\-]+\\.([a-zA-Z]{2,4})(:\\d+)?(/[a-zA-Z0-9\\.\\-~!@#$%^&*+?:_/=<>]*)?)|(www.[a-zA-Z0-9\\.\\-]+\\.([a-zA-Z]{2,4})(:\\d+)?(/[a-zA-Z0-9\\.\\-~!@#$%^&*+?:_/=<>]*)?)";
//
//NSPredicate*urlPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", reg];
//
//return[urlPredicate evaluateWithObject:url];

}

/**
*  部分子字符串高亮显示(支持搜索的内容拆分为单个字符串与整体的数据进行比较)
*
*  @param substring  需高亮显示的字符串
*  @param color 高亮颜色
*
*  @return 富文本字符串
*/

- (NSMutableAttributedString *)stringWithPartHighLightSubstring:(NSString *)substring highLightColor:(UIColor *)color {
    
  
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:self];
    NSString * copyTotalString = self;
    NSMutableString * replaceString = [NSMutableString stringWithString:@" "];
    for (int i = 0; i < substring.length; i ++) {
        NSString *singleString = [substring substringWithRange:NSMakeRange(i, 1)];
        while ([copyTotalString rangeOfString:singleString].location != NSNotFound) {
             NSRange range = [copyTotalString rangeOfString:singleString];
             //颜色如果统一的话可写在这里，如果颜色根据内容在改变，可把颜色作为参数，调用方法的时候传入
             [attributedString addAttribute:NSForegroundColorAttributeName value:color range:range];
             copyTotalString = [copyTotalString stringByReplacingCharactersInRange:range withString:replaceString];
         }
    }
    return attributedString;
}
//去掉字符串中所有空格及换行
+(NSString *)removeSpaceAndNewline:(NSString *)str{
    NSString *temp = [str stringByReplacingOccurrencesOfString:@" " withString:@""];
    temp = [temp stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    temp = [temp stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    return temp;
}

//字节长度转化为KB，MB，GB等
+(NSString *)formattedFileSize:(unsigned long long)size {
    if (size == 0) return @"0 KB";
    NSArray *units = @[@"B", @"KB", @"MB", @"GB", @"TB", @"PB", @"EB", @"ZB", @"YB"];
    NSInteger index = (NSInteger)floor(log10(size)/log10(1000));
    double convertedSize = size / pow(1000, index);
    return [NSString stringWithFormat:@"%.2f %@", convertedSize, units[index]];
}

//该格式是否支持上传
+ (BOOL)supportedFileformats:(NSString *)formats{
    
    if ([[formats uppercaseString] isEqualToString:@"PNG"]||[[formats uppercaseString] isEqualToString:@"JPG"]||[[formats uppercaseString] isEqualToString:@"JPEG"]||[[formats uppercaseString] isEqualToString:@"GIF"]||[[formats uppercaseString] isEqualToString:@"HEIC"]||[[formats uppercaseString] isEqualToString:@"HEIF"]||[[formats uppercaseString] isEqualToString:@"MP4"]||[[formats uppercaseString] isEqualToString:@"3GP"]||[[formats uppercaseString] isEqualToString:@"MOV"]||[[formats uppercaseString] isEqualToString:@"FLV"]||[[formats uppercaseString] isEqualToString:@"F4V"]||[[formats uppercaseString] isEqualToString:@"WEBM"]||[[formats uppercaseString] isEqualToString:@"DOC"]||[[formats uppercaseString] isEqualToString:@"DOCX"]||[[formats uppercaseString] isEqualToString:@"XLS"]||[[formats uppercaseString] isEqualToString:@"XLSX"]||[[formats uppercaseString] isEqualToString:@"PPT"]||[[formats uppercaseString] isEqualToString:@"PPTX"]||[[formats uppercaseString] isEqualToString:@"XLSX"]||[[formats uppercaseString] isEqualToString:@"PDF"]||[[formats uppercaseString] isEqualToString:@"HTML"]||[[formats uppercaseString] isEqualToString:@"TXT"]||[[formats uppercaseString] isEqualToString:@"M4A"]||[[formats uppercaseString] isEqualToString:@"WMA"]||[[formats uppercaseString] isEqualToString:@"MP3"]||[[formats uppercaseString] isEqualToString:@"AAC"]||[[formats uppercaseString] isEqualToString:@"WMA"]||[[formats uppercaseString] isEqualToString:@"HEVC"]) {
        return YES;
    }
    return NO;//不为空
}

//对传入的double 类型，始终保留两位小数并向下取整
/**
 如果你想要向下舍入，但仍然避免由于浮点数精度问题导致的错误，你可以使用一个小技巧，将数值乘以一个大的倍数，然后再除以该倍数，以减小精度损失的影响。这样可以在尽量保留精度的同时达到向下舍入的效果,比如100改成10000**/
+ (NSString *)formattedStringWithDouble:(double)value{
    // 向下取整
     double roundedValue = floor(value * 10000) / 10000;
     
     // 使用NSNumberFormatter来保留两位小数
     NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
     [formatter setNumberStyle:NSNumberFormatterNoStyle];//NSNumberFormatterDecimalStyle
     [formatter setMinimumFractionDigits:2];
     [formatter setMaximumFractionDigits:2];
     
     return [formatter stringFromNumber:@(roundedValue)];
}


//对传入的double 类型，始终保留两位小数并向下取整,如果末尾数是0，则去掉
+ (NSString *)formattedStringWithoutZeroWithDouble:(double)value {
    
//    // 使用 NSNumberFormatter 进行格式化
//       NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
//       formatter.numberStyle = NSNumberFormatterDecimalStyle;
//       formatter.minimumFractionDigits = (value - (int)value) == 0 ? 0 : 2;  // 如果末尾两位小数都是0，则最小小数位数为0，否则为2
//       formatter.maximumFractionDigits = 2;
//       formatter.roundingMode = NSNumberFormatterRoundDown;
//       // 将 double 值转换为字符串并应用格式化
//       NSString *formattedString = [formatter stringFromNumber:@(value)];
//
//       return formattedString;
    NSString *formattedString = [NSString stringWithFormat:@"%.2lf", floor(value * 100) / 100];
       // 移除小数部分末尾的0
       while ([formattedString rangeOfString:@"."].location != NSNotFound &&
              ([formattedString hasSuffix:@"0"] || [formattedString hasSuffix:@"."])) {
           formattedString = [formattedString substringToIndex:formattedString.length - 1];
       }

       return formattedString;
}




//对传入的NSString 类型，始终保留两位小数并向下取整
+ (NSString *)formattedStringWithString:(NSString *)inputString {
//    // 将输入字符串转换为 double 值
//      double value = [inputString doubleValue];
//      
//      // 使用 NSNumberFormatter 进行格式化
//      NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
//      formatter.numberStyle = NSNumberFormatterDecimalStyle;
//      formatter.minimumFractionDigits = 0;  // 最小小数位数为 0
//      formatter.maximumFractionDigits = 2;  // 最大小数位数为 2
//      formatter.roundingMode = NSNumberFormatterRoundDown;
//      
//      // 将 double 值转换为字符串并应用格式化
//      NSString *formattedString = [formatter stringFromNumber:@(value)];
//    return formattedString;
      double value = [inputString doubleValue];
      NSString *formattedString = [NSString stringWithFormat:@"%.2lf", floor(value * 100) / 100];
      // 移除小数部分末尾的0
      while ([formattedString rangeOfString:@"."].location != NSNotFound &&
             ([formattedString hasSuffix:@"0"] || [formattedString hasSuffix:@"."])) {
          formattedString = [formattedString substringToIndex:formattedString.length - 1];
      }

      return formattedString;
}


+(NSString *)maskEmail:(NSString *)email {
        NSArray<NSString *> *components = [email componentsSeparatedByString:@"@"];
        if (components.count != 2) {
            return email; // 如果不是有效的邮箱地址，返回nil
        }
        
        NSString *localPart = components[0];
        NSString *domainPart = components[1];
        
        if (localPart.length < 3) {
            return email; // 如果本地部分少于3个字符，返回nil
        }
        
        NSString *maskedLocalPart = [NSString stringWithFormat:@"%@****", [localPart substringToIndex:3]];
        
        return [NSString stringWithFormat:@"%@@%@", maskedLocalPart, domainPart];
    }


// 日期格式转换工具方法（把日期字符串2024-11-16 23:40:21改成2024.11.16  23:40:21 ）
+ (NSString *)convertDateString:(NSString *)originalDateString {
    
    
    return originalDateString;
    /*
    // 检查入参是否有效
    if (!originalDateString || originalDateString.length == 0) {
        return nil; // 入参为空，返回 nil
    }

    // 创建日期格式化器
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    // 设置原始日期格式
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    // 将原始字符串解析为 NSDate
    NSDate *date = [dateFormatter dateFromString:originalDateString];
    if (!date) {
        return nil; // 解析失败，返回 nil
    }
    
    // 设置目标日期格式
    dateFormatter.dateFormat = @"yyyy.MM.dd HH:mm:ss";
    
    // 将 NSDate 格式化为目标字符串
    NSString *formattedDateString = [dateFormatter stringFromDate:date];
    
    return formattedDateString;
     */
}


// 日期格式转换工具方法（把日期字符串2024-11-16 23:40:21改成2024/11/16  23:40:21 ）
+ (NSString *)convertDate2String:(NSString *)originalDateString {
    // 检查入参是否有效
    if (!originalDateString || originalDateString.length == 0) {
        return nil; // 入参为空，返回 nil
    }

    // 创建日期格式化器
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    // 设置原始日期格式
    dateFormatter.dateFormat = @"yyyy-MM-dd";
    
    // 将原始字符串解析为 NSDate
    NSDate *date = [dateFormatter dateFromString:originalDateString];
    if (!date) {
        return nil; // 解析失败，返回 nil
    }
    
    // 设置目标日期格式
    dateFormatter.dateFormat = @"yyyy/MM/dd";
    
    // 将 NSDate 格式化为目标字符串
    NSString *formattedDateString = [dateFormatter stringFromDate:date];
    
    return formattedDateString;
}

@end
