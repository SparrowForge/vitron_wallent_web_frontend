//
//  UIViewController+HideNavBackTitle.m
//  CregisCard
//
//  Created by sunliang on 2022/8/20.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "UIViewController+HideNavBackTitle.h"

@implementation UIViewController (HideNavBackTitle)

+(void)load {
swizzleMethod([self class], @selector(viewDidLoad), @selector(ac_viewDidLoad));
}

//设置导航栏返回按钮文字
- (void)ac_viewDidLoad{
//self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]
//initWithTitle:@""
//style:UIBarButtonItemStylePlain
//target:self
//action:nil];
    
//隐藏返回按钮
// [self.navigationController.navigationItem setHidesBackButton:YES];
// [self.navigationItem setHidesBackButton:YES];
// [self.navigationController.navigationBar.backItem setHidesBackButton:YES];
    
  [self ac_viewDidLoad];
}

void swizzleMethod(Class class, SEL originalSelector, SEL swizzledSelector)
{
// the method might not exist in the class, but in its superclass
Method originalMethod = class_getInstanceMethod(class, originalSelector);
Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);

// class_addMethod will fail if original method already exists
BOOL didAddMethod = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));

// the method doesn’t exist and we just added one
if (didAddMethod) {
class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
}
else {
method_exchangeImplementations(originalMethod, swizzledMethod);
}
}
@end
