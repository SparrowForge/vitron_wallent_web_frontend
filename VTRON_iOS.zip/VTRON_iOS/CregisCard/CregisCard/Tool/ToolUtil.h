//
//  ToolUtil.h
//  DynamicTraffic 3.0
//
//  Created by sunliang on 16/6/24.
//  Copyright © 2016年 yundi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface ToolUtil : NSObject
//加载16进制颜色
+ (UIColor *)colorWithHexString:(NSString *)color;
//
+ (NSString*)checkNullOrEmpty:(id)obj;
+ (BOOL)checkPhoneNumInput:(NSString *)phoneStr;//电话号码匹配
//保存UUID到Keychain
+ (void)save:(NSString *)service data:(id)data;
//keychain中取出UUDI
+ (id)load:(NSString *)service;

+ (void)delete:(NSString *)service;

//转换成code
+ (NSString *)encodeToPercentEscapeString: (NSString *) input;
//根据当前时间 ->年月日时分
+ (NSString *)printDateStringWithNowDate:(NSString *)format;

//截图
+ (UIImage *)screenShot;

//输入框只能输入中文，字母，数字
+ (BOOL)textfiledOnlyCanInputWithText:(NSString *)text;

//获取UTC时间
+ (NSString *)presentDateTransformUTCdateWithFormat:(NSString *)format;

//MARK:--时间字符串转为时间戳
+ (long  long)returnHowManyMintesswithstr:(NSString *)timeStr;
//匹配6-20位的密码
+ (BOOL)matchPassword:(NSString *)password;
//匹配邮箱帐号
+ (BOOL)matchEmail:(NSString *)email;
//匹配手机号
+ (BOOL)matchPhone:(NSString *)phone;
//国际手机号匹配
+ (BOOL)matchWorldPhone:(NSString *)phone;

+(NSString *)stampFormatterWithStamp:(NSInteger)stamp;

//当日0点
+ (NSDate *)zeroOfDate;

//判断字符串后有几位小数，超过length位就省略
+(NSString *)judgeStringForDecimalPlaces:(NSString *)string withLength:(int)length;

//MARK:--科学计数法转具体数字 ,如果传输的就是具体数据，可控制其小数点后面最多保留length位
+(NSString *)formartScientificNotationWithString:(NSString *)str withLength:(int)length;

//MARK:--秒时间戳转 formatterStr为转化格式 yyyy-MM-dd HH:mm:ss HH:mm MM/dd
+ (NSString *)secTimeStampToDateTime:(NSString *)timeStr withFormatterStr:(NSString *)formatterStr;

//MARK:--毫秒时间戳转 formatterStr为转化格式 yyyy/MM/dd HH:mm:ss
+ (NSString *)timeStampToDateTime:(NSString *)timeStr withFormatterStr:(NSString *)formatterStr;

//MARK:--时间字符串转化 formatterStr为转化格式 yyyy/MM/dd HH:mm:ss
+(NSString *)transformForTimeString:(NSString *)timeStr withFormatterStr:(NSString *)formatterStr;

//MARK:--获取当前时间（秒）
+ (NSString *)getCurrentTimeSec;

//MARK:--获取当前时间（毫秒）
+ (NSString *)getCurrentTimeMilliSecond;

//MARK:--获取当前日期
+ (NSString *)getCurrentTimeWithFormatterStr:(NSString *)formatterStr;
//doubleNumber,原数据，decimalNum,保留的小数位数
+(NSString*)stringFromNumber:(double)doubleNumber withlimit:(int)decimalNum;
// 截取小数点后面length  18 <= leng >= 2 isLength:是否只处理保留小数点后两位
+ (NSString *)decimalNumberFromString:(NSString *)number withNormalLength:(BOOL)isLength;
//获取当前的时间  YYYY-MM-dd HH:mm:ss
+(NSString*)getCurrentDateString;
//MARK:--截取小数点后面length位
+(NSString*)cutOutLengthDecimalPoint:(NSString *)str withLength:(int)length;
//MARK:--NSData转long long
+(long long) NSDataToUInt:(NSData *)data;
//MARK:--浮点数处理并去掉多余的0
+(NSString *)removeFloatAllZeroByString:(NSString *)testNumber;

//MARK:--密码同时包含8~20位数字和大小写字母，不包含特殊字符的判断方法（正则表达式）
+ (BOOL)isOrNoPasswordStyle:(NSString *)passWordName;

//MARK:--判断是否含有表情文字
+ (BOOL)stringContainsEmoji:(NSString *)string;

//MARK:--计算宽度
+ (CGFloat)caculateWidth:(NSString *)text size:(UIFont *)font height:(CGFloat)height;

//MARK:--重设图片尺寸
+ (UIImage *)imageResize:(UIImage*)img andResizeTo:(CGSize)newSize;

//截断显示，不四舍五入
+(NSString *)notStrRounding:(NSString *)price afterPoint:(int)position;

//截断显示，不四舍五入 position代表截断的位数NSDecimalNumber
+(NSString *)notRounding:(NSDecimalNumber *)price afterPoint:(int)position;

//截断显示，四舍五入
+(NSString *)strRounding:(NSString *)price afterPoint:(int)position;

//截断显示，四舍五入 position代表截断的位数NSDecimalNumber
+(NSString *)rounding:(NSDecimalNumber *)price afterPoint:(int)position;


//MARK:--判断控制器是否显示
+ (BOOL) viewControllerIsShow:(UIViewController *)vc;

//MARK:--获取字符串二维码
+(UIImage *)createNonInterpolatedUIImageForString:(NSString *)qrString withSize:(CGFloat) size;

//MARK:--判断String是否为空
+ (BOOL) stringIsNil:(NSString *)string;
//判断当前控制器
+ (UIViewController *)getCurrentViewController;
+(NSString *)getNowTimeTimestamp;
//MARK:--NSDate转化为自定义时间
+(NSString *)timeStampForDate:(NSDate *)date withFormatterStr:(NSString *)formatterStr;
//MARK:--比较两个版本号的大小（2.0）
+ (NSInteger)compareVersion:(NSString *)v1 to:(NSString *)v2;

+ (NSString *)removeFloatAllZeroAnd8PlaceByString:(NSString *)testNumber;

//资产字符串每三位插入一个逗号
+(NSString *)insetDouhao:(NSString *)str;
//获取实名认证时，手写提示
+(NSString*)getPromptForrealNameAuthenticationWithHost:(NSString*)host;
//MARK:--获取数组中最小值
+(int)getMinNumInArr:(NSArray *)array;
//计算两个日期的间隔
+(NSInteger)calculateTimeWithStartTime:(NSString *)startTime;
//获取某个日期的时间戳
+ (NSString*)getCurrentTimeStampWithFormatterStr:(NSString *)formatterStr WithTime:(NSString *)timeStr;
//如果想要判断设备是ipad，要用如下方法
+ (BOOL)getIsIpad;
//根据文字宽度和行间距，计算高度
+ (CGFloat)getLabelHeightWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font withLineSpacing:(CGFloat)LineSpacing;
//根据文字宽度，计算Label高度
+ (CGFloat)getLabelHeightWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font;
//根据文字宽度，计算高度
+ (CGFloat)getTextViewHeightWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font;
+ (CGSize)getLabelSizeWithText:(NSString *)text width:(CGFloat)width font: (UIFont*)font;
//压缩图片
+ (NSData *)compressWithOrgImg:(NSData *)imageData;
@end
