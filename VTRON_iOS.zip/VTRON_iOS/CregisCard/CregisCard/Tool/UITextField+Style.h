//
//  UITextField+Style.h
//  CregisCard
//
//  Created by sunliang on 2025/7/17.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (Style)
-(void)setStyleWithPlaceholder:(NSString*)placeholder;
@end

NS_ASSUME_NONNULL_END
