//
//  UIViewController+UBTrackerStyle.m
//  CregisCard
//
//  Created by sunliang on 2022/4/26.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "UIViewController+UBTrackerStyle.h"
#import "UBTrackerFindController.h"
@implementation UIViewController (UBTrackerStyle)
//系统提示框
-(void)addUIAlertControlWithTileString:(NSString *)titleStr WithSubString:(NSString *)subString withActionBlock:(void(^)(void))actionBlock WithActionString:(NSString *)actionTitleStr andCancel:(void(^)(void))cancelBlock WithCancelString:(NSString *)cancelTitleStr{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:titleStr message:subString preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:actionTitleStr style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        actionBlock();
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:cancelTitleStr style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        cancelBlock();
    }]];
   
    dispatch_async(dispatch_get_main_queue(), ^{
        [[UBTrackerFindController findCurrentShowingViewController] presentViewController: alert animated: YES completion: nil];
    });
}

//自定义弹出框
-(void)addCustomUIAlertControlWithString:(NSString *)titleString  WithSubString:(NSString *)subString Withalignment:(NSTextAlignment)alignment withActionBlock:(void(^)(void))actionBlock WithActionString:(NSString *)actionTitleStr  andCancel:(void(^)(void))cancelBlock WithCancelString:(NSString *)cancelTitleStr{
  
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:titleString message:subString preferredStyle:UIAlertControllerStyleAlert];
       //修改title
        NSMutableAttributedString *alertControllerStr = [[NSMutableAttributedString alloc] initWithString:titleString];
        [alertControllerStr addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, titleString.length)];
        [alertControllerStr addAttribute:NSFontAttributeName value:[UIFont boldSystemFontOfSize:17] range:NSMakeRange(0, titleString.length)];
        [alert setValue:alertControllerStr forKey:@"attributedTitle"];
        //修改message
        NSMutableAttributedString *alertControllerMessageStr = [[NSMutableAttributedString alloc] initWithString:subString];
        [alertControllerMessageStr addAttribute:NSForegroundColorAttributeName value:[[UIColor blackColor] colorWithAlphaComponent:0.6] range:NSMakeRange(0, subString.length)];
        [alertControllerMessageStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(0, subString.length)];
        NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
        paragraph.alignment = alignment;//对齐方式
       [alertControllerMessageStr addAttribute:NSParagraphStyleAttributeName value:paragraph range:NSMakeRange(0, subString.length)];
        [alert setValue:alertControllerMessageStr forKey:@"attributedMessage"];
    UIView *firstSubview = alert.view.subviews.firstObject;
    UIView *alertContentView = firstSubview.subviews.firstObject;
    for (UIView *subSubView in alertContentView.subviews) { //This is main catch
        subSubView.backgroundColor = [UIColor whiteColor]; //Here you change background
    }
    UIAlertAction *cencerAct=[UIAlertAction actionWithTitle:cancelTitleStr style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        cancelBlock();
    }];
    [cencerAct setValue:[[UIColor blackColor] colorWithAlphaComponent:0.4] forKey:@"_titleTextColor"];
    [alert addAction:cencerAct];
    
    UIAlertAction *endAct=[UIAlertAction actionWithTitle:actionTitleStr style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        actionBlock();
    }];
    [endAct setValue: [UIColor colorWithHexString:@"#0066FF" alpha:1] forKey:@"_titleTextColor"];
  
    [alert addAction:endAct];
   
    dispatch_async(dispatch_get_main_queue(), ^{
        [[UBTrackerFindController findCurrentShowingViewController] presentViewController: alert animated: YES completion: nil];
    });
}

@end
