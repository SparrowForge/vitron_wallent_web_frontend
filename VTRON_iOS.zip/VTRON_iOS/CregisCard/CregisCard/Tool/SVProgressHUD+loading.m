//
//  SVProgressHUD+loading.m
//  CregisCard
//
//  Created by 孙良 on 2024/10/29.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "SVProgressHUD+loading.h"
#import "UIImage+GIFImage.h"
@implementation SVProgressHUD (loading)

+ (void)load{
   [SVProgressHUD switchDurationForString];

}

+ (void)switchDurationForString {

Class cls = object_getClass(self);

Method originMethod = class_getClassMethod(cls,@selector(displayDurationForString:));

Method swizzledMethod = class_getClassMethod(cls,@selector(my_displayDurationForString:));

[self swizzleMethodWithOriginSel:@selector(displayDurationForString:) oriMethod:originMethod swizzledSel:@selector(my_displayDurationForString:) swizzledMethod:swizzledMethod class:cls];

}

+ (void)swizzleMethodWithOriginSel:(SEL)oriSel oriMethod:(Method)oriMethod swizzledSel:(SEL)swizzledSel swizzledMethod:(Method)swizzledMethod class:(Class)cls {
    BOOL didAddMethod = class_addMethod(cls, oriSel, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
 if(didAddMethod) {
 class_replaceMethod(cls, swizzledSel, method_getImplementation(oriMethod), method_getTypeEncoding(oriMethod));
 }else{
      method_exchangeImplementations(oriMethod, swizzledMethod);
 }

}

+ (NSTimeInterval)my_displayDurationForString:(nullable NSString*)string {

    
    return 10000.f;
//   if([string hasSuffix:@"\0"]) {
//
//    return 200.f;
//
// }
//NSTimeInterval interval = [SVProgressHUD my_displayDurationForString:string];
// return interval;

}
//带有加载动效
+(void)customShowWithStyle{
   
    [SVProgressHUD showImage:[UIImage imageWithGIFNamed:@"动效"] status:nil];
    //[SVProgressHUD showImage:[UIImage imageNamed:@"mainAppIcon"] status:nil];
    [SVProgressHUD setShouldTintImages:NO];
    [SVProgressHUD setForegroundColor:[UIColor blackColor]];
    [SVProgressHUD setBackgroundColor:[UIColor blackColor]];
}
//带有加载动效,带文字
+(void)customShowWithStyleWithStatus:(NSString*)status{
   
    [SVProgressHUD showImage:[UIImage imageWithGIFNamed:@"动效"] status:status];
    [SVProgressHUD setShouldTintImages:NO];
     
    [SVProgressHUD setBackgroundColor:[UIColor blackColor]];
    
}
//完全透明不可见
+(void)customShowWithNone{
   
    // 设置前景色和背景色为透明
    [SVProgressHUD setBackgroundColor:[UIColor colorWithWhite:0 alpha:0]];
    [SVProgressHUD setForegroundColor:[UIColor colorWithWhite:0 alpha:0]];
    [SVProgressHUD show];
    
}

@end
