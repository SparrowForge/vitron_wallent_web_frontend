//
//  UIViewController+navStyle.h
//  horizonLoan
//
//  Created by sunliang on 2017/9/30.
//  Copyright © 2017年 XinHuoKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^BackBlock) (UIButton *);
@interface UIViewController (navStyle)
//返回按钮
@property (nonatomic, weak) UIButton *backBtn;
//返回按钮：响应回调
@property (nonatomic, copy) BackBlock backBlock;

-(void)setNavigationControllerStyle;//设置导航栏样式
-(void)cancelNavigationControllerStyle;//还原导航栏样式
// 返回按钮：自定义图片
-(void)backBtnNoNavBar:(BOOL)noNavBar normalBack:(BOOL)normalBack;
// 返回按钮：白色图片
-(void)whitebackBtnNoNavBar:(BOOL)noNavBar normalBack:(BOOL)normalBack;

/** 下拉刷新
 */
- (void)headRefreshWithScrollerView:(UIScrollView *)scrol;
//上拉加载
- (void)footRefreshWithScrollerView:(UIScrollView *)scrol;

/// 集成nav上右侧的控件
/// @param pictureName 图片名
/// @param isChange 控件颜色是否随动
-(void)RightsetupNavgationItemWithpictureName:(NSString*)pictureName withColorIsChange:(BOOL)isChange;
//集成nav上左侧的控件
- (void)LeftsetupNavgationItemWithpictureName:(NSString*)pictureName;
-(void)RightsetupNavgationItemWithImage:(UIImage*)picImage withColor:(UIColor*)color;
/** 导航左侧按钮-文字
 */
-(void)leftBarItemWithTitle:(NSString *)title;
/** 导航右侧按钮-文字
 */
-(void)rightBarItemWithTitle:(NSString *)title;
-(void)rightBarItemWithTitle:(NSString *)title color:(UIColor *)color;
-(void)openLargeTitle;
-(void)hideNavBar; //隐藏导航栏
-(void)showNavBar; //显示导航栏
//View切圆角
- (void)maskToCorner:(UIView *)view RoundingCorners:(UIRectCorner)corner cornerRedius:(CGSize)size;
-(void)hideNavigationBarBottomLine:(BOOL)hidden;

/// 指定导航返回控制器
/// @param fromVc 当前视图控制器
/// @param toVc 目标视图控制器
- (void)makeFrom:(UIViewController *)fromVc toVc:(Class)toVc;

/// 指定导航返回控制器
/// @param fromVc  当前视图控制器
/// @param toVcClass 目标视图控制器类
- (void)gobackFromVc:(UIViewController *)fromVc toVc:(Class )toVcClass;
-(void)addUIAlertControlWithString:(NSString *)string withActionBlock:(void(^)(void))actionBlock andCancel:(void(^)(void))cancelBlock;
-(void)addUIAlertControlForUpdateWithString:(NSString *)string withcanCancle:(BOOL)canCancel withActionBlock:(void(^)(void))actionBlock andCancel:(void(^)(void))cancelBlock;
-(void)LeftsetupNavgationItemWithImage:(UIImage*)picImage withColor:(UIColor*)color;
/// 集成nav上右侧的控件
/// @param pictureName 图片名
/// @param color 控件颜色
-(void)RightsetupNavgationItemWithpictureName:(NSString*)pictureName withColor:(UIColor *)color;
#pragma mark -若用户未登录，则显示登录界面
-(void)showLoginViewController;



/**  退出 presentViewController  count：次数*/
- (void)dismissViewControllerWithCount:(NSInteger)count animated:(BOOL)animated;


/**  退出 presentViewController 到指定的控制器*/
- (void)dismissToViewControllerWithClassName:(NSString *)className animated:(BOOL)animated;

@end
