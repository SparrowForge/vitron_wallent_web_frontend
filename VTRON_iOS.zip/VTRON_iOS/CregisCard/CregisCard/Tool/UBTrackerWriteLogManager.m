//
//  SLWriteLogManager.m
//  exchange
//
//  Created by sunliang on 2021/2/20.
//  Copyright © 2021 XinHuoKeJi. All rights reserved.
//

#import "UBTrackerWriteLogManager.h"

@implementation UBTrackerWriteLogManager

#pragma mark - Instance

+ (UBTrackerWriteLogManager *)writeLog_shareManager {
    static UBTrackerWriteLogManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[UBTrackerWriteLogManager alloc] init];
    });
    return instance;
}


#pragma mark _Publish

- (void)writeLog_startWriteLogToFile {
    /// 子线程中操作
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        /// log文件路径
        NSString *logFilePath = [self writeLog_logFilePath];
        /// 删除已经存在的文件
        NSFileManager *defaultManager = [NSFileManager defaultManager];
        if ([defaultManager fileExistsAtPath:logFilePath]) {
            [defaultManager removeItemAtPath:logFilePath error:nil];
        }
        freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding],"a+", stdout);
        freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding],"a+", stderr);
        /// 获取手机设备信息
        [self writeLog_iPhoneMessage];
    });
}


/// 获取log文件路径
- (NSString *)writeLog_logFilePath {
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    NSString *fileName = [NSString stringWithFormat:@"CregisCarder_iOS.log"];
    NSString *logFilePath = [documentDirectory stringByAppendingPathComponent:fileName];
    return logFilePath;
}


/// 通过社交app分享log文件
- (void)writeLog_shareLogFile {
    NSURL *fileURL = [NSURL fileURLWithPath:[self writeLog_logFilePath]];
    NSArray *activityItems = @[fileURL];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems
                                                                             applicationActivities:nil];
    /// 根视图中显示分享界面
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:activityVC
                                                                                 animated:YES
                                                                               completion:nil];
}


#pragma mark - Method

/// 当前手机设备信息
- (void)writeLog_iPhoneMessage {
    UIDevice *device = [UIDevice currentDevice];
    NSDictionary *iPhoneMessageDict = @{ @"name" : device.name,
                                         @"model" : device.model,
                                         @"localizedModel" : device.localizedModel,
                                         @"systemName" : device.systemName,
                                         @"systemVersion" : device.systemVersion,
                                         @"identifierForVendor" : device.identifierForVendor};
    NSLog(@"device info = %@", iPhoneMessageDict);
}



@end
