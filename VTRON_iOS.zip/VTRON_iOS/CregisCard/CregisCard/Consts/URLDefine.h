//
//  URLDefine.h
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#ifndef URLDefine_h
#define URLDefine_h

#define Appstore_account  @"1825571811@qq.com"//appstore审核账号

#define MY_PROJECT_GLOBAL_CONTROL 1 //项目环境

#if (MY_PROJECT_GLOBAL_CONTROL == 0)//开发环境

#define DOMAINCOM @"192.168.2.123"//通行密钥使用

#define HOST_Global      @"http://192.168.2.30:8080"

#define HOST_Exclusive      @"http://192.168.2.30:8080"
/**
 管理端：https://admin.vtron-card.com/login/
 */

#elif (MY_PROJECT_GLOBAL_CONTROL == 1)//测试环境

#define DOMAINCOM @"platform.beexpay.net"//通行密钥使用

#define HOST_Global         @"https://platform.vtron-card.com"

#define HOST_Exclusive      @"https://platform.vtron-card.com"
/**
 管理端：https://admin.vtron-card.com
 */
#else //生产环境

#define DOMAINCOM @"platform.vcard-usa.com"//通行密钥使用

#define HOST_Global @"https://platform.vcard-usa.com"

//专属节点
#define HOST_Exclusive      @"https://platform.vcard-usa.com"
/**
 管理端：https://admin.cregispay.top
 */

#endif
#endif /* URLDefine_h */
