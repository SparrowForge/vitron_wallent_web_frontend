//
//  NotificaDefine.h
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#ifndef NotificaDefine_h
#define NotificaDefine_h

#define kNotificationWXLOGIN_AUTHORIZED     @"wxLogin"//微信登录成功的通知
#define kNotificationWXLOGIN_USERCANCELLED  @"wxCancel"//微信登录取消的通知
#define DarkMode                            @"DarkMode" //夜间模式
#define LocalLanguageKey                    @"LocalLanguageKey" //选择语言
#define ACCESS_TOKEN                        @"access_token"
#define REFRESH_TOKEN                       @"refresh_token"
#define APPID_TOKEN                       @"appId"
#define HIDDENACCOUNT                     @"HiddenAccount"//是否隐藏账户余额
#define HIDDENHOMECARD                     @"HiddenHomeCard"//是否隐藏首页卡片账户余额
#define KNotificationLanguageChange         @"LanguageChange" //切换语言
#define SHOW_RECHARGE                        @"showRecharge"//显示充币提示
#define NOTE_EXCLUSIVE                       @"ExclusiveNote"//专属节点

#define KACCOUNT          @"account" //账号
#define KPSD              @"passwaord" //密码
#define Login_OUT         @"Loginout" //退出登录
#define Login_OUT_OTHER   @"LoginoutForOther" //退出登录(被别的设备踢下线)
#define NET_CHANGE        @"NET_CHANGE" //网络变化
#define CHANGE_ONLINE_STATUS  @"changeOnlieStatus"//改变用户在线状态
#define KEYBOARDDOWN  @"UBTracker_keyBoardDown"//键盘下落
#define UT_ARTICLE    @"UBTracker_article"//发送wiki文章
#define UT_FASTREPLY    @"UBTracker_fastReplay"//发送快捷回复
#define UT_MODIFYUSERNAME   @"UBTracker_modifyName"//修改用户名称
#define UT_CHANGEPROJECT   @"UBTracker_changeProject"//切换项目
#define KEYBOARD_CONTENT_CHANGE         @"KEYBOARD_CONTENT_CHANGE" //输入框内容变化

#define UT_ORIGINALIMAGE   @"UBTracker_OriginalImage"//下载原图
#define ReloadBIN                        @"ReloadBin"//申请卡或者创建持卡人时候，刷新

//长链接
#define K_ON_CHAT             @"on_chat_message" //发送消息
#define K_ON_INSIDECHAT       @"on_inside_message" //内部消息
#define K_ON_MESSAGE_READ      @"on_message_read" //未读消息变成了已读
#define K_REMIND_CHAT_READ     @"on_remind_chat_read" //消息列表小红点消息
#define K_ENTER_REMING         @"on_enter_remind" //键入消息提醒

#define K_SOUND_CHANGE        @"on_sound_status_change" //音效开关通知

#define K_CREATE_CHAT         @"on_create_chat" //创建了会话
#define K_ALLOT_CHAT          @"on_allot_chat" //分配了会话
#define K_END_CHAT            @"on_end_chat" //结束了会话
#define K_AUTO_END_CHAT       @"end_chat" //系统主动结束了会话(时间到期)
#define K_REOPEN_CHAT         @"on_reopen_chat" //重新打开了会话
#define K_RE_ALLOT_CHAT       @"on_re_allot_chat" //重新分配了会话
#define K_ADDRESS_CHANGE_CHAT @"on_address_change" //位置发生了变更
#define K_OVER_CHAT           @"on_over_chat" //会话过期
#define K_REMOVE_CHAT           @"allot_chat" //移除了会话分配
#define K_REVOCATION_MESSAGE         @"on_revocation_message" //撤销消息

#define K_CHANGE_STATUS           @"on_member_change_status" //改变了工作状态

#define K_TRANSLATE_MESSAGE  @"on_message_translate" //翻译消息完成
#define K_INSIGHT_MESSAGE  @"on_chatUnderstand_message" //会话洞察
#define K_CHATENHANCE_MESSAGE  @"on_chatEnhance_message" //扩展，改写
#endif /* NotificaDefine_h */
