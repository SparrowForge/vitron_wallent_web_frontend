//
//  Const.h
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#ifndef Const_h
#define Const_h



// 屏幕宽高
#define SCREEN_WIDTH        [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT       [UIScreen mainScreen].bounds.size.height
#define kWindowW            [UIScreen mainScreen].bounds.size.width
#define kWindowH            [UIScreen mainScreen].bounds.size.height //应用程序的屏幕高度
// 判断 iPad
#define DX_UI_IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

// 判断iPhone X
#define DX_Is_iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)

//判断iPHoneXr | 11
#define DX_Is_iPhoneXR ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPHoneXs | 11Pro
#define DX_Is_iPhoneXS ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhoneXs Max | 11ProMax
#define DX_Is_iPhoneXS_MAX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone12_Mini
#define DX_Is_iPhone12_Mini ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1080, 2340), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone12 | 12Pro
#define DX_Is_iPhone12 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1170, 2532), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone12 Pro Max
#define DX_Is_iPhone12_ProMax ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1284, 2778), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone13_Mini
#define DX_Is_iPhone13_Mini ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1080, 2340), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone13 | 13Pro
#define DX_Is_iPhone13 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1170, 2532), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone13 Pro Max
#define DX_Is_iPhone13_ProMax ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1284, 2778), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//判断iPhone 14 Pro
#define DX_Is_iPhone14_Pro ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1179, 2556), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//iPhone 14 Pro Max
#define DX_Is_iPhone14_ProMax  ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1290, 2796), [[UIScreen mainScreen] currentMode].size) && !DX_UI_IS_IPAD : NO)

//x系列，带刘海
//#define DX_IS_IPhoneX_All (DX_Is_iPhoneX || DX_Is_iPhoneXR || DX_Is_iPhoneXS || DX_Is_iPhoneXS_MAX || DX_Is_iPhone12_Mini || DX_Is_iPhone12 || DX_Is_iPhone12_ProMax|| DX_Is_iPhone13_Mini || DX_Is_iPhone13 || DX_Is_iPhone13_ProMax||DX_Is_iPhone14_Pro||DX_Is_iPhone14_ProMax)

#define DX_IS_IPhoneX_All \
({BOOL isBang = NO; \
if (@available(iOS 11.0, *)) { \
    isBang = [[UIApplication sharedApplication].delegate.window safeAreaInsets].top > 20; \
} \
isBang;})

#define UBTracker_phoneStatusHeight \
({ \
    CGFloat height = 0.0; \
    if (@available(iOS 13.0, *)) { \
        CGFloat topHeight = [UIApplication sharedApplication].windows.firstObject.safeAreaInsets.top; \
        height = topHeight ? topHeight : 20.0; \
    } else { \
        height = [[UIApplication sharedApplication] statusBarFrame].size.height; \
    } \
    height; \
})//最新的获取状态栏高度的方法 06-21,如果topHeight=0（横屏时），则设置为20


// 状态栏高度
#define STATUS_BAR_HEIGHT UBTracker_phoneStatusHeight

// 导航栏高度
#define NAVIGATION_BAR_HEIGHT (UBTracker_phoneStatusHeight >20? (UBTracker_phoneStatusHeight+44) : 64)

// tabBar高度
#define TAB_BAR_HEIGHT (DX_IS_IPhoneX_All ? (49.f+34.f) : 49.f)

// home indicator
#define HOME_INDICATOR_HEIGHT (DX_IS_IPhoneX_All ? 34.f : 0.f)

#define UIIMAGE(name)       [UIImage imageNamed:name]
#define Thumbnail(imageUrl)       [NSString stringWithFormat:@"%@?x-oss-process=image/quality,q_30",imageUrl]//OSS压缩图片
//国际化
#define LocalizationKey(key) [[ChangeLanguage bundle] localizedStringForKey:key value:nil table:@"Localizable"]

//黑夜模式
#define IsDarkMode NO
// RGB颜色
#define RGB(r, g, b, a)     [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
//十六进制颜色
#define UIColorFromHexWithAlpha(hexValue,a) [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 green:((float)((hexValue & 0xFF00) >> 8))/255.0 blue:((float)(hexValue & 0xFF))/255.0 alpha:a]
#define PingFangMediumFont(sizeFont) \
[UIFont fontWithName:@"PingFangSC-Medium"size:(sizeFont)] // [UIFont systemFontOfSize:sizeFont weight:UIFontWeightMedium];
#define RegularFont(sizeFont) \
[UIFont systemFontOfSize:(sizeFont)]
//单例快速写法
#define CREATE_SHARED_MANAGER(CLASS_NAME) \
+ (instancetype)sharedManager { \
static CLASS_NAME *_instance; \
static dispatch_once_t onceToken; \
dispatch_once(&onceToken, ^{ \
_instance = [[CLASS_NAME alloc] init]; \
}); \
\
return _instance; \
}



#endif /* Const_h */
