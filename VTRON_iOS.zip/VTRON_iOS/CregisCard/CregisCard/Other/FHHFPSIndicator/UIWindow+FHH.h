//
//  UIWindow+FHH.h
//  FHHFPSIndicator:https://github.com/jvjishou/FHHFPSIndicator
//
//  Created by 002 on 16/6/27.
//  Copyright © 2016年 002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (FHH)

@end
