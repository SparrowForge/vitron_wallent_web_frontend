//
//  VerCodeInputView.m
//  VerCodeInputView
//
//  Created by sunliang on 2019/4/13.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import "VerCodeInputView.h"
#import "Masonry.h"
#import "UIView+MQ.h"
#import "UIView+UBTrackerCornerRedius.h"
@interface VerCodeInputView ()<UITextViewDelegate>

@property (nonatomic, strong) UIView *contairView;
@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) NSMutableArray *viewArr;
@property (nonatomic, strong) NSMutableArray *labelArr;
@property (nonatomic, strong) NSMutableArray *pointlineArr;

@end

@implementation VerCodeInputView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initDefaultValue];
    }
    return self;
}
-(void)awakeFromNib{
    
    [super awakeFromNib];
    [self initDefaultValue];
    
}
-(void)initDefaultValue{
    //初始化默认值
    self.maxLenght = 4;
     _viewColor = [UIColor lightGrayColor];
     _viewColorHL = [UIColor baseColor];
    self.backgroundColor = [UIColor clearColor];
    //[self beginEdit];
}

-(void)mq_verCodeViewWithMaxLenght{
    //创建输入验证码view
    if (_maxLenght<=0) {
        return;
    }
    if (_contairView) {
        [_contairView removeFromSuperview];
    }
    _contairView  = [UIView new];
    _contairView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_contairView];
    [_contairView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(self.mas_height);
        make.centerX.equalTo(self);
        make.centerY.equalTo(self);
    }];
    [_contairView addSubview:self.textView];
    //添加textView
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self->_contairView);
    }];
    
    CGFloat padding = (CGRectGetWidth(self.frame) -_maxLenght*CGRectGetHeight(self.frame))/(_maxLenght - 1);
    UIView *lastView;
    for (int i=0; i<self.maxLenght; i++) {
        UIView *subView = [UIView new];
        subView.backgroundColor = [UIColor clearColor];
        subView.cornerRadius = 4;
        subView.borderWidth = (0.5);//
        subView.borderColor=[UIColor lightGrayColor];//
        subView.userInteractionEnabled = NO;
        [_contairView addSubview:subView];
        [subView mas_makeConstraints:^(MASConstraintMaker *make) {
            if (lastView) {
                make.left.equalTo(lastView.mas_right).with.offset(padding);
            }else{
                make.left.equalTo(@(0));
            }
            make.centerY.equalTo(self.contairView);
            make.height.equalTo(self.contairView.mas_height);
            make.width.equalTo(self.contairView.mas_height);
            
        }];
        UILabel *subLabel = [UILabel new];
        subLabel.font = [UIFont systemFontOfSize:38];
        subLabel.textColor=[UIColor blackColor];
        [subView addSubview:subLabel];
        [subLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(subView);
            make.centerY.equalTo(subView);
        }];
        lastView = subView;
        
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake((CGRectGetHeight(self.frame)-2)/2,5,2,(CGRectGetHeight(self.frame)-10))];
        CAShapeLayer *line = [CAShapeLayer layer];
        line.path = path.CGPath;
        line.fillColor =  _viewColorHL.CGColor;
        [subView.layer addSublayer:line];
        if (i == 0) {//初始化第一个view为选择状态
            [line addAnimation:[self opacityAnimation] forKey:@"kOpacityAnimation"];
            line.hidden = NO;
            subView.borderColor = _viewColorHL;
    
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
              //  [self setBorderWithView:subView top:NO left:NO bottom:YES right:NO borderColor:self->_viewColorHL borderWidth:1];
            });
            
           
        }else{
            line.hidden = YES;
            subView.borderColor = _viewColor;
   
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
              //  [self setBorderWithView:subView top:NO left:NO bottom:YES right:NO borderColor:self->_viewColor borderWidth:1];
                
            });
        }
        [self.viewArr addObject:subView];
        [self.labelArr addObject:subLabel];
        [self.pointlineArr addObject:line];
    }
    [_contairView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(lastView?lastView.mas_right:@(0));
    }];
}

#pragma mark - TextView

-(void)beginEdit{
    [self.textView becomeFirstResponder];
}

-(void)endEdit{
    [self.textView resignFirstResponder];
}

- (void)textViewDidChange:(UITextView *)textView{
    
    NSString *verStr = textView.text;
    //有空格去掉空格
    verStr = [verStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (verStr.length >= _maxLenght) {
        verStr = [verStr substringToIndex:_maxLenght];
        [self endEdit];
    }
    textView.text = verStr;

    if (self.block) {
        //将textView的值传出去
        self.block(verStr);
    }

    for (int i= 0; i < self.viewArr.count; i++) {
        //以text为中介区分
        UILabel *label = self.labelArr[i];
        if (i<verStr.length) {
            [self changeViewLayerIndex:i pointHidden:YES];
            label.text = [verStr substringWithRange:NSMakeRange(i, 1)];

        }else{
            [self changeViewLayerIndex:i pointHidden:i==verStr.length?NO:YES];
            if (!verStr&&verStr.length==0) {//textView的text为空的时候
                [self changeViewLayerIndex:0 pointHidden:NO];
            }
            label.text = @"";
        }
    }
}
- (void)changeViewLayerIndex:(NSInteger)index pointHidden:(BOOL)hidden{
    
    UIView *view = self.viewArr[index];
    view.borderColor = hidden?_viewColor:_viewColorHL;
    
//    UIColor*color=hidden?_viewColor:_viewColorHL;
//    [self setBorderWithView:view top:NO left:NO bottom:YES right:NO borderColor:color borderWidth:1];
    CAShapeLayer *line =self.pointlineArr[index];
    if (hidden) {
        [line removeAnimationForKey:@"kOpacityAnimation"];
    }else{
        [line addAnimation:[self opacityAnimation] forKey:@"kOpacityAnimation"];
    }
    line.hidden = hidden;

}

- (CABasicAnimation *)opacityAnimation {
    CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    opacityAnimation.fromValue = @(1.0);
    opacityAnimation.toValue = @(0.0);
    opacityAnimation.duration = 0.9;
    opacityAnimation.repeatCount = HUGE_VALF;
    opacityAnimation.removedOnCompletion = YES;
    opacityAnimation.fillMode = kCAFillModeForwards;
    opacityAnimation.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    return opacityAnimation;
}


#pragma mark --setter&&getter

-(void)setMaxLenght:(NSInteger)maxLenght{
    _maxLenght = maxLenght;
}

-(void)setKeyBoardType:(UIKeyboardType)keyBoardType{
    _keyBoardType = keyBoardType;
    self.textView.keyboardType = keyBoardType;
}

-(void)setViewColor:(UIColor *)viewColor{
    _viewColor = viewColor;
}

-(void)setViewColorHL:(UIColor *)viewColorHL{
    _viewColorHL = viewColorHL;
}

-(UITextView *)textView{
    if (!_textView) {
        _textView = [UITextView new];
        _textView.tintColor = [UIColor clearColor];
        _textView.backgroundColor = [UIColor clearColor];
        _textView.textColor = [UIColor clearColor];
        _textView.delegate = self;
        _textView.keyboardType = UIKeyboardTypeDefault;
    }
    return _textView;
}
-(void)clearContentFotInputView{
    
    _textView.text=@"";
    [self textViewDidChange:_textView];
    [self beginEdit];
}
-(NSMutableArray *)pointlineArr{
    if (!_pointlineArr) {
        _pointlineArr = [NSMutableArray new];
    }
    return _pointlineArr;
}
-(NSMutableArray *)viewArr{
    if (!_viewArr) {
        _viewArr = [NSMutableArray new];
    }
    return _viewArr;
}
-(NSMutableArray *)labelArr{
    if (!_labelArr) {
        _labelArr = [NSMutableArray new];
    }
    return _labelArr;
}

- (void)setBorderWithView:(UIView *)view top:(BOOL)top left:(BOOL)left bottom:(BOOL)bottom right:(BOOL)right borderColor:(UIColor *)color borderWidth:(CGFloat)width
{
    if (top)
    {
        CALayer *layer = [CALayer layer];
        layer.frame = CGRectMake(0, 0, view.frame.size.width, width);
        layer.backgroundColor = color.CGColor;
        [view.layer addSublayer:layer];
    }

    if (left)
    {
        CALayer *layer = [CALayer layer];
        layer.frame = CGRectMake(0, 0, width, view.frame.size.height);
        layer.backgroundColor = color.CGColor;
        [view.layer addSublayer:layer];
    }

    if (bottom)
    {
        CALayer *layer = [CALayer layer];
        layer.frame = CGRectMake(0, view.frame.size.height - width, view.frame.size.width, width);
        layer.backgroundColor = color.CGColor;
        [view.layer addSublayer:layer];
    }

    if (right)
    {
        CALayer *layer = [CALayer layer];
        layer.frame = CGRectMake(view.frame.size.width - width, 0, width, view.frame.size.height);
        layer.backgroundColor = color.CGColor;
        [view.layer addSublayer:layer];
    }

}



@end
