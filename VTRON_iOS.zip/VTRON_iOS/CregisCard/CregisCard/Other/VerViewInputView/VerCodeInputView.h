//
//  VerCodeInputView.h
//  VerCodeInputView
//
//  Created by sunliang on 2019/4/13.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^MQTextViewBlock)(NSString *text);

@interface VerCodeInputView : UIView

@property (nonatomic, assign) UIKeyboardType keyBoardType;
@property (nonatomic, copy) MQTextViewBlock block;

/*验证码的最大长度*/
@property (nonatomic, assign) NSInteger maxLenght;

/*未选中下的view的borderColor*/
@property (nonatomic, strong) UIColor *viewColor;

/*选中下的view的borderColor*/
@property (nonatomic, strong) UIColor *viewColorHL;
-(void)beginEdit;
-(void)endEdit;
-(void)mq_verCodeViewWithMaxLenght;

-(void)clearContentFotInputView;
@end
