//
//  AppDelegate.m
//  CregisCard
//
//  Created by sunliang on 2022/2/16.
//

#import "AppDelegate.h"
#import  <UserNotifications/UserNotifications.h>
#import "LocalizationManager.h"
#import "UBTrackerWriteLogManager.h"
#import "IQKeyboardManager.h"
//#import <Bytetrack/Bytetrack.h>
//#import <Bugly/Bugly.h>
#import "AFNetworkReachabilityManager.h"
#import "FHHFPSIndicator.h"
#import "NSObject+UBTrackerModel.h"
#import "UBTracker_YYCache.h"
#import "UBTracker_YYWebImageManager.h"
#import "SDImageCache.h"
#import "StartPageController.h"
#import "TABAnimated.h"
#import "HostManager.h"
//#import "Growing.h"
#ifdef DEBUG
#import <DoraemonKit/DoraemonManager.h>
#endif
#define IOS_VERSION [[UIDevice currentDevice] systemVersion].floatValue
#define BUGLY_KEY  @"75d5f70cb9"


//#define api_Key @"ios_sdk08f2cd51bc8c4147862d360cad4522fc"
//#define app_Id @"6Y7xrMnd"//正式环境下自己的测试账户

#define api_Key @"ios_sdkb1fd9c0a37154c22985db3c842d2b73e"
#define app_Id @"8CTFE8cF"//公司正式环境

//#define api_Key @"ios_sdk7fdad256088c41658cc8f2d775b60aa5"
//#define app_Id @"cquyCRfT"//公司测试环境

@interface AppDelegate ()<UNUserNotificationCenterDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    if (@available(iOS 9.0, *)) {
        // 全局强制 LTR
           [UIView appearance].semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
       }
    if ([NSString stringIsNull:[UBTNSUserDefaultUtil GetDefaults:K_SOUND_CHANGE]] ) {
        [UBTNSUserDefaultUtil PutDefaults:K_SOUND_CHANGE Value:@"1"];//如果没设置的话，默认有音效
    }

    if ([[NSUserDefaults standardUserDefaults] objectForKey:HIDDENACCOUNT] == nil) {
        [UBTNSUserDefaultUtil PutBoolDefaults:HIDDENACCOUNT Value:YES];//首次安装默认隐藏账户
    }
    if ([[UBTNSUserDefaultUtil GetDefaults:NOTE_EXCLUSIVE] intValue]==1) {
        //专属节点
        [HostManager sharedManager].host=HOST_Exclusive;
        NSLog(@"专属节点");
    }else{
        //全球节点
        [HostManager sharedManager].host=HOST_Global;
        NSLog(@"全球节点");
    }
    [[UITextField appearance] setTintColor:[UIColor colorWithHexString:@"#E11D53" alpha:1.0]];//全局设置光标颜色
    
    [SDImageCache sharedImageCache].config.maxMemoryCost = 1024 * 1024 * 500;// 500M
    UBTracker_YYImageCache *cache = [UBTracker_YYWebImageManager sharedManager].cache;
   // cache.decodeForDisplay=NO;//是否启用解码显示，其实就是用到 YYImageCoder 的拓展方法
    cache.memoryCache.shouldRemoveAllObjectsWhenEnteringBackground = YES;
    cache.memoryCache.shouldRemoveAllObjectsOnMemoryWarning = YES;
   // cache.memoryCache.costLimit=1000*1000*500;//最大500MB内存缓存
    
    NSLog(@"运行环境是--%d",MY_PROJECT_GLOBAL_CONTROL);
    
    [self performSelector:@selector(setNew) withObject:nil afterDelay:1];
    if (@available(iOS 13.0, *)) {
           [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDarkContent;//黑色
       } else {
           // Fallback on earlier versions
           [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
       }
    //[LocalizationManager initUserLanguage];
//    [[FHHFPSIndicator sharedFPSIndicator] show];
//    [FHHFPSIndicator sharedFPSIndicator].fpsLabelPosition = FPSIndicatorPositionTopRight;
    
    [ChangeLanguage initUserLanguage];//初始化应用语言
    [self initKeyboardManager];
   // [ChangeLanguage setUserlanguage:@"zh-Hans"];//写死中文（默认根据手机系统语言）
  //  [Bugly startWithAppId:BUGLY_KEY];
    [self AFNReachability];
//    [Bytetrack initMessengerWithApiKey:api_Key forAppId:app_Id withPrivateServerURL:nil];//初始化SDK
//    if ([[ChangeLanguage userLanguage] isEqualToString:@"en"]) {
//        [Bytetrack setLanguage:2];//设置语言
//    }else{
//        [Bytetrack setLanguage:1];//设置语言
//    }
//
//    NSString*verison= [Bytetrack getSDKVersion];
//    NSLog(@"此SDK版本号是--%@",verison);
   
   
    //[Bytetrack setLauncherVisible:YES];//显示悬浮图标，默认不显示
    
    //[[DoraemonManager shareInstance] install];
    
    //全局设置
     if (@available(iOS 15.0, *)) {
         [UITableView appearance].sectionHeaderTopPadding = 0;
     }

    
//    //友盟
//    [UMConfigure initWithAppkey:@"6295733c88ccdf4b7e7fad9e" channel:@"App Store"];
//    [UMConfigure setLogEnabled:YES];
//    [UMVisual setVisualEnabled:YES];//默认使用
//    NSString * deviceID =[UMConfigure deviceIDForIntegration];
//    NSLog(@"集成测试的deviceID:%@", deviceID);
    
    
//    [self initSensorsAnalyticsSDKWithOptions:launchOptions];//神策
//
//    [[BaiduMobStat defaultStat] startWithAppId:@"c977519ef7"];
//    [[BaiduMobStat defaultStat] getTestDeviceId];
//    [Growing startWithAccountId:@"aa13c6ea5d79172e"];
//    [Growing setEnableLog:YES];// 开启Growing调试日志 可以开启日志
    /**
     {"oid": "bbe3bd46a6c8101fedbe6f1b677e1453e004c8b5"}

     */
    
    //默认为YES
//    [[IQKeyboardManager sharedManager] setEnable:YES];
//    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
//    [IQKeyboardManager sharedManager].shouldResignOnTouchOutside = YES;
   // [self registerNotificationsWithapplication:application];//注册推送
    [self initRootViewController];
  
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];//用户不可以做其他操作
    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];// 黑色背景，白色字体
    [SVProgressHUD setDefaultAnimationType:SVProgressHUDAnimationTypeNative];//菊花
    [SVProgressHUD setMinimumSize:CGSizeMake(100, 100)];//最小尺寸
    [SVProgressHUD setImageViewSize:CGSizeMake(50, 50)];
    [SVProgressHUD setMaxSupportedWindowLevel:NSIntegerMax];//永远显示在最外层的window上
    [TABAnimated sharedAnimated].openLog = YES;
  // [TABAnimated sharedAnimated].openAnimationTag = YES;
    [TABAnimated sharedAnimated].animationType=TABAnimationTypeShimmer;
    
    
   // [SVProgressHUD setContainerView:[UIApplication sharedApplication].delegate.window];
   // [SVProgressHUD setBackgroundColor:[UIColor colorWithHexString:@"#515151" alpha:1]];
    
  //  [[UBTrackerWriteLogManager writeLog_shareManager] writeLog_startWriteLogToFile];//打印日志
#ifdef DEBUG
    //默认
 //   [[DoraemonManager shareInstance] install];
   //  或者使用传入位置,解决遮挡关键区域,减少频繁移动
 //   [[DoraemonManager shareInstance] installWithStartingPosition:CGPointMake(66, 66)];
    

#endif
    // Override point for customization after application launch.
    return YES;
}


-(void)initRootViewController{
    //启动页
    StartPageController*startVC=[[StartPageController alloc]init];
    self.window.rootViewController = startVC;
    [self.window makeKeyAndVisible];

}


-(void)initKeyboardManager
{
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager];
    keyboardManager.enable = YES;//
    keyboardManager.toolbarDoneBarButtonItemText = LocalizationKey(@"完成");
    keyboardManager.shouldResignOnTouchOutside = YES;// 控制点击背景是否收起键盘
    keyboardManager.shouldToolbarUsesTextFieldTintColor = YES;// 控制键盘上的工具条文字颜色是否用户自定义
    keyboardManager.toolbarManageBehaviour = IQAutoToolbarBySubviews;// 有多个输入框时，可以通过点击Toolbar 上的“前一个”“后一个”按钮来实现移动到不同的输入框
    keyboardManager.enableAutoToolbar = YES;// 控制是否显示键盘上的工具条
    //    keyboardManager.shouldShowTextFieldPlaceholder = NO;// 是否显示占位文字
    keyboardManager.placeholderFont = [UIFont boldSystemFontOfSize:17]; // 设置占位文字的字体
    keyboardManager.keyboardDistanceFromTextField = 10.0f;
    
}

//使用AFN框架来检测网络状态的改变
-(void)AFNReachability
{
  //1.创建网络监听管理者
  AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
 
  //2.监听网络状态的改变
  /*
   AFNetworkReachabilityStatusUnknown     = 未知
   AFNetworkReachabilityStatusNotReachable   = 没有网络
   AFNetworkReachabilityStatusReachableViaWWAN = 3G
   AFNetworkReachabilityStatusReachableViaWiFi = WIFI
   */
    
  [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
      
      [[NSNotificationCenter defaultCenter] postNotificationName:NET_CHANGE object:nil];
    switch (status) {
  
      case AFNetworkReachabilityStatusUnknown:
        NSLog(@"未知");
          
        break;
      case AFNetworkReachabilityStatusNotReachable:
        NSLog(@"没有网络");
        
        break;
      case AFNetworkReachabilityStatusReachableViaWWAN:
        NSLog(@"3G");
          
        break;
      case AFNetworkReachabilityStatusReachableViaWiFi:
        NSLog(@"WIFI");
        
        break;
 
      default:
        break;
    }
  }];
 
  //3.开始监听
  [manager startMonitoring];
}

+(instancetype)shareAppDelegate {
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}
-(void)setNew
{

   //self.Win = [[LogView alloc] initWithFrame:CGRectMake(0, 200, 60, 60)];
}
//GrowingIO
//- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
//{
//    
//// if ([Growing handleUrl:url]) // 请务必确保该函数被调用
////  {
////      return YES;
////  }
//  return YES;
//
//}
//
//-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url API_DEPRECATED_WITH_REPLACEMENT("application:openURL:options:", ios(2.0, 9.0)) API_UNAVAILABLE(tvos)
//{
//    NSString *strUrl=url.absoluteString;
//    NSLog(@"%@",strUrl);
//    return true;
//}

//- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options API_AVAILABLE(ios(9.0)){
//    NSString *strUrl=url.absoluteString;
//     NSLog(@"%@",strUrl);
//
//
//     return true;
//}




//// 引入神策分析 SDK
//-(void)initSensorsAnalyticsSDKWithOptions:(NSDictionary *)launchOptions{
//
//    // 初始化配置
//        SAConfigOptions *options = [[SAConfigOptions alloc] initWithServerURL:@"" launchOptions:launchOptions];
//        // 开启全埋点
//        options.autoTrackEventType = SensorsAnalyticsEventTypeAppStart |
//                                     SensorsAnalyticsEventTypeAppEnd |
//                                     SensorsAnalyticsEventTypeAppClick |
//                                     SensorsAnalyticsEventTypeAppViewScreen;
//    #ifdef DEBUG
//        // 开启 Log
//        options.enableLog = YES;
//
//    #endif
//        /**
//         * 其他配置，如开启可视化全埋点
//         */
//    options.enableVisualizedAutoTrack = true;//开启可视化全埋点
//        // 初始化 SDK
//        [SensorsAnalyticsSDK startWithConfigOptions:options];
//
//
//
//
//}
//iOS9以上使用以下方法
- (BOOL)application:(UIApplication *)application openURL:(nonnull NSURL *)url options:(nonnull NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    
    
//    if ([MobClick handleUrl:url]) {
//        return YES;
//    }
   // 其它第三方处理
//    if ([Growing handleUrl:url]) // 请务必确保该函数被调用
//     {
//         return YES;
//     }
    return YES;
}


#pragma mark - Core Data stack

@synthesize persistentContainer = _persistentContainer;

- (NSPersistentContainer *)persistentContainer {
    // The persistent container for the application. This implementation creates and returns a container, having loaded the store for the application to it.
    @synchronized (self) {
        if (_persistentContainer == nil) {
            _persistentContainer = [[NSPersistentContainer alloc] initWithName:@"CregisCard"];
            [_persistentContainer loadPersistentStoresWithCompletionHandler:^(NSPersistentStoreDescription *storeDescription, NSError *error) {
                if (error != nil) {
                    // Replace this implementation with code to handle the error appropriately.
                    // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                    
                    /*
                     Typical reasons for an error here include:
                     * The parent directory does not exist, cannot be created, or disallows writing.
                     * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                     * The device is out of space.
                     * The store could not be migrated to the current model version.
                     Check the error message to determine what the actual problem was.
                    */
                    NSLog(@"Unresolved error %@, %@", error, error.userInfo);
                    abort();
                }
            }];
        }
    }
    
    return _persistentContainer;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *context = self.persistentContainer.viewContext;
    NSError *error = nil;
    if ([context hasChanges] && ![context save:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, error.userInfo);
        abort();
    }
}

@end
