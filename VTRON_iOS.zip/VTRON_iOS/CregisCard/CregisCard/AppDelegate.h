//
//  AppDelegate.h
//  CregisCard
//
//  Created by sunliang on 2022/2/16.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow * window;
@property (readonly, strong) NSPersistentContainer *persistentContainer;
@property(nonatomic,strong) NSMutableArray*myChatListArray;
@property(nonatomic,strong) NSMutableArray*mentionListArray;
@property(nonatomic,copy)  NSString*deviceToken;

- (void)saveContext;
+(instancetype)shareAppDelegate;

@end

