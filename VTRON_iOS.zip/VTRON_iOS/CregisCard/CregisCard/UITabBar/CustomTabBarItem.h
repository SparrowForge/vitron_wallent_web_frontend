//
//  CustomTabBarItem.h
//  Badtest
//
//  Created by 孙良 on 2024/8/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomTabBarItem : UIView
@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIView *dotView;
@property (nonatomic, assign) BOOL isSelected;

- (instancetype)initWithImage:(UIImage *)image title:(NSString *)title;
- (void)setSelected:(BOOL)selected animated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
