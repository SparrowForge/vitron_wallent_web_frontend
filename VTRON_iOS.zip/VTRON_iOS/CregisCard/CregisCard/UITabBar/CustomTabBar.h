//
//  CustomTabBar.h
//  Badtest
//
//  Created by 孙良 on 2024/8/1.
//

#import <UIKit/UIKit.h>
#import "CustomTabBarItem.h"
NS_ASSUME_NONNULL_BEGIN

@interface CustomTabBar : UITabBar

@property (nonatomic, strong) NSMutableArray<CustomTabBarItem *> *customItems;
- (void)selectItemAtIndex:(NSUInteger)index;
@end

NS_ASSUME_NONNULL_END
