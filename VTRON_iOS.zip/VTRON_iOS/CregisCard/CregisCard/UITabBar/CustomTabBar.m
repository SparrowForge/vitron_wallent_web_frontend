//
//  CustomTabBar.m
//  Badtest
//
//  Created by 孙良 on 2024/8/1.
//

#import "CustomTabBar.h"


@implementation CustomTabBar

- (instancetype)init {
    self = [super init];
    if (self) {
        self.customItems = [NSMutableArray array];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat width = CGRectGetWidth(self.bounds) / self.customItems.count;
    CGFloat height = CGRectGetHeight(self.bounds);
    
    [self.customItems enumerateObjectsUsingBlock:^(CustomTabBarItem * _Nonnull item, NSUInteger idx, BOOL * _Nonnull stop) {
        item.frame = CGRectMake(idx * width, 0, width, height);
        [self addSubview:item];
    }];
   
    
}

- (void)selectItemAtIndex:(NSUInteger)index {
    [self.customItems enumerateObjectsUsingBlock:^(CustomTabBarItem * _Nonnull item, NSUInteger idx, BOOL * _Nonnull stop) {
        [item setSelected:(idx == index) animated:YES];
    }];
}

@end
