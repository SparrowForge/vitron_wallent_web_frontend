//
//  CustomTabBarItem.m
//  Badtest
//
//  Created by 孙良 on 2024/8/1.
//

#import "CustomTabBarItem.h"

@implementation CustomTabBarItem

- (instancetype)initWithImage:(UIImage *)image title:(NSString *)title {
    self = [super initWithFrame:CGRectZero];
    if (self) {
        
        self.iconImageView = [[UIImageView alloc] initWithImage:image];
        self.iconImageView.contentMode = UIViewContentModeScaleAspectFit;
      //  self.iconImageView.backgroundColor=[UIColor redColor];
        [self addSubview:self.iconImageView];
        
        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.text = title;
        self.titleLabel.font = [UIFont boldSystemFontOfSize:13];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.hidden = YES;
       // self.titleLabel.backgroundColor=[UIColor yellowColor];
        [self addSubview:self.titleLabel];
         
        self.dotView = [[UIView alloc] init];
        self.dotView.backgroundColor = [UIColor colorWithHexString:@"#E11D53" alpha:1.0];
        self.dotView.layer.cornerRadius = 4;
        self.dotView.hidden = YES;
        [self addSubview:self.dotView];
      //  self.backgroundColor=[UIColor orangeColor];

    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat width = CGRectGetWidth(self.bounds);
  //  CGFloat height = CGRectGetHeight(self.bounds);
    
    if (self.isSelected) {
        self.iconImageView.hidden = YES;
        self.titleLabel.hidden = NO;
        self.dotView.hidden = NO;
        
        self.titleLabel.frame = CGRectMake(0, 5, width, 20); // Center vertically with offset
        self.dotView.frame = CGRectMake((width - 8) / 2, CGRectGetMaxY(self.titleLabel.frame) + 10, 8, 8); // Closer to text
    } else {
        self.iconImageView.hidden = NO;
        self.titleLabel.hidden = YES;
        self.dotView.hidden = YES;
        
      //  CGFloat iconSize = MIN(width, height) * 0.5; // Smaller icon size
        self.iconImageView.frame = CGRectMake((width - 25) / 2, 10, 25, 25);
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    BOOL wasSelected = _isSelected;
    _isSelected = selected;
    
    if (animated) {
        //0.3
        [UIView animateWithDuration:0.9 // 调整动画持续时间
                              delay:0
             usingSpringWithDamping:0.5 // 减小阻尼，以增加弹性效果
              initialSpringVelocity:0.5 // 增加初始速度
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             if (selected) {
                                 // 向上移动图标和文字
                                 self.iconImageView.transform = CGAffineTransformMakeTranslation(0, -10); // 更小的向上位移
                                 self.titleLabel.transform = CGAffineTransformMakeTranslation(0, -10); // 文字也向上位移
                                 self.dotView.alpha = 1.0; // 显示红点
                             } else {
                                 // 恢复原位置
                                 self.iconImageView.transform = CGAffineTransformIdentity;
                                 self.titleLabel.transform = CGAffineTransformIdentity; // 文字恢复位置
                                 self.dotView.alpha = 0.0; // 隐藏红点
                             }
                         } completion:^(BOOL finished) {
                             [self setNeedsLayout];
                         }];
    } else {
        [self setNeedsLayout];
    }

    // 添加振动反馈
    if (selected && !wasSelected) {
        [self triggerHapticFeedback];
    }
}


/*
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    BOOL wasSelected = _isSelected;
    _isSelected = selected;
    
    if (animated) {
        // 调整动画参数以实现更流畅的滚动效果
        [UIView animateWithDuration:0.4 // 增加动画持续时间
                              delay:0
             usingSpringWithDamping:0.8 // 增加阻尼以减缓过渡
              initialSpringVelocity:0.3 // 减少初始速度
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             // 根据选中状态调整变换
                             if (selected) {
                                 self.iconImageView.transform = CGAffineTransformMakeTranslation(0, -20); // 向上移动更多
                                 self.titleLabel.transform = CGAffineTransformIdentity;
                             } else {
                                 self.iconImageView.transform = CGAffineTransformIdentity;
                                 self.titleLabel.transform = CGAffineTransformMakeTranslation(0, 20); // 向下移动更多
                             }
                         } completion:^(BOOL finished) {
                             [self setNeedsLayout];
                         }];
    } else {
        [self setNeedsLayout];
    }
    // 添加振动反馈
       if (selected && !wasSelected) {
           [self triggerHapticFeedback];
       }
}
*/

- (void)triggerHapticFeedback {
    UIImpactFeedbackGenerator *feedbackGenerator = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [feedbackGenerator impactOccurred];
}

@end
