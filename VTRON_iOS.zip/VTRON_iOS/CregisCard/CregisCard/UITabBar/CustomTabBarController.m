//
//  CustomTabBarController.m
//  Badtest
//
//  Created by 孙良 on 2024/8/1.
//

#import "CustomTabBarController.h"
#import "BaseNavigationController.h"
#import "CardsHomeController.h"
#import "AccountPageController.h"
#import "MineController.h"

@interface CustomTabBarController ()<UINavigationControllerDelegate>

@end

@implementation CustomTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
   // [self.tabBar removeFromSuperview];
    // 清除 UITabBar 上的黑线
    self.tabBar.shadowImage = [UIImage new];
    self.tabBar.backgroundImage = [UIImage new];
    self.tabBar.backgroundColor = [UIColor clearColor];
    // 获取系统 Tab Bar 的高度
   // CGRect rect = self.tabBar.frame;
    self.customTabBar = [[CustomTabBar alloc] init];
    [self setValue:self.customTabBar forKey:@"tabBar"];
//    // 使用 Safe Area 处理 Tab Bar 的 frame
//      if (@available(iOS 11.0, *)) {
//          [self.view addSubview:self.customTabBar];
//          self.customTabBar.translatesAutoresizingMaskIntoConstraints = NO;
//          [NSLayoutConstraint activateConstraints:@[
//              [self.customTabBar.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
//              [self.customTabBar.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
//              [self.customTabBar.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
//              [self.customTabBar.heightAnchor constraintEqualToConstant:rect.size.height] // Tab Bar 高度
//          ]];
//      } else {
//          self.customTabBar.frame = rect; // 适用于早期版本
//          [self.view addSubview:self.customTabBar];
//      }
//   
       NSArray *titles = @[LocalizationKey(@"钱包"), LocalizationKey(@"卡"), LocalizationKey(@"我的")];
       NSArray *images = @[[UIImage imageNamed:@"account_Icon"], [UIImage imageNamed:@"cards_Icon"], [UIImage imageNamed:@"mine_Icon"]];
       
       for (NSUInteger i = 0; i < titles.count; i++) {
           CustomTabBarItem *item = [[CustomTabBarItem alloc] initWithImage:images[i] title:titles[i]];
           [self.customTabBar.customItems addObject:item];
           
           UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tabBarItemTapped:)];
           [item addGestureRecognizer:tapGesture];
       }
    
    
    [self setupTabBarTheme];
    [self setControlForSuper];
    [self clearTabBarTopLineForBar:self.tabBar];//去除顶部黑线
    [self clearTabBarTopLineForBar:self.customTabBar];//去除顶部黑线
    [self.customTabBar selectItemAtIndex:0];//默认
    for (BaseNavigationController *navController in self.viewControllers) {
        navController.delegate = self;
    }
 
    
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
   
}


- (void)tabBarItemTapped:(UITapGestureRecognizer *)gesture {
    NSUInteger index = [self.customTabBar.customItems indexOfObject:(CustomTabBarItem *)gesture.view];
    [self.customTabBar selectItemAtIndex:index];
    self.selectedIndex = index;
}

#pragma mark -- setControlForSuper
- (void)setControlForSuper
{
   
    CardsHomeController * cardsVC = [[CardsHomeController alloc]init];
    BaseNavigationController * cardsVCNav = [[BaseNavigationController alloc]initWithRootViewController:cardsVC];

    AccountPageController * accountVC = [[AccountPageController alloc]init];
    BaseNavigationController * accountNav = [[BaseNavigationController alloc]initWithRootViewController:accountVC];

    MineController *mineVC = [[MineController alloc]init];
    BaseNavigationController * mineNav = [[BaseNavigationController alloc]initWithRootViewController:mineVC];
 
    self.viewControllers = @[accountNav,cardsVCNav,mineNav];
   
}

-(void)clearTabBarTopLineForBar:(UITabBar*)tabBar {
    if (@available(iOS 13.0, *)) {
        UITabBarAppearance *appearance = [[UITabBarAppearance alloc] init];
        appearance.backgroundColor = UIColorFromHexWithAlpha(0xFFFFFF, 0.8); // 设置背景色
        appearance.backgroundImage = [self imageWithColor:[UIColor clearColor]]; // 设置透明背景
        appearance.shadowColor = [UIColor clearColor]; // 清除 shadowColor
        if (@available(iOS 15.0, *)) {
            tabBar.scrollEdgeAppearance = appearance; // iOS 15 及更高版本
        }
        tabBar.standardAppearance = appearance; // iOS 13 及以上
    } else {
        // iOS 13 以下的版本
        CGRect rect = CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
        UIGraphicsBeginImageContext(rect.size);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGColorRef clearColor = [[UIColor clearColor] CGColor];
        CGContextSetFillColor(context, CGColorGetComponents(clearColor));
        CGContextFillRect(context, rect);
        UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        tabBar.backgroundImage = img;
        tabBar.shadowImage = img; // 清除横线
    }
    
}


- (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0, 0, 1, 1);

    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);

    [color setFill];

    UIRectFill(rect);

    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();

    UIGraphicsEndImageContext();
    
    return image;

}
#pragma mark -- target Methods
- (void)setupTabBarTheme
{
    UITabBar * tabBar = [UITabBar appearance];
    if (@available(iOS 13.0, *)) {
        UITabBarAppearance * appearance = [UITabBarAppearance new];
        appearance.backgroundColor=[UIColor whiteColor];
        if (@available(iOS 15.0, *)) {
            tabBar.scrollEdgeAppearance=appearance;
        } else {
            // Fallback on earlier versions
        }
            tabBar.standardAppearance=appearance;//放在最后
    } else {
        // Fallback on earlier versions
    }
   
  //  tabBar.translucent = NO;
    //[self reSetTabbarColor];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
