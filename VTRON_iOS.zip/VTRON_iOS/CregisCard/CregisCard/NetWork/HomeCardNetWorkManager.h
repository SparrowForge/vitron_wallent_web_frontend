//
//  HomeCardNetWorkHelper.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/16.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "UBTrackerNetWorkHelper.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeCardNetWorkManager : UBTrackerNetWorkHelper
//获取卡片列表
+(void)getmerchantCardListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡片详情/隐藏
+(void)getCardCloseDetailWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡片详情/显示
+(void)getCardOpenDetailWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取申请中的卡片数量
+(void)getPendingCardCountsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡充值页面数据
+(void)getcardRechargeDataWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//申请充值
+(void)applyTorechargeCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//申请退款
+(void)applyTorefundCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//卡冻结/解冻
+(void)changeCardStatusWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//销卡页面数据
+(void)getCloseCardDataWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//申请销卡
+(void)applyCloseCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取卡片流水
+(void)getCardRecordListWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//申请卡页面数据
+(void)getApplyCardDataWithcardId:(NSString*)cardID success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//申请开卡
+(void)applyOpenCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//新建持卡人
+(void)addcardUserInfoWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//更新持卡人
+(void)updateCardUserInfoListWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fai;
//获取持卡人详情
+(void)getSinglecardUserInfoWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//删除持卡人
+(void)deleteCardUserInfoWithparams:(NSString*)ID success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取持卡人支持的国家
+(void)getSinglecardUserInfosuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取卡申请列表
+(void)getSupportCardListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡邮寄
+(void)shipCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//1.6.0
//转账前校验邮箱
+(void)checkMerchantForTransferparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

/**2025/10/21新加**/

//获取申请卡片的所有卡bin
+(void)getAllCardBINsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡充值
+(void)cardDepositParams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡提现页面数据
+(void)getcardWithdrawDataWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//卡提现
+(void)applyTowithdrawCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;


@end

NS_ASSUME_NONNULL_END
