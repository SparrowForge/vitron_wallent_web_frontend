//
//  AccountNetWorkManager.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "UBTrackerNetWorkHelper.h"

NS_ASSUME_NONNULL_BEGIN

@interface AccountNetWorkManager : UBTrackerNetWorkHelper

//获取首页各币种详情
+(void)merchantWalletListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取加密后的收款二维码
+(void)getERcodesuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//解析收款二维码
+(void)decryptERcodeWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fai;

//获取转账数据
+(void)getTransferConfigDatasuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//去转账
+(void)toTransferWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取兑换数据
+(void)getExchangeConfigDatasuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//去兑换
+(void)toExchangeWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取USDT对各币种的汇率
+(void)getCurrencyRatesuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取账户资产
+(void)getAccountAssetsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取账户流水
+(void)getAccountRecordListWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取提币申请列表
+(void)getWithdrawRecordListWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//获取充值页面数据
+(void)getRechargeConfigsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//重新获取充币地址
+(void)resetAddressWithParams:(NSString *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//校验币种地址
+(void)judgeAddressWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取提现页面数据
+(void)getWithdrawConfigsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//申请提现
+(void)toWithdrawWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;



@end

NS_ASSUME_NONNULL_END
