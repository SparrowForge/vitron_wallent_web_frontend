//
//  AccountNetWorkManager.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "AccountNetWorkManager.h"
#import "HostManager.h"

@implementation AccountNetWorkManager

//获取首页各币种详情
+(void)merchantWalletListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/list",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//获取加密后的收款二维码
+(void)getERcodesuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/collection",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//解析收款二维码
+(void)decryptERcodeWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/decrypt",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//获取转账数据
+(void)getTransferConfigDatasuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/toTransfer",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//去转账
+(void)toTransferWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/transfer",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取兑换数据
+(void)getExchangeConfigDatasuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/toExchange",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}

//去兑换
+(void)toExchangeWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/exchange",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取USDT对各币种的汇率
+(void)getCurrencyRatesuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/currencyRate/list",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}


//获取账户资产
+(void)getAccountAssetsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchant/index",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] success:success fail:fail];
    
}

//获取账户流水
+(void)getAccountRecordListWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantTransaction/page",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//获取提币申请列表
+(void)getWithdrawRecordListWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/withdraw/page",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//获取充值页面数据
+(void)getRechargeConfigsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/toDeposit",[HostManager sharedManager].host];

   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
}

//重新获取充币地址
+(void)resetAddressWithParams:(NSString *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/resetAddress/%@",[HostManager sharedManager].host,params];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] success:success fail:fail];
    
}

//校验币种地址
+(void)judgeAddressWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/getAddress",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
    
}

//获取提现页面数据
+(void)getWithdrawConfigsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/toWithdraw",[HostManager sharedManager].host];
  //  [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new]  success:success fail:fail];
}


//申请提现
+(void)toWithdrawWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/withdraw",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}




@end
