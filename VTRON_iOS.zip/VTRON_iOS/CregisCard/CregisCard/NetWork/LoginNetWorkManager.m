//
//  UTNetWorkManager.m
//  CregisCard
//
//  Created by sunliang on 2022/3/16.
//

#import "LoginNetWorkManager.h"
#import "HostManager.h"
@implementation LoginNetWorkManager

//获取登录验证码
+(void)getCodeForLoginWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@",[HostManager sharedManager].host,@"merchant-server/email/sendEmail"];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
    
}


//获取注册验证码
+(void)getCodeForRegisterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@",[HostManager sharedManager].host,@"merchant-server/email/sendEmail"];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
    
}


//注册
+(void)toRegisterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@", [HostManager sharedManager].host,@"merchant-server/merchant/registMember"];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取忘记密码的验证码
+(void)getForgotCodeForRegisterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@", [HostManager sharedManager].host,@"merchant-server/email/sendEmail"];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
}

//忘记密码
+(void)toForgotWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@", [HostManager sharedManager].host,@"merchant-server/merchant/forgetPassword"];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//登录时检验密码
+(void)loginForCheckPasswordWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@", [HostManager sharedManager].host,@"merchant-server/login/check/password"];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//登录业务系统or刷新refreshToken
+(void)loginForMerchantServerWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@", [HostManager sharedManager].host,@"merchant-server/login"];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//登录第一步，获取token
+(void)getTokenWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-login/oauth/token?grant_type=password&client_secret=123456&client_id=client_web&auth_type=password&username=%@&password=%@", [HostManager sharedManager].host,params[@"username"],params[@"password"]];
    url=[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//登录第二步，获取验证码
+(void)getLogincodeWithloginType:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/email/sendCheckEmailWithoutEmail", [HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
    
}

//登录第三步，验证验证码
+(void)loginCheckWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/email/checkEmail",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
    
}
//校验token是否失效
+(void)checkTokenWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/login/oauth/check_token",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//退出登录
+(void)logoutsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchant/logout",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}






@end
