//
//  UTNetWorkManager.h
//  CregisCard
//
//  Created by sunliang on 2022/3/16.
//

#import "UBTrackerNetWorkHelper.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginNetWorkManager:UBTrackerNetWorkHelper

//获取登录验证码
+(void)getCodeForLoginWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取注册验证码
+(void)getCodeForRegisterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//注册
+(void)toRegisterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//获取忘记密码的验证码
+(void)getForgotCodeForRegisterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//忘记密码
+(void)toForgotWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//登录时检验密码
+(void)loginForCheckPasswordWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//登录业务系统or刷新refreshToken
+(void)loginForMerchantServerWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//登录第一步，获取token
+(void)getTokenWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//登录第二步，获取短信验证码
+(void)getLogincodeWithloginType:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//登录第三步，验证验证码
+(void)loginCheckWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;
//校验token是否失效
+(void)checkTokenWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

//退出登录
+(void)logoutsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail;

@end

NS_ASSUME_NONNULL_END
