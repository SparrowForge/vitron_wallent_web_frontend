//
//  HomeCardNetWorkHelper.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/16.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "HomeCardNetWorkManager.h"
#import "HostManager.h"
@implementation HomeCardNetWorkManager

//获取卡片列表
+(void)getmerchantCardListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/list",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}
//卡片详情/隐藏
+(void)getCardCloseDetailWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/hide",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
}
//卡片详情/显示
+(void)getCardOpenDetailWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/importance",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取申请中的卡片数量
+(void)getPendingCardCountsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/pendingCount",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}


//卡充值页面数据
+(void)getcardRechargeDataWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/pre/deposit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//申请充值
+(void)applyTorechargeCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/recharge",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//申请退款
+(void)applyTorefundCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/refund",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//卡冻结/解冻
+(void)changeCardStatusWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/modify",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//销卡页面数据
+(void)getCloseCardDataWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/toClose?cardId=%@",[HostManager sharedManager].host,params[@"cardId"]];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//申请销卡
+(void)applyCloseCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/close",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取卡片流水
+(void)getCardRecordListWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardTransaction/page",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//申请卡页面数据
+(void)getApplyCardDataWithcardId:(NSString*)cardID success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/toApply/%@",[HostManager sharedManager].host,cardID];
    //[UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}


//申请开卡
+(void)applyOpenCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/apply",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
}

//添加持卡人
+(void)addcardUserInfoWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardHolder/add",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//更新持卡人
+(void)updateCardUserInfoListWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardHolder/edit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取持卡人详情
+(void)getSinglecardUserInfoWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardHolder/detail",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//删除持卡人
+(void)deleteCardUserInfoWithparams:(NSString*)ID success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardUserInfo/delete/%@",[HostManager sharedManager].host,ID];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}


//获取持卡人支持的国家
+(void)getSinglecardUserInfosuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardUserInfo/getBinCountries",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] success:success fail:fail];
    
}

//获取卡申请列表
+(void)getSupportCardListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/bin/config/list",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//卡邮寄
+(void)shipCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/ship/commit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//1.6.0

//转账前校验邮箱
+(void)checkMerchantForTransferparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantWallet/checkMerchant",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

/**2025/10/21新加**/

//获取申请卡片的所有卡bin
+(void)getAllCardBINsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/toApplyV2",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}

//卡充值
+(void)cardDepositParams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/deposit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
}


//卡提现页面数据
+(void)getcardWithdrawDataWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/pre/withdraw",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//卡提现
+(void)applyTowithdrawCardWithparams:(NSDictionary*)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/withdraw",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}







@end
