//
//  MineNetWorkManager.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/2.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "MineNetWorkManager.h"
#import "HostManager.h"
@implementation MineNetWorkManager


//获取个人基本信息
+(void)getMemberInfosuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchant/info",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0  success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//修改用户信息（包括用户名邮箱，密码等）
+(void)modifyMemberInfoWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchant/update",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取更改邮箱的验证码
+(void)sendCheckEmailInfoWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/email/sendCheckEmail",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params success:success fail:fail];
    
}

//上传文件
+(void)uplodFileWithData:(NSData *)fileData success:(void(^)(NSData *successData))successBlock error:(void(^)(NSError *error))errorBlock{
    
    NSString*url=[NSString stringWithFormat:@"%@/%@",[HostManager sharedManager].host,@"merchant-server/upload/kyc/file"];//member/upload/local/image
    NSString *filename =[NSString stringWithFormat:@"%@.png",[self getTimeNow]];
    [UBTrackerNetWorkHelper uploadRequestWithUrl:url Data:fileData fileType:UTFileTypeImage fileName:filename success:successBlock error:errorBlock];
  
}
/**
 *  返回当前时间戳
 */
+(NSString *)getTimeNow
{
    NSString* date;
    NSDateFormatter * formatter = [[NSDateFormatter alloc ] init];
    [formatter setDateFormat:@"YYYYMMddhhmmss"];
    date = [formatter stringFromDate:[NSDate date]];
    //取出个随机数
    int last = arc4random() % 10000;
    NSString *timeNow = [[NSString alloc] initWithFormat:@"%@-%i", date,last];
    NSLog(@"%@", timeNow);
    return timeNow;
}

//获取所有支持实名认证的国家
+(void)getAllcountrysuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/country/list",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//提交实名认证
+(void)submitMemberInfoWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantKyc/submit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//查询kyc详情
+(void)getKycDetailsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantKyc/detail",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}


//获取钱包记录列表
+(void)getOrderRecordListWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/page",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//获取卡片记录列表
+(void)getCardRecordListWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardRecord/page",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}


//获取钱包流水详情
+(void)getOrderRecordDetailWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/orderRecord/detail",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}


//获取卡流水详情
+(void)getCardRecordDetailWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardRecord/detail",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}


//查询是否开启了谷歌验证
+(void)getisGoogleSecretsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/google/isGoogleSecret",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new]  success:success fail:fail];
}

//开启/关闭谷歌验证
+(void)changeGoogleStatusWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/googleVerify/save",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//获取谷歌验证secret
+(void)getGoogleQrcodesuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/google/getQrcode",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:[NSDictionary new]  success:success fail:fail];
}


//通知中心
+(void)getNotificationCenterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/messageCenter/page",[HostManager sharedManager].host];
  //  [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//通知中心消息一键已读
+(void)messageCenterAllreadsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/messageCenter/read",[HostManager sharedManager].host];
  //  [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}


//授权认证
+(void)authNotificationCenterWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/messageCenter/auth",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//版本更新
+(void)getVersionWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/appVersion/getVersion",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"GET" params:params  success:success fail:fail];
}

/*分销商相关
 */
//分销商首页数据
+(void)getDistributorInfosuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/distributorInfo/index",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] success:success fail:fail];
    
}

//编辑初始收益
+(void)editDistributorInfoWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/distributorInfo/init/edit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//获取邀请记录
+(void)getInvitedRecordsWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/distributorInfo/page",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//编辑分销商给某用户的加点
+(void)editDistributorSomeoneInfoWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/distributorInfo/add/edit",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


/*实体卡相关
 */

////获取实体卡发卡状态
//+(void)getCardStatusWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
//    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/status/detail",[HostManager sharedManager].host];
//    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
//    
//}

//获取实体卡激活码
+(void)getCardActiveCodeWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/get/activeCode",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
}

//激活实体卡
+(void)toActiveCardWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/activeCard",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
}

//获取实体卡物流信息
+(void)getCardlogisticsWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/ship/detail",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
}

//设置实体卡PIN
+(void)updatePINWithParams:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/update/pin",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
}

//校验用户是否开启了通行密钥
+(void)judgeOpenPasskeyOrNot:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/login/check/passkey",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}


//注册通行密钥第一步
+(void)registerPasskeywithUserNameForFirstStep:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/passkey/register/start",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//注册通行密钥第二步
+(void)registerPasskeyForSecondStep:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/passkey/register/finish",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//通行密钥登录第一步
+(void)loginPasskeywithUserNameForFirstStep:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/login/passkey/start",[HostManager sharedManager].host];
    //[UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//通行密钥登录第二步
+(void)loginPasskeyForSecondStep:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/login",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}
//passkey重命名
+(void)renamePasskey:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/passkey/rename",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//passkey列表查询
+(void)getPasskeyList:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/passkey/list",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//passkey删除
+(void)deletePasskey:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/passkey/delete",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}
           

//查询可以邮寄的国家信息和费用
+(void)getShipListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/ship/list",[HostManager sharedManager].host];
  //  [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}


//批量邮寄
+(void)bulkCards:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/bulk/ship",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//修改卡片绑定的邮箱
+(void)modifyCardEmail:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/update/cardEmail",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//修改卡片绑定的手机号
+(void)modifyCardPhone:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/update/cardPhone",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}

//查询可以邮寄的卡列表
+(void)getShipCardListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/ship/list",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
    
}

//查询可转移的卡列表
+(void)getToTransferCardListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/toTransfer",[HostManager sharedManager].host];
  //  [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//卡转移
+(void)cardTransfer:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantCard/transfer",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}


//查询卡转移记录
+(void)getCardTransferRecordList:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/cardTransferRecord/page",[HostManager sharedManager].host];
    //[UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params  success:success fail:fail];
}

//卡邮寄时候获取国家手机区号
+(void)getCardShipWithcountryAreaCodesuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantKyc/phone/list",[HostManager sharedManager].host];
   // [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new] maxRetryCount:0 retryCount:0 success:success fail:fail];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}

//实名认证时获取职业列表
+(void)getOccupationListsuccess:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantKyc/occupation/list",[HostManager sharedManager].host];

    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:[NSDictionary new]  success:success fail:fail];
}


//实名认证时获取城市列表
+(void)getCityList:(NSDictionary *)params success:(void (^)(id data))success fail:(void (^)(NSError *error))fail{
    
    NSString*url=[NSString stringWithFormat:@"%@/merchant-server/merchantKyc/city/list",[HostManager sharedManager].host];
    [UBTrackerNetWorkHelper requestWithURLString:url httpMethod:@"POST" params:params success:success fail:fail];
    
}






@end
