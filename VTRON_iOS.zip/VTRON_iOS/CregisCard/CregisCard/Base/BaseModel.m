//
//  BaseModel.m
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#import "BaseModel.h"

@implementation BaseModel

@end
