//
//  BaseNavigationController.m
//  CregisCard
//
//  Created by sunliang on 2022/5/19.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()<UIGestureRecognizerDelegate>

@end

@implementation BaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.whiteColor;
    self.interactivePopGestureRecognizer.enabled = YES;
    self.interactivePopGestureRecognizer.delegate = self;
    [self setupNavigationBarTheme];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count > 0) {
        // 当前导航栏, 只有第一个viewController push的时候设置隐藏
        if (self.viewControllers.count == 1) {
            viewController.hidesBottomBarWhenPushed = YES;

        }
    } else {
            viewController.hidesBottomBarWhenPushed = NO;
            
    }
           [super pushViewController:viewController animated:animated];
}


#pragma mark -- didReceiveMemoryWarning
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark -- setControlForSuper
- (void)setControlForSuper{
    
}

#pragma mark -- addConstrainsForSuper
- (void)addConstrainsForSuper{
    
    
}

#pragma mark -- target Methods

/**
 导航栏设置
 */
- (void)setupNavigationBarTheme
{
    UINavigationBar *appearance = [UINavigationBar appearance];
    // 设置标题 按钮
    NSMutableDictionary *textAttrs            = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor mainTextColor];
    textAttrs[NSFontAttributeName]            = [UIFont boldSystemFontOfSize:17];
    [appearance setTitleTextAttributes:textAttrs];
    [appearance setShadowImage:nil];
    [appearance setTranslucent:YES];//默认为YES
    // 设置导航按钮颜色
     appearance.tintColor = [UIColor whiteColor];
    // 设置导航栏背景颜色
    appearance.barTintColor =[UIColor whiteColor];
    // 设置状态样式
    appearance.barStyle = UIBarStyleBlackOpaque;
//    if (@available(iOS 15.0, *)) {
//            UINavigationBarAppearance *barApp = [UINavigationBarAppearance new];
//            barApp.backgroundColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
//            self.navigationController.navigationBar.scrollEdgeAppearance = barApp;
//            self.navigationController.navigationBar.standardAppearance = barApp;
//        }
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground];
        appearance.shadowColor = [UIColor clearColor];//导航黑线
        appearance.backgroundColor = [UIColor whiteColor];
        //[appearance setTitleTextAttributes:[NSDictionary dictionaryWithObject:[UIColor blackColor] forKey:NSForegroundColorAttributeName]];//导航栏字体颜色
        self.navigationBar.standardAppearance = appearance;
        self.navigationBar.scrollEdgeAppearance=appearance;
    } else {
        // Fallback on earlier versions
    }
    
}

// 自定义初始化方法
- (instancetype)initWithRootViewController:(UIViewController *)root
                                     title:(NSString *)title
                               normalImage:(NSString *)nomalImage
                               selectImage:(NSString *)selectImage
{
    self = [super initWithRootViewController:root];
    if (self)
    {
      
        self.tabBarItem.title = title;
        // 未选中状态的图片
        self.tabBarItem.image = [[UIImage imageNamed:nomalImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        // 选中状态的图片
        self.tabBarItem.selectedImage = [[UIImage imageNamed:selectImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }
    
    return self;
}

- (void)handleNavigationTransition:(id)sender
{
    
}

// pop 点击相应事件
- (void)backClick:(id)sender
{
    [self popViewControllerAnimated:YES];
}

-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if (self.viewControllers.count <= 1 ) {
        return NO;
    }
    return YES;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
