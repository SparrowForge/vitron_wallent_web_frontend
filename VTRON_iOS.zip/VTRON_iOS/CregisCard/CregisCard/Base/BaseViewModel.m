//
//  BaseViewModel.m
//  CregisCard
//
//  Created by sunliang on 2022/4/1.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "BaseViewModel.h"

@implementation BaseViewModel

@end
