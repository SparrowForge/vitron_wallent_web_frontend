//
//  BaseNavigationController.h
//  CregisCard
//
//  Created by sunliang on 2022/5/19.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseNavigationController : UINavigationController
/**
 *  @brief  自定义初始化方法
 *
 *  @param  root        控制器
 *  @param  title       标题
 *  @param  nomalImage  未选中状态图片
 *  @param  selectImage 选中状态图片
 */
- (instancetype)initWithRootViewController:(UIViewController *)root
                                     title:(NSString *)title
                               normalImage:(NSString *)nomalImage
                               selectImage:(NSString *)selectImage;
@end

NS_ASSUME_NONNULL_END
