//
//  BaseTableViewCell.m
//  CregisCard
//
//  Created by sunliang on 2022/5/20.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

@implementation BaseTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentView.backgroundColor=[UIColor whiteColor];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
 
    // Initialization code
}


-(void)setBorderView:(UIView*)view{
    
    view.backgroundColor=[UIColor whiteColor];
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"000000" alpha:0.2].CGColor;
    [view setCornerRadius:12];
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}



@end
