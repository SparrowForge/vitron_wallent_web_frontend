//
//  BaseView.m
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#import "BaseView.h"

@implementation BaseView

//重写初始化方法
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor whiteColor];
    }
    return self;
}

@end
