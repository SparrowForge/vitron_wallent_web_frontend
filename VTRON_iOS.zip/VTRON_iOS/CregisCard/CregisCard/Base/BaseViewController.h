//
//  BaseViewController.h
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewController : UIViewController
//导航栏黑线
- (UIImageView *)findHairlineImageViewUnder:(UIView *)view;
-(void)setBorderView:(UIView*)view;
@end

NS_ASSUME_NONNULL_END
