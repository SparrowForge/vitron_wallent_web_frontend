//
//  BaseViewModel.h
//  CregisCard
//
//  Created by sunliang on 2022/4/1.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewModel : NSObject

@end

NS_ASSUME_NONNULL_END
