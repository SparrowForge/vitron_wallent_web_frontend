//
//  BaseViewController.m
//  CregisCard
//
//  Created by sunliang on 2022/3/30.
//

#import "BaseViewController.h"
#import "CustomTabBarController.h"
@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    [self backBtnNoNavBar:NO normalBack:YES];
    [self setupNavigationBarTheme];
    // Do any additional setup after loading the view.
}

-(void)setBorderView:(UIView*)view{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
}
- (void)viewWillAppear:(BOOL)animated {
   [super viewWillAppear:animated];
//    // 强制转换 tabBarController 为 CustomTabBarController 类型
//    if ([self.tabBarController isKindOfClass:[CustomTabBarController class]]) {
//        CustomTabBarController *customTabBarController = (CustomTabBarController *)self.tabBarController;
//        customTabBarController.customTabBar.hidden = YES;
//    }
 
//     if (self.navigationController.viewControllers.count == 1) {
//         CustomTabBarController *customTabBarController = (CustomTabBarController *)self.tabBarController;
//         customTabBarController.customTabBar.hidden = NO;
//     }else{
//         CustomTabBarController *customTabBarController = (CustomTabBarController *)self.tabBarController;
//         customTabBarController.customTabBar.hidden = YES;
//     }
//     
}

//导航栏黑线
- (UIImageView *)findHairlineImageViewUnder:(UIView *)view {
    if ([view isKindOfClass:UIImageView.class] && view.bounds.size.height <= 1.0) {
            return (UIImageView *)view;
    }
    for (UIView *subview in view.subviews) {
        UIImageView *imageView = [self findHairlineImageViewUnder:subview];
        if (imageView) {
            return imageView;
        }
    }
    return nil;
}

- (void)setupNavigationBarTheme {
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground]; // 配置不透明背景
        appearance.backgroundColor = [UIColor whiteColor]; // 设置背景颜色
        appearance.shadowColor = [UIColor clearColor]; // 去掉黑线
        // 设置普通标题属性
        NSDictionary *titleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:17]
        };
        appearance.titleTextAttributes = titleTextAttributes;

        // 设置大标题属性
        NSDictionary *largeTitleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:29]
        };//系统默认的大标题（Large Title）的字体大小为 34 points
        appearance.largeTitleTextAttributes = largeTitleTextAttributes;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // iOS 13 以下版本，使用 shadowImage 方式去掉黑线
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
