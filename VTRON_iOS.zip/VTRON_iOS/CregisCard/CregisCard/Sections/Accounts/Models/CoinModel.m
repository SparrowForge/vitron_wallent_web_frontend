//
//  CoinModel.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/13.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CoinModel.h"

@implementation CoinModel
- (NSDictionary *)utr_modelMapPropertyNames{
    return @{@"ID" : @"id"
      };
}
@end
