//
//  CoinModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/13.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CoinModel : NSObject
@property(nonatomic,copy)NSString*ID;
@property(nonatomic,copy)NSString*chainId;
@property(nonatomic,copy)NSString*isLegal;
@property(nonatomic,copy)NSString*name;
@property(nonatomic,copy)NSString*merchantId;
@property(nonatomic,copy)NSString*address;

@property(nonatomic,copy)NSString*currency;
@property(nonatomic,assign) double amount;
@property(nonatomic,assign) double frozenAmount;
@property(nonatomic,copy)   NSString*url;
@property(nonatomic,copy)   NSString*convertFeeRate;//兑换费率
@end

NS_ASSUME_NONNULL_END
