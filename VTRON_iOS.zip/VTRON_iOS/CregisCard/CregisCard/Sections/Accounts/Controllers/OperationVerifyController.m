//
//  OperationVerifyController.m
//  CregisCard
//
//  Created by 孙良 on 2024/11/5.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "OperationVerifyController.h"
#import "PayPasswordController.h"
#import "HolderInfoController.h"
#import "IdentityInreviewController.h"

@interface OperationVerifyController ()
@property (weak, nonatomic) IBOutlet UIView *IDView;
@property (weak, nonatomic) IBOutlet UILabel *IDLabel;
@property (weak, nonatomic) IBOutlet UIView *pswView;
@property (weak, nonatomic) IBOutlet UILabel *pswLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet UIImageView *IDstatusImageV;
@property (weak, nonatomic) IBOutlet UIImageView *pswstatusImageV;
@property (weak, nonatomic) IBOutlet UIView *IDstatusView;
@property (weak, nonatomic) IBOutlet UILabel *IDtips;

@end

@implementation OperationVerifyController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setBorderView:self.IDView];
    [self setBorderView:self.pswView];
    self.IDLabel.text=LocalizationKey(@"身份认证");
    self.pswLabel.text=LocalizationKey(@"交易密码");
    self.IDLabel.font=RegularFont(17);
    self.pswLabel.font=RegularFont(17);
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    [self updateUI];
    [self configIDStatusUI];
}


-(void)updateUI{
    
    if (self.type==0) {
        self.title=LocalizationKey(@"提币验证2");
        self.alertLabel.text=LocalizationKey(@"提币前，需要完成以下安全验证");
        self.IDView.hidden=YES;
        self.topDistance.constant=40;
        
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]==1) {
            self.pswstatusImageV.image=UIIMAGE(@"google_Normal");
        }
      
        
    }else if(self.type==1){
        self.title=LocalizationKey(@"转账验证2");
        self.alertLabel.text=LocalizationKey(@"转账前，需要完成以下安全验证");
        self.IDView.hidden=YES;
        self.topDistance.constant=40;
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]==1) {
            self.pswstatusImageV.image=UIIMAGE(@"google_Normal");
        }
    }
    else if(self.type==2){
        self.title=LocalizationKey(@"申请卡");
        self.alertLabel.text=LocalizationKey(@"申请卡需要先完成以下信息");
        [self configUIForApplyCard];

    }else{
        
        
    }
    

}


-(void)configUIForApplyCard{
    
    if ([[UserWrapper shareUserInfo].kycStatus intValue]!=5&&[[UserWrapper shareUserInfo].isPayPassword intValue]!=1) {
        //未实名认证，也未设置交易密码
     
       
    }else{
        if ([[UserWrapper shareUserInfo].kycStatus intValue]!=5) {
            self.pswstatusImageV.image=UIIMAGE(@"google_Normal");
            //未实名认证

        }else{
            //已经实名
            self.IDstatusImageV.image=UIIMAGE(@"google_Normal");
        }
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]!=1) {
            //未设置交易密码
 
            self.IDstatusImageV.image=UIIMAGE(@"google_Normal");
        }else{
            //交易密码已经设置
            self.pswstatusImageV.image=UIIMAGE(@"google_Normal");
        }
 
    }
    
    
}




- (IBAction)btnClick:(UIButton*)sender {
    
    if (sender.tag==0) {
        //身份认证
        if ([[UserWrapper shareUserInfo].kycStatus intValue]==5) {
            return;
        }
        if ([[UserWrapper shareUserInfo].kycStatus intValue]==4||[[UserWrapper shareUserInfo].kycStatus intValue]==7) {
            //未提交或者审核拒绝
            HolderInfoController*identityVC=[[HolderInfoController alloc]init];
            identityVC.type=0;
            [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:identityVC animated:YES];
        }else{
            //审核中或者审核通过
            IdentityInreviewController*identityVC=[[IdentityInreviewController alloc]init];
            [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:identityVC animated:YES];
        }
        
        
    }else{
        //交易密码
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]==1) {
            return;
        }
        PayPasswordController*passwordVC=[[PayPasswordController alloc]init];
        WEAKSELF
        passwordVC.pushBlock = ^(int pushType) {
            
            if (pushType==1) {
                //提币
                [weakSelf.navigationController popViewControllerAnimated:NO];
                if (weakSelf.nextOperateBlock) {
                    weakSelf.nextOperateBlock(pushType);
                }
              
                
            }else if (pushType==2){
                //转账
                [weakSelf.navigationController popViewControllerAnimated:NO];
                if (weakSelf.nextOperateBlock) {
                    weakSelf.nextOperateBlock(pushType);
                }
            }else{
                
                
                
            }
            
        };
        passwordVC.type=1;
        passwordVC.pushType=self.type+1;
        [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:passwordVC animated:YES];
        
    }
  
}

-(void)configIDStatusUI{
    
    if ([[UserWrapper shareUserInfo].kycStatus intValue]==5||[[UserWrapper shareUserInfo].kycStatus intValue]==7) {
        self.IDstatusView.hidden=YES;
    }
    self.IDstatusView.backgroundColor=[self getIDViewColor];
    self.IDtips.textColor=[self getIDTextColor];
    self.IDtips.text=[self getIDStatus];
   
}

-(UIColor*)getIDTextColor{
    switch ([[UserWrapper shareUserInfo].kycStatus intValue]) {
        case 0://审核中
            return  [UIColor colorWithHexString:@"#FA6400" alpha:1.0];
            break;
        case 1://后台审核完成
            return [UIColor baseColor];
            break;
        case 2://待用户人脸识别
            return [UIColor baseColor];
            break;
        case 3://待 ipeakoin审核
            return [UIColor baseColor];
            break;
        case 4://未通过
            return [UIColor colorWithHexString:@"#EC312C" alpha:1.0];
            break;
        case 5://已认证
            return [UIColor colorWithHexString:@"#6DD400" alpha:1.0];
            break;
       
        case 7://未认证
            return [UIColor colorWithHexString:@"#F7B500" alpha:1.0];
            break;
        default:
            return [UIColor alertColor];
            break;
    }
    
}

-(UIColor*)getIDViewColor{
    switch ([[UserWrapper shareUserInfo].kycStatus intValue]) {
        case 0://审核中
            return  [UIColor colorWithHexString:@"#FA6400" alpha:0.04];
            break;
        case 1://后台审核完成
            return [UIColor baseColor];
            break;
        case 2://待用户人脸识别
            return [UIColor baseColor];
            break;
        case 3://待 ipeakoin审核
            return [UIColor baseColor];
            break;
        case 4://未通过
            return [UIColor colorWithHexString:@"#EC312C" alpha:0.04];
            break;
        case 5://已认证
            return [[UIColor colorWithHexString:@"#6DD400" alpha:1.0] colorWithAlphaComponent:0.1];
            break;
       
        case 7://未认证
            return [UIColor colorWithHexString:@"#F7B500" alpha:0.1];
            break;
        default:
            return [UIColor alertColor];
            break;
    }
    
}
-(NSString*)getIDStatus{
    switch ([[UserWrapper shareUserInfo].kycStatus intValue]) {
        case 0:
            return LocalizationKey(@"审核中");
            break;
        case 1:
            return LocalizationKey(@"后台审核完成");
            break;
        case 2:
            return LocalizationKey(@"待用户人脸识别");
            break;
        case 3:
            return LocalizationKey(@"待 ipeakoin审核");
            break;
        case 4:
            return LocalizationKey(@"未通过");
            break;
        case 5:
            return LocalizationKey(@"已认证");
            break;
       
        case 7:
            return LocalizationKey(@"未认证");
            break;
        default:
            return LocalizationKey(@"未知");
            break;
    }
    
}


-(void)dealloc{
    NSLog(@"这个页面释放了");
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
