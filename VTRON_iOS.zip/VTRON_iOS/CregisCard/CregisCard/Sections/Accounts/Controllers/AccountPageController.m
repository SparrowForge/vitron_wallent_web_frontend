//
//  AccountPageController.m
//  CregisCard
//
//  Created by 孙良 on 2024/11/14.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "AccountPageController.h"
#import "AccountTopView.h"
#import "TransactionViewController.h"
#import "CoinRechargeController.h"
#import "WithdrawController.h"
#import "TransferController.h"
#import "TransferFirstStepController.h"
#import "ReceivingQRController.h"
#import "VersionUpdateView.h"
#import "MineNetWorkManager.h"
#import "LoginController.h"
#import "FWPopupWindow.h"
#import "LoginOverdueView.h"
#import "OperationVerifyController.h"
#import "TABAnimated.h"
#import "AccountRecordCell.h"
#import "AccountOtherCell.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "AccountNetWorkManager.h"
#import "NSObject+UBTrackerModel.h"
#import "OrderRecordModel.h"
#import "TransactionDetailController.h"
#import "CardSectionView.h"
#import "NotificationCenterController.h"

@interface AccountPageController ()<UITableViewDelegate,UITableViewDataSource>
{
    int _pageNO;
}
@property (strong, nonatomic) UITableView *tableView;
@property(nonatomic,strong)   NSMutableArray*contentArray;
@property (nonatomic, strong) AccountTopView *topView;
@property(nonatomic,strong)   VersionUpdateView *versionUpdateView;
@property (nonatomic, strong) UIView *redDotView;

@end

@implementation AccountPageController

- (VersionUpdateView *)versionUpdateView {
    if(!_versionUpdateView) {
        _versionUpdateView=[VersionUpdateView instanceViewWithFrame:[UIScreen mainScreen].bounds];
    }
    return _versionUpdateView;
}

-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _pageNO=1;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(toLogout)name:Login_OUT object:nil];//退出登录
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showLoginOverdueView)name:Login_OUT_OTHER object:nil];//退出登录(被踢下线)
    [self setRightCustomView];
    [self setTableViewConfig];
    [self getAccountRecordListWithOtherParams:[NSDictionary new]];
    [self getVersionForAPP];
    [UBTNSUserDefaultUtil PutDefaults:KACCOUNT Value:[UserWrapper shareUserInfo].email];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    [self getAssetDetail];
    [self getNotificationMessages];

}

-(void)setRightCustomView{
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
     [button setImage:[UIImage imageNamed:@"homeAlertIcon"] forState:UIControlStateNormal];
     button.frame = CGRectMake(0, 0, 24, 24);
     [button addTarget:self action:@selector(rightTouchEvent) forControlEvents:UIControlEventTouchUpInside];
     // 红点
     UIView *redDot = [[UIView alloc] initWithFrame:CGRectMake(14, 0, 8, 8)];
     redDot.backgroundColor = [UIColor colorWithHexString:@"#E11D53" alpha:1.0];
     redDot.layer.cornerRadius = 4;
     redDot.hidden = YES; // 初始隐藏
     [button addSubview:redDot];
     self.redDotView = redDot;
     UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:button];
     self.navigationItem.rightBarButtonItem = item;
    
}


-(void)setTableViewConfig{
    
 
    self.tableView= [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.view addSubview:self.tableView];
    [self.tableView registerNib:[UINib nibWithNibName:@"AccountRecordCell" bundle:nil] forCellReuseIdentifier:@"AccountRecordCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AccountOtherCell" bundle:nil] forCellReuseIdentifier:@"AccountOtherCell"];
    self.tableView.tableFooterView=[UIView new];
    self.tableView.estimatedRowHeight=90;
    self.tableView.backgroundColor=[UIColor whiteColor];
    self.tableView.tabAnimated=[TABTableAnimated animatedWithCellClassArray:@[[AccountRecordCell class], [AccountOtherCell class]] cellHeightArray:@[@90.0, @120.0] animatedCountArray:@[@10,@10]];
    [self.tableView tab_startAnimation];
    [self headRefreshWithScrollerView:self.tableView];
   // [self footRefreshWithScrollerView:self.tableView];
    UIView*topView=[[UIView alloc]initWithFrame:CGRectMake(0, 0,kWindowW, 280+30+(kWindowW-40)*220/684)];
    topView.backgroundColor=[UIColor whiteColor];
    
    self.topView=[AccountTopView instanceViewWithFrame:topView.bounds];
    [topView addSubview:self.topView];
    self.tableView.tableHeaderView=topView;
    WEAKSELF
    [self.topView.rechargeBtn dn_addActionHandler:^{
        //充值
        [weakSelf.navigationController pushViewController:[[CoinRechargeController alloc]init] animated:YES];
    }];
    [self.topView.withdrawBtn dn_addActionHandler:^{
        //提现
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]!=1) {
            //设置交易密码
            OperationVerifyController*operateVC=[[OperationVerifyController alloc]init];
            operateVC.nextOperateBlock = ^(int pushType) {
                //设置完交易密码之后直接跳转到提币页面
                WithdrawController*withdrawVC=[[WithdrawController alloc]init];
                [weakSelf.navigationController pushViewController:withdrawVC animated:YES];
            };
            operateVC.type=0;
            [self.navigationController pushViewController:operateVC animated:YES];
            return;
            }
        WithdrawController*withdrawVC=[[WithdrawController alloc]init];
        [weakSelf.navigationController pushViewController:withdrawVC animated:YES];
        
    }];
    [self.topView.transferBtn dn_addActionHandler:^{
        //转账
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]!=1) {
            //设置交易密码
            OperationVerifyController*operateVC=[[OperationVerifyController alloc]init];
            operateVC.nextOperateBlock = ^(int pushType) {
                //设置完交易密码之后直接跳转到转账页面
                TransferFirstStepController*transferVC=[[TransferFirstStepController alloc]init];
                [weakSelf.navigationController pushViewController:transferVC animated:YES];
            };
            operateVC.type=1;
            [self.navigationController pushViewController:operateVC animated:YES];
            return;
          }
        TransferFirstStepController*transferVC=[[TransferFirstStepController alloc]init];
        [weakSelf.navigationController pushViewController:transferVC animated:YES];
        
    }];
    [self.topView.exchangeBtn dn_addActionHandler:^{
        //收款
        ReceivingQRController*receivingVC=[[ReceivingQRController alloc]init];
        [weakSelf.navigationController pushViewController:receivingVC animated:YES];
        
    }];
  
}

-(void)configEmptyViewForTableView{
 
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        //CGFloat offsetY=DX_IS_IPhoneX_All?40:0;
        CGFloat offsetY=50;
        emptyView.contentViewY=280+30+(kWindowW-40)*220/684+80+offsetY;
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}


//MARK: 通知中心
- (void)rightTouchEvent {
    
    NotificationCenterController*notificationVC=[[NotificationCenterController alloc]init];
    [self.navigationController pushViewController:notificationVC animated:YES];
   
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    OrderRecordModel*model=self.contentArray[indexPath.row];
    
    if ([model.type isEqualToString:@"create_card"]||[model.type isEqualToString:@"deposit_card"]||[model.type isEqualToString:@"withdraw_card"]||[model.type isEqualToString:@"program_fee_card"]) {
        //卡申请，卡充值，卡提现，卡手续费 展示卡号
        AccountOtherCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AccountOtherCell"];
        [cell configDataWithModel:self.contentArray[indexPath.row] withType:0];
        return cell;
        
    }else{
        AccountRecordCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AccountRecordCell"];
        [cell configDataWithModel:self.contentArray[indexPath.row] withType:0];
        return cell;
    }
    
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
    TransactionDetailController*detailVC=[[TransactionDetailController alloc]init];
    detailVC.orderModel=self.contentArray[indexPath.row];
    detailVC.type=0;
    [self.navigationController pushViewController:detailVC animated:YES];
}


-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    UIView*view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW,60)];
    view.backgroundColor=[UIColor whiteColor];
    CardSectionView*sectionView=[CardSectionView instanceViewWithFrame:view.bounds withHomeCardType:5];
    WEAKSELF
    //全部
    [sectionView.allBtn dn_addActionHandler:^{
        TransactionViewController*allCountVC=[[TransactionViewController alloc]init];
        allCountVC.type=0;
        [weakSelf.navigationController pushViewController:allCountVC animated:YES];
    }];
    [view addSubview:sectionView];
   
    return view;

  }

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

    return 60;
 }

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    OrderRecordModel*model=self.contentArray[indexPath.row];
    if ([model.type isEqualToString:@"create_card"]||[model.type isEqualToString:@"deposit_card"]||[model.type isEqualToString:@"withdraw_card"]||[model.type isEqualToString:@"program_fee_card"]) {
        return 106;
    }
    
    return 88;
    
}
//MARK: 上拉加载更多
- (void)refreshFooterAction{
    _pageNO+=1;
    [self getAccountRecordListWithOtherParams:[NSDictionary new]];
  
}
//MARK: 下拉刷新
- (void)refreshHeaderAction{
    _pageNO=1;
    [self.tableView.mj_footer resetNoMoreData];
    [self getAccountRecordListWithOtherParams:[NSDictionary new]];
    [self getAssetDetail];
}
#pragma mark -- 获取资产详情
-(void)getAssetDetail{
    
    [AccountNetWorkManager merchantWalletListsuccess:^(id  _Nonnull data) {
        if ([data[@"code"] intValue]==200) {
            NSArray*coinsArray=data[@"data"];
        
            self.topView.dataDic=data;
            NSMutableArray*allCoins=[[NSMutableArray alloc]init];
            [coinsArray enumerateObjectsUsingBlock:^(NSDictionary* obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [allCoins addObject:obj[@"currency"]];
                            
            }];
            [CommonInfoManager sharedInstance].coinsArray=allCoins;
     
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
     } fail:^(NSError * _Nonnull error) {
         //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

#pragma mark -- 获取账单流水
-(void)getAccountRecordListWithOtherParams:(NSDictionary*)otherDic{
    
    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10)} mutableCopy];
   
    [dic addEntriesFromDictionary:otherDic];
   //[SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getOrderRecordListWithParams:dic success:^(id  _Nonnull data) {
        //[SVProgressHUD dismiss];
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
        if ([data[@"code"] intValue]==200) {
            
            if(self->_pageNO==1){
                [self.contentArray removeAllObjects];
            }
            NSArray*onceArray=[OrderRecordModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
            if(onceArray.count>0){
                [self.contentArray addObjectsFromArray:onceArray];
            }
            [self.tableView reloadData];
            if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                [self.tableView.mj_footer endRefreshingWithNoMoreData];
            }
          
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        
    } fail:^(NSError * _Nonnull error) {
        //[SVProgressHUD dismiss];
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}
//获取版本更新
-(void)getVersionForAPP{

    [MineNetWorkManager getVersionWithParams:@{@"type":@"ios"} success:^(id  _Nonnull data) {
        
        if ([data[@"code"] intValue]==200) {
            NSString*version=data[@"data"][@"version"];
            version = [version stringByReplacingOccurrencesOfString:@" " withString:@""];//去掉所有空格
       
            if ([version containsString:@"v"]) {
                version=[version stringByReplacingOccurrencesOfString:@"v" withString:@""];
            }
            if ([version containsString:@"V"]) {
                version=[version stringByReplacingOccurrencesOfString:@"V" withString:@""];
            }
            // app当前版本
            NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
            NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
            if ([app_Version compare:version options:NSNumericSearch] == NSOrderedSame ||[app_Version compare:version options:NSNumericSearch] == NSOrderedDescending) {
                //不需要更新
            }else{
                //要更新
                [self.versionUpdateView show];
                self.versionUpdateView.dic=data[@"data"];

          }
   
        }
        
    } fail:^(NSError * _Nonnull error) {
        
        
    }];
}

//获取消息
-(void)getNotificationMessages{
    NSMutableDictionary*dic=[@{@"pageIndex":@(1),@"pageSize":@(1)} mutableCopy];
    [MineNetWorkManager getNotificationCenterWithParams:dic success:^(id  _Nonnull data) {
      
        if ([data[@"code"] intValue]==200) {
            NSArray*dataArray=data[@"data"][@"records"];
            if (dataArray.count>0) {
                NSDictionary*dic=[dataArray firstObject];
                if ([dic[@"authStatus"] intValue]==0) {
                    //有未读消息
                    self.redDotView.hidden=NO;
                }else{
                    self.redDotView.hidden=YES;
                }
            }else{
                self.redDotView.hidden=YES;
            }
            
         
        }
        else{
          
            }
      
        } fail:^(NSError * _Nonnull error) {
          
   }];
    
}


//登录超时
-(void)toLogout{
 
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self popLoginOutViewWithType:0];
        
    });
}

//MARK: 被别的设备登录下线提醒
-(void)showLoginOverdueView{
  
    [self popLoginOutViewWithType:1];
}


//0 登录过期 1 被别的设备踢下线
-(void)popLoginOutViewWithType:(int)type{
    
    [SVProgressHUD dismiss];
    UIView* attachedView = [FWPopupWindow sharedWindow].attachView;
    UIView *foundView = [attachedView viewWithTag:19029];//防止多次弹窗
    if (foundView) {
        return;
    }
    LoginOverdueView*overdueView=[LoginOverdueView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
    overdueView.detailLabel.text=type==0?LocalizationKey(@"登录状态已失效，请重新登录"):LocalizationKey(@"您的账户在另一台设备上登录");
    overdueView.tag=19029;
    WEAKSELF
    [overdueView.okBtn dn_addActionHandler:^{
        [overdueView hide];
        [weakSelf logout];
    }];
    [overdueView show];
    
    
}

//MARK:退出登录
-(void)logout{
    
    if(![UserWrapper isLogIn]){
        return;
    }
    [UserWrapper logout];
    [self initRootViewController];
}

-(void)initRootViewController{
    LoginController*loginVC=[[LoginController alloc]init];
    BaseNavigationController*loginNav=[[BaseNavigationController alloc]initWithRootViewController:loginVC];
    APPLICATION.window.rootViewController = loginNav;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
