//
//  TransactionDetailController.m
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "TransactionDetailController.h"
#import "TransactionHeadView.h"
#import "OrderDetailCell.h"
#import "TransactionDetailCell.h"
#import "MineNetWorkManager.h"
#import "NSObject+UBTrackerModel.h"
#import "TABAnimated.h"

@interface TransactionDetailController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) UITableView *tableView;
@property(nonatomic,strong) TransactionHeadView*detailHeadView;
@property(nonatomic,strong)   NSArray*titleArray;
@property(nonatomic,strong)   NSArray*contentArray;

@end

@implementation TransactionDetailController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self backBtnNoNavBar:NO normalBack:YES backTitle:[self getTypeNameWithType:self.orderModel.type]];
    [self setTableViewConfig];
    if (self.type==0) {
        [self getOrderDetail];
    }else{
        [self getCardDetail];
    }
 
}

- (void)backBtnNoNavBar:(BOOL)noNavBar normalBack:(BOOL)normalBack backTitle:(NSString *)backTitle {
    CGFloat ww = 80; //宽度放大，给文字留位置
    CGFloat hh = 28;

    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, ww, hh)];

    //返回图标
    UIImage *image = [[UIImage imageNamed:@"returnBtn"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [backBtn setImage:image forState:UIControlStateNormal];

    //返回文字
    [backBtn setTitle:backTitle forState:UIControlStateNormal];
    [backBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0] forState:UIControlStateNormal];
    backBtn.titleLabel.font = PingFangMediumFont(17);

    //对齐
    backBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;

    //调整图片和文字的间距
    [backBtn setImageEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 0)];
    [backBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];

    [backBtn addTarget:self action:@selector(backNav:) forControlEvents:UIControlEventTouchUpInside];
    backBtn.tag = normalBack;
    backBtn.backgroundColor = [UIColor clearColor];

    UIBarButtonItem *leftBarBtn = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = leftBarBtn;
    self.backBtn = backBtn;
}
//点击返回按钮
-(void)backNav:(UIButton *)Btn {
    
    [self.navigationController popViewControllerAnimated:YES];
   
}

-(void)setTableViewConfig{
    
    self.tableView =[[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.tableView registerNib:[UINib nibWithNibName:@"OrderDetailCell" bundle:nil] forCellReuseIdentifier:@"OrderDetailCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"TransactionDetailCell" bundle:nil] forCellReuseIdentifier:@"TransactionDetailCell"];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    self.tableView.tabAnimated=[TABTableAnimated animatedWithCellClassArray:@[[OrderDetailCell class]] cellHeightArray:@[@50.0] animatedCountArray:@[@6]];
    self.tableView.tabAnimated.showTableHeaderView = YES;//表头动画
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 215)];
    self.detailHeadView=[TransactionHeadView instanceViewWithFrame:headView.bounds];
    [headView addSubview:self.detailHeadView];
    [self.detailHeadView configDataWithModel:self.orderModel withType:(int)self.type];
    self.tableView.tableHeaderView=headView;
    self.tableView.estimatedRowHeight=500;//取值要大点
    self.tableView.backgroundColor=[UIColor whiteColor];
    [self.tableView tab_startAnimation];


}

// 创建区头视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 24)];
    headerView.backgroundColor = [UIColor whiteColor];
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return section==0?(self.titleArray.count>1?10:24):24; // 根据需求设置区头高度
}
//获取钱包流水详情
-(void)getOrderDetail{
    
    NSMutableDictionary*dic=[@{@"id":self.orderModel.ID} mutableCopy];

    [MineNetWorkManager getOrderRecordDetailWithParams:dic success:^(id  _Nonnull data) {
       
        [self.tableView tab_endAnimation];//结束动画
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        if ([data[@"code"] intValue]==200) {
           
            OrderRecordModel*model=[OrderRecordModel utr_modelWithKeyValue:data[@"data"]];
            self.orderModel=model;
            [self.detailHeadView configDataWithModel:self.orderModel withType:(int)self.type];
            [self configWalletData];
            
        }else{
            
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
      
        [self.tableView reloadData];
    
        } fail:^(NSError * _Nonnull error) {
            [self.tableView tab_endAnimation];//结束动画
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });

   }];
    
    
}

//获取卡流水详情
-(void)getCardDetail{
    
    NSMutableDictionary*dic=[@{@"id":self.orderModel.ID} mutableCopy];

    [MineNetWorkManager getCardRecordDetailWithParams:dic success:^(id  _Nonnull data) {
       
        [self.tableView tab_endAnimation];//结束动画
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        if ([data[@"code"] intValue]==200) {
           
            OrderRecordModel*model=[OrderRecordModel utr_modelWithKeyValue:data[@"data"]];
            self.orderModel=model;
            [self.detailHeadView configDataWithModel:self.orderModel withType:(int)self.type];
            [self configCardDetail];
            NSLog(@"卡流水记录--%@",data);
        }else{
            
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
      
        [self.tableView reloadData];
    
        } fail:^(NSError * _Nonnull error) {
            [self.tableView tab_endAnimation];//结束动画
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });

   }];
    
    
}
//配置钱包流水详情数据
-(void)configWalletData{
    
    if ([self.orderModel.type isEqualToString:@"top_up"]) {
        //充值
        self.titleArray=@[@[LocalizationKey(@"充币"),LocalizationKey(@"汇率"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"网络"),LocalizationKey(@"地址"),LocalizationKey(@"交易哈希"),LocalizationKey(@"交易ID"),]];
        self.contentArray=@[@[[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.amount],[NSString dealWithCurrency:self.orderModel.currency]],@"1USDT=1USD",[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalFee],@"USD"]],@[[NSString convertDateString:self.orderModel.createTime],[NSString repalceNULLWithlineString:self.orderModel.addressChain],[self shortenString:self.orderModel.address],[self shortenString:[NSString repalceNULLWithlineString:self.orderModel.hashId]],self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"withdrawal"]){
        //提币
      
        self.titleArray=@[@[LocalizationKey(@"到账金额"),LocalizationKey(@"汇率"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"审核结果"),LocalizationKey(@"网络"),LocalizationKey(@"收款地址"),LocalizationKey(@"交易哈希"),LocalizationKey(@"交易ID")]];
        NSString*reviewReslut;
        if ([self.orderModel.withdrawStatus intValue]==0) {
            reviewReslut=LocalizationKey(@"待审核");
        }else if ([self.orderModel.withdrawStatus intValue]==1){
            reviewReslut=LocalizationKey(@"审核通过");

        }else{
            reviewReslut=LocalizationKey(@"审核拒绝");

        }
       
        if (![NSString stringIsNull:self.orderModel.remark]) {
            reviewReslut=[NSString stringWithFormat:@"%@(%@)",reviewReslut,self.orderModel.remark];
        }
        if ([NSString stringIsNull:self.orderModel.withdrawStatus]) {
            reviewReslut=@"--";//兼容老数据
        }
       
        self.contentArray=@[@[[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.amount],[NSString dealWithCurrency:self.orderModel.currency]],@"1USDT=1USD",[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalFee],@"USD"]],@[[NSString convertDateString:self.orderModel.createTime],reviewReslut,[NSString repalceNULLWithlineString:self.orderModel.addressChain],[self shortenString:self.orderModel.address],[self shortenString:[NSString repalceNULLWithlineString:self.orderModel.hashId]],self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"create_card"]){
        //卡片申请
        NSString*cardType=[self.orderModel.cardType intValue]==1?LocalizationKey(@"虚拟卡"):LocalizationKey(@"实体卡");
        if ([NSString stringIsNull:self.orderModel.cardType]) {
            cardType=@"--";
        }
        self.titleArray=@[@[LocalizationKey(@"卡类型"),LocalizationKey(@"卡号")],@[LocalizationKey(@"时间"),LocalizationKey(@"交易ID")]];
        self.contentArray=@[@[cardType,[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]]],@[[NSString convertDateString:self.orderModel.createTime],self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"deposit_card"]){
        //卡片充值
        self.titleArray=@[@[LocalizationKey(@"到账金额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"交易ID")]];
        NSString*cardNo=[NSString stringIsNull:self.orderModel.cardNo]?@"--":[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]];
        self.contentArray=@[@[[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.amount],[NSString dealWithCurrency:self.orderModel.currency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalFee],[NSString dealWithCurrency:self.orderModel.currency]]],@[[NSString convertDateString:self.orderModel.createTime],cardNo,self.orderModel.orderId]];
        
    }else if ([self.orderModel.type isEqualToString:@"program_fee_card"]){
        //卡手续费
        self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"类型"),LocalizationKey(@"交易ID")]];
        NSString*feeType=@"--";
        if ([self.orderModel.subType isEqualToString:@"Fee_Consumption"]) {
            feeType=LocalizationKey(@"消费手续费");
        }else if([self.orderModel.subType isEqualToString:@"Declined_Fee"]){
            feeType=LocalizationKey(@"卡授权手续费");
        }else if([self.orderModel.subType isEqualToString:@"Fee_Credit"]){
            feeType=LocalizationKey(@"退款手续费");
        }
        
        self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]],feeType,self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"withdraw_card"]){
        //卡片提现
        self.titleArray=@[@[LocalizationKey(@"提现总额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"交易ID")]];
        self.contentArray=@[@[[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.amount],[NSString dealWithCurrency:self.orderModel.currency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalFee],[NSString dealWithCurrency:self.orderModel.currency]]],@[[NSString convertDateString:self.orderModel.createTime],[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]],self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"transfer"]){
        //转账
        self.titleArray=@[@[LocalizationKey(@"到账金额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"备注"),LocalizationKey(@"收款方"),LocalizationKey(@"交易ID")]];
        self.contentArray=@[@[[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.amount],[NSString dealWithCurrency:self.orderModel.currency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalFee],[NSString dealWithCurrency:self.orderModel.currency]]],@[[NSString convertDateString:self.orderModel.createTime],[NSString repalceNULLWithlineString:self.orderModel.remark],[NSString stringWithFormat:@"%@(ID)\n%@",self.orderModel.transId,self.orderModel.transEmail],self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"receive"]){
        //收款
        self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"备注"),LocalizationKey(@"付款方"),LocalizationKey(@"交易ID")]];
        self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],[NSString repalceNULLWithlineString:self.orderModel.remark],[NSString stringWithFormat:@"%@(ID)\n%@",self.orderModel.transId,self.orderModel.transEmail],self.orderModel.orderId]];
    }else if ([self.orderModel.type isEqualToString:@"correction"]){
        //冲正
        self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"备注"),LocalizationKey(@"交易ID")]];
        self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],[NSString repalceNULLWithlineString:self.orderModel.remark],self.orderModel.orderId]];
    }else{
        //未知
    }

       [self.tableView reloadData];
   
}

//配置卡流水详情
-(void)configCardDetail{
    
    if ([self.orderModel.type isEqualToString:@"deposit_card"]){
       //卡片充值
       self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"交易ID")]];
       NSString*cardNo=[NSString stringIsNull:self.orderModel.cardNo]?@"--":[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]];
       self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],cardNo,self.orderModel.orderId]];
    }else if([self.orderModel.type isEqualToString:@"fee_card"]){
        //卡费
        NSString*feeType=@"--";
        if ([self.orderModel.subType isEqualToString:@"Fee_Consumption"]) {
            feeType=LocalizationKey(@"消费手续费");
        }else if([self.orderModel.subType isEqualToString:@"Declined_Fee"]){
            feeType=LocalizationKey(@"卡授权手续费");
        }else if([self.orderModel.subType isEqualToString:@"Fee_Credit"]){
            feeType=LocalizationKey(@"退款手续费");
        }
        self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"类型"),LocalizationKey(@"关联交易"),LocalizationKey(@"交易ID")]];
        NSString*cardNo=[NSString stringIsNull:self.orderModel.cardNo]?@"--":[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]];
        self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],cardNo,feeType,[NSString repalceNULLWithlineString:self.orderModel.relationOrderId],self.orderModel.orderId]];
        
    }else if([self.orderModel.type isEqualToString:@"verification_card"]){
        //验证
        self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"商家"),LocalizationKey(@"交易ID")]];
        NSString*cardNo=[NSString stringIsNull:self.orderModel.cardNo]?@"--":[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]];
        self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],cardNo,[NSString repalceNULLWithlineString:self.orderModel.consumerMerchantName],self.orderModel.orderId]];
        
        
    }else if ([self.orderModel.type isEqualToString:@"refund_card"]) {
        //退款
        self.titleArray=@[@[LocalizationKey(@"退款金额"),LocalizationKey(@"账单金额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"商家"),LocalizationKey(@"交易ID"),]];
        NSString*refundString=self.orderModel.totalAmount>0?[NSString stringWithFormat:@"+%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]]:[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]];
        self.contentArray=@[@[refundString,[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.billAmount],[NSString dealWithCurrency:self.orderModel.billCurrency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.fee],[NSString dealWithCurrency:self.orderModel.feeCurrency]]],@[[NSString convertDateString:self.orderModel.createTime],[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]],[NSString repalceNULLWithlineString:self.orderModel.consumerMerchantName],self.orderModel.orderId]];
      
    }
    else if ([self.orderModel.type isEqualToString:@"program_fee_card"]) {
        //消费
        self.titleArray=@[@[LocalizationKey(@"消费总额"),LocalizationKey(@"账单金额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"商家"),LocalizationKey(@"交易ID"),]];
        NSString*consumptionString=self.orderModel.totalAmount>0?[NSString stringWithFormat:@"-%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]]:[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]];
       
        self.contentArray=@[@[consumptionString,[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.billAmount],[NSString dealWithCurrency:self.orderModel.billCurrency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.fee],[NSString dealWithCurrency:self.orderModel.feeCurrency]]],@[[NSString convertDateString:self.orderModel.createTime],[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]],[NSString repalceNULLWithlineString:self.orderModel.consumerMerchantName],self.orderModel.orderId]];
        
            
    }else if([self.orderModel.type isEqualToString:@"withdraw_card"]){
        //卡片提现
        self.titleArray=@[@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"交易ID")]];
        NSString*cardNo=[NSString stringIsNull:self.orderModel.cardNo]?@"--":[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]];
        self.contentArray=@[@[[NSString convertDateString:self.orderModel.createTime],cardNo,self.orderModel.orderId]];
        
    }
    else if([self.orderModel.type isEqualToString:@"reversal_card"]){
        //撤销
        self.titleArray=@[@[LocalizationKey(@"撤销总额"),LocalizationKey(@"账单金额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"商家"),LocalizationKey(@"关联交易"),LocalizationKey(@"交易ID"),]];
        NSString*revokeString=self.orderModel.totalAmount>0?[NSString stringWithFormat:@"+%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]]:[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]];
        self.contentArray=@[@[revokeString,[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.billAmount],[NSString dealWithCurrency:self.orderModel.billCurrency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.fee],[NSString dealWithCurrency:self.orderModel.feeCurrency]]],@[[NSString convertDateString:self.orderModel.createTime],[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]],[NSString repalceNULLWithlineString:self.orderModel.consumerMerchantName],[NSString repalceNULLWithlineString:self.orderModel.relationOrderId],self.orderModel.orderId]];
        
    }
    else if([self.orderModel.type isEqualToString:@"atm_fee_card"]){
        //ATM
        self.titleArray=@[@[LocalizationKey(@"取款总额"),LocalizationKey(@"账单金额"),LocalizationKey(@"手续费")],@[LocalizationKey(@"时间"),LocalizationKey(@"卡号"),LocalizationKey(@"商家"),LocalizationKey(@"交易ID"),]];
        NSString*takeOutString=self.orderModel.totalAmount>0?[NSString stringWithFormat:@"-%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]]:[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.totalAmount],[NSString dealWithCurrency:self.orderModel.totalCurrency]];
        self.contentArray=@[@[takeOutString,[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.billAmount],[NSString dealWithCurrency:self.orderModel.billCurrency]],[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.fee],[NSString dealWithCurrency:self.orderModel.feeCurrency]]],@[[NSString convertDateString:self.orderModel.createTime],[NSString stringWithFormat:@".... %@",[self last4CharactersOfString:self.orderModel.cardNo]],[NSString repalceNULLWithlineString:self.orderModel.consumerMerchantName],self.orderModel.orderId]];
    }
    [self.tableView reloadData];
    
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.titleArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.titleArray.count>1) {
        
        if (section==0) {
            return 1;
        }else{
            NSArray*titleArray=self.titleArray[section];
            return titleArray.count;
        }
    }else{
        NSArray*titleArray=self.titleArray[section];
        return titleArray.count;
    }
  
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.titleArray.count>1) {
        //两个区
        if (indexPath.section==0) {
            TransactionDetailCell*cell=[tableView dequeueReusableCellWithIdentifier:@"TransactionDetailCell"];
            [cell configDataWithModel:self.orderModel  AtIndexPath:indexPath withTitleArray:self.titleArray[indexPath.section] withContentArray:self.contentArray[indexPath.section]];
    

            return cell;
        }else{
            
            OrderDetailCell*cell=[tableView dequeueReusableCellWithIdentifier:@"OrderDetailCell"];
            [cell configDataWithModel:self.orderModel AtIndexPath:indexPath withTitleArray:self.titleArray[indexPath.section] withContentArray:self.contentArray[indexPath.section] withType:(int)self.type];
           
            return cell;
            
        }
       
        
    }else{
        //一个区
        OrderDetailCell*cell=[tableView dequeueReusableCellWithIdentifier:@"OrderDetailCell"];
        [cell configDataWithModel:self.orderModel  AtIndexPath:indexPath withTitleArray:self.titleArray[indexPath.section] withContentArray:self.contentArray[indexPath.section] withType:(int)self.type];
      
        return cell;
        
    }
   
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
    
}

// 设置每个 section 的底部间距
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01; // 保持底部尽量小
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

//获取类型
-(NSString*)getTypeNameWithType:(NSString*)type{
    NSString*lastType;
    if (self.type==0) {
        //钱包流水
        if ([type isEqualToString:@"top_up"]) {
            lastType=LocalizationKey(@"充值");
        }else if ([type isEqualToString:@"withdrawal"]){
            lastType=LocalizationKey(@"提币");
            
        }else if ([type isEqualToString:@"create_card"]){
            lastType=LocalizationKey(@"卡片申请");
            
        }else if ([type isEqualToString:@"deposit_card"]){
            lastType=LocalizationKey(@"卡片充值");
            
        }else if ([type isEqualToString:@"program_fee_card"]){
            lastType=LocalizationKey(@"卡手续费");
            
        }else if ([type isEqualToString:@"withdraw_card"]){
            lastType=LocalizationKey(@"卡片提现");
            
        }else if ([type isEqualToString:@"transfer"]){
            lastType=LocalizationKey(@"转账");
            
        }else if ([type isEqualToString:@"receive"]){
            lastType=LocalizationKey(@"收款");
            
        }else if ([type isEqualToString:@"correction"]){
            lastType=LocalizationKey(@"冲正");
           
        }
    }else{
        //卡流水
      
       if ([type isEqualToString:@"program_fee_card"]){
            lastType=LocalizationKey(@"消费");
            
        }else if ([type isEqualToString:@"refund_card"]){
            lastType=LocalizationKey(@"退款");
            
        }  else if ([type isEqualToString:@"deposit_card"]) {
            lastType=LocalizationKey(@"卡片充值");
        }else if ([type isEqualToString:@"withdraw_card"]){
            lastType=LocalizationKey(@"卡片提现");
        }
        else if ([type isEqualToString:@"verification_card"]){
            lastType=LocalizationKey(@"验证");
            
        }else if ([type isEqualToString:@"fee_card"]){
            lastType=LocalizationKey(@"卡费");
            
        } else if ([type isEqualToString:@"reversal_card"]){
            lastType=LocalizationKey(@"撤销");
            
        }else if ([type isEqualToString:@"atm_fee_card"]){
            lastType=LocalizationKey(@"ATM");
            
        }
        
    }
   
    return lastType;

}

//获取交易渠道
-(NSString*)getTransactionChannel{
    
    if ([self.orderModel.tradeChannel isEqualToString:@"ATM"]) {
        return @"ATM";
    }else if ([self.orderModel.tradeChannel isEqualToString:@"POS"]){
        return @"POS";
    }else if ([self.orderModel.tradeChannel isEqualToString:@"ECOMMERCE"]){
        return LocalizationKey(@"电商");
    }else if ([self.orderModel.tradeChannel isEqualToString:@"VISA_DIRECT"]){
        return LocalizationKey(@"转账");
    }else{
        return LocalizationKey(@"其他");
    }
}



//获取字符串后四位
- (NSString *)last4CharactersOfString:(NSString *)str {
    if (str.length >= 4) {
        return [str substringFromIndex:str.length - 4];
    } else {
        return [NSString repalceNULLWithlineString:str];
    }
}


//地址和交易哈希的展示格式：前6位+...+后6位
-(NSString *)shortenString:(NSString *)originalString {
    if (originalString.length <= 12) {
        return originalString;
    }
    
    NSString *prefix = [originalString substringToIndex:6];
    NSString *suffix = [originalString substringFromIndex:originalString.length - 6];
    return [NSString stringWithFormat:@"%@...%@", prefix, suffix];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
