//
//  TransactionViewController.m
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "TransactionViewController.h"
#import "TransactionDetailController.h"
#import "FilterItemCell.h"
#import "FilterItem.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "AccountNetWorkManager.h"
#import "HomeCardNetWorkManager.h"
#import "OrderRecordModel.h"
#import "NSObject+UBTrackerModel.h"
#import "OrderStatusModel.h"
#import "AccountRecordCell.h"
#import "AccountOtherCell.h"
#import "MineNetWorkManager.h"
#import "TABAnimated.h"
#import "FilterListView.h"
#import "FilterDateView.h"

@interface TransactionViewController ()

{
    int _pageNO;
}
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *filterItems;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) FilterListView*filterTypeView;
@property(nonatomic,strong) FilterListView*filterStatusView;
@property(nonatomic,strong) FilterDateView*filterDateView;
@property(nonatomic,strong) NSMutableDictionary*otherDic;

@end

@implementation TransactionViewController

-(NSMutableDictionary*)otherDic{
    if (!_otherDic) {
        _otherDic=[[NSMutableDictionary  alloc]init];
    }
    return _otherDic;
}

- (FilterListView *)filterTypeView {
    if(!_filterTypeView) {
        if (self.type==0) {
            _filterTypeView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH*0.8)withSelectMenuType:TypeForWallet];
        
        }else{
            _filterTypeView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 7*68+HOME_INDICATOR_HEIGHT+60)withSelectMenuType:TypeForCard];
        }
        _filterTypeView.currentDic=@{@"name":LocalizationKey(@"所有类型"),@"kind":@"-1"};
       
    }
    return _filterTypeView;
}

- (FilterListView *)filterStatusView {
    if(!_filterStatusView) {
        if (self.type==0) {
            _filterStatusView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 4*68+HOME_INDICATOR_HEIGHT+60)withSelectMenuType:StatusForWallet];
            
        }else{
            _filterStatusView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 4*68+HOME_INDICATOR_HEIGHT+60)withSelectMenuType:StatusForCard];
        }
        _filterStatusView.currentDic=@{@"name":LocalizationKey(@"所有状态"),@"kind":@"-1"};
    }
    return _filterStatusView;
}

- (FilterDateView *)filterDateView {
    if(!_filterDateView) {
        _filterDateView=[FilterDateView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 420)];
    }
    return _filterDateView;
}
-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"全部交易");
    [self configTopView];
    [self setTableViewConfig];
    [self getDataWithFirst:YES];
   
   
    // Do any additional setup after loading the view from its nib.
}

-(void)setTableViewConfig{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"AccountRecordCell" bundle:nil] forCellReuseIdentifier:@"AccountRecordCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AccountOtherCell" bundle:nil] forCellReuseIdentifier:@"AccountOtherCell"];
    self.tableView.tableFooterView=[UIView new];
    self.tableView.estimatedRowHeight=90;
    self.tableView.backgroundColor=[UIColor whiteColor];
    //self.tableView.tabAnimated= [TABTableAnimated animatedWithCellClass:[AccountRecordCell class] cellHeight:90.0];
    self.tableView.tabAnimated=[TABTableAnimated animatedWithCellClassArray:@[[AccountRecordCell class], [AccountOtherCell class]] cellHeightArray:@[@90.0, @120.0] animatedCountArray:@[@10,@10]];
    [self headRefreshWithScrollerView:self.tableView];
    [self footRefreshWithScrollerView:self.tableView];
    [self.tableView tab_startAnimation];
   
}
-(void)configTopView{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumInteritemSpacing = 8;
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[FilterItemCell class] forCellWithReuseIdentifier:@"FilterItemCell"];
    FilterItem*typeItem=[[FilterItem alloc]init];
    typeItem.name=LocalizationKey(@"所有类型");
    typeItem.type=@"-1";
    typeItem.kind=0;
    
    FilterItem*statusItem=[[FilterItem alloc]init];
    statusItem.name=LocalizationKey(@"所有状态");
    statusItem.status=@"-1";
    statusItem.kind=1;
    
    FilterItem*dateItem=[[FilterItem alloc]init];
    dateItem.name=LocalizationKey(@"筛选日期");
    dateItem.isCustom=NO;
    
    self.filterItems=[@[typeItem,statusItem,dateItem] mutableCopy];
    [self.collectionView reloadData];
    
}

//获取交易记录数据
-(void)getDataWithFirst:(BOOL)isFirst{
    
    if (self.type==0) {
        //钱包流水
        [self getWalletOrderListWithOtherParams:self.otherDic withFirst:isFirst];
    }else{
        //卡片流水
        [self getCardListWithOtherParams:self.otherDic withFirst:isFirst];
    }
    
    
}


#pragma mark - UICollectionView Delegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.filterItems.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FilterItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FilterItemCell" forIndexPath:indexPath];
    FilterItem *item = self.filterItems[indexPath.item];
    FilterItemCellType type =FilterItemCellTypeNormal;
    if (indexPath.item==0){
        //类型
        if ([item.type isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else if (indexPath.item==1){
        
        //状态
        if ([item.status isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else{
        //时间
        if (!item.isCustom) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
        
    }
    cell.type=type;
    cell.text = item.name;
    
    WEAKSELF
    cell.onCloseTapped = ^{
        NSLog(@"点击了第 %ld 个叉号", (long)indexPath.item);
        if (indexPath.item==0) {
            //类型
            FilterItem *item =[weakSelf.filterItems firstObject];
            item.type=@"-1";
            item.name=LocalizationKey(@"所有类型");
            if (self.type==0) {
                [weakSelf.otherDic setValue:@"" forKey:@"typeString"];
            }else{
                [weakSelf.otherDic setValue:@"" forKey:@"type"];
            }
            weakSelf.filterTypeView.currentDic=@{@"name":LocalizationKey(@"所有类型"),@"kind":@"-1"};
            [weakSelf.filterTypeView reloadTableView];
            
        }else if (indexPath.item==1){
            //状态
            FilterItem *item =[weakSelf.filterItems objectAtIndex:1];
            item.status=@"-1";
            item.name=LocalizationKey(@"所有状态");
            [weakSelf.otherDic setValue:@"" forKey:@"status"];
            weakSelf.filterStatusView.currentDic=@{@"name":LocalizationKey(@"所有状态"),@"kind":@"-1"};
            [weakSelf.filterStatusView reloadTableView];

        }else{
            //时间
            FilterItem *item =[weakSelf.filterItems lastObject];
            item.isCustom=NO;
            item.name=LocalizationKey(@"筛选日期");
            [weakSelf.otherDic setValue:@"" forKey:@"createTimeStart"];
            [weakSelf.otherDic setValue:@"" forKey:@"createTimeEnd"];
            [weakSelf.filterDateView resetAllTime];//重置时间
            
        }
        [weakSelf.tableView.mj_footer resetNoMoreData];
        self->_pageNO=1;
        [weakSelf getDataWithFirst:NO];
        [weakSelf.collectionView reloadData];
        
    };
    
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    FilterItem *item = self.filterItems[indexPath.item];
    NSString *text = item.name;
    FilterItemCellType type =FilterItemCellTypeDeletable;
    if (indexPath.item==0){
        //类型
        if ([item.type isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else if (indexPath.item==1){
        
        //状态
        if ([item.status isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else{
        //时间
        if (!item.isCustom ) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
    }
    
    
    
    CGSize textSize = [text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:13]}];
    CGFloat base = textSize.width + 16*2; // padding
    if (type == FilterItemCellTypeDeletable) {
        base += 14 + 6; // 叉号 + 间距
    }
    return CGSizeMake(base, 32);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    WEAKSELF
    if (indexPath.item==0) {
        //类型
        [self.filterTypeView show];
        self.filterTypeView.filterMenuBlock = ^(NSString * _Nullable name, NSString * _Nullable type) {
            NSLog(@"类型--%@--%@",name,type);
            FilterItem *item =[weakSelf.filterItems firstObject];
            item.name=name;
            item.type=type;
            [weakSelf.collectionView reloadData];
            if (self.type==0) {
                type= [type isEqualToString:@"-1"]?@"":type;
                [weakSelf.otherDic setValue:type forKey:@"typeString"];

            }else{
                type= [type isEqualToString:@"-1"]?@"":type;
                [weakSelf.otherDic setValue:type forKey:@"type"];

            }
            
            [weakSelf.tableView.mj_footer resetNoMoreData];
            self->_pageNO=1;
            [weakSelf getDataWithFirst:NO];

            
        };
        
    }else if (indexPath.item==1){
        //状态
        [self.filterStatusView show];
        self.filterStatusView.filterMenuBlock = ^(NSString * _Nullable name, NSString * _Nullable status) {
            NSLog(@"状态--%@--%@",name,status);
            FilterItem *item =[weakSelf.filterItems objectAtIndex:1];
            item.name=name;
            item.status=status;
            [weakSelf.collectionView reloadData];
            status= [status isEqualToString:@"-1"]?@"":status;
            [weakSelf.otherDic setValue:status forKey:@"status"];
            [weakSelf.tableView.mj_footer resetNoMoreData];
            self->_pageNO=1;
            [weakSelf getDataWithFirst:NO];

        };
        
    }else{
        //时间
        [self.filterDateView show];
        self.filterDateView.filterDateBlock = ^(NSString * _Nullable startTime, NSString * _Nullable endTime) {
            NSLog(@"开始时间：%@，结束时间：%@",startTime,endTime);
            FilterItem *item =[weakSelf.filterItems lastObject];
            item.startTime=startTime;
            item.endTime=endTime;
            if (![NSString stringIsNull:startTime]||![NSString stringIsNull:endTime]) {
                item.name=LocalizationKey(@"自定义");
                item.isCustom=YES;
            }else{
                
                item.name=LocalizationKey(@"筛选日期");
                item.isCustom=NO;
            }
            [weakSelf.collectionView reloadData];
            if (![NSString stringIsNull:startTime]) {
                [weakSelf.otherDic setValue:[NSString stringWithFormat:@"%@ %@",[weakSelf convertDateString:startTime],@"00:00:00"] forKey:@"createTimeStart"];
            }else{
                [weakSelf.otherDic setValue:@"" forKey:@"createTimeStart"];
            }
            if (![NSString stringIsNull:endTime]) {
                [weakSelf.otherDic setValue:[NSString stringWithFormat:@"%@ %@",[weakSelf convertDateString:endTime],@"23:59:59"] forKey:@"createTimeEnd"];
            }else{
                [weakSelf.otherDic setValue:@"" forKey:@"createTimeEnd"];
                
            }
            [weakSelf.tableView.mj_footer resetNoMoreData];
            self->_pageNO=1;
            [weakSelf getDataWithFirst:NO];

            
        };
        
    }
    
    
}



#pragma mark -- 获取钱包流水
-(void)getWalletOrderListWithOtherParams:(NSDictionary*)otherDic withFirst:(BOOL)isFirst{
    
    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10)} mutableCopy];
   
    [dic addEntriesFromDictionary:otherDic];
    
    if (!isFirst) {
        [SVProgressHUD customShowWithStyle];
    }
    NSLog(@"当前参数--%@",dic);
    [MineNetWorkManager getOrderRecordListWithParams:dic success:^(id  _Nonnull data) {
        if (!isFirst) {
            [SVProgressHUD dismiss];
        }else{
            [self.tableView tab_endAnimation];//结束动画
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
        }
        
        if ([data[@"code"] intValue]==200) {
            
            if(self->_pageNO==1){
                [self.contentArray removeAllObjects];
            }
            NSArray*onceArray=[OrderRecordModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
            if(onceArray.count>0){
                [self.contentArray addObjectsFromArray:onceArray];
            }
            if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                [self.tableView.mj_footer endRefreshingWithNoMoreData];
            }
            NSLog(@"reload 前数量: %ld", self.contentArray.count);
            [self.tableView reloadData];
            [self configEmptyViewForTableView];
        }else{
          
            [self configEmptyViewForTableView];
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        if (!isFirst) {
            [SVProgressHUD dismiss];
        }else{
            [self.tableView tab_endAnimation];//结束动画
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
        }
        [self configEmptyViewForTableView];
       
    }];
    
}


#pragma mark -- 获取卡片流水
-(void)getCardListWithOtherParams:(NSDictionary*)otherDic withFirst:(BOOL)isFirst{
    
    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10)} mutableCopy];
    [dic setValue:self.cardId forKey:@"cardId"];//卡片流水
    [dic addEntriesFromDictionary:otherDic];
    
    if (!isFirst) {
        [SVProgressHUD customShowWithStyle];
    }
    NSLog(@"当前参数--%@",dic);
    [MineNetWorkManager getCardRecordListWithParams:dic success:^(id  _Nonnull data) {
        
        if (!isFirst) {
            [SVProgressHUD dismiss];
        }else{
            [self.tableView tab_endAnimation];//结束动画
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
        }
        
        if ([data[@"code"] intValue]==200) {
            
            if(self->_pageNO==1){
                [self.contentArray removeAllObjects];
            }
            NSArray*onceArray=[OrderRecordModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
            if(onceArray.count>0){
                [self.contentArray addObjectsFromArray:onceArray];
            }
            if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                [self.tableView.mj_footer endRefreshingWithNoMoreData];
            }
            NSLog(@"reload 前数量: %ld", self.contentArray.count);
            [self.tableView reloadData];
            [self configEmptyViewForTableView];
        }else{
          
            [self configEmptyViewForTableView];
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        if (!isFirst) {
            [SVProgressHUD dismiss];
        }else{
            [self.tableView tab_endAnimation];//结束动画
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
        }
        [self configEmptyViewForTableView];
       
    }];
    
}






-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"当前行数--%lu",(unsigned long)self.contentArray.count);
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    OrderRecordModel*model=self.contentArray[indexPath.row];
    
    if (self.type==0) {
        //钱包流水
        if ([model.type isEqualToString:@"create_card"]||[model.type isEqualToString:@"deposit_card"]||[model.type isEqualToString:@"withdraw_card"]||[model.type isEqualToString:@"program_fee_card"]) {
            //卡申请，卡充值，卡提现，卡手续费 展示卡号
            AccountOtherCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AccountOtherCell"];
            [cell configDataWithModel:self.contentArray[indexPath.row] withType:0];
            return cell;
            
        }else{
            AccountRecordCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AccountRecordCell"];
            [cell configDataWithModel:self.contentArray[indexPath.row] withType:0];
            return cell;
        }
    }else{
        //卡流水
        AccountOtherCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AccountOtherCell"];
        [cell configDataWithModel:self.contentArray[indexPath.row] withType:1];
        return cell;
        
    }
    
   
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
 
    if (self.type==0) {
        //钱包流水
        OrderRecordModel*model=self.contentArray[indexPath.row];
        if ([model.type isEqualToString:@"create_card"]||[model.type isEqualToString:@"deposit_card"]||[model.type isEqualToString:@"withdraw_card"]||[model.type isEqualToString:@"program_fee_card"]) {
            return 106;
        }
        
        return 88;
        
    }else{
        //卡片流水
        return 106;
    }
  
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
 
    TransactionDetailController*detailVC=[[TransactionDetailController alloc]init];
    detailVC.orderModel=self.contentArray[indexPath.row];
    detailVC.type=self.type;
    [self.navigationController pushViewController:detailVC animated:YES];
   
}
//MARK: 上拉加载更多
- (void)refreshFooterAction{
    _pageNO+=1;
    [self getDataWithFirst:NO];

}
//MARK: 下拉刷新
- (void)refreshHeaderAction{
    _pageNO=1;
    [self.tableView.mj_footer resetNoMoreData];
    [self getDataWithFirst:NO];

}

//把2028.07.10这种时间字符串改成2028-07-10
- (NSString *)convertDateString:(NSString *)dateString {
    return [dateString stringByReplacingOccurrencesOfString:@"." withString:@"-"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
