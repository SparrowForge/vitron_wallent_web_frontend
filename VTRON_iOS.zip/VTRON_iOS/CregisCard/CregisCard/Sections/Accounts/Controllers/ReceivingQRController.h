//
//  ReceivingQRController.h
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ReceivingQRController : BaseViewController

@end

NS_ASSUME_NONNULL_END
