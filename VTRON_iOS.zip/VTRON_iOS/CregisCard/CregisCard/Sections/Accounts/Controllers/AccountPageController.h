//
//  AccountPageController.h
//  CregisCard
//
//  Created by 孙良 on 2024/11/14.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AccountPageController : UIViewController

@end

NS_ASSUME_NONNULL_END
