//
//  WithdrawController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "WithdrawController.h"
#import "WithdrawApplyView.h"
#import "AccountNetWorkManager.h"
#import "YCMenuView.h"
#import "WithdrawTipsView.h"
#import "WithdrawFootView.h"



@interface WithdrawController ()
@property(nonatomic,strong) WithdrawApplyView*withdrawView;
@property(nonatomic,strong)NSDictionary*configDic;
@property(nonatomic,strong) WithdrawTipsView *tipsView;
@property(nonatomic,strong) WithdrawFootView *footView;

@end

@implementation WithdrawController

- (WithdrawTipsView *)tipsView {
    if(!_tipsView) {
        _tipsView=[WithdrawTipsView instanceViewWithFrame:CGRectMake(0, 0, kWindowW-40, 150)];
    }
    return _tipsView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"提币");
    [self RightsetupNavgationItemWithImage:UIIMAGE(@"wenhao_account") withColor:[UIColor blackColor]];
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];/**https://www.jianshu.com/p/8b3b3aeb2430**/
    
    self.footView=[WithdrawFootView instanceViewWithFrame:CGRectMake(0, kWindowH-200-HOME_INDICATOR_HEIGHT, kWindowW, 200)];
    WEAKSELF
    [self.footView.okBtn dn_addActionHandler:^{
        [weakSelf.withdrawView toSubmit];//提交提币请求
    }];
    [self.view addSubview:self.footView];
    
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIScrollView*scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT-200)];
            [self.view addSubview:scrollView];
        scrollView.contentSize=CGSizeMake(kWindowW, 600);
        self.withdrawView=[WithdrawApplyView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 600)];
        
        self.withdrawView.withdrawBlock = ^(NSString * _Nullable feeString, NSString * _Nullable estimateString) {
            weakSelf.footView.feeLabel.text=feeString;
            weakSelf.footView.estimateLabel.text=estimateString;
        };
        self.withdrawView.btnColorBlock = ^(int status) {
            if (status==0) {
                //不可点击
                weakSelf.footView.okBtn.enabled=NO;
                [weakSelf.footView.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
                weakSelf.footView.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
            }else{
                //可以点击
                weakSelf.footView.okBtn.enabled=YES;
                weakSelf.footView.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                [weakSelf.footView.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }
            
        };
        [scrollView addSubview:self.withdrawView];
        [self getWithdrawConfig];
    });
   
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
   // self.navigationController.navigationBar.prefersLargeTitles = YES;
  //  self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAlways;
}

-(void)rightTouchEvent{
    
    self.tipsView.rateLabel.text=[NSString stringWithFormat:@"%@%%",self.configDic[@"ratio"]];
    [self.tipsView show];
    return;
    NSString*tips=[NSString stringWithFormat:LocalizationKey(@"提币手续费率"),self.configDic[@"ratio"]];
    YCMenuAction*action = [YCMenuAction actionWithTitle:tips image:nil handler:^(YCMenuAction *action) {
        
           }];
        NSMutableArray * array =  [NSMutableArray array];
        [array addObject:action];
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?100:80;
        YCMenuView*menuView = [YCMenuView menuWithActions:array width:230 relyonView:self.navigationItem.rightBarButtonItem];
        menuView.menuColor=[UIColor whiteColor];
        menuView.menuCellHeight=height;
        menuView.showType=2;
        menuView.textColor=[UIColor blackColor];
        menuView.maxDisplayCount =4;
        [menuView show];
    
}

//MARK: 获取提现页面数据
-(void)getWithdrawConfig{
    
    [SVProgressHUD customShowWithStyle];
    [AccountNetWorkManager getWithdrawConfigsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            self.configDic=data[@"data"];
            self.withdrawView.configDic=self.configDic;
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
           }
            
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
     }];
}



-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
   // self.navigationController.navigationBar.prefersLargeTitles =NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
