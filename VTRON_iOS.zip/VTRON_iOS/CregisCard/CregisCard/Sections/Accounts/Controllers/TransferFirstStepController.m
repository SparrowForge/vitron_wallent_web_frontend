//
//  TransferFirstStepController.m
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "TransferFirstStepController.h"
#import "MMScanViewController.h"
#import "TransferController.h"
#import "HomeCardNetWorkManager.h"


@interface TransferFirstStepController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

@implementation TransferFirstStepController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"转账");
    [self.okBtn setTitle:LocalizationKey(@"下一步") forState:UIControlStateNormal];
    self.titleLabel.text=LocalizationKey(@"收款账户");
    [self setBorderView:self.accountView];
    [self RightsetupNavgationItemWithImage:UIIMAGE(@"scanIcon") withColor:[UIColor blackColor]];
    self.accountTF.delegate=self;
    [self.accountTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.titleLabel.font=PingFangMediumFont(13);
    [self.accountTF setStyleWithPlaceholder:LocalizationKey(@"请输入邮箱")];
#if DEBUG == 1
    self.accountTF.text = @"pro_great@126.com";
#endif
    // Do any additional setup after loading the view from its nib.
}

//MARK: 扫描二维码
- (void)rightTouchEvent {
    WEAKSELF
    MMScanViewController *scanVC = [[MMScanViewController alloc] initWithQrType:MMScanTypeQrCode onFinish:^(NSString *result, NSError *error) {
        if (error) {
        } else {
            //转账
            if ([result isEqualToString:[UserWrapper shareUserInfo].email]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"不能向自己账户转账"));
                return;
            }
            TransferController*transferVC=[[TransferController alloc]init];
            transferVC.defalutAccount=result;
            [weakSelf.navigationController pushViewController:transferVC animated:YES];
        }
    }];
    scanVC.popType = 1;
    scanVC.isPhoto = NO;//不隐藏相册
    scanVC.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:scanVC animated:YES];
   
}
//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField{
    [self judgeCorrectEmail:[ToolUtil matchEmail:textField.text]];
    
}

//限制只能输入6位数字
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // 获取当前文本框的文本
    NSString *currentText = textField.text;
    
    // 计算替换后的文本
    NSString *updatedText = [currentText stringByReplacingCharactersInRange:range withString:string];
    // 检查文本长度是否超过最大字符
    if (updatedText.length > 50) {
        return NO; // 返回NO，表示不允许输入
    } else {
        return YES; // 返回YES，表示允许输入
    }
}

//判断电子邮件是否正确
-(void)judgeCorrectEmail:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }else{
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    }
   
}

//下一步
- (IBAction)nextClick:(id)sender {
   
    if ([NSString stringIsNull:self.accountTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
        return;
    }
    
    if ([self.accountTF.text isEqualToString:[UserWrapper shareUserInfo].email]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"不能向自己账户转账"));
        return;
    }
    [self checkMerchant];
    
}


//转账之前先校验邮箱
-(void)checkMerchant{
    
    [SVProgressHUD customShowWithStyle];
    [HomeCardNetWorkManager checkMerchantForTransferparams:@{@"email":self.accountTF.text
    }success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];

        if ([data[@"code"] intValue]==200) {
            TransferController*transferVC=[[TransferController alloc]init];
            transferVC.defalutAccount=self.accountTF.text;
            [self.navigationController pushViewController:transferVC animated:YES];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
       [SVProgressHUD dismiss];
    }];
    
    
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
