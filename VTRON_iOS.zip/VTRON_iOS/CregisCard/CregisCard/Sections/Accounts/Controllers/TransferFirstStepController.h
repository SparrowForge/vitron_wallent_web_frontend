//
//  TransferFirstStepController.h
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TransferFirstStepController : BaseViewController
@property (weak, nonatomic) IBOutlet UIView *accountView;

@end

NS_ASSUME_NONNULL_END
