//
//  TransferController.m
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "TransferController.h"
#import "TransferView.h"
@interface TransferController ()
@property(nonatomic,strong) TransferView*transferView;
@end

@implementation TransferController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"转账");
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];/**https://www.jianshu.com/p/8b3b3aeb2430**/
    self.view.backgroundColor=[UIColor whiteColor];
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        UIScrollView*scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT)];
            [self.view addSubview:scrollView];
        scrollView.contentSize=CGSizeMake(kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT);
        scrollView.backgroundColor=[UIColor whiteColor];
        self.transferView=[TransferView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT)];
        self.transferView.backgroundColor=[UIColor whiteColor];
        [scrollView addSubview:self.transferView];
        if (![NSString stringIsNull:self.defalutAccount]) {
            self.transferView.accountTF.text=self.defalutAccount;//,扫码进来的，默认填充邮箱账户
        }
        
    });
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
  //  self.navigationController.navigationBar.prefersLargeTitles = YES;
    //self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;

}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
