//
//  OperationVerifyController.h
//  CregisCard
//
//  Created by 孙良 on 2024/11/5.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

typedef void(^NextOperateBlock)(int pushType);
NS_ASSUME_NONNULL_BEGIN

@interface OperationVerifyController : BaseViewController

@property(nonatomic,assign)int type;//0 提币验证 1 转账验证 2 申请卡验证
@property (nonatomic, copy) NextOperateBlock nextOperateBlock;
@end

NS_ASSUME_NONNULL_END
