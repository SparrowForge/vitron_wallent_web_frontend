//
//  CoinRechargeController.m
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CoinRechargeController.h"
#import "RechargeView.h"
#import "AccountNetWorkManager.h"
#import "CoinModel.h"
#import "NSObject+UBTrackerModel.h"

@interface CoinRechargeController ()
@property(nonatomic,strong) RechargeView*rechargeView;
@end

@implementation CoinRechargeController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"充值");
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIScrollView*scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT)];
            [self.view addSubview:scrollView];
        scrollView.contentSize=CGSizeMake(kWindowW, 800);
        self.rechargeView=[RechargeView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 800)];
        [scrollView addSubview:self.rechargeView];
        [self getRechargeConfigData];
    });
   
    // Do any additional setup after loading the view.
}

//MARK: 获取充值页面数据
-(void)getRechargeConfigData{
    
    [SVProgressHUD customShowWithStyle];
    [AccountNetWorkManager getRechargeConfigsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*coinsArray=[CoinModel utr_modelsWithKeyValues:data[@"data"]];
            if (coinsArray.count<=0) {
                return;
            }
            [self.rechargeView configDataWithArray:coinsArray];
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
            
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
     }];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
