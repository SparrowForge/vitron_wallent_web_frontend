//
//  TransactionDetailController.h
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"
#import "OrderRecordModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface TransactionDetailController : BaseViewController
@property(nonatomic,strong) OrderRecordModel*orderModel;
@property (nonatomic, assign) NSInteger type;//0钱包流水  1卡片流水

@end

NS_ASSUME_NONNULL_END
