//
//  ReceivingQRController.m
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "ReceivingQRController.h"
#import "ReceivingQRView.h"
#import "AccountNetWorkManager.h"

@interface ReceivingQRController ()
@property(nonatomic,strong) ReceivingQRView*QRView;
@property(nonatomic,strong) UIButton*okBtn;
@end

@implementation ReceivingQRController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"收款");
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    CGSize maxSize = CGSizeMake(kWindowW-48, CGFLOAT_MAX);
    CGRect textRect = [LocalizationKey(@"扫描上方的二维码收款") boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin
                                                 attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:15]}
                                                    context:nil];
    CGFloat footViewHeight=ceil(textRect.size.height)+20+16+50+20;
    [self createFootViewwithFootViewHeight:footViewHeight withTextHeight:ceil(textRect.size.height)];
    UIScrollView*scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT-footViewHeight)];
        [self.view addSubview:scrollView];
    scrollView.contentSize=CGSizeMake(kWindowW, 600);
    self.QRView=[ReceivingQRView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 600)];
    [scrollView addSubview:self.QRView];
    [self getQRCodeData];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    //self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
}


-(void)createFootViewwithFootViewHeight:(CGFloat)footViewHeight withTextHeight:(CGFloat)textHeight{

    UIView*footView=[[UIView alloc]initWithFrame:CGRectMake(0, kWindowH-HOME_INDICATOR_HEIGHT-footViewHeight, kWindowW, footViewHeight)];
    [self.view addSubview:footView];
    UILabel *tipsLabel = [[UILabel alloc]initWithFrame:CGRectMake(24, 20, kWindowW-48, 0)];
    tipsLabel.numberOfLines = 0;
    tipsLabel.textAlignment = NSTextAlignmentCenter;
    tipsLabel.text = LocalizationKey(@"扫描上方的二维码收款");
    tipsLabel.textColor = [UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    tipsLabel.font = [UIFont systemFontOfSize:15];
    // 计算高度
    CGRect frame = tipsLabel.frame;
    frame.size.height = textHeight;
    tipsLabel.frame = frame;
    [footView addSubview:tipsLabel];
    self.okBtn=[[UIButton alloc]initWithFrame:CGRectMake(24,CGRectGetMaxY(tipsLabel.frame)+16, kWindowW-48, 50)];
    [self.okBtn setCornerRadius:25];
    [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor mainBtnColor];
    [self.okBtn setTitle:LocalizationKey(@"保存图片") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    WEAKSELF
    [self.okBtn dn_addActionHandler:^{
        [weakSelf.QRView toSaveImage];
    }];
    [footView addSubview:self.okBtn];
    
}
//获取收款二维码数据
-(void)getQRCodeData{
    [SVProgressHUD customShowWithStyle];
    [AccountNetWorkManager getERcodesuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            [self.QRView configDataWithQRCodeString:data[@"data"]];
         
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
        }];
   
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
