//
//  WithdrawFootView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/16.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "WithdrawFootView.h"

@implementation WithdrawFootView

+ (WithdrawFootView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"WithdrawFootView" owner:nil options:nil];
    WithdrawFootView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    return view;
}


-(void)awakeFromNib{
    [super awakeFromNib];
    self.feeTitle.font=PingFangMediumFont(13);
    self.arrivalTitle.font=PingFangMediumFont(13);
    self.estimateLabel.font=PingFangMediumFont(17);
    self.unitLabel.font=PingFangMediumFont(17);
    self.feeLabel.font=PingFangMediumFont(15);
    self.feeTitle.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    self.arrivalTitle.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self.okBtn setTitle:LocalizationKey(@"提币") forState:UIControlStateNormal];
    self.feeTitle.text=LocalizationKey(@"手续费");
    self.arrivalTitle.text=LocalizationKey(@"到账金额");
}


@end
