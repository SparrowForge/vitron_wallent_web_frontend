//
//  RechargeView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "RechargeView.h"
#import "CoinModel.h"
#import "AccountNetWorkManager.h"
#import "SelectMenuView.h"

@interface RechargeView()
@property (weak, nonatomic) IBOutlet UILabel *coinNameLabel;
@property (weak, nonatomic) IBOutlet UIView *noAddressView;
@property (weak, nonatomic) IBOutlet UILabel *noAddressTips;
@property (weak, nonatomic) IBOutlet UIImageView *qrCodeImageV;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UIView *addressView;
@property (weak, nonatomic) IBOutlet UIView *rateView;
@property (weak, nonatomic) IBOutlet UILabel *rateTitle;
@property (weak, nonatomic) IBOutlet UILabel *rateContentLabel;
@property (weak, nonatomic) IBOutlet UILabel *rechargeRateTitle;
@property (weak, nonatomic) IBOutlet UILabel *rechargeRateContentLabel;
@property (weak, nonatomic) IBOutlet UIView *tipsView;
@property(nonatomic,strong) CoinModel*defalutCoin;
@property(nonatomic,strong) NSArray*coinsArray;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel1;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel2;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIView *qrView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;

@property(nonatomic,strong) NSDictionary*currentCoinDic;
@property(nonatomic,strong) SelectMenuView*selectView;
@end


@implementation RechargeView


-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 180+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectNet];
    }
    return _selectView;
}
+ (RechargeView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"RechargeView" owner:nil options:nil];
    RechargeView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.backgroundColor=[UIColor whiteColor];
    [view setUpUI];
    return view;
}


-(void)setUpUI{
    self.coinNameLabel.font=PingFangMediumFont(17);
    self.addressLabel.font=PingFangMediumFont(15);
    self.rateContentLabel.font=PingFangMediumFont(15);
    self.rechargeRateContentLabel.font=PingFangMediumFont(15);
    self.rateTitle.text=LocalizationKey(@"汇率");
    self.rechargeRateTitle.text=LocalizationKey(@"充值费率");
    self.rateTitle.font=PingFangMediumFont(15);
    self.rechargeRateTitle.font=PingFangMediumFont(15);
    [self.addressView setCornerRadius:12.0];
    [self.rateView setCornerRadius:12.0];
    self.rateView.layer.borderWidth=0.33;
    self.rateView.layer.borderColor=[UIColor colorWithHexString:@"000000" alpha:0.2].CGColor;
    [self.qrView setCornerRadius:12.0];
    self.qrView.layer.borderWidth=0.33;
    self.qrView.layer.borderColor=[UIColor colorWithHexString:@"000000" alpha:0.2].CGColor;
    self.tipsLabel1.text=LocalizationKey(@"此地址只接收对应网络的USDT充值；");
    self.tipsLabel2.text=LocalizationKey(@"请不要向此地址充值除USDT以外的任何资产；");
    self.noAddressTips.text=LocalizationKey(@"请重新获取地址信息");
    [self.okBtn setTitle:LocalizationKey(@"获取地址") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.topDistance.constant=kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT-70;
}

//初始化数据
-(void)configDataWithArray:(NSArray*)coinArray{
    self.coinsArray=coinArray;
    [coinArray enumerateObjectsUsingBlock:^(CoinModel* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.name isEqualToString:@"USDT-TRC20"]) {
            self.defalutCoin=obj;
            *stop=YES;
        }
    }];
    if (!self.defalutCoin) {
        self.defalutCoin=[coinArray objectAtIndex:0];
    }
    self.coinNameLabel.text=self.defalutCoin.name;
    [self setQRcodeWithAddress:self.defalutCoin.address];//先填充一下，后面再更新，防止显示太慢
    [self judgeCoinAddressWithchainId:self.defalutCoin.chainId withFirst:YES];
    [ self.coinsArray enumerateObjectsUsingBlock:^(CoinModel* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary*dic=@{obj.name:obj.ID};
        [self.contentArray addObject:dic];
    }];
    
    self.currentCoinDic=@{self.defalutCoin.name:self.defalutCoin.ID};
    
}

- (IBAction)okClick:(UIButton *)sender {
    
    if (sender.tag==0) {
        //复制地址
        if (![NSString stringIsNull:self.defalutCoin.address]) {
            UIPasteboard *pboard = [UIPasteboard generalPasteboard];
            pboard.string = self.defalutCoin.address;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
        }
        
    }
    else if (sender.tag==1) {
        //重新获取地址
        [self getAddress];
        
    }
    else{
        //切换币种
        if (self.contentArray.count<=0) {
            return;
        }
      
        self.selectView.currentDic=self.currentCoinDic;
        [self.selectView show];
        [self.selectView reloadDataWithArray:self.contentArray];
        WEAKSELF
        self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
            NSString*key= [[dic allKeys] objectAtIndex:0];
            weakSelf.coinNameLabel.text=key;
            [weakSelf getDefalutCoinwithcoinId:dic[key]];
            [weakSelf judgeCoinAddressWithchainId:weakSelf.defalutCoin.chainId withFirst:NO];
            weakSelf.currentCoinDic=dic;
        };
        
    }
    
}


//根据字符串生成二维码
-(void)setQRcodeWithAddress:(NSString*)address{
    
    NSString*coinIcon=@"ErcIcon";
    if ([self.defalutCoin.name isEqualToString:@"USDT-TRC20"]) {
        coinIcon=@"TrcIcon";
    }
    
    if (![NSString stringIsNull:address]) {
        self.qrCodeImageV.image=[self logolOrQRImage2:address logolImage:coinIcon];
        self.addressLabel.text=address;
        self.rechargeRateContentLabel.text=[NSString stringWithFormat:@"%@%%",self.defalutCoin.convertFeeRate];
        self.qrCodeImageV.hidden=NO;
        self.noAddressView.hidden=YES;
        self.addressView.hidden=NO;
        self.rateView.hidden=NO;
        self.tipsView.hidden=NO;
        self.okBtn.hidden=YES;

    }else{
        self.qrCodeImageV.hidden=YES;
        self.noAddressView.hidden=NO;
        self.addressView.hidden=YES;
        self.rateView.hidden=YES;
        self.tipsView.hidden=YES;
        self.okBtn.hidden=NO;
        self.addressLabel.text=@"";

    }
   
}


//MARK: 中间logo带有圆角
- (UIImage *)logolOrQRImage2:(NSString *)QRTargetString logolImage:(NSString *)logolImage{
    
    // 滤镜数组
    NSArray *filters = [CIFilter filterNamesInCategory:kCICategoryBuiltIn];
    NSLog(@"%@", filters);
    
    // 二维码过滤器
    CIFilter *qrImageFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 设置过滤器默认属性
    [qrImageFilter setDefaults];
    
    // 将字符串转换成 NSData
    NSData *qrImageData = [QRTargetString dataUsingEncoding:NSUTF8StringEncoding];
    
    // 设置过滤器的输入值
    [qrImageFilter setValue:qrImageData forKey:@"inputMessage"];
    
    // 取出图片
    CIImage *qrImage = [qrImageFilter outputImage];
    qrImage = [qrImage imageByApplyingTransform:CGAffineTransformMakeScale(20, 20)]; // 放大二维码
    
    // 转成 UIImage 类型
    UIImage *qrUIImage = [UIImage imageWithCIImage:qrImage];
    
    //----------------给二维码中间增加一个自定义图片----------------
    // 开启绘图，获取图形上下文（上下文的大小，就是二维码的大小）
    UIGraphicsBeginImageContext(qrUIImage.size);
    
    // 把二维码图片画上去（这里是以图形上下文，左上角为(0,0)点）
    [qrUIImage drawInRect:CGRectMake(0, 0, qrUIImage.size.width, qrUIImage.size.height)];
    
    // 加载 logo 图片
    UIImage *logoImage = [UIImage imageNamed:logolImage];
    
    // 计算 logo 图片的大小，取二维码的 1/5 大小
    CGFloat logoWidth = qrUIImage.size.width / 5;
    CGFloat logoHeight = qrUIImage.size.height / 5;
    
    // 设置 logo 图片的位置和大小
    CGRect logoRect = CGRectMake((qrUIImage.size.width - logoWidth) / 2, (qrUIImage.size.height - logoHeight) / 2, logoWidth, logoHeight);
    
    // 创建带有圆角的 logo 图片
    UIGraphicsBeginImageContextWithOptions(logoRect.size, NO, logoImage.scale);
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, logoRect.size.width, logoRect.size.height) cornerRadius:20.0]; // 圆角半径为20
    [path addClip];
    [logoImage drawInRect:CGRectMake(0, 0, logoRect.size.width, logoRect.size.height)];
    UIImage *roundedLogoImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // 在二维码上绘制 logo 图片
    [roundedLogoImage drawInRect:logoRect blendMode:kCGBlendModeNormal alpha:1.0];
    
    // 获取当前画得的这张图片
    UIImage *finalImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // 关闭图形上下文
    UIGraphicsEndImageContext();
   
    // 设置图片
    return finalImage;
}



//MARK: 校验币种地址
-(void)judgeCoinAddressWithchainId:(NSString*)chainId withFirst:(BOOL)isFirst{
    if (!isFirst) {
        [SVProgressHUD customShowWithStyle];
    }
   
    [AccountNetWorkManager judgeAddressWithParams:@{@"chainId":chainId} success:^(id  _Nonnull data) {
        if (!isFirst) {
            [SVProgressHUD dismiss];
        }
        if ([data[@"code"] intValue]==200) {
           [self setQRcodeWithAddress:data[@"data"][@"address"]];
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        } fail:^(NSError * _Nonnull error) {
            if (!isFirst) {
                [SVProgressHUD dismiss];
            }
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
    
}

//获取地址
-(void)getAddress{
    
    [SVProgressHUD customShowWithStyle];
    [AccountNetWorkManager resetAddressWithParams:self.defalutCoin.ID success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            if (![NSString stringIsNull:data[@"data"]]) {
                self.defalutCoin.address=data[@"data"];
                [self setQRcodeWithAddress:data[@"data"]];
              
                
            }
            
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
            
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
    
    
}


-(void)getDefalutCoinwithcoinId:(NSString*)coinId{
    [self.coinsArray enumerateObjectsUsingBlock:^(CoinModel* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.ID intValue]==[coinId intValue]) {
            self.defalutCoin=obj;
            *stop=YES;
        }
    }];
}




@end
