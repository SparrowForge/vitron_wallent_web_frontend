//
//  AccountTopView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "AccountTopView.h"
#import "InviteController.h"


@implementation AccountTopView

+ (AccountTopView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"AccountTopView" owner:nil options:nil];
    AccountTopView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    [view.boardView setCornerRadius:10.0];
    view.isFirst=YES;
    [view.totalAmountLabel setLastTargetNumberString:@"0.00"];
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    NSString*imageName=[NSString stringWithFormat:@"invitePage_%@",[ChangeLanguage userLanguage]];
    self.inviteIcon.image=UIIMAGE(imageName);
    self.totalTitle.text=LocalizationKey(@"总资产");
    self.rechargeTitle.text=LocalizationKey(@"充值");
    self.withdrawTitle.text=LocalizationKey(@"提币");
    self.tansferTitle.text=LocalizationKey(@"转账");
    self.receiveTitle.text=LocalizationKey(@"收款");
    self.totalTitle.font= RegularFont(17);
    self.rechargeTitle.font= PingFangMediumFont(13);
    self.withdrawTitle.font= PingFangMediumFont(13);
    self.tansferTitle.font= PingFangMediumFont(13);
    self.receiveTitle.font= PingFangMediumFont(13);
    self.useAbleLabel.font= PingFangMediumFont(13);
    self.frozenAmountLabel.font= PingFangMediumFont(13);
    self.useAbleLabel.text=[NSString stringWithFormat:@"%@：$%@",LocalizationKey(@"可用"),@"****"];
    self.frozenAmountLabel.text=[NSString stringWithFormat:@"%@：$%@",LocalizationKey(@"冻结"),@"****"];
   
}


-(void)setDataDic:(NSDictionary *)dataDic{
    _dataDic=dataDic;
    if ([UBTNSUserDefaultUtil GetBoolDefaults:HIDDENACCOUNT]) {
        self.eyeBtn.selected=NO;
        [self hiddenAccountMoney];
    }else{
        self.eyeBtn.selected=YES;
        [self showAccountMoney];
    }
}

//隐藏或显示账户余额
- (IBAction)eyeClick:(UIButton *)sender {
    sender.selected=!sender.selected;
    if (sender.selected) {
        [self showAccountMoney];
    }else{
        [self hiddenAccountMoney];
    }
    [UBTNSUserDefaultUtil PutBoolDefaults:HIDDENACCOUNT Value:!sender.selected];
}

//MARK: 显示账户余额
-(void)showAccountMoney{
    //全部先折合成USDT，最后再折合成USD
    __block double totalUSDT=0;
    __block double useAbleUSDT=0;
    __block double frozenUSDT=0;
    NSArray*coinsarray=self.dataDic[@"data"];
    [coinsarray enumerateObjectsUsingBlock:^(NSDictionary*obj, NSUInteger idx, BOOL * _Nonnull stop) {
        double total=[obj[@"amount"] doubleValue]+[obj[@"frozenAmount"] doubleValue];
        double totalAble=[obj[@"amount"] doubleValue];
        double totalfrozen=[obj[@"frozenAmount"] doubleValue];
        NSString*rate;
        if ([obj[@"currency"] isEqualToString:@"USDT"]||[obj[@"currency"] isEqualToString:@"USD"]) {
           rate=@"1";
        }else{
            rate=[self getRateWithCurrentCoin:obj[@"currency"]];
        }

        totalUSDT+=total/[rate doubleValue];
        useAbleUSDT+=totalAble/[rate doubleValue];
        frozenUSDT+=totalfrozen/[rate doubleValue];
    }];

    NSString*totalNum=[NSString formattedStringWithDouble:totalUSDT*[[self getRateWithCurrentCoin:@"USD"] doubleValue]];
   
    
    if (self.isFirst) {
        self.totalAmountLabel.text = @"$0.00";
        [self.totalAmountLabel rollToNumberWithString:totalNum];
        self.isFirst=NO;
    }else{
      [self.totalAmountLabel setLastTargetNumberString:totalNum];
      
    }

    self.useAbleLabel.text=[NSString stringWithFormat:@"%@：$%@",LocalizationKey(@"可用"),[NSString formattedStringWithDouble:useAbleUSDT*[[self getRateWithCurrentCoin:@"USD"] doubleValue]]];
    self.frozenAmountLabel.text=[NSString stringWithFormat:@"%@：$%@",LocalizationKey(@"冻结"),[NSString formattedStringWithDouble:frozenUSDT*[[self getRateWithCurrentCoin:@"USD"] doubleValue]]];
}

//MARK: 隐藏账户余额
-(void)hiddenAccountMoney{
    
    self.totalAmountLabel.text=@"****";
    self.useAbleLabel.text=[NSString stringWithFormat:@"%@：$%@",LocalizationKey(@"可用"),@"****"];
    self.frozenAmountLabel.text=[NSString stringWithFormat:@"%@：$%@",LocalizationKey(@"冻结"),@"****"];
}


//获取USDT与某币种的汇率,例如USDT:HKD
-(NSString*)getRateWithCurrentCoin:(NSString*)currency{
    if (![CommonInfoManager sharedInstance].rateDic) {
        return @"1";
    }
    NSString*rate=[[CommonInfoManager sharedInstance].rateDic objectForKey:currency];
    
    return rate;
}


//分销商，邀请好友
- (IBAction)inviteClick:(id)sender {
    
 
}




@end
