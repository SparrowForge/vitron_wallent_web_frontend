//
//  ReceivingQRView.m
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "ReceivingQRView.h"
#import "UIImage+UBTrackerImgSize.h"

@implementation ReceivingQRView


+ (ReceivingQRView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ReceivingQRView" owner:nil options:nil];
    ReceivingQRView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    return view;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.ercodeBackView setCornerRadius:24];
    //四边添加阴影
    self.ercodeBackView.layer.shadowColor = [UIColor grayColor].CGColor;//阴影颜色
    self.ercodeBackView.layer.shadowOffset = CGSizeMake(0, 0);//阴影的偏移量
    self.ercodeBackView.layer.shadowOpacity = 0.2;//阴影透明度
    self.ercodeBackView.layer.shadowRadius = 10.0;//阴影圆角
    self.ercodeBackView.clipsToBounds=NO;//这个属性为NO是必须的，不然阴影不会显示
    self.nameLabel.text=[NSString stringWithFormat:@"%@(ID)",[UserWrapper shareUserInfo].ID];
    self.emailLabel.text=[UserWrapper shareUserInfo].email;
    [self.headImageV UBTracker_yy_setImageWithURL:[NSURL URLWithString:[[UserWrapper shareUserInfo].headUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]] placeholder:UIIMAGE(@"noImage")];
    self.scanTitle.text=LocalizationKey(@"扫描上方的二维码收款");
    [self.okBtn setTitle:LocalizationKey(@"保存图片") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.emailLabel.font=PingFangMediumFont(15);
    // Initialization code
}

-(void)configDataWithQRCodeString:(NSString*)QRString{
    
 self.QRImageV.image=[self logolOrQRImage2:[NSString stringWithFormat:@"%@",QRString] logolImage:@"mainAppIcon"];
    
    
}
//保存收款码到相册
- (IBAction)saveClick:(id)sender {
    
    [self toSaveImage];
    
}

-(void)toSaveImage{
    
    // 设置绘制图片的大小
    UIGraphicsBeginImageContextWithOptions(self.ercodeBackView.bounds.size, NO, 0.0);
    // 绘制图片
    [self.ercodeBackView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    // 保存图片到相册   如果需要获取保存成功的事件第二和第三个参数需要设置响应对象和方法，该方法为固定格式。
    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
    
    
}


- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error) {
        // 保存失败
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"保存失败"));
    } else {
        // 保存成功
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"保存成功"));
    }
}

//二维码生成 实质:  把字符串转变为 图片
// 需要 coreImage框架, 已经包含在了 UIKit框架里面
//MARK: 二维码中间内置图片,可以是公司logo
- (UIImage *)logolOrQRImage:(NSString *)QRTargetString logolImage:(NSString *)logolImage{
    
    //滤镜数组
    NSArray *filters = [CIFilter filterNamesInCategory:kCICategoryBuiltIn];
    NSLog(@"%@",filters);
    //二维码过滤器
    CIFilter *qrImageFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    //设置过滤器默认属性
    [qrImageFilter setDefaults];
    //将字符串转换成 NSdata (虽然二维码本质上是 字符串,但是这里需要转换,不转换就崩溃)
    //字符串可以随意换成网址等
    NSData *qrImageData = [QRTargetString dataUsingEncoding:NSUTF8StringEncoding];
    //我们可以打印,看过滤器的 输入属性.这样我们才知道给谁赋值
    NSLog(@"%@",qrImageFilter.inputKeys);
    //设置过滤器的 输入值  ,KVC赋值
    [qrImageFilter setValue:qrImageData forKey:@"inputMessage"];
    //取出图片
    CIImage *qrImage = [qrImageFilter outputImage];
    //但是图片 发现有的小 (27,27),我们需要放大..我们进去CIImage 内部看属性
    qrImage = [qrImage imageByApplyingTransform:CGAffineTransformMakeScale(20, 20)];
    //转成 UI的 类型
    UIImage *qrUIImage = [UIImage imageWithCIImage:qrImage];
    //----------------给 二维码 中间增加一个 自定义图片----------------
    //开启绘图,获取图形上下文  (上下文的大小,就是二维码的大小)
    UIGraphicsBeginImageContext(qrUIImage.size);
    
    //把二维码图片画上去. (这里是以,图形上下文,左上角为 (0,0)点)
    [qrUIImage drawInRect:CGRectMake(0, 0, qrUIImage.size.width, qrUIImage.size.height)];
    //再把小图片画上去
    UIImage *sImage = [UIImage imageNamed:logolImage];
   
    CGFloat sImageW = 80;
    CGFloat sImageH = sImageW;
    CGFloat sImageX = (qrUIImage.size.width - sImageW) * 0.5;
    CGFloat sImgaeY = (qrUIImage.size.height - sImageH) * 0.5;
    [sImage drawInRect:CGRectMake(sImageX, sImgaeY, sImageW, sImageH)];
    //获取当前画得的这张图片
    UIImage *finalyImage = UIGraphicsGetImageFromCurrentImageContext();
    //关闭图形上下文
    UIGraphicsEndImageContext();
   
    //设置图片
    return finalyImage;
}
 
//MARK: 中间logo带有圆角
- (UIImage *)logolOrQRImage2:(NSString *)QRTargetString logolImage:(NSString *)logolImage{
    
    // 滤镜数组
    NSArray *filters = [CIFilter filterNamesInCategory:kCICategoryBuiltIn];
    NSLog(@"%@", filters);
    
    // 二维码过滤器
    CIFilter *qrImageFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 设置过滤器默认属性
    [qrImageFilter setDefaults];
    
    // 将字符串转换成 NSData
    NSData *qrImageData = [QRTargetString dataUsingEncoding:NSUTF8StringEncoding];
    
    // 设置过滤器的输入值
    [qrImageFilter setValue:qrImageData forKey:@"inputMessage"];
    
    // 取出图片
    CIImage *qrImage = [qrImageFilter outputImage];
    qrImage = [qrImage imageByApplyingTransform:CGAffineTransformMakeScale(20, 20)]; // 放大二维码
    
    // 转成 UIImage 类型
    UIImage *qrUIImage = [UIImage imageWithCIImage:qrImage];
    
    //----------------给二维码中间增加一个自定义图片----------------
    // 开启绘图，获取图形上下文（上下文的大小，就是二维码的大小）
    UIGraphicsBeginImageContext(qrUIImage.size);
    
    // 把二维码图片画上去（这里是以图形上下文，左上角为(0,0)点）
    [qrUIImage drawInRect:CGRectMake(0, 0, qrUIImage.size.width, qrUIImage.size.height)];
    
    // 加载 logo 图片
    UIImage *logoImage = [UIImage imageNamed:logolImage];
    
    // 计算 logo 图片的大小，取二维码的 1/5 大小
    CGFloat logoWidth = qrUIImage.size.width / 5;
    CGFloat logoHeight = qrUIImage.size.height / 5;
    
    // 设置 logo 图片的位置和大小
    CGRect logoRect = CGRectMake((qrUIImage.size.width - logoWidth) / 2, (qrUIImage.size.height - logoHeight) / 2, logoWidth, logoHeight);
    
    // 创建带有圆角的 logo 图片
    UIGraphicsBeginImageContextWithOptions(logoRect.size, NO, logoImage.scale);
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, logoRect.size.width, logoRect.size.height) cornerRadius:20.0]; // 圆角半径为20
    [path addClip];
    [logoImage drawInRect:CGRectMake(0, 0, logoRect.size.width, logoRect.size.height)];
    UIImage *roundedLogoImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // 在二维码上绘制 logo 图片
    [roundedLogoImage drawInRect:logoRect blendMode:kCGBlendModeNormal alpha:1.0];
    
    // 获取当前画得的这张图片
    UIImage *finalImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // 关闭图形上下文
    UIGraphicsEndImageContext();
   
    // 设置图片
    return finalImage;
}


@end
