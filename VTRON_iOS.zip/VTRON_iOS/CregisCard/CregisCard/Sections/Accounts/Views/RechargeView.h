//
//  RechargeView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RechargeView : UIView
+ (RechargeView *)instanceViewWithFrame:(CGRect)Rect;
-(void)configDataWithArray:(NSArray*)coinArray;
@end

NS_ASSUME_NONNULL_END
