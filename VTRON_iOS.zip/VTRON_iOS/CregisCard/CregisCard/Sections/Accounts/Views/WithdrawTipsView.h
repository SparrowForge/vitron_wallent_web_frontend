//
//  WithdrawTipsView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface WithdrawTipsView : FWPopupBaseView
+ (WithdrawTipsView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UILabel *rateLabel;
@property (weak, nonatomic) IBOutlet UILabel *coinLabel;

@end

NS_ASSUME_NONNULL_END
