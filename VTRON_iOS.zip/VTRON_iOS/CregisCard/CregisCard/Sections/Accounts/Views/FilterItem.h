//
//  FilterItem.h
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FilterItem : NSObject
@property(nonatomic,copy) NSString*name;
@property(nonatomic,copy) NSString*type;
@property(nonatomic,copy) NSString*status;
@property(nonatomic,assign)int kind;//0类型 1状态 2日期
@property(nonatomic,copy) NSString*startTime;
@property(nonatomic,copy) NSString*endTime;
@property(nonatomic,assign) BOOL isCustom;
@end

NS_ASSUME_NONNULL_END
