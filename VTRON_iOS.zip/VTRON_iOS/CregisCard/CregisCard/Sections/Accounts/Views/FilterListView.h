//
//  FilterListView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"

typedef void(^FilterMenuBlock)(NSString*_Nullable name,NSString*_Nullable kind);

typedef NS_ENUM(NSInteger, FilterMenuType) {
    TypeForWallet,//钱包页面类型
    StatusForWallet,//钱包页面状态
    TypeForCard,//卡页面类型
    StatusForCard,//卡页面状态
    NotificationCenter,//通知中心
    TypeForAllCard,//全部卡片页面类型
    StatusForAllCard,//全部卡片页面状态
    
};
NS_ASSUME_NONNULL_BEGIN

@interface FilterListView : FWPanPopupView

+ (FilterListView *)instanceViewWithFrame:(CGRect)Rect withSelectMenuType:(FilterMenuType)menuType;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, copy)   FilterMenuBlock filterMenuBlock;
@property(nonatomic,strong)   NSDictionary*currentDic;
-(void)reloadTableView;
@end

NS_ASSUME_NONNULL_END
