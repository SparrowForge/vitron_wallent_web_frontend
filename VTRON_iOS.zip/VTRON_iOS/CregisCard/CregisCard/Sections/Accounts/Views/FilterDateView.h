//
//  FilterDateView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"

typedef void(^FilterDateBlock)(NSString*_Nullable startTime,NSString*_Nullable endTime);
NS_ASSUME_NONNULL_BEGIN

@interface FilterDateView : FWPanPopupView
@property (weak, nonatomic) IBOutlet UIView *boardView;
+ (FilterDateView *)instanceViewWithFrame:(CGRect)Rect;
@property (nonatomic, copy)   FilterDateBlock filterDateBlock;
//重置时间
-(void)resetAllTime;
@end

NS_ASSUME_NONNULL_END
