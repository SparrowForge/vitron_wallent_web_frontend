//
//  SelectMenuView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "SelectMenuView.h"
#import "CountrySelectCell.h"
@interface SelectMenuView()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)NSArray*contentArray;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

@implementation SelectMenuView


+ (SelectMenuView *)instanceViewWithFrame:(CGRect)Rect withSelectMenuType:(SelectMenuType)menuType{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"SelectMenuView" owner:nil options:nil];
    SelectMenuView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    view.tableView.delegate=view;
    view.tableView.delegate=view;
    view.menuType=menuType;
    [view setUpUI];
    return view;
}


-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

-(void)setUpUI{
    
    self.titleLabel.font=PingFangMediumFont(13);
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.tableView registerNib:[UINib nibWithNibName:@"CountrySelectCell" bundle:nil] forCellReuseIdentifier:@"CountrySelectCell"];
    self.tableView.tableFooterView=[UIView new];
    self.tableView.rowHeight=60;
    if (self.menuType==SelectLanguage) {
        self.titleLabel.text=LocalizationKey(@"选择语言");
    }else if (self.menuType==SelectNet){
        self.titleLabel.text=LocalizationKey(@"网络");
    }else if (self.menuType==IdentifyType){
        self.titleLabel.text=LocalizationKey(@"选择证件类型");
    }else if (self.menuType==SelectCurrency){
        self.titleLabel.text=LocalizationKey(@"选择币种");
    }else if (self.menuType==SelectCard){
        self.titleLabel.text=LocalizationKey(@"选择卡号");
    }else if (self.menuType==SelectNotes){
        self.titleLabel.text=LocalizationKey(@"选择节点");
    }
    else if (self.menuType==SelectSex){
        self.titleLabel.text=LocalizationKey(@"选择性别");
    }
    else if (self.menuType==SelectOccupation){
        self.titleLabel.text=LocalizationKey(@"选择职业");
    }
    else{
        self.titleLabel.text=LocalizationKey(@"未知");
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CountrySelectCell*cell=[tableView dequeueReusableCellWithIdentifier:@"CountrySelectCell"];
    NSDictionary*dic=self.contentArray[indexPath.row];

    cell.countryNameLabel.text=[[dic allKeys] objectAtIndex:0];
    cell.selectedIcon.hidden=[self.currentDic isEqual:dic]?NO:YES;
    cell.backView.backgroundColor=[self.currentDic isEqual:dic]?[UIColor colorWithHexString:@"#1F211F" alpha:0.03]:[UIColor whiteColor];
    [cell configUIWithMenuType:self.menuType withIndexPath:indexPath];
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _currentDic=self.contentArray[indexPath.row];
    [self.tableView reloadData];
    [self hide];
    if (self.selectMenuBlock) {
        self.selectMenuBlock(self.currentDic);
    }
    
}

-(void)reloadDataWithArray:(NSArray*)dataArray{
    if (dataArray.count<=0) {
        return;
    }
    if (!_currentDic) {
        _currentDic= [dataArray objectAtIndex:0];
    }
    self.contentArray=dataArray;
    [self.tableView reloadData];
}


-(void)setCurrentDic:(NSDictionary *)currentDic{
    
    _currentDic=currentDic;
    [self.tableView reloadData];
}





@end
