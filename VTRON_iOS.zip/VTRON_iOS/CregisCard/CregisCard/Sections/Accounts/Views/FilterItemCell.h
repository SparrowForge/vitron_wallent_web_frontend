//
//  FilterItemCell.h
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, FilterItemCellType) {
    FilterItemCellTypeNormal,     // 没有叉号
    FilterItemCellTypeDeletable   // 有叉号
};

NS_ASSUME_NONNULL_BEGIN

@interface FilterItemCell : UICollectionViewCell

@property (nonatomic, copy) NSString *text;
@property (nonatomic, assign) FilterItemCellType type;

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *closeButton;

/// 点击叉号回调（仅在 type == Deletable 时）
@property (nonatomic, copy) void(^onCloseTapped)(void);

/// 设置选中状态
- (void)setSelectedState:(BOOL)selected;
@end

NS_ASSUME_NONNULL_END
