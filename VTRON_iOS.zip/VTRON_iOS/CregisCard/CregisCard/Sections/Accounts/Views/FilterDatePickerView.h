//
//  FilterDatePickerView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FilterDatePickerView : UIView

/// 选择的回调
@property (nonatomic, copy) void (^didSelectDate)(NSString *dateString);
/// 设置默认日期（字符串格式 yyyy.MM.dd）
- (void)setDefaultDateString:(NSString *)dateString;
/// 设置默认日期
- (void)setDefaultDate:(NSDate *)date;
@end

NS_ASSUME_NONNULL_END
