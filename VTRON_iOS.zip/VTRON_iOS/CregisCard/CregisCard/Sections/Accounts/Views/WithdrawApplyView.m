//
//  WithdrawApplyView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "WithdrawApplyView.h"
#import "SelectMenuView.h"
#import "VerifyPermissionView.h"
#import "AccountNetWorkManager.h"

@interface WithdrawApplyView()<UITextFieldDelegate>
@property(nonatomic,strong)SelectMenuView*selectView;
@property(nonatomic,strong)VerifyPermissionView*verifyView;
@property(nonatomic,strong)NSString*addressChain;
@property (weak, nonatomic) IBOutlet UILabel *coinTypeTitle;
@property (weak, nonatomic) IBOutlet UILabel *feeTitle;
@property (weak, nonatomic) IBOutlet UILabel *arrivalTitle;
@property (weak, nonatomic) IBOutlet UIButton *maxBtn;
@property (weak, nonatomic) IBOutlet UILabel *useAbleTitle;
@property (weak, nonatomic) IBOutlet UILabel *unitLabel;
@property (weak, nonatomic) IBOutlet UITextField *usdtLabel;

@property(nonatomic,strong) NSDictionary*currentNetDic;


@end


@implementation WithdrawApplyView


- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 180+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectNet];
    }
    return _selectView;
}
- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:AccountWithdraw];
    }
    return _verifyView;
}
+ (WithdrawApplyView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"WithdrawApplyView" owner:nil options:nil];
    WithdrawApplyView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.backgroundColor=[UIColor whiteColor];
    return view;
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.coinTypeTitle.font=PingFangMediumFont(13);
    self.netTiltle.font=PingFangMediumFont(13);
    self.gatherAddressTitle.font=PingFangMediumFont(13);
    self.withdrawTitle.font=PingFangMediumFont(13);
    self.feeTitle.font=PingFangMediumFont(13);
    self.arrivalTitle.font=PingFangMediumFont(13);
    self.estimateLabel.font=PingFangMediumFont(17);
    self.useAbleTitle.font=PingFangMediumFont(13);
    self.useAbleLabel.font=PingFangMediumFont(13);
    self.feeLabel.font=PingFangMediumFont(15);
    self.usdtLabel.font=PingFangMediumFont(15);
    self.unitLabel.font= RegularFont(13);

    self.feeTitle.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    self.arrivalTitle.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    [self setBorderView:self.amountView];
    [self setBorderView:self.coinTypeView];
    [self setBorderView:self.netView];
    [self setBorderView:self.addressView];
    [self setUIlabelattributedTextWithlabel:self.withdrawTitle withTitle:[NSString stringWithFormat:@"%@",LocalizationKey(@"提币金额")]];
    [self setUIlabelattributedTextWithlabel:self.netTiltle withTitle:[NSString stringWithFormat:@"%@",LocalizationKey(@"网络")]];
    
    [self setUIlabelattributedTextWithlabel:self.gatherAddressTitle withTitle:[NSString stringWithFormat:@"%@",LocalizationKey(@"收款地址")]];
    self.coinTypeTitle.text=LocalizationKey(@"币种");
    self.feeTitle.text=LocalizationKey(@"手续费");
    self.arrivalTitle.text=LocalizationKey(@"到账金额");
    [self.okBtn setTitle:LocalizationKey(@"提币") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self.maxBtn setTitle:LocalizationKey(@"最大") forState:UIControlStateNormal];
    self.maxBtn.titleLabel.font=RegularFont(13);
    [self.netTF setStyleWithPlaceholder:LocalizationKey(@"请选择")];
    [self.addressTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.amountTF setStyleWithPlaceholder:LocalizationKey(@"最少")];
    
    
    
    self.amountTF.delegate=self;
    self.useAbleTitle.text=LocalizationKey(@"可用：");
    self.useAbleLabel.text=@"0.00 USD";
   
    [self.addressTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.amountTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.currentNetDic=@{@"NO":@"NO"};//随便写一个不存在的币种网络
#if DEBUG == 1
//self.addressTF.text = @"TFD58Sg3ZDzXkMxNC2ojEnjZQXfTNUeon2";//测试地址
#endif
  
}

-(void)setUIlabelattributedTextWithlabel:(UILabel*)label withTitle:(NSString*)title{
//    NSString *text = title;
//    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
//    [attributedText addAttribute:NSForegroundColorAttributeName
//                              value:[UIColor alertColor]
//                              range:NSMakeRange(0, 1)];
//       
//       // 将带有属性的文本设置给 UILabel
//    [label setAttributedText:attributedText];
    label.text=title;
 
}

-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];                          
    
}

- (IBAction)okClick:(UIButton *)sender {
    if (sender.tag==0) {
        //选择网络
        [self.selectView show];
        self.selectView.currentDic=self.currentNetDic;
        [self.selectView reloadDataWithArray:@[@{@"USDT-ERC20":@"USDT-ERC20"},@{@"USDT-TRC20":@"USDT-TRC20"}]];
        WEAKSELF
        self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
            NSString*key= [[dic allKeys] objectAtIndex:0];
            weakSelf.netTF.text=key;
            weakSelf.addressChain=[dic objectForKey:key];
            [weakSelf judgeBtnStatus];
            weakSelf.currentNetDic=dic;
        };
        
        
    }else{
        //提交
        [self toSubmit];
        
    }
    
    
    
}

//MARK: 提交提现请求
-(void)toSubmit{
//    [self.verifyView show];
//    return;
    if ([NSString stringIsNull:self.amountTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入提币金额"));
        return;
    }
    if (![NSString stringIsNull:self.configDic[@"minWithdraw"]]&&[self.amountTF.text doubleValue]<[self.configDic[@"minWithdraw"] doubleValue]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"低于最少提币金额"));
        return;
    }
    
    if ([self.amountTF.text doubleValue]>[self.configDic[@"amount"] doubleValue]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"可用金额不足"));
        return;
    }
    
    if ([NSString stringIsNull:self.netTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择收款网络"));
        return;
    }
    if ([NSString stringIsNull:self.addressTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入收款地址"));
        return;
    }
    
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
        [weakSelf toApplyWithDrawWithpayPassword:payPassword Withcode:code withType:type];
    };
  
}

//MARK: 提交提现申请
-(void)toApplyWithDrawWithpayPassword:(NSString*)payPassword Withcode:(NSString*)code withType:(int)type {
    [SVProgressHUD customShowWithNone];
    [self.verifyView startAnimation];
    NSString*codeType=type==0?@"code":@"googleCode";
    [AccountNetWorkManager toWithdrawWithParams:@{@"addressChain":self.addressChain,@"amount":self.amountTF.text,@"address":self.addressTF.text,@"payPassword":payPassword,codeType:code} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"提交成功"));
            [self.verifyView hide];
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[UBTrackerFindController findCurrentShowingViewController].navigationController popViewControllerAnimated:YES];
            });
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
    
}

-(void)setConfigDic:(NSDictionary *)configDic{
    
    _configDic=configDic;
  
    [self.amountTF setStyleWithPlaceholder:[NSString stringWithFormat:@"%@ %@",LocalizationKey(@"最少"),[NSString formattedStringWithDouble:[configDic[@"minWithdraw"] doubleValue]]]];
    self.useAbleLabel.text=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:[configDic[@"amount"] doubleValue]]];
   
}


//MARK: 监听输入金额变化
- (IBAction)amountChange:(UITextField *)sender {
    
    NSString*feeString=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:[sender.text doubleValue]*[self.configDic[@"ratio"] doubleValue]/100.00]];
    self.feeLabel.text=feeString;
    NSString*estimateString=[NSString stringWithFormat:@"%@",[NSString formattedStringWithDouble:[sender.text doubleValue]*(100-[self.configDic[@"ratio"] doubleValue])/100.00]];
    self.estimateLabel.text=estimateString;
    if (self.withdrawBlock) {
        self.withdrawBlock(feeString, estimateString);
    }
}

//限制只能输入2位小数
// 实现UITextFieldDelegate协议方法，控制小数位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // 获取当前输入的文本
    NSString *currentText = [textField.text stringByReplacingCharactersInRange:range withString:string];

    // 检查是否是有效的数字，以及小数位数是否超过两位
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *number = [formatter numberFromString:currentText];

    if (number || [currentText isEqualToString:@""]) { // 检查是否是有效的数字或为空
        NSArray *components = [currentText componentsSeparatedByString:@"."];
        if (components.count > 1) {
            NSString *decimalPart = components[1];
            return decimalPart.length <= 2; // 限制小数位数为两位
        }
        return YES;
    } else {
        return NO; // 输入无效，不允许修改
    }
}


//最大
- (IBAction)maxClick:(UIButton *)sender {
    self.amountTF.text=[NSString formattedStringWithDouble:[self.configDic[@"amount"] doubleValue]];
    NSString*feeString=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:[self.amountTF.text doubleValue]*[self.configDic[@"ratio"] doubleValue]/100.00]];
    self.feeLabel.text=feeString;
    NSString*estimateString=[NSString stringWithFormat:@"%@",[NSString formattedStringWithDouble:[self.amountTF.text doubleValue]*(100-[self.configDic[@"ratio"] doubleValue])/100.00]];
    self.estimateLabel.text=estimateString;
    
    if (self.withdrawBlock) {
        self.withdrawBlock(feeString, estimateString);
    }
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    [self judgeBtnStatus];
}

-(void)judgeBtnStatus{
    
    if ([NSString stringIsNull:self.amountTF.text]||[NSString stringIsNull:self.addressTF.text]||[NSString stringIsNull:self.netTF.text]) {
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        if (self.btnColorBlock) {
            self.btnColorBlock(0);
        }
    }else{
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        if (self.btnColorBlock) {
            self.btnColorBlock(1);
        }
    }
   
}


@end
