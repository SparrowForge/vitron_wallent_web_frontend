//
//  FilterDateView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FilterDateView.h"
#import "FilterDatePickerView.h"

@interface FilterDateView()

@property (weak, nonatomic) IBOutlet UIView *beginView;
@property (weak, nonatomic) IBOutlet UILabel *startLabel;
@property (weak, nonatomic) IBOutlet UIView *endView;
@property (weak, nonatomic) IBOutlet UILabel *endLabel;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property(nonatomic,copy)   NSString*startTime;
@property(nonatomic,copy)   NSString*endTime;
@property(nonatomic,assign) int currentIndex;
@property(nonatomic,strong) FilterDatePickerView *picker;
@end




@implementation FilterDateView

+ (FilterDateView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"FilterDateView" owner:nil options:nil];
    FilterDateView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setUpUI];
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}


-(void)setUpUI{
    
    self.beginView.backgroundColor=[UIColor whiteColor];
    [self.beginView setCornerRadius:22.0];
    self.beginView.layer.borderWidth=0.5;
    self.beginView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    self.endView.backgroundColor=[UIColor whiteColor];
    self.endView.layer.borderWidth=0.5;
    self.endView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [self.endView setCornerRadius:22.0];
    self.startLabel.text=LocalizationKey(@"开始时间");
    self.endLabel.text=LocalizationKey(@"结束时间");
    self.tipsLabel.text=LocalizationKey(@"筛选日期");
    [self.resetBtn setTitle:LocalizationKey(@"重置") forState:UIControlStateNormal];
    [self.okBtn setTitle:LocalizationKey(@"确认") forState:UIControlStateNormal];
    [self.resetBtn setborderColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] withborderWidth:0.5];
    self.resetBtn.titleLabel.font=PingFangMediumFont(15);
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.picker = [[FilterDatePickerView alloc] initWithFrame:CGRectMake(0, 120, self.bounds.size.width, 200)];
    [self.picker setDefaultDate:[NSDate date]]; // 设置默认日期
//    NSDateComponents *components = [[NSDateComponents alloc] init];
//    components.year = 2024;
//    components.month = 1;
//    components.day = 1;
//    NSCalendar *calendar = [NSCalendar currentCalendar];
//    NSDate *defaultDate = [calendar dateFromComponents:components];
//    [picker setDefaultDate:defaultDate];
    WEAKSELF
    self.picker.didSelectDate = ^(NSString *dateString) {
        
        if (weakSelf.currentIndex==1) {
            weakSelf.startLabel.text=dateString;
            weakSelf.startTime=dateString;
        }else if (weakSelf.currentIndex==2){
            weakSelf.endLabel.text=dateString;
            weakSelf.endTime=dateString;
        }
        NSLog(@"选择的日期：%@", dateString);
    };
    
    [self addSubview:self.picker];
    
    
}

- (IBAction)timeClick:(UIButton *)sender {
    if (sender.tag==0) {
        //开始时间
        if (self.currentIndex==0) {
            //第一次点击开始时间时候，默认当天时间
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            formatter.dateFormat = @"yyyy.MM.dd";
            NSString*startTime=[formatter stringFromDate:[NSDate date]];
            self.startLabel.text=startTime;
            self.startTime=startTime;
        }
        self.currentIndex=1;
        if (![NSString stringIsNull:self.startTime]) {
            [self.picker setDefaultDateString:self.startTime];
        }
       
        [self setBorderView:self.beginView forColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0]];
        [self setBorderView:self.endView forColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2]];
        self.beginView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.05];
        self.endView.backgroundColor=[UIColor whiteColor];
        
        
        
    }else{
        //结束时间
        if (self.currentIndex==0) {
            //第一次点击开始时间时候，默认当天时间
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            formatter.dateFormat = @"yyyy.MM.dd";
            NSString*endTime=[formatter stringFromDate:[NSDate date]];
            self.endLabel.text=endTime;
            self.endTime=endTime;
        }
        self.currentIndex=2;
        [self setBorderView:self.beginView forColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2]];
        [self setBorderView:self.endView forColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0]];
        self.beginView.backgroundColor=[UIColor whiteColor];
        self.endView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.05];
        if (![NSString stringIsNull:self.endTime]) {
            [self.picker setDefaultDateString:self.endTime];
        }
    }
   
}




- (IBAction)okClick:(UIButton *)sender {
    if (sender.tag==0) {
        //重置
        [self resetAllTime];
        
        
        
    }else{
        //确认
        [self hide];
        if (self.filterDateBlock) {
            self.filterDateBlock(self.startTime, self.endTime);
        }
      
    }
    
    
}

//重置时间
-(void)resetAllTime{
    
    self.currentIndex=0;
    self.startLabel.text=LocalizationKey(@"开始时间");
    self.endLabel.text=LocalizationKey(@"结束时间");
    self.startTime=@"";
    self.endTime=@"";
    [self setBorderView:self.beginView forColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2]];
    [self setBorderView:self.endView forColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2]];
    self.beginView.backgroundColor=[UIColor whiteColor];
    self.endView.backgroundColor=[UIColor whiteColor];
    [self.picker setDefaultDate:[NSDate date]];
    
}



-(void)setBorderView:(UIView*)view forColor:(UIColor*)color{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=color.CGColor;
    [view setCornerRadius:22];
}




@end
