//
//  ReceivingQRView.h
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ReceivingQRView : UIView
@property (weak, nonatomic) IBOutlet UIView *ercodeBackView;
@property (weak, nonatomic) IBOutlet UIImageView *QRImageV;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headImageV;
@property (weak, nonatomic) IBOutlet UILabel *scanTitle;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

+ (ReceivingQRView *)instanceViewWithFrame:(CGRect)Rect;
-(void)configDataWithQRCodeString:(NSString*)QRString;
-(void)toSaveImage;//保存图片
@end

NS_ASSUME_NONNULL_END
