//
//  AccountTopView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RollingNumberLabel.h"
NS_ASSUME_NONNULL_BEGIN

@interface AccountTopView : UIView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet RollingNumberLabel *totalAmountLabel;//总计
@property (weak, nonatomic) IBOutlet UILabel *useAbleLabel;//可用
@property (weak, nonatomic) IBOutlet UILabel *frozenAmountLabel;//冻结
@property (weak, nonatomic) IBOutlet UIButton *rechargeBtn;
@property (weak, nonatomic) IBOutlet UIButton *withdrawBtn;
@property (weak, nonatomic) IBOutlet UIButton *eyeBtn;
@property (weak, nonatomic) IBOutlet UIButton *transferBtn;
@property (weak, nonatomic) IBOutlet UIButton *exchangeBtn;
@property (weak, nonatomic) IBOutlet UILabel *totalTitle;
@property (weak, nonatomic) IBOutlet UILabel *rechargeTitle;
@property (weak, nonatomic) IBOutlet UILabel *withdrawTitle;
@property (weak, nonatomic) IBOutlet UILabel *tansferTitle;
@property (weak, nonatomic) IBOutlet UILabel *receiveTitle;
@property (weak, nonatomic) IBOutlet UIImageView *inviteIcon;

@property(nonatomic,assign)BOOL isFirst;//限制金额只滚动显示一次
@property(nonatomic,strong)NSDictionary*dataDic;

+ (AccountTopView *)instanceViewWithFrame:(CGRect)Rect;

@end

NS_ASSUME_NONNULL_END
