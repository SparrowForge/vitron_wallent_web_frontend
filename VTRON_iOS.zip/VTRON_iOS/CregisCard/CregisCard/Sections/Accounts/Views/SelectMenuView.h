//
//  SelectMenuView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"

NS_ASSUME_NONNULL_BEGIN
typedef void(^SelectMenuBlock)(NSDictionary* _Nullable dic);

typedef NS_ENUM(NSInteger, SelectMenuType) {
    SelectLanguage,//选择语言
    AddCardHolderPhone,//添加持卡人手机号码
    SelectNet,//提币时选择网络
    SelectCurrency,//转账时选择币种
    ExchangeCoin,//兑换时切换币种
    IdentifyType,//实名认证时选择证件类型
    SelectCard,//卡转移时选择卡号
    SelectNotes,//切换节点
    SelectSex,//选择性别
    SelectOccupation,//选择职业
};

@interface SelectMenuView : FWPanPopupView
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (nonatomic, copy)   SelectMenuBlock selectMenuBlock;
@property(nonatomic,strong)   NSDictionary*currentDic;
@property(nonatomic,assign) SelectMenuType menuType;
+ (SelectMenuView *)instanceViewWithFrame:(CGRect)Rect withSelectMenuType:(SelectMenuType)menuType;
-(void)reloadDataWithArray:(NSArray*)dataArray;

@end

NS_ASSUME_NONNULL_END
