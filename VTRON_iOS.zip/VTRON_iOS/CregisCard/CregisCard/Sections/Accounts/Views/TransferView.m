//
//  TransferView.m
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "TransferView.h"
#import "SelectMenuView.h"
#import "VerifyPermissionView.h"
#import "AccountNetWorkManager.h"
@interface TransferView()<UITextFieldDelegate>
@property(nonatomic,strong)SelectMenuView*selectView;
@property(nonatomic,strong)VerifyPermissionView*verifyView;
@property(nonatomic,strong)NSArray*coinsAmountArray;
@property(nonatomic,copy)NSString*fee;//转账手续费百分比
@property (weak, nonatomic) IBOutlet UITextField *explainTF;
@property (weak, nonatomic) IBOutlet UILabel *numLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailAlertLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emailAlertHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *alertTopDistance;
@property (weak, nonatomic) IBOutlet UILabel *useAbleTitle;
@property (weak, nonatomic) IBOutlet UILabel *unitLabel;

@end

@implementation TransferView

- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 180+15*2+HOME_INDICATOR_HEIGHT) withSelectMenuType:SelectCurrency];
    }
    return _selectView;
}
- (VerifyPermissionView *)verifyView {
    
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:TransferCoin];
    }
    return _verifyView;
}
+ (TransferView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"TransferView" owner:nil options:nil];
    TransferView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
 
    [self.accountTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.amountTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.explainTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    self.receiverTitle.text=LocalizationKey(@"收款账户");
    self.receiverCoinTitle.text=LocalizationKey(@"转账币种");
    self.receiverAmountTitle.text=LocalizationKey(@"转账金额");
    self.receiverExplainTitle.text=LocalizationKey(@"转账说明");
    self.receiverFeeTitle.text=LocalizationKey(@"手续费");
    self.totalTilte.text=LocalizationKey(@"总计");
    [self.okBtn setTitle:LocalizationKey(@"转账") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.emailAlertLabel.text=LocalizationKey(@"电子邮件格式不正确");
    self.useAbleTitle.text=LocalizationKey(@"可用：");
    self.useAbleTitle.font=PingFangMediumFont(13);
    self.totalLabel.font=PingFangMediumFont(17);
    self.receiverTitle.font=PingFangMediumFont(13);
    self.receiverCoinTitle.font=PingFangMediumFont(13);
    self.receiverExplainTitle.font=PingFangMediumFont(13);
    self.receiverAmountTitle.font=PingFangMediumFont(13);
    self.receiverFeeTitle.font=PingFangMediumFont(13);
    self.totalTilte.font=PingFangMediumFont(13);
    self.useableLabel.font=PingFangMediumFont(13);
    self.feeLabel.font=PingFangMediumFont(15);
    self.unitLabel.font=PingFangMediumFont(17);
    self.coinUnitLabel.font=RegularFont(13);
    self.numLabel.font=RegularFont(13);
    self.numLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    self.receiverFeeTitle.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    self.totalTilte.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    [self setBorderView:self.accountView];
    [self setBorderView:self.coinView];
    [self setBorderView:self.amountView];
    [self setBorderView:self.explainView];
    self.amountTF.delegate=self;
    self.explainTF.delegate=self;
    [self.accountTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.amountTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.emailAlertLabel.hidden=YES;
    self.alertTopDistance.constant=0;
    self.emailAlertHeight.constant=0;
    [self getConfigData];
#if DEBUG == 1
   // self.accountTF.text=@"1825571811@qq.com";
#endif
   
}

//获取转账数据
-(void)getConfigData{
    [SVProgressHUD customShowWithStyle];
    [AccountNetWorkManager getTransferConfigDatasuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            self.coinsAmountArray=data[@"data"][@"amount"];
            self.fee=data[@"data"][@"fee"];
            self.useableLabel.text=[NSString stringWithFormat:@"%@ %@",[self getAmountWithCurrentCoin:@"USD"],@"USD"];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
        }];
  
}

//选择币种
- (IBAction)selectCoin:(id)sender {
    [self.selectView show];
    NSMutableArray*coinsArray=[[NSMutableArray alloc]init];
    [self.coinsAmountArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [coinsArray addObject:@{obj[@"currency"]:obj[@"currency"]}];
       
    }];
    [self.selectView reloadDataWithArray:coinsArray];
    WEAKSELF
    self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
        weakSelf.coinUnitLabel.text=[dic allValues][0];
        [weakSelf judgeBtnStatus];
        weakSelf.useableLabel.text=[NSString stringWithFormat:@"%@ %@",[weakSelf getAmountWithCurrentCoin:[dic allValues][0]],[dic allValues][0]];
        weakSelf.coinTF.text=[dic allValues][0];
        weakSelf.feeLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:[weakSelf.amountTF.text doubleValue]*[weakSelf.fee doubleValue]*0.01 ],weakSelf.coinUnitLabel.text];//手续费
        weakSelf.totalLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:([weakSelf.amountTF.text doubleValue]+[weakSelf.amountTF.text doubleValue]*[weakSelf.fee doubleValue]*0.01 )],@""];//总计
    };
    
}
//转账金额变化
- (IBAction)amountInput:(UITextField *)sender {
   
    self.feeLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:[self.amountTF.text doubleValue]*[self.fee doubleValue]*0.01 ],self.coinUnitLabel.text];//手续费
    self.totalLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:([self.amountTF.text doubleValue]+[self.amountTF.text doubleValue]*[self.fee doubleValue]*0.01 )],@""];//总计
}

//转账
- (IBAction)transferClick:(id)sender {
    if ([NSString stringIsNull:self.accountTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
        return;
    }
//    if ([NSString stringIsNull:self.coinTF.text]) {
//        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择转账币种"));
//        return;
//    }
    if ([NSString stringIsNull:self.amountTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入转账金额"));
        return;
    }
    if ([self.amountTF.text doubleValue]>[[self getAmountWithCurrentCoin:self.coinUnitLabel.text] doubleValue]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"可用金额不足"));
        return;
    }
    
    if ([self.amountTF.text doubleValue]+[self.amountTF.text doubleValue]*[self.fee doubleValue]*0.01>[[self getAmountWithCurrentCoin:self.coinUnitLabel.text] doubleValue]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"可用金额不足"));
        return;
    }
  
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
        
        [weakSelf toTransferWalletwithpayPassword:payPassword withcode:code withType:type];
    };
    
}

//去转账
-(void)toTransferWalletwithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    [SVProgressHUD customShowWithNone];
    [self.verifyView startAnimation];
    NSString*codeType=type==0?@"code":@"googleCode";
    [AccountNetWorkManager toTransferWithParams:@{@"amount":self.amountTF.text,@"payPassword":payPassword,codeType:code,@"email":self.accountTF.text,@"currency":self.coinUnitLabel.text,@"remark":self.explainTF.text} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.verifyView hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"转账成功"));
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[UBTrackerFindController findCurrentShowingViewController].navigationController popViewControllerAnimated:YES];
            });
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
    
    
}

//获取某币种的可用金额
-(NSString*)getAmountWithCurrentCoin:(NSString*)currency{
    
    __block NSDictionary*currentCoinDic;
    [self.coinsAmountArray enumerateObjectsUsingBlock:^(NSDictionary* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([currency isEqualToString:obj[@"currency"]]) {
            currentCoinDic=obj;
            *stop=YES;
        }
            
    }];
    
    return [NSString formattedStringWithDouble:[currentCoinDic[@"amount"] doubleValue]];
}


-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}


//限制只能输入2位小数
// 实现UITextFieldDelegate协议方法，控制小数位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if ([textField isEqual:self.explainTF]) {
        NSString *currentText = textField.text;
        NSUInteger newLength = [currentText length] + [string length] - range.length;
        return newLength <= 20;
    }
    // 获取当前输入的文本
    NSString *currentText = [textField.text stringByReplacingCharactersInRange:range withString:string];

    // 检查是否是有效的数字，以及小数位数是否超过两位
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *number = [formatter numberFromString:currentText];

    if (number || [currentText isEqualToString:@""]) { // 检查是否是有效的数字或为空
        NSArray *components = [currentText componentsSeparatedByString:@"."];
        if (components.count > 1) {
            NSString *decimalPart = components[1];
            return decimalPart.length <= 2; // 限制小数位数为两位
        }
        return YES;
    } else {
        return NO; // 输入无效，不允许修改
    }
}

//输入转账说明
- (IBAction)explanTF:(UITextField *)sender {
    self.numLabel.text=[NSString stringWithFormat:@"%lu/20",(unsigned long)sender.text.length];
    
}
//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    if ([textField isEqual:self.accountTF]) {
        //邮箱
        [self judgeCorrectEmail:[ToolUtil matchEmail:textField.text]];
    }
    [self judgeBtnStatus];
}

-(void)judgeBtnStatus{
    
    if ([NSString stringIsNull:self.amountTF.text]||[NSString stringIsNull:self.accountTF.text]) {
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    }else{
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
    }
   
}


//判断电子邮件是否正确
-(void)judgeCorrectEmail:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.emailAlertLabel.hidden=YES;
        self.accountView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.accountView.backgroundColor=[UIColor whiteColor];
        self.alertTopDistance.constant=0;
        self.emailAlertHeight.constant=0;
    }else{
        self.emailAlertLabel.hidden=NO;
        self.accountView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.accountView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.alertTopDistance.constant=8;
        self.emailAlertHeight.constant=15;
    }
   
}

@end
