//
//  TransactionTopsCell.h
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "OrderRecordModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TransactionTopsCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIButton *tipsBtn;
-(void)configDataWithModel:(OrderRecordModel*)orderModel AtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray;
@end

NS_ASSUME_NONNULL_END
