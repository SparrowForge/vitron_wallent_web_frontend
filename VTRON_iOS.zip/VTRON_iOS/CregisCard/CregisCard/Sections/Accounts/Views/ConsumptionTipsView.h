//
//  ConsumptionTipsView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"
#import "OrderRecordModel.h"

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, ConsumptionMenuType) {
    ConsumptionInstructions,//消费说明
    RefundInstructions,//退款说明
   
};
@interface ConsumptionTipsView : FWPanPopupView
@property (weak, nonatomic) IBOutlet UIView *boardView;
+ (ConsumptionTipsView *)instanceViewWithFrame:(CGRect)Rect withSelectMenuType:(ConsumptionMenuType)menuType withModel:(OrderRecordModel*)model;
@property(nonatomic,assign) ConsumptionMenuType menuType;

@end

NS_ASSUME_NONNULL_END
