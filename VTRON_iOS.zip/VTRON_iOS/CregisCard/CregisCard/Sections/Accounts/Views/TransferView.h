//
//  TransferView.h
//  CregisCard
//
//  Created by 孙良 on 2024/2/21.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TransferView : UIView
+ (TransferView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UIView *accountView;
@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UIView *coinView;
@property (weak, nonatomic) IBOutlet UITextField *coinTF;
@property (weak, nonatomic) IBOutlet UIView *amountView;
@property (weak, nonatomic) IBOutlet UIView *explainView;

@property (weak, nonatomic) IBOutlet UITextField *amountTF;

@property (weak, nonatomic) IBOutlet UILabel *coinUnitLabel;
@property (weak, nonatomic) IBOutlet UILabel *feeLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalLabel;
@property (weak, nonatomic) IBOutlet UILabel *useableLabel;
@property (weak, nonatomic) IBOutlet UILabel *receiverTitle;
@property (weak, nonatomic) IBOutlet UILabel *receiverCoinTitle;
@property (weak, nonatomic) IBOutlet UILabel *receiverAmountTitle;
@property (weak, nonatomic) IBOutlet UILabel *receiverExplainTitle;
@property (weak, nonatomic) IBOutlet UILabel *receiverFeeTitle;
@property (weak, nonatomic) IBOutlet UILabel *totalTilte;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;




@end

NS_ASSUME_NONNULL_END
