//
//  AccountOtherCell.h
//  CregisCard
//
//  Created by sunliang on 2025/7/8.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "OrderRecordModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface AccountOtherCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardNoLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *typeImageV;

-(void)configDataWithModel:(OrderRecordModel*)model withType:(int)type;
@end

NS_ASSUME_NONNULL_END
