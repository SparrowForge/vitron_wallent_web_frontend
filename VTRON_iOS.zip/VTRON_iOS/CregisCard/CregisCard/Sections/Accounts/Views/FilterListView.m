//
//  FilterListView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FilterListView.h"
#import "FilterTableViewCell.h"
@interface FilterListView()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property(nonatomic,strong) NSArray*contentArray;
@property(nonatomic,strong) NSArray*imageArray;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property(nonatomic,assign) FilterMenuType menuType;
@end

@implementation FilterListView

+ (FilterListView *)instanceViewWithFrame:(CGRect)Rect withSelectMenuType:(FilterMenuType)menuType{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"FilterListView" owner:nil options:nil];
    FilterListView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    view.tableView.delegate=view;
    view.tableView.delegate=view;
    view.menuType=menuType;
    [view setUpUI];
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

-(void)setUpUI{

    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.tableView registerNib:[UINib nibWithNibName:@"FilterTableViewCell" bundle:nil] forCellReuseIdentifier:@"FilterTableViewCell"];
    self.tableView.tableFooterView=[UIView new];
    self.tableView.rowHeight=60+8;
    self.titleLabel.font=PingFangMediumFont(13);
    if (self.menuType==TypeForWallet||self.menuType==TypeForCard||self.menuType==TypeForAllCard||self.menuType==NotificationCenter) {
        self.titleLabel.text=LocalizationKey(@"类型");
    }
    else if (self.menuType==StatusForWallet||self.menuType==StatusForCard||self.menuType==StatusForAllCard){
        
        self.titleLabel.text=LocalizationKey(@"状态");
    }else{
        self.titleLabel.text=LocalizationKey(@"未知");

        
    }
    
    [self configData];
}

-(void)configData{
    if (self.menuType==TypeForWallet) {
        //钱包-类型
        self.imageArray=@[@"filter_all_small",@"filter_charge_small",@"filter_withdraw_small",@"filter_apply_small",@"filter_cardRecharge_small",@"filter_cardContine_small",@"filter_cardWithdraw_small",@"filter_transfer_small",@"filter_receive_small",@"filter_restore_small"];
        self.contentArray=@[LocalizationKey(@"所有类型"),LocalizationKey(@"充值"),LocalizationKey(@"提币"),LocalizationKey(@"卡片申请"),LocalizationKey(@"卡片充值"),LocalizationKey(@"卡手续费"),LocalizationKey(@"卡片提现"),LocalizationKey(@"转账"),LocalizationKey(@"收款"),LocalizationKey(@"冲正")];
    }else if (self.menuType==StatusForWallet){
        //钱包-状态
        self.imageArray=@[@"filter_all_small",@"filter_confirm_small",@"filter_end_small",@"filter_down_small"];
        self.contentArray=@[LocalizationKey(@"所有状态"),LocalizationKey(@"确认中"),LocalizationKey(@"已完成"),LocalizationKey(@"已取消")];
        
    }else if (self.menuType==TypeForCard){
        //卡-类型
        self.imageArray=@[@"filter_all_small",@"filter_consumption_small",@"filter_refund_small",@"filter_cardRecharge_small",@"filter_cardWithdraw_small",@"filter_reject_small",@"filter_cardfee_small",@"filter_atm_small"];
        self.contentArray=@[LocalizationKey(@"所有类型"),LocalizationKey(@"消费"),LocalizationKey(@"退款"),LocalizationKey(@"卡片充值"),LocalizationKey(@"卡片提现"),LocalizationKey(@"撤销"),LocalizationKey(@"卡费"),LocalizationKey(@"ATM")];
        
    }else  if (self.menuType==StatusForCard){
        //卡-状态
        self.imageArray=@[@"filter_all_small",@"filter_confirm_small",@"filter_end_small",@"filter_down_small"];
        self.contentArray=@[LocalizationKey(@"所有状态"),LocalizationKey(@"确认中"),LocalizationKey(@"已完成"),LocalizationKey(@"已取消")];
        
    }else  if (self.menuType==NotificationCenter){
        //通知中心
        self.imageArray=@[@"filter_all_small",@"filter_3ds",@"filter_activeCode"];
        self.contentArray=@[LocalizationKey(@"所有类型"),LocalizationKey(@"3DS"),LocalizationKey(@"激活码")];
        
    }else if (self.menuType==TypeForAllCard){
        //全部卡片-类型
        self.imageArray=@[@"filter_all_small",@"beex_virtual",@"beex_entity"];
        self.contentArray=@[LocalizationKey(@"所有类型"),LocalizationKey(@"虚拟卡"),LocalizationKey(@"实体卡")];
        
    }else  if (self.menuType==StatusForAllCard){
        //全部卡片-状态
        self.imageArray=@[@"filter_all_small",@"filter_active",@"filter_frozen",@"filter_unactive",@"filter_cancel"];
        self.contentArray=@[LocalizationKey(@"所有状态"),LocalizationKey(@"激活"),LocalizationKey(@"冻结"),LocalizationKey(@"未激活"),LocalizationKey(@"注销")];
        
    }
    
    [self.tableView reloadData];
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FilterTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"FilterTableViewCell"];
    NSString*nameString=self.contentArray[indexPath.row];
    cell.typeImageV.image=UIIMAGE(self.imageArray[indexPath.row]);
    cell.nameLabel.text=nameString;
    cell.dotView.hidden=[self.currentDic[@"name"] isEqual:nameString]?NO:YES;
    cell.backView.backgroundColor=[self.currentDic[@"name"] isEqual:nameString]?[UIColor colorWithHexString:@"#1F211F" alpha:0.03]:[UIColor whiteColor];

    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString*name=self.contentArray[indexPath.row];
    [self hide];
    if (self.filterMenuBlock) {
        if (self.menuType==TypeForWallet||self.menuType==TypeForCard) {
            //类型
            self.filterMenuBlock(name,[self getTypeWithName:name]);
            self.currentDic=@{@"name":name,@"kind":[self getTypeWithName:name]};
            
        }else if(self.menuType==StatusForWallet||self.menuType==StatusForCard){
            //状态
            self.filterMenuBlock(name,[self getStatusWithName:name]);
            self.currentDic=@{@"name":name,@"kind":[self getStatusWithName:name]};
        }
        else if(self.menuType==NotificationCenter){
            //通知中心
            self.filterMenuBlock(name,[self getNotificationAuthStatusWithName:name]);
            self.currentDic=@{@"name":name,@"kind":[self getNotificationAuthStatusWithName:name]};
        } else if(self.menuType==TypeForAllCard){
            //全部卡片类型
            self.filterMenuBlock(name,[self getAllCardTypeWithName:name]);
            self.currentDic=@{@"name":name,@"kind":[self getAllCardTypeWithName:name]};
        }else if(self.menuType==StatusForAllCard){
            //全部卡片状态
            self.filterMenuBlock(name,[self getAllCardStatusWithName:name]);
            self.currentDic=@{@"name":name,@"kind":[self getAllCardStatusWithName:name]};
        }
        
        else{
            //未知
        }
        
            [self.tableView reloadData];
    }
    
}

-(void)reloadTableView{
    [self.tableView reloadData];
}
//根据名称种类获取type
-(NSString*)getTypeWithName:(NSString*)name{
    if ([name isEqualToString:LocalizationKey(@"所有类型")]) {
        return @"";
    }else if([name isEqualToString:LocalizationKey(@"充值")]){
        return @"top_up";
    }else if([name isEqualToString:LocalizationKey(@"提币")]){
        return @"withdrawal";
    }else if([name isEqualToString:LocalizationKey(@"卡片申请")]){
        return @"create_card";
    }else if([name isEqualToString:LocalizationKey(@"卡片充值")]){
        return @"deposit_card";
    }else if([name isEqualToString:LocalizationKey(@"卡手续费")]){
        return @"program_fee_card";
    }else if([name isEqualToString:LocalizationKey(@"卡片提现")]){
        return @"withdraw_card";
    }else if([name isEqualToString:LocalizationKey(@"转账")]){
        return @"transfer";
    }else if([name isEqualToString:LocalizationKey(@"收款")]){
        return @"receive";
    }else if([name isEqualToString:LocalizationKey(@"冲正")]){
        return @"correction";
    }
    else if([name isEqualToString:LocalizationKey(@"消费")]){
        return @"program_fee_card";
    }
    else if([name isEqualToString:LocalizationKey(@"退款")]){
        return @"refund_card";
    }
    else if([name isEqualToString:LocalizationKey(@"验证")]){
        return @"verification_card";
    }
    else if([name isEqualToString:LocalizationKey(@"卡费")]){
        return @"fee_card";
    }
    else if([name isEqualToString:LocalizationKey(@"撤销")]){
        return @"reversal_card";
    }
    else if([name isEqualToString:LocalizationKey(@"ATM")]){
        return @"atm_fee_card";
    }
    else{
        return @"";
    }
    
}
//根据名称种类获取status
-(NSString*)getStatusWithName:(NSString*)name{
    
    if ([name isEqualToString:LocalizationKey(@"所有状态")]) {
        return @"";
    }else if([name isEqualToString:LocalizationKey(@"确认中")]){
        return @"1";
    }else if([name isEqualToString:LocalizationKey(@"已完成")]){
        return @"2";
    }else if([name isEqualToString:LocalizationKey(@"已取消")]){
        return @"3";
    }else{
        return @"4";//已授权
    }
   
}


//根据名称种类获取通知中心授权状态
-(NSString*)getNotificationAuthStatusWithName:(NSString*)name{
    
    if ([name isEqualToString:LocalizationKey(@"所有类型")]) {
        return @"-1";
    }else if([name isEqualToString:LocalizationKey(@"3DS")]){
        return @"1";
    }else if([name isEqualToString:LocalizationKey(@"激活码")]){
        return @"2";
    }else{
        return @"";
    }
   
}

//根据名称种类获取全部卡片的卡片类型
-(NSString*)getAllCardTypeWithName:(NSString*)name{
    
    if ([name isEqualToString:LocalizationKey(@"虚拟卡")]) {
        return @"1";
    }else if([name isEqualToString:LocalizationKey(@"实体卡")]){
        return @"2";
    }else{
        return @"-1";
    }
   
}

//根据名称种类获取全部卡片的卡片状态
-(NSString*)getAllCardStatusWithName:(NSString*)name{
    
    if ([name isEqualToString:LocalizationKey(@"所有状态")]) {
        return @"-1";
    }else if([name isEqualToString:LocalizationKey(@"激活")]){
        return @"01";
    }else if([name isEqualToString:LocalizationKey(@"冻结")]){
        return @"04";
    }else if([name isEqualToString:LocalizationKey(@"未激活")]){
        return @"03";
    }else if([name isEqualToString:LocalizationKey(@"注销")]){
        return @"05";
    }
    else{
        return @"";
    }
   
}

@end
