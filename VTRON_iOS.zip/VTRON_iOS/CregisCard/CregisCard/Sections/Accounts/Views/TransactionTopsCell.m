//
//  TransactionTopsCell.m
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "TransactionTopsCell.h"
#import "ConsumptionTipsView.h"

@interface TransactionTopsCell()
@property(nonatomic,strong) ConsumptionTipsView*consumptionTipsView;
@property(nonatomic,strong) OrderRecordModel*orderModel;

@end

@implementation TransactionTopsCell

- (ConsumptionTipsView *)consumptionTipsView {
    if(!_consumptionTipsView) {
        if ([self.orderModel.type intValue
            ]==5||[self.orderModel.type intValue
                  ]==14) {
            //消费
            _consumptionTipsView=[ConsumptionTipsView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 500+HOME_INDICATOR_HEIGHT) withSelectMenuType:ConsumptionInstructions withModel:self.orderModel];
            }else{
                //退款
                _consumptionTipsView=[ConsumptionTipsView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 550+HOME_INDICATOR_HEIGHT) withSelectMenuType:RefundInstructions withModel:self.orderModel];
            }
      
       
    }
    return _consumptionTipsView;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.font=[UIFont systemFontOfSize:15];
    self.contentLabel.font=RegularFont(15);
    self.titleLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    // Initialization code
}

-(void)configDataWithModel:(OrderRecordModel*)orderModel AtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray{
    self.titleLabel.text=titleArray[indexPath.row];
    self.contentLabel.text=contentArray[indexPath.row];
    self.orderModel=orderModel;
    self.tipsBtn.hidden=YES;

   
}

- (IBAction)okClick:(UIButton *)sender {
    [self.consumptionTipsView show];
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
