//
//  TransactionHeadView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderRecordModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface TransactionHeadView : UIView
+ (TransactionHeadView *)instanceViewWithFrame:(CGRect)Rect;
-(void)configDataWithModel:(OrderRecordModel*)orderModel withType:(int)type;

@end

NS_ASSUME_NONNULL_END
