//
//  TransactionDetailCell.m
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "TransactionDetailCell.h"
#import "TransactionTopsCell.h"

@interface TransactionDetailCell()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSArray*titleArray;
@property(nonatomic,strong)NSArray*contentArray;
@property(nonatomic,strong)OrderRecordModel*orderModel;
@end


@implementation TransactionDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.tableView registerNib:[UINib nibWithNibName:@"TransactionTopsCell" bundle:nil] forCellReuseIdentifier:@"TransactionTopsCell"];
    self.tableView.estimatedRowHeight=48;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.boardView setCornerRadius:12.0];
    [self.boardView setborderColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] withborderWidth:0.33];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    TransactionTopsCell*cell=[tableView dequeueReusableCellWithIdentifier:@"TransactionTopsCell"];
    [cell configDataWithModel:self.orderModel AtIndexPath:indexPath withTitleArray:self.titleArray withContentArray:self.contentArray];
    return cell;
    
    
}



-(void)configDataWithModel:(OrderRecordModel*)orderModel AtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray{
    self.titleArray=titleArray;
    self.contentArray=contentArray;
    self.orderModel=orderModel;
    [self.tableView reloadData];
    // 强制layout，确保contentSize更新
    [self.tableView setNeedsLayout];
    [self.tableView layoutIfNeeded];
    

}

-(CGSize)systemLayoutSizeFittingSize:(CGSize)targetSize withHorizontalFittingPriority:(UILayoutPriority)horizontalFittingPriority verticalFittingPriority:(UILayoutPriority)verticalFittingPriority{
    CGSize size = [super systemLayoutSizeFittingSize:targetSize withHorizontalFittingPriority:horizontalFittingPriority verticalFittingPriority:verticalFittingPriority];
    [self.tableView layoutIfNeeded];
    CGFloat heigth = self.tableView.contentSize.height;
    return CGSizeMake(size.width, heigth+8*2);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
