//
//  VerifyPermissionView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"

typedef void(^VerifyBlock)(NSString* _Nullable payPassword,NSString*_Nullable code,int type);//type 0 邮箱验证 1 谷歌验证
NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, VerifyPermissionType) {
    AccountWithdraw,//账户提币
    CardRecharge,//卡片充值
    CardRefund,//卡片退款
    CardFreeze,//卡冻结确认
    CardThaw,//卡解冻确认
    CardUnsubscribe,//销卡确认
    CardToOpen,//开卡确认
    TransferCoin,//转账
    ActivateCard,//实体卡激活
    GetActivateCardCode,//重新获取实体卡激活码
    SetCardPINCode,//设置PIN码
    EmailCard,//邮寄实体卡（单张）
    Phone_manage,//管理-修改手机号
    Email_manage,//管理-修改邮箱
    EmailCards,//邮寄实体卡（批量）
    TransferCard,//卡转移
    BeexRechargeCard,//卡充值
    BeexWithdrawCard,//卡提现
    CardDetail,//查看卡详情
};


@interface VerifyPermissionView : FWPanPopupView

@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIView *topAlertView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topAlertH;
@property (weak, nonatomic) IBOutlet UIView *pswView;
@property (weak, nonatomic) IBOutlet UIView *codeView;
@property (weak, nonatomic) IBOutlet UITextField *pswTF;
@property (weak, nonatomic) IBOutlet UITextField *codeTF;
@property (weak, nonatomic) IBOutlet UIButton *verifyCodeBtn;
@property (weak, nonatomic) IBOutlet UILabel *pswTitle;
@property (weak, nonatomic) IBOutlet UIView *tipsView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *verifyCodeWidth;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *alertLabel;
@property (weak, nonatomic) IBOutlet UILabel *codeTitle;
@property (weak, nonatomic) IBOutlet UILabel *confirmLabel;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicatorView;
@property (weak, nonatomic) IBOutlet UILabel *emailAlert;
@property (weak, nonatomic) IBOutlet UIView *emailTitleView;

@property (nonatomic, copy) NSString* activateCardString;
@property (nonatomic, copy) VerifyBlock verifyBlock;
@property(nonatomic,assign) VerifyPermissionType permissionType;
@property(nonatomic,retain) dispatch_source_t _timer;
+ (VerifyPermissionView *)instanceViewWithFrame:(CGRect)Rect withVerifyPermissionType:(VerifyPermissionType)permissionType;
-(void)resetBtnColor;
-(void)startAnimation;//开始转圈
-(void)stopAnimation;//停止转圈
@end

NS_ASSUME_NONNULL_END
