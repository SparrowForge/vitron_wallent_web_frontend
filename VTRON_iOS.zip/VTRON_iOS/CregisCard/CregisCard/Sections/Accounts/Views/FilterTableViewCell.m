//
//  FilterTableViewCell.m
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FilterTableViewCell.h"

@interface FilterTableViewCell()


@end


@implementation FilterTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.backView setCornerRadius:16.0];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
