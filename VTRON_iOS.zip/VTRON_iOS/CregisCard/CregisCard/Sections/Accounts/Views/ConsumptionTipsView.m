//
//  ConsumptionTipsView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "ConsumptionTipsView.h"

@interface ConsumptionTipsView()
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIView *backView1;
@property (weak, nonatomic) IBOutlet UIView *backView2;
@property (weak, nonatomic) IBOutlet UIView *backView3;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel1;
@property (weak, nonatomic) IBOutlet UILabel *exchangeTitle;
@property (weak, nonatomic) IBOutlet UILabel *atmFeeTitle;
@property (weak, nonatomic) IBOutlet UILabel *exchangeContentLabel;
@property (weak, nonatomic) IBOutlet UILabel *atmFeeContentLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel2;
@property (weak, nonatomic) IBOutlet UILabel *consumptionTitle;
@property (weak, nonatomic) IBOutlet UILabel *consumptionContentLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel3;
@property (weak, nonatomic) IBOutlet UILabel *consumptionTitle2;
@property (weak, nonatomic) IBOutlet UILabel *consumptionContentLabel2;
@property (weak, nonatomic) IBOutlet UILabel *refundTitle;
@property (weak, nonatomic) IBOutlet UILabel *refundContentLabel;
@property(nonatomic,strong) OrderRecordModel*orderModel;

@end


@implementation ConsumptionTipsView

+ (ConsumptionTipsView *)instanceViewWithFrame:(CGRect)Rect withSelectMenuType:(ConsumptionMenuType)menuType withModel:(OrderRecordModel*)model{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ConsumptionTipsView" owner:nil options:nil];
    ConsumptionTipsView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    view.menuType=menuType;
    view.orderModel=model;
    [view setUpUI];
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

-(void)setUpUI{
    
    [self.backView1 setborderColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] withborderWidth:0.33];
    [self.backView1 setCornerRadius:12];
    self.backView1.backgroundColor=[UIColor whiteColor];
    [self.backView2 setborderColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] withborderWidth:0.33];
    [self.backView2 setCornerRadius:12];
    self.backView2.backgroundColor=[UIColor whiteColor];
    [self.backView3 setborderColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] withborderWidth:0.33];
    [self.backView3 setCornerRadius:12];
    self.backView3.backgroundColor=[UIColor whiteColor];
    self.tipsLabel.font=PingFangMediumFont(17);
    self.titleLabel.font=RegularFont(17);
    self.detailLabel.font=RegularFont(13);
    self.titleLabel1.font=RegularFont(15);
    self.titleLabel2.font=RegularFont(15);
    self.titleLabel3.font=RegularFont(15);
    self.tipsLabel.text=LocalizationKey(@"说明");
    if (self.menuType==ConsumptionInstructions) {
        //消费说明
        
        self.titleLabel.text=LocalizationKey(@"清算金额=账单金额+手续费");
        self.detailLabel.text=LocalizationKey(@"清算金额为实扣账户的金额");
        self.titleLabel1.text=LocalizationKey(@"账单金额=消费金额+FX兑换费+ATM手续费");
        self.exchangeTitle.text=LocalizationKey(@"FX兑换费");
        self.atmFeeTitle.text=LocalizationKey(@"ATM手续费");
        self.titleLabel2.text=LocalizationKey(@"手续费=消费手续费");
        self.consumptionTitle.text=LocalizationKey(@"消费手续费");
        self.backView3.hidden=YES;
        self.backView2.hidden=NO;
        self.exchangeContentLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.fxFee],self.orderModel.currency];
        self.atmFeeContentLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.atmFee],self.orderModel.currency];
       // NSString*tradeFeeString=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.tradeFee],self.orderModel.currency];

        
        self.consumptionContentLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.tradeFee],self.orderModel.currency];
        
    }else{
        //退款说明
        
        self.titleLabel.text=LocalizationKey(@"退款金额=账单金额-手续费");
        self.detailLabel.text=LocalizationKey(@"退款金额为实到账户的金额");
        self.titleLabel1.text=LocalizationKey(@"账单金额=消费金额+FX兑换费+ATM手续费");
        self.exchangeTitle.text=LocalizationKey(@"FX兑换费");
        self.atmFeeTitle.text=LocalizationKey(@"ATM手续费");
        self.titleLabel3.text=LocalizationKey(@"手续费=消费手续费+退款手续费");
        self.consumptionTitle2.text=LocalizationKey(@"消费手续费");
        self.refundTitle.text=LocalizationKey(@"退款手续费");
        self.backView3.hidden=NO;
        self.backView2.hidden=YES;
        self.exchangeContentLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.fxFee],self.orderModel.currency];
        self.atmFeeContentLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.atmFee],self.orderModel.currency];
        self.consumptionContentLabel2.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.tradeFee],self.orderModel.currency];
        self.refundContentLabel.text=[NSString stringWithFormat:@"%@%@",[NSString formattedStringWithDouble:self.orderModel.refundFee],self.orderModel.currency];
        
    }
}
- (IBAction)okClick:(id)sender {
    [self hide];
}


@end
