//
//  AccountRecordCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "OrderRecordModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface AccountRecordCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomDistance;
@property (weak, nonatomic) IBOutlet UIImageView *statusIcon;

@property (weak, nonatomic) IBOutlet UILabel *timeTitle;

-(void)configDataWithModel:(OrderRecordModel*)model withType:(int)type;


@end

NS_ASSUME_NONNULL_END
