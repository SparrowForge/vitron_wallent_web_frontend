//
//  TransactionHeadView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "TransactionHeadView.h"

@interface TransactionHeadView()
@property (weak, nonatomic) IBOutlet UILabel *typeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *typeImageV;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *coinlabel;

@end


@implementation TransactionHeadView

+ (TransactionHeadView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"TransactionHeadView" owner:nil options:nil];
    TransactionHeadView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.typeLabel.textColor=[UIColor blackColor];
    return view;
}

-(void)configDataWithModel:(OrderRecordModel*)orderModel withType:(int)type{
    
    if (type==0) {
        //钱包流水
        NSString*lastType=@"";
        if ([orderModel.type isEqualToString:@"top_up"]) {
            lastType=@"filter_charge";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"withdrawal"]){
            lastType=@"filter_withdraw";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"create_card"]){
            lastType=@"filter_apply";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"deposit_card"]){
            lastType=@"filter_cardRecharge";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"program_fee_card"]){
            //卡手续费
            lastType=@"filter_cardContine";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"withdraw_card"]){
            lastType=@"filter_cardWithdraw";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"transfer"]){
            lastType=@"filter_transfer";
            self.lineView.hidden=YES;

        }else if ([orderModel.type isEqualToString:@"receive"]){
            lastType=@"filter_receive";
            self.lineView.hidden=NO;

        }else if ([orderModel.type isEqualToString:@"correction"]){
            lastType=@"filter_restore";
            self.lineView.hidden=NO;
            ////////
            ///
        }
        self.typeImageV.image=UIIMAGE(lastType);
        
    }else{
        
        //卡流水
        NSString*lastType=@"";
       if ([orderModel.type isEqualToString:@"program_fee_card"]){
            //卡流水-消费
            lastType=@"filter_consumption";
            self.lineView.hidden=YES;
            
        }else if ([orderModel.type isEqualToString:@"refund_card"]){
            lastType=@"filter_refund";
            self.lineView.hidden=YES;
            
        }else if ([orderModel.type isEqualToString:@"deposit_card"]){
            lastType=@"filter_cardRecharge";
            self.lineView.hidden=NO;
        }else if ([orderModel.type isEqualToString:@"withdraw_card"]){
            lastType=@"filter_cardWithdraw";
            self.lineView.hidden=NO;
        }
        else if ([orderModel.type isEqualToString:@"verification_card"]){
            lastType=@"filter_verify";
            self.lineView.hidden=NO;
        }else if ([orderModel.type isEqualToString:@"fee_card"]){
            lastType=@"filter_cardfee";
            self.lineView.hidden=NO;
        }else if ([orderModel.type isEqualToString:@"reversal_card"]){
            lastType=@"filter_reject";
            self.lineView.hidden=YES;
        }else if ([orderModel.type isEqualToString:@"atm_fee_card"]){
            lastType=@"filter_atm";
            self.lineView.hidden=YES;
        }
        
        self.typeImageV.image=UIIMAGE(lastType);
        
    }
   
    self.typeLabel.text=[self getStatusStringWithstatus:[orderModel.status intValue]];
    self.typeLabel.textColor=[self getStatusColorWithstatus:[orderModel.status intValue]];
    if (type==0) {
        //钱包流水
        if ([orderModel.type isEqualToString:@"top_up"]||[orderModel.type isEqualToString:@"withdrawal"]){
            //充提币单位写死
            if (orderModel.totalAmount>0) {
                self.amountLabel.attributedText=[self formattedAmount:[NSString stringWithFormat:@"+%@",[NSString formattedStringWithDouble:orderModel.totalAmount]] unit:@"USD"];
                
            }else{
                self.amountLabel.attributedText=[self formattedAmount:[NSString formattedStringWithDouble:orderModel.totalAmount] unit:@"USD"];
             
            }
        }
        else{
            if (orderModel.totalAmount>0) {
                self.amountLabel.attributedText=[self formattedAmount:[NSString stringWithFormat:@"+%@",[NSString formattedStringWithDouble:orderModel.totalAmount]] unit:orderModel.currency];
            }else{
              
                self.amountLabel.attributedText=[self formattedAmount:[NSString formattedStringWithDouble:orderModel.totalAmount] unit:orderModel.currency];
            }
        }
        
    }else{
        //卡流水
        if ([orderModel.type isEqualToString:@"top_up"]||[orderModel.type isEqualToString:@"withdrawal"]){
            //充提币单位写死
            if (orderModel.amount>0) {
                self.amountLabel.attributedText=[self formattedAmount:[NSString stringWithFormat:@"+%@",[NSString formattedStringWithDouble:orderModel.amount]] unit:@"USD"];
                
            }else{
                self.amountLabel.attributedText=[self formattedAmount:[NSString formattedStringWithDouble:orderModel.amount] unit:@"USD"];
            }
        }
        else{
            if (orderModel.amount>0) {
                self.amountLabel.attributedText=[self formattedAmount:[NSString stringWithFormat:@"+%@",[NSString formattedStringWithDouble:orderModel.amount]] unit:orderModel.currency];
            }else{
                self.amountLabel.attributedText=[self formattedAmount:[NSString formattedStringWithDouble:orderModel.amount] unit:orderModel.currency];
            }
        }
        
        
        
    }
  
}


//获取订单状态文字颜色
-(UIColor*)getStatusColorWithstatus:(int)status{
    
    UIColor*statusColor=[UIColor colorWithHexString:@"000000" alpha:0.6];
    switch (status)
    {
        case 1://确认中
            statusColor=[UIColor colorWithHexString:@"#FA6400" alpha:1.0];
            break;
        case 2://已完成
            statusColor=[UIColor colorWithHexString:@"#6DD400" alpha:1.0];
            break;
        case 3://已取消
            statusColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0];
            break;
        case 4://已授权
            statusColor=[UIColor colorWithHexString:@"#6DD400" alpha:1.0];
            break;
        default:
            break;
    }
    return  statusColor;
    
}


//获取状态
-(NSString*)getStatusStringWithstatus:(int)status{
    
    NSString*statusString=LocalizationKey(@"未知");
    switch (status) {
        case 1:
            statusString=LocalizationKey(@"确认中");
            break;
        case 2:
            statusString=LocalizationKey(@"已完成");
            break;
        case 3:
            statusString=LocalizationKey(@"已取消");
            break;
        case 4:
            statusString=LocalizationKey(@"已授权");
            break;
        default:
            break;
    }
    
    return  statusString;
    
}


-(void)awakeFromNib{
    [super awakeFromNib];

}

- (NSAttributedString *)formattedAmount:(NSString *)amount unit:(NSString *)unit {
    if (!amount) amount = @"";
    if (!unit) unit = @"";

    NSString *fullString = [NSString stringWithFormat:@"%@ %@", amount, unit];
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:fullString];

    // 设置 amount 部分字体大小为 31（不含空格）
    [attrString addAttribute:NSFontAttributeName
                       value:PingFangMediumFont(31)
                       range:NSMakeRange(0, amount.length)];

    // 设置 unit 部分字体大小为 19（跳过空格）
    [attrString addAttribute:NSFontAttributeName
                       value:PingFangMediumFont(19)
                       range:NSMakeRange(amount.length + 1, unit.length)];

    return attrString;
}


@end
