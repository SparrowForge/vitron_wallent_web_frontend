//
//  FilterItemCell.m
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FilterItemCell.h"
/// 定义全局默认大小
static CGSize kDefaultCloseButtonSize = {14,14};

@implementation FilterItemCell

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 4;
        self.layer.masksToBounds = YES;
        
        // Label
        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.font = [UIFont systemFontOfSize:13];
        self.titleLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLabel];
        
        // Close Button
        self.closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.closeButton setBackgroundImage:UIIMAGE(@"filterTop_cancel") forState:UIControlStateNormal];
        self.closeButton.tintColor = [UIColor blackColor];
        self.closeButton.frame = CGRectMake(0, 0, kDefaultCloseButtonSize.width, kDefaultCloseButtonSize.height);
        self.closeButton.hidden = YES;
        [self.closeButton addTarget:self action:@selector(closeTapped) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.closeButton];
        self.contentView.backgroundColor=[UIColor whiteColor];
        self.contentView.layer.borderWidth=0.5;
        self.contentView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        [self.contentView setCornerRadius:16];
        
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGSize textSize = [self.titleLabel.text sizeWithAttributes:@{NSFontAttributeName: self.titleLabel.font}];
    CGFloat padding = 16;
    
    if (self.type == FilterItemCellTypeNormal) {
        self.titleLabel.frame = CGRectMake(padding, (self.bounds.size.height - kDefaultCloseButtonSize.width) / 2, self.bounds.size.width - 2 * padding, kDefaultCloseButtonSize.width);
        self.closeButton.hidden = YES;
        self.contentView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        
    } else {
        self.titleLabel.frame = CGRectMake(padding, (self.bounds.size.height - kDefaultCloseButtonSize.width) / 2, textSize.width, kDefaultCloseButtonSize.width);
        self.closeButton.frame = CGRectMake(CGRectGetMaxX(self.titleLabel.frame) + 6, (self.bounds.size.height - kDefaultCloseButtonSize.width) / 2, kDefaultCloseButtonSize.width, kDefaultCloseButtonSize.height);
        self.closeButton.hidden = NO;
        self.contentView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0].CGColor;
    }
}

- (void)setText:(NSString *)text {
    _text = text;
    self.titleLabel.text = text;
    [self setNeedsLayout];
}

- (void)setType:(FilterItemCellType)type {
    _type = type;
    [self setNeedsLayout];
}

- (void)setSelectedState:(BOOL)selected {
    if (selected) {
        self.titleLabel.textColor = [UIColor whiteColor];
        self.contentView.backgroundColor = [UIColor blueColor];
    } else {
        self.titleLabel.textColor = [UIColor blackColor];
        self.contentView.backgroundColor = [UIColor lightGrayColor];
    }
}

- (void)closeTapped {
    if (self.onCloseTapped) {
        self.onCloseTapped();
    }
}


@end
