//
//  WithdrawApplyView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^WithdrawBlock)(NSString* _Nullable feeString,NSString*_Nullable estimateString);
typedef void(^BtnColorBlock)(int status);
NS_ASSUME_NONNULL_BEGIN

@interface WithdrawApplyView : UIView
@property (weak, nonatomic) IBOutlet UIView *amountView;
@property (weak, nonatomic) IBOutlet UILabel *useAbleLabel;
@property (weak, nonatomic) IBOutlet UITextField *amountTF;
@property (weak, nonatomic) IBOutlet UIView *coinTypeView;
@property (weak, nonatomic) IBOutlet UIView *netView;
@property (weak, nonatomic) IBOutlet UITextField *netTF;
@property (weak, nonatomic) IBOutlet UIView *addressView;
@property (weak, nonatomic) IBOutlet UITextField *addressTF;
@property (weak, nonatomic) IBOutlet UILabel *rateLabel;
@property (weak, nonatomic) IBOutlet UILabel *feeLabel;
@property (weak, nonatomic) IBOutlet UILabel *estimateLabel;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property (weak, nonatomic) IBOutlet UILabel *withdrawTitle;
@property (weak, nonatomic) IBOutlet UILabel *netTiltle;
@property (weak, nonatomic) IBOutlet UILabel *gatherAddressTitle;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property(nonatomic,strong)NSDictionary*configDic;
@property (nonatomic, copy) WithdrawBlock withdrawBlock;
@property (nonatomic, copy) BtnColorBlock btnColorBlock;

+ (WithdrawApplyView *)instanceViewWithFrame:(CGRect)Rect;

-(void)toSubmit;
@end

NS_ASSUME_NONNULL_END
