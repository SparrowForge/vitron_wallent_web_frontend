//
//  WithdrawTipsView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "WithdrawTipsView.h"

@interface WithdrawTipsView()
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *rateTitle;
@property (weak, nonatomic) IBOutlet UILabel *withdrawRateTitle;

@end



@implementation WithdrawTipsView

+ (WithdrawTipsView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"WithdrawTipsView" owner:nil options:nil];
    WithdrawTipsView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
//    property.popupAlignment = FWPopupAlignmentCenter;
//    property.popupAnimationStyle = FWPopupAnimationStyleScale3D;
    property.popupAlignment = FWPopupAlignmentCenter;
    property.popupAnimationStyle = FWPopupAnimationStyleScale3D;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 20);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor whiteColor];
    view.vProperty = property;
    [view setCornerRadius:20];
    view.rateTitle.text=LocalizationKey(@"汇率");
    view.withdrawRateTitle.text=LocalizationKey(@"提币费率");
    view.coinLabel.font=PingFangMediumFont(15);
    view.rateLabel.font=PingFangMediumFont(15);
    return view;
}


@end
