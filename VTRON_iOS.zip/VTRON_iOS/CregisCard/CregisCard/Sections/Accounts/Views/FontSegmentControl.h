//
//  FontSegmentControl.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/10.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@protocol FontSegmentControlDelegate <NSObject>
- (CGFloat)segmentControlTitleSizeForIndex:(NSInteger)index;
@end
@interface FontSegmentControl : UIView
@property (nonatomic, assign) NSInteger selectedSegmentIndex;
@property (nonatomic, strong) UIColor *selectedBgColor;
@property (nonatomic, strong) UIColor *backBgColor;
@property (nonatomic, strong) UIColor *selectedTextColor;
@property (nonatomic, strong) UIColor *normalTextColor;
@property (nonatomic, copy)   void (^selectIndex)(NSInteger index);
@property (nonatomic, weak)   id<FontSegmentControlDelegate> delegate;

- (instancetype)initWithFrame:(CGRect)frame Items:(NSArray<NSString *> *)items;
-(void)setupUI;

@end

NS_ASSUME_NONNULL_END
