//
//  VerifyPermissionView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "VerifyPermissionView.h"
#import "YCMenuView.h"

@interface VerifyPermissionView()
{
    int _verifyType;//0 邮箱验证 1谷歌验证；默认邮箱验证
}
@property(nonatomic,strong) YCMenuView *menuView;

@end

@implementation VerifyPermissionView

+ (VerifyPermissionView *)instanceViewWithFrame:(CGRect)Rect withVerifyPermissionType:(VerifyPermissionType)permissionType{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"VerifyPermissionView" owner:nil options:nil];
    VerifyPermissionView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    view.permissionType=permissionType;
    if (view.permissionType==CardFreeze) {
        CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
        view.topAlertH.constant=44+addtionalHeight;
        view.topAlertView.hidden=NO;
        view.alertLabel.text=LocalizationKey(@"冻结后，卡片将不可使用，请谨慎操作！");
    }
    else if (view.permissionType==CardThaw) {
        CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
        view.topAlertH.constant=44+addtionalHeight;
        view.topAlertView.hidden=NO;
        view.alertLabel.text=LocalizationKey(@"解冻后，卡片将恢复使用，请谨慎操作！");
    }
   else if (view.permissionType==CardUnsubscribe) {
       CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
        view.topAlertH.constant=44+addtionalHeight;
        view.topAlertView.hidden=NO;
       view.alertLabel.text=LocalizationKey(@"注销后，卡片将被作废，请谨慎操作！");
    }
    else{
        view.topAlertH.constant=0;
        view.topAlertView.hidden=YES;
    }
    view.pswTitle.font=PingFangMediumFont(13);
    view.codeTitle.font=PingFangMediumFont(13);
    view.titleLabel.font=PingFangMediumFont(19);
    
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self setBorderView:self.pswView];
    [self setBorderView:self.codeView];
    self.cancelBtn.titleLabel.font=PingFangMediumFont(15);
    self.confirmLabel.font=PingFangMediumFont(15);
    self.pswTitle.text=LocalizationKey(@"交易密码");
    self.codeTitle.text=LocalizationKey(@"邮箱验证码");
    [self.pswTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.codeTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.verifyCodeBtn setTitle:LocalizationKey(@"获取") forState:UIControlStateNormal];
    self.verifyCodeBtn.titleLabel.font=PingFangMediumFont(13);
    self.confirmLabel.text=LocalizationKey(@"提交");
    [self.cancelBtn setTitle:LocalizationKey(@"取消") forState:UIControlStateNormal];
    [self.pswTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.codeTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    self.okBtn.enabled=NO;
    self.confirmLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.cancelBtn.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    self.cancelBtn.layer.borderWidth=0.5;
    self.indicatorView.hidden=YES;
    _verifyType=0;
    if ([[UserWrapper shareUserInfo].emailCheck intValue]==0) {
        self.emailTitleView.hidden=YES;
        self.codeView.hidden=YES;
    }
    
}


-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
    [self.topAlertView setCornerRadius:12.0];
    /*
    if (self.permissionType==AccountWithdraw) {
        self.titleLabel.text=LocalizationKey(@"安全验证");//提币验证
    }else if (self.permissionType==CardRecharge){
        self.titleLabel.text=LocalizationKey(@"充值确认");
        
    }else if (self.permissionType==CardRefund){
        self.titleLabel.text=LocalizationKey(@"退款确认");
    }
    else if (self.permissionType==CardFreeze){
        self.titleLabel.text=LocalizationKey(@"卡冻结安全验证");
    }
    else if (self.permissionType==CardThaw){
        self.titleLabel.text=LocalizationKey(@"卡解冻安全验证");
    }else if (self.permissionType==CardUnsubscribe){
        self.titleLabel.text=LocalizationKey(@"卡注销安全验证");
    }else if (self.permissionType==CardToOpen){
        self.titleLabel.text=LocalizationKey(@"申请卡片确认");
    }
    else if (self.permissionType==TransferCoin){
        self.titleLabel.text=LocalizationKey(@"转账验证");
    }
    
    else if (self.permissionType==ActivateCard){
        self.titleLabel.text=LocalizationKey(@"安全验证");
    }
    else if (self.permissionType==GetActivateCardCode){
        self.titleLabel.text=LocalizationKey(@"获取激活码");
    }
    else if (self.permissionType==SetCardPINCode){
        self.titleLabel.text=LocalizationKey(@"安全验证");
    }
    else if (self.permissionType==EmailCard||self.permissionType==EmailCards){
        self.titleLabel.text=LocalizationKey(@"安全验证");
    }
    else if (self.permissionType==Phone_manage){
        self.titleLabel.text=LocalizationKey(@"安全验证");
    }
    else if (self.permissionType==Email_manage){
        self.titleLabel.text=LocalizationKey(@"安全验证");
    }
    else if (self.permissionType==TransferCard){
        self.titleLabel.text=LocalizationKey(@"安全验证");
    }
    else{
        
        
    }
     */
    self.titleLabel.text=LocalizationKey(@"安全验证");//全部改成安全验证
    
}



- (IBAction)closeClick:(id)sender {
    [self hide];
}


- (IBAction)eventClick:(UIButton *)sender {
    if (sender.tag==0) {
        //隐藏或显示交易密码
        sender.selected=!sender.selected;
        self.pswTF.secureTextEntry=sender.selected?NO:YES;
    }else if (sender.tag==1){
        //切换邮箱或谷歌验证
        [self changeCodeView];
        
    }else if (sender.tag==2){
       //发送邮箱验证码
        [self getEmailVerifyCode];
    }else{
        //点击确定按钮
        [self confirmToOperate];
    }
    
}
//MARK: 确定
-(void)confirmToOperate{
    
    if ([NSString stringIsNull:self.pswTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入交易密码"));
        return;
    }
    if ([[UserWrapper shareUserInfo].emailCheck intValue]==1) {
        //需要邮箱/谷歌验证
        if ([NSString stringIsNull:self.codeTF.text]) {
            if (_verifyType==0) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
            }else{
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入谷歌验证码"));
            }
            return;
        }
        
        if (self.verifyBlock) {
            self.verifyBlock(self.pswTF.text, self.codeTF.text, _verifyType);
        }
    }else{
        //不需要邮箱/谷歌验证
        if (self.verifyBlock) {
            self.verifyBlock(self.pswTF.text,@"",0);
        }
    }
    
}


//MARK: 发送邮箱或谷歌验证码
-(void)getEmailVerifyCode{
    NSString*typeString=@"";
    if (self.permissionType==AccountWithdraw) {
        typeString=@"withdraw";
    }else if (self.permissionType==CardRecharge){
        typeString=@"rechargeCard";
        
    }else if (self.permissionType==CardRefund){
        typeString=@"refundCard";
    } else if (self.permissionType==CardFreeze){
        typeString=@"frozenCard";
    }
    else if (self.permissionType==CardThaw){
        typeString=@"unfrozenCard";
    }else if (self.permissionType==CardUnsubscribe){
        typeString=@"closeCard";
    }else if (self.permissionType==CardToOpen){
        typeString=@"applyCard";
    }else if (self.permissionType==TransferCoin){
        typeString=@"walletTransfer";
    }
    else if (self.permissionType==ActivateCard){
        typeString=@"activeCard";
    }else if (self.permissionType==GetActivateCardCode){
        typeString=@"activeCodeCheck";
    }else if (self.permissionType==SetCardPINCode){
        typeString=@"setPin";
    }else if (self.permissionType==EmailCard){
        typeString=@"shipCard";
    }
    else if (self.permissionType==EmailCards){
        typeString=@"bulkShipCard";
    }
    else if (self.permissionType==Phone_manage){
        typeString=@"otpPhone";
    }
    else if (self.permissionType==Email_manage){
        typeString=@"otpEmail";
    }
    else if (self.permissionType==TransferCard){
        typeString=@"transferCard";
    }
    else if (self.permissionType==BeexRechargeCard){
        typeString=@"depositCard";
    }
    else if (self.permissionType==BeexWithdrawCard){
        typeString=@"withdrawCard";
    }
    else if (self.permissionType==CardDetail){
        typeString=@"cardDetail";
    }
    else{
        
    }
    
    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":typeString} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[NSString maskEmail:[UserWrapper shareUserInfo].email]];
            self.emailAlert.text=email;
            self.emailAlert.hidden=NO;
            [self CountDown:59];
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

/* 倒计时 */
- (void)CountDown:(int)timeDistance{
    __block NSInteger time = timeDistance; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    self._timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    dispatch_source_set_timer(self._timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(self._timer, ^{
        
        if(time <= 0){ //倒计时结束，关闭
            
            dispatch_source_cancel(self._timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置按钮的样式
                [self.verifyCodeBtn setTitle:LocalizationKey(@"重新发送") forState:UIControlStateNormal];
                [self.verifyCodeBtn setTitleColor:[UIColor baseColor] forState:UIControlStateNormal];
                self.verifyCodeBtn.userInteractionEnabled = YES;
                
            });
            
        }else{
            
            int seconds = (int)time ;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //设置按钮显示读秒效果
                [self.verifyCodeBtn setTitle:[NSString stringWithFormat:@"%.2ldS",(long)seconds] forState:UIControlStateNormal];
                [self.verifyCodeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                self.verifyCodeBtn.userInteractionEnabled = NO;
            });
            time--;
        }
    });
    dispatch_resume(self._timer);
}



//MARK: 切换验证方式
-(void)changeCodeView{
/*
    WEAKSELF
    UIImage *emailImage =_verifyType==0? UIIMAGE(@"check_account"):UIIMAGE(@"checkNo_account");
    UIImage *googleImage = _verifyType==0? UIIMAGE(@"checkNo_account"):UIIMAGE(@"check_account");
    YCMenuAction*action0 = [YCMenuAction actionWithTitle:LocalizationKey(@"邮箱") image:emailImage handler:^(YCMenuAction *action) {

          self->_verifyType=0;
          weakSelf.tipsView.hidden=NO;
          weakSelf.verifyCodeBtn.hidden=NO;
          weakSelf.verifyCodeWidth.constant=95;
          [weakSelf.verifyTypeBtn setTitle:LocalizationKey(@"邮箱") forState:UIControlStateNormal];
           }];
        YCMenuAction *action1 = [YCMenuAction actionWithTitle:LocalizationKey(@"谷歌") image:googleImage handler:^(YCMenuAction *action) {
            self->_verifyType=1;
            weakSelf.tipsView.hidden=YES;
            weakSelf.verifyCodeBtn.hidden=YES;
            weakSelf.verifyCodeWidth.constant=0;
            [weakSelf.verifyTypeBtn setTitle:LocalizationKey(@"谷歌") forState:UIControlStateNormal];
           }];
           
        NSMutableArray * array =  [NSMutableArray array];
        [array addObject:action0];
        [array addObject:action1];
        self.menuView = [YCMenuView menuWithActions:array width:120 relyonView:self.verifyTypeBtn];
        self.menuView.menuColor=[UIColor whiteColor];
        self.menuView.menuCellHeight=55;
        self.menuView.textColor=[UIColor blackColor];
        self.menuView.maxDisplayCount = 2;
        [self.menuView show];
  
    */
}

-(void)setActivateCardString:(NSString *)activateCardString{
    _activateCardString=activateCardString;
    self.topAlertH.constant=44+30;
    self.topAlertView.hidden=NO;
    self.alertLabel.text=activateCardString;
    
    
}

//切换验证码
- (IBAction)changeClick:(UIButton *)sender {
    _verifyType=_verifyType==0?1:0;
    if (_verifyType==0) {
        //邮箱验证
        self.codeTitle.text=LocalizationKey(@"邮箱验证码");
        self.verifyCodeBtn.hidden=NO;
        self.verifyCodeWidth.constant=95;
        if (![NSString stringIsNull:self.emailAlert.text]) {
            self.emailAlert.hidden=NO;
        }
    }else{
        //谷歌验证
        self.codeTitle.text=LocalizationKey(@"谷歌验证码");
        self.verifyCodeBtn.hidden=YES;
        self.verifyCodeWidth.constant=0;
        if (!self.emailAlert.hidden) {
            self.emailAlert.hidden=YES;
        }
    }
    
}

-(void)startAnimation{
    self.indicatorView.hidden=NO;
    [self.indicatorView startAnimating];
    
}
-(void)stopAnimation{
    self.indicatorView.hidden=YES;
    [self.indicatorView stopAnimating];
    
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    [self judgeBtnStatus];
}

-(void)judgeBtnStatus{
    
    if ([[UserWrapper shareUserInfo].emailCheck intValue]==1) {
        //需要邮箱/谷歌验证码
        if ([NSString stringIsNull:self.codeTF.text]||[NSString stringIsNull:self.pswTF.text]) {
            self.okBtn.enabled=NO;
            self.confirmLabel.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        }else{
            self.okBtn.enabled=YES;
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
            self.confirmLabel.textColor=[UIColor whiteColor];
        }
       
        
    }else{
        //不需要邮箱/谷歌验证码
        if ([NSString stringIsNull:self.pswTF.text]) {
            self.okBtn.enabled=NO;
            self.confirmLabel.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        }else{
            self.okBtn.enabled=YES;
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
            self.confirmLabel.textColor=[UIColor whiteColor];
        }
       
        
    }
    
    
}


-(void)resetBtnColor{
    
    self.pswTF.text=@"";
    self.okBtn.enabled=NO;
    self.confirmLabel.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
}


@end
