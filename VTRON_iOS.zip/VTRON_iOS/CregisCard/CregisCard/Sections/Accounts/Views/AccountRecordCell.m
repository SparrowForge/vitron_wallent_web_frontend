//
//  AccountRecordCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "AccountRecordCell.h"

@implementation AccountRecordCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentView.backgroundColor=[UIColor whiteColor];
    self.titleLabel.font=PingFangMediumFont(15);
    self.amountLabel.font=PingFangMediumFont(15);
//    [self.boardView setCornerRadius:10];
//    //四边添加阴影
//    self.boardView.layer.shadowColor = [UIColor grayColor].CGColor;//阴影颜色
//    self.boardView.layer.shadowOffset = CGSizeMake(0, 0);//阴影的偏移量
//    self.boardView.layer.shadowOpacity = 0.2;//阴影透明度
//    self.boardView.layer.shadowRadius = 10.0;//阴影圆角
//    self.boardView.clipsToBounds=NO;//这个属性为NO是必须的，不然阴影不会显示
    // Initialization code
}


-(void)configDataWithModel:(OrderRecordModel*)model withType:(int)type{
    if (type==0) {
        //钱包流水
        self.titleLabel.text=[self getTypeNameWithType:model.type withlistType:type];
       
        if ([model.type isEqualToString:@"top_up"]||[model.type isEqualToString:@"withdrawal"]){
            //充提币单位写死
            if (model.totalAmount>0) {
                self.amountLabel.text=[NSString stringWithFormat:@"+%@ %@",[NSString formattedStringWithDouble:model.totalAmount],@"USD"];
            }else{
                self.amountLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:model.totalAmount],@"USD"];
            }
           
        }else{
            if (model.totalAmount>0) {
                self.amountLabel.text=[NSString stringWithFormat:@"+%@ %@",[NSString formattedStringWithDouble:model.totalAmount],[NSString dealWithCurrency:model.currency]];
                
            }else{
                self.amountLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:model.totalAmount],[NSString dealWithCurrency:model.currency]];
                
            }
            
        }
        
    }else{
        //卡片流水
        if ([model.type isEqualToString:@"program_fee_card"]) {
            //卡交易
            self.titleLabel.text=[self trimStringIfNeeded:model.consumerMerchantName];
        }else{
            self.titleLabel.text=[self getTypeNameWithType:model.type withlistType:type];
        }
      
        if ([model.type isEqualToString:@"top_up"]||[model.type isEqualToString:@"withdrawal"]){
            //充提币单位写死
            if (model.amount>0) {
                self.amountLabel.text=[NSString stringWithFormat:@"+%@ %@",[NSString formattedStringWithDouble:model.amount],@"USD"];
            }else{
                self.amountLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:model.amount],@"USD"];
            }
           
        }else{
            if (model.amount>0) {
                self.amountLabel.text=[NSString stringWithFormat:@"+%@ %@",[NSString formattedStringWithDouble:model.amount],[NSString dealWithCurrency:model.currency]];
                
            }else{
                self.amountLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:model.amount],[NSString dealWithCurrency:model.currency]];
                
            }
            
        }
    }
   
   
   
    self.timeLabel.textColor=[UIColor colorWithHexString:@"000000" alpha:0.4];
    self.timeLabel.text=[NSString convertDateString:model.createTime];
    self.statusLabel.textColor=[UIColor colorWithHexString:@"000000" alpha:0.6];
    self.statusLabel.text=[self getStatusStringWithstatus:[model.status intValue]];
    self.statusIcon.image=UIIMAGE([self getTypeImageNameWithType:model.type withlistType:type]);
    
}

//获取类型
-(NSString*)getTypeNameWithType:(NSString*)type withlistType:(int)listType{
    NSString*lastType=LocalizationKey(@"未知");
    if ([type isEqualToString:@"top_up"]) {
        lastType=LocalizationKey(@"充值");
    }else if ([type isEqualToString:@"withdrawal"]){
        lastType=LocalizationKey(@"提币");
        
    }else if ([type isEqualToString:@"create_card"]){
        lastType=LocalizationKey(@"卡片申请");
        
    }else if ([type isEqualToString:@"deposit_card"]){
        lastType=LocalizationKey(@"卡片充值");
        
    }else if ([type isEqualToString:@"program_fee_card"]){
        if (listType==0) {
            lastType=LocalizationKey(@"卡手续费");
        }else{
            lastType=LocalizationKey(@"消费");

        }
        
    }else if ([type isEqualToString:@"withdraw_card"]){
        lastType=LocalizationKey(@"卡片提现");
        
    }else if ([type isEqualToString:@"transfer"]){
        lastType=LocalizationKey(@"转账");
        
    }else if ([type isEqualToString:@"receive"]){
        lastType=LocalizationKey(@"收款");
        
    }else if ([type isEqualToString:@"correction"]){
        lastType=LocalizationKey(@"冲正");
        ////////
        ///
    }else if ([type isEqualToString:@"refund_card"]){
        lastType=LocalizationKey(@"退款");
        
    }else if ([type isEqualToString:@"verification_card"]){
        lastType=LocalizationKey(@"验证");
        
    }else if ([type isEqualToString:@"fee_card"]){
        lastType=LocalizationKey(@"卡费");
        
    }else if ([type isEqualToString:@"reversal_card"]){
        lastType=LocalizationKey(@"撤销");
        
    }else if ([type isEqualToString:@"atm_fee_card"]){
        lastType=LocalizationKey(@"ATM");
        
    }
   
    return lastType;
}


//获取图片
-(NSString*)getTypeImageNameWithType:(NSString*)type withlistType:(int)listType{
    
    NSString*lastType=@"";
    if ([type isEqualToString:@"top_up"]) {
        lastType=@"filter_charge_small";
    }else if ([type isEqualToString:@"withdrawal"]){
        lastType=@"filter_withdraw_small";
        
    }else if ([type isEqualToString:@"create_card"]){
        lastType=@"filter_apply_small";
        
    }else if ([type isEqualToString:@"deposit_card"]){
        lastType=@"filter_cardRecharge_small";
        
    }else if ([type isEqualToString:@"program_fee_card"]){
        if (listType==0) {
            lastType=@"filter_cardContine_small";
        }else{
            lastType=@"filter_consumption_small";

        }
       
        
    }else if ([type isEqualToString:@"withdraw_card"]){
        lastType=@"filter_cardWithdraw_small";
        
    }else if ([type isEqualToString:@"transfer"]){
        lastType=@"filter_transfer_small";
        
    }else if ([type isEqualToString:@"receive"]){
        lastType=@"filter_receive_small";
        
    }else if ([type isEqualToString:@"correction"]){
        lastType=@"filter_restore_small";
        ////////
        ///
    }else if ([type isEqualToString:@"refund_card"]){
        lastType=@"filter_refund_small";
        
    }else if ([type isEqualToString:@"verification_card"]){
        lastType=@"filter_verify_small";
        
    }else if ([type isEqualToString:@"fee_card"]){
        lastType=@"filter_cardfee_small";
        
    }else if ([type isEqualToString:@"reversal_card"]){
        lastType=@"filter_reject_small";
        
    }else if ([type isEqualToString:@"atm_fee_card"]){
        lastType=@"filter_atm_small";
        
    }
   
    return lastType;
}


//获取卡流水状态
-(NSString*)getStatusStringWithstatus:(int)status{
    
    NSString*statusString=LocalizationKey(@"未知");
    switch (status) {
        case 1:
            statusString=LocalizationKey(@"确认中");
            break;
        case 2:
            statusString=LocalizationKey(@"已完成");
            break;
        case 3:
            statusString=LocalizationKey(@"已取消");
            break;
       
        default:
            break;
    }
    
    return  statusString;
    
}
-(NSString *)trimStringIfNeeded:(NSString *)input {
    if (!input || input.length <= 10) {
        return input;
    }
    NSString *trimmed = [input substringToIndex:10];
    return [NSString stringWithFormat:@"%@...", trimmed];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
