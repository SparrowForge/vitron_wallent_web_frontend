//
//  TransactionDetailCell.h
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "OrderRecordModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface TransactionDetailCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *boardView;

-(void)configDataWithModel:(OrderRecordModel*)orderModel AtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray;


@end

NS_ASSUME_NONNULL_END
