//
//  FilterDatePickerView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FilterDatePickerView.h"

@interface FilterDatePickerView () <UIPickerViewDataSource, UIPickerViewDelegate>
@property (nonatomic, strong) UIPickerView *pickerView;
@property (nonatomic, strong) NSArray *years;
@property (nonatomic, strong) NSArray *months;
@property (nonatomic, strong) NSArray *days;
@property (nonatomic, strong) NSDateFormatter *formatter;
@end

@implementation FilterDatePickerView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupData];
        [self setupViews];
    }
    return self;
}

- (void)setupData {
    NSMutableArray *yearArray = [NSMutableArray array];
    for (int i = 1970; i <= 2100; i++) {
        [yearArray addObject:[NSString stringWithFormat:@"%d", i]];
    }
    self.years = yearArray;

    NSMutableArray *monthArray = [NSMutableArray array];
    for (int i = 1; i <= 12; i++) {
        [monthArray addObject:[NSString stringWithFormat:@"%02d", i]];
    }
    self.months = monthArray;

    [self updateDaysForYear:2024 month:1];
    
    self.formatter = [[NSDateFormatter alloc] init];
    self.formatter.dateFormat = @"yyyy.MM.dd";
}

- (void)setupViews {
    self.pickerView = [[UIPickerView alloc] initWithFrame:self.bounds];
    self.pickerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.pickerView.delegate = self;
    self.pickerView.dataSource = self;
    [self addSubview:self.pickerView];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 3;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component == 0) return self.years.count;
    if (component == 1) return self.months.count;
    return self.days.count;
}
#pragma mark - UIPickerViewDelegate
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == 0) return self.years[row];
    if (component == 1) return self.months[row];
    return self.days[row];
}
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 36;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (component == 0 || component == 1) {
        NSInteger year = [self.years[[pickerView selectedRowInComponent:0]] intValue];
        NSInteger month = [self.months[[pickerView selectedRowInComponent:1]] intValue];
        [self updateDaysForYear:year month:month];
        [pickerView reloadComponent:2];
    }
    [self notifyDateSelected];
}
- (void)notifyDateSelected {
    NSInteger year = [self.years[[self.pickerView selectedRowInComponent:0]] intValue];
    NSInteger month = [self.months[[self.pickerView selectedRowInComponent:1]] intValue];
    NSInteger day = [self.days[[self.pickerView selectedRowInComponent:2]] intValue];
    
    NSString *dateString = [NSString stringWithFormat:@"%04ld.%02ld.%02ld", (long)year, (long)month, (long)day];
    
    if (self.didSelectDate) {
        self.didSelectDate(dateString);
    }
}

#pragma mark - Helpers
- (void)updateDaysForYear:(NSInteger)year month:(NSInteger)month {
    NSInteger daysInMonth = 31;
    switch (month) {
        case 2:
            daysInMonth = [self isLeapYear:year] ? 29 : 28;
            break;
        case 4: case 6: case 9: case 11:
            daysInMonth = 30;
            break;
        default:
            daysInMonth = 31;
    }
    NSMutableArray *dayArray = [NSMutableArray array];
    for (int i = 1; i <= daysInMonth; i++) {
        [dayArray addObject:[NSString stringWithFormat:@"%02d", i]];
    }
    self.days = dayArray;
}

- (BOOL)isLeapYear:(NSInteger)year {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

- (void)setDefaultDate:(NSDate *)date {
    if (!date) return;
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date];
    NSInteger yearIndex = [self.years indexOfObject:[NSString stringWithFormat:@"%ld", (long)components.year]];
    NSInteger monthIndex = components.month - 1;
    
    [self updateDaysForYear:components.year month:components.month];
    
    NSInteger dayIndex = components.day - 1;
    
    [self.pickerView reloadAllComponents];
    [self.pickerView selectRow:yearIndex inComponent:0 animated:NO];
    [self.pickerView selectRow:monthIndex inComponent:1 animated:NO];
    [self.pickerView selectRow:dayIndex inComponent:2 animated:NO];
    
    [self notifyDateSelected];
}


- (void)setDefaultDateString:(NSString *)dateString {
    if (!dateString || dateString.length == 0) return;
    NSDateFormatter*formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy.MM.dd";
    NSDate *date = [formatter dateFromString:dateString];
    if (date) {
        [self setDefaultDate:date];
    }
}
@end
