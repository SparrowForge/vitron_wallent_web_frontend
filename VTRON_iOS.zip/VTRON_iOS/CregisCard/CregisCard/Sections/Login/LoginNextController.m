//
//  LoginNextController.m
//  CregisCard
//
//  Created by 孙良 on 2024/10/31.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "LoginNextController.h"
#import "RegisterController.h"
#import "Masonry.h"
#import "SelectMenuView.h"
#import "CardDetailPermissionView.h"
#import "CustomTabBarController.h"
#import "LoginController.h"
#import "MineNetWorkManager.h"

@interface LoginNextController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIView *accountView;
@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UIView *pswView;
@property (weak, nonatomic) IBOutlet UITextField *pswTF;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *loginLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailAlertLabel;
@property (weak, nonatomic) IBOutlet UILabel *pswAlertLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emailTitleHeight;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicatorView;
@property (weak, nonatomic) IBOutlet UIButton *registerBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UILabel *accountLabel;
@property (weak, nonatomic) IBOutlet UILabel *pswLabel;
@property (weak, nonatomic) IBOutlet UIButton *forgetBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tipsDistance;


@property(nonatomic,strong) UIButton*countryBtn;
@property(nonatomic,strong) UIImageView*countryImageV;
@property(nonatomic,strong) SelectMenuView*selectView;
@property(nonatomic,strong) CardDetailPermissionView*loginAuthView;
@property(nonatomic,strong) NSDictionary*currentLanguageDic;
@end

@implementation LoginNextController


- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 160+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectLanguage];
    }
    return _selectView;
}

- (CardDetailPermissionView *)loginAuthView {
    if(!_loginAuthView) {
        _loginAuthView=[CardDetailPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320)withVerifyPermissionType:LoginServer];
    }
    return _loginAuthView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.okBtn.enabled=NO;
    self.loginLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.loginLabel.font=PingFangMediumFont(15);
    [self setBorderView:self.accountView];
    [self setBorderView:self.pswView];
    [self setTextFieldObserverWithtextField:self.accountTF];
    [self setTextFieldObserverWithtextField:self.pswTF];
    self.pswAlertLabel.hidden=YES;
    self.emailAlertLabel.hidden=YES;
    self.emailTitleHeight.constant=0;
    self.tipsDistance.constant=0;
    self.pswTitleHeight.constant=0;
    self.accountLabel.font=PingFangMediumFont(13);
    self.pswLabel.font=PingFangMediumFont(13);
#if DEBUG == 1
    self.accountTF.text = @"1825571811@qq.com";
    self.pswTF.text=@"Aa123456";
    self.okBtn.enabled=YES;
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    self.loginLabel.textColor=[UIColor whiteColor];
#endif
    self.indicatorView.hidden=YES;
    [self setLanguage];
    if (![NSString stringIsNull:self.account]) {
        self.accountTF.text=self.account;//默认填充
    }
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self setRightBar];
    [self setLanguage];
}

//隐藏或显示密码
- (IBAction)eyeClick:(UIButton *)sender {
    sender.selected=!sender.selected;
    self.pswTF.secureTextEntry=sender.selected?NO:YES;
    
}


//去登录
- (IBAction)okClick:(UIButton *)sender {
    
    if ([NSString stringIsNull:self.accountTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
        return;
    }
    if ([NSString stringIsNull:self.pswTF.text]) {
       
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入密码"));
        return;
    }
  
    [self checkUserNameAndPassword];
}

//校验用户名和密码是否匹配
-(void)checkUserNameAndPassword{
    
    [SVProgressHUD customShowWithNone];
    self.indicatorView.hidden=NO;
    [self.indicatorView startAnimating];
    NSDictionary*dic=@{@"username":self.accountTF.text,@"password":self.pswTF.text};
    [LoginNetWorkManager loginForCheckPasswordWithParams:dic success:^(id  _Nonnull data) {
        
        [SVProgressHUD dismiss];
        self.indicatorView.hidden=YES;
        [self.indicatorView stopAnimating];
        if (![data isKindOfClass:[NSDictionary class]]) {
            return;
        }
        if ([data[@"code"] intValue]==200) {
            self.loginAuthView.email=self.accountTF.text;
            [self.loginAuthView show];
            WEAKSELF
            self.loginAuthView.verifyBlock = ^(NSString * _Nullable code, int type) {
                [weakSelf toLoginServerwithcode:code withType:type];
            };
            
        }
        else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        self.indicatorView.hidden=YES;
        [self.indicatorView stopAnimating];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
  
}
//登录业务系统
-(void)toLoginServerwithcode:(NSString*)code withType:(int)type{
    NSString*codeType=type==0?@"code":@"googleCode";
    NSDictionary*dic=@{@"username":self.accountTF.text,@"password":self.pswTF.text,@"authType":@"password",codeType:code};
    [SVProgressHUD customShowWithNone];
    [self.loginAuthView startAnimation];
    [LoginNetWorkManager loginForMerchantServerWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.loginAuthView stopAnimation];
        if ([data[@"code"] intValue]==200) {
          
            [self.loginAuthView hide];
            [UBTNSUserDefaultUtil PutDefaults:ACCESS_TOKEN Value:[NSString stringWithFormat:@"%@%@",data[@"data"][@"token_type"],data[@"data"][@"access_token"]]];
            [UBTNSUserDefaultUtil PutDefaults:REFRESH_TOKEN Value:[NSString stringWithFormat:@"%@",data[@"data"][@"refresh_token"]]];
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                [self getMemberInfo];
                
            });
           
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
       } fail:^(NSError * _Nonnull error) {
           [SVProgressHUD dismiss];
           [self.loginAuthView stopAnimation];
          // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
   }];
    
}

//获取个人信息
-(void)getMemberInfo{
   
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getMemberInfosuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            [UserWrapper getuserInfoWithDic:data[@"data"]];//存储用户信息
            [self initRootViewController];
           
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
           ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
         
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}


-(void)setBorderView:(UIView*)view{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
}

-(void)setTextFieldObserverWithtextField:(UITextField *)textField{
   
    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
   
}

//判断电子邮件是否正确
-(void)judgeCorrectEmail:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.emailAlertLabel.hidden=YES;
        self.accountView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.accountView.backgroundColor=[UIColor whiteColor];
        self.emailTitleHeight.constant=0;
        self.tipsDistance.constant=0;

    }else{
        self.emailAlertLabel.hidden=NO;
        self.accountView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.accountView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.emailTitleHeight.constant=15;
        self.tipsDistance.constant=8;

    }
   
}


//判断密码格式是否正确
-(void)judgeCorrectPassword:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.pswAlertLabel.hidden=YES;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.pswView.backgroundColor=[UIColor whiteColor];
        self.pswTitleHeight.constant=0;
    }else{
        self.pswAlertLabel.hidden=NO;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.pswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.pswTitleHeight.constant=15;
    }
    
    
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    if ([textField isEqual:self.accountTF]) {
        //邮箱
        [self judgeCorrectEmail:[ToolUtil matchEmail:textField.text]];
    }else{
        //密码
        [self judgeCorrectPassword:[ToolUtil isOrNoPasswordStyle:textField.text]];
    
    }
    [self judgeBtnStatus];
 
}
-(void)judgeBtnStatus{
    
    if ([ToolUtil matchEmail:self.accountTF.text]&&[ToolUtil isOrNoPasswordStyle:self.pswTF.text]) {
        //可点击
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        self.loginLabel.textColor=[UIColor whiteColor];
       
    }else{
       //不可点击
        self.okBtn.enabled=NO;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        self.loginLabel.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
    }
  
}

    
 -(void)setRightBar{
        
        NSString*languageString=[ChangeLanguage userLanguage];
        NSString*countrySting;
        UIImage*countryImage;
        if ([languageString isEqualToString:@"zh-Hans"]) {
            countryImage=UIIMAGE(@"languageIcon");
            countrySting=LocalizationKey(@"简体中文");
        }else{
            countryImage=UIIMAGE(@"languageIcon");
            countrySting=LocalizationKey(@"English");

        }
        UIView*boardView=[[UIView alloc]init];
        self.countryBtn=[[UIButton alloc]init];
        self.countryBtn.userInteractionEnabled=NO;
        [self.countryBtn setTitle:countrySting forState:UIControlStateNormal];
        [self.countryBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0] forState:UIControlStateNormal];
        self.countryBtn.titleLabel.font=PingFangMediumFont(13);
        [boardView addSubview:self.countryBtn];
        boardView.layer.borderWidth=1;
        boardView.layer.borderColor=[[UIColor colorWithHexString:@"#1F211F" alpha:1.0] colorWithAlphaComponent:0.1].CGColor;
        [boardView setCornerRadius:16.0];
        self.countryImageV=[[UIImageView alloc]init];
        self.countryImageV.image=countryImage;
        [boardView addSubview:self.countryImageV];
        [boardView mas_makeConstraints:^(MASConstraintMaker *make) {
         make.height.mas_equalTo(32);
         }];
    
        [self.countryBtn mas_makeConstraints:^(MASConstraintMaker *make) {
         make.right.equalTo((boardView).mas_right).offset(-10);
         make.centerY.equalTo(boardView.mas_centerY).offset(0);
         }];
        [self.countryImageV mas_makeConstraints:^(MASConstraintMaker *make) {
         make.right.equalTo(self.countryBtn.mas_left).offset(-5);
         make.centerY.equalTo(boardView.mas_centerY).offset(0);
         make.size.mas_equalTo(CGSizeMake(16, 16));
         make.left.equalTo(boardView.mas_left).offset(10);
         }];
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:boardView];
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture:)];
        [boardView addGestureRecognizer:tapGesture];
     self.currentLanguageDic=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?@{@"English":@"en"}:@{@"简体中文":@"zh-Hans"};//初始化
    }
//选择语言
-(void)tapGesture:(id)sender{
       
    [self showLanguageSelectView];
    
  }

    //MARK: 选择语言
-(void)showLanguageSelectView{
        
        [self.selectView show];
        self.selectView.currentDic=self.currentLanguageDic;
        [self.selectView reloadDataWithArray:@[@{@"简体中文":@"zh-Hans"},@{@"English":@"en"}]];
        WEAKSELF
        self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
            NSString*key= [[dic allKeys] objectAtIndex:0];
            [weakSelf.countryBtn setTitle:key forState:UIControlStateNormal];
            [weakSelf setLanguageWithString:[dic objectForKey:key]];
            weakSelf.currentLanguageDic=dic;
            
        };
        
    }
//注册/忘记密码
- (IBAction)toRegister:(UIButton*)sender {
   
    RegisterController*registerVC=[[RegisterController alloc]init];
    registerVC.type=(int)sender.tag;
    [self.navigationController pushViewController:registerVC animated:YES];
    
}

-(void)initRootViewController{
  
    CustomTabBarController *tabbar = [[CustomTabBarController alloc] init];
    APPLICATION.window.rootViewController = tabbar;
    
   }

//MARK: 设置语言
-(void)setLanguageWithString:(NSString*)language{
    
    [ChangeLanguage setUserlanguage:language];
    [self setLanguage];
    
}
/**
 多语言
 */
-(void)setLanguage{
    
    self.titleLabel.text=LocalizationKey(@"登录");
    self.detailLabel.text=LocalizationKey(@"欢迎使用VTRON");
    self.accountLabel.text=LocalizationKey(@"邮箱");
    self.pswLabel.text=LocalizationKey(@"密码");
    self.emailAlertLabel.text=LocalizationKey(@"电子邮件格式不正确");
    self.pswAlertLabel.text=LocalizationKey(@"密码规则不正确");
    [self.accountTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.pswTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.forgetBtn setTitle:LocalizationKey(@"忘记密码？") forState:UIControlStateNormal];
    self.loginLabel.text=LocalizationKey(@"登录");
    [self.registerBtn setTitle:LocalizationKey(@"注册VTRON新用户") forState:UIControlStateNormal];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
