//
//  LoginController.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "LoginController.h"
#import "Masonry.h"
#import "SelectMenuView.h"
#import "PassKeyController.h"
#import "LoginNextController.h"
#import "RegisterController.h"
#import "MineNetWorkManager.h"
#import "NetworkDetectionController.h"
#import "VersionUpdateView.h"

@interface LoginController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property(nonatomic,strong) UIButton*countryBtn;
@property(nonatomic,strong) UIImageView*countryImageV;
@property(nonatomic,strong) SelectMenuView*selectView;
@property(nonatomic,strong) VersionUpdateView *versionUpdateView;
@property(nonatomic,strong) NSDictionary*currentLanguageDic;
@end

@implementation LoginController

- (VersionUpdateView *)versionUpdateView {
    if(!_versionUpdateView) {
        _versionUpdateView=[VersionUpdateView instanceViewWithFrame:[UIScreen mainScreen].bounds];
    }
    return _versionUpdateView;
}

- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 160+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectLanguage];
    }
    return _selectView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setBorderView:self.accountView];
    [self setTextFieldObserverWithtextField:self.accountTF];
    self.indicatorView.hidden=YES;
    self.titleLabel.font=PingFangMediumFont(13);
    self.nextStepLabel.font=PingFangMediumFont(15);
    self.registerBtn.titleLabel.font=PingFangMediumFont(15);
    [self LeftsetupNavgationItemWithpictureName:@"netDetectionIcon"];
    if (![NSString stringIsNull:[UBTNSUserDefaultUtil GetDefaults:KACCOUNT]]) {
        self.accountTF.text =[UBTNSUserDefaultUtil GetDefaults:KACCOUNT];//记住上次账号
    }
    
#if DEBUG == 1
   // self.accountTF.text = @"1825571811@qq.com";
#endif
    [self setLanguage];
    [self judgeBtnStatus];
    [self getVersionForAPP];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self setRightBar];
    [self setLanguage];
}


//获取版本更新
-(void)getVersionForAPP{

    [MineNetWorkManager getVersionWithParams:@{@"type":@"ios"} success:^(id  _Nonnull data) {
        
        if ([data[@"code"] intValue]==200) {
            NSString*version=data[@"data"][@"version"];
            version = [version stringByReplacingOccurrencesOfString:@" " withString:@""];//去掉所有空格
       
            if ([version containsString:@"v"]) {
                version=[version stringByReplacingOccurrencesOfString:@"v" withString:@""];
            }
            if ([version containsString:@"V"]) {
                version=[version stringByReplacingOccurrencesOfString:@"V" withString:@""];
            }
            // app当前版本
            NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
            NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
            if ([app_Version compare:version options:NSNumericSearch] == NSOrderedSame ||[app_Version compare:version options:NSNumericSearch] == NSOrderedDescending) {
                //不需要更新
            }else{
                //要更新
                [self.versionUpdateView show];
                self.versionUpdateView.dic=data[@"data"];
    
          }
  
        }
  
    } fail:^(NSError * _Nonnull error) {
        
        
    }];

}




-(void)setBorderView:(UIView*)view{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
}
-(void)setTextFieldObserverWithtextField:(UITextField *)textField{
   
    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
   
}

-(void)LefttouchEvent{
    
    NetworkDetectionController*netDetectionVC=[[NetworkDetectionController alloc]init];
    netDetectionVC.popType=1;
    [self.navigationController pushViewController:netDetectionVC animated:YES];
    
}

-(void)setRightBar{
       
       NSString*languageString=[ChangeLanguage userLanguage];
       NSString*countrySting;
       UIImage*countryImage;
       if ([languageString isEqualToString:@"zh-Hans"]) {
           countryImage=UIIMAGE(@"languageIcon");
           countrySting=LocalizationKey(@"简体中文");
       }else{
           countryImage=UIIMAGE(@"languageIcon");
           countrySting=LocalizationKey(@"English");

       }
       UIView*boardView=[[UIView alloc]init];
       self.countryBtn=[[UIButton alloc]init];
       self.countryBtn.userInteractionEnabled=NO;
       [self.countryBtn setTitle:countrySting forState:UIControlStateNormal];
       [self.countryBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0] forState:UIControlStateNormal];
       self.countryBtn.titleLabel.font=PingFangMediumFont(13);
       [boardView addSubview:self.countryBtn];
       boardView.layer.borderWidth=1;
       boardView.layer.borderColor=[[UIColor colorWithHexString:@"#1F211F" alpha:1.0] colorWithAlphaComponent:0.1].CGColor;
       [boardView setCornerRadius:16.0];
       self.countryImageV=[[UIImageView alloc]init];
       self.countryImageV.image=countryImage;
       [boardView addSubview:self.countryImageV];
       [boardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(32);
        }];
   
       [self.countryBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo((boardView).mas_right).offset(-10);
        make.centerY.equalTo(boardView.mas_centerY).offset(0);
        }];
       [self.countryImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.countryBtn.mas_left).offset(-5);
        make.centerY.equalTo(boardView.mas_centerY).offset(0);
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.left.equalTo(boardView.mas_left).offset(10);
        }];
       self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:boardView];
       UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture:)];
       [boardView addGestureRecognizer:tapGesture];
    self.currentLanguageDic=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?@{@"English":@"en"}:@{@"简体中文":@"zh-Hans"};//初始化
   }

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField{
    
    [self judgeBtnStatus];
    
}

-(void)judgeBtnStatus{
    
    if ([ToolUtil matchEmail:self.accountTF.text]) {
        //可点击
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        self.nextStepLabel.textColor=[UIColor whiteColor];
       
    }else{
       //不可点击
        self.okBtn.enabled=NO;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        self.nextStepLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2];
    }
  
}

//选择语言
 -(void)tapGesture:(id)sender
 {
   
     [self showLanguageSelectView];
 }

//MARK: 选择语言
-(void)showLanguageSelectView{
    
    [self.selectView show];
    self.selectView.currentDic=self.currentLanguageDic;
    [self.selectView reloadDataWithArray:@[@{@"简体中文":@"zh-Hans"},@{@"English":@"en"}]];
    WEAKSELF
    self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
        NSString*key= [[dic allKeys] objectAtIndex:0];
        [weakSelf.countryBtn setTitle:key forState:UIControlStateNormal];
        [weakSelf setLanguageWithString:[dic objectForKey:key]];
        weakSelf.currentLanguageDic=dic;
        
    };
    
}
/**
 多语言
 */
-(void)setLanguage{
    self.welcomeLabel.text=LocalizationKey(@"登录");
    self.welcomeLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    self.detailLabel.text=LocalizationKey(@"欢迎使用VTRON");
    self.titleLabel.text=LocalizationKey(@"邮箱");
    self.nextStepLabel.text=LocalizationKey(@"登录");
    [self.accountTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.registerBtn setTitle:LocalizationKey(@"注册VTRON新用户") forState:UIControlStateNormal];
}

//MARK: 设置语言
-(void)setLanguageWithString:(NSString*)language{

    [ChangeLanguage setUserlanguage:language];
    [self setLanguage];
    
}

//下一步or注册
- (IBAction)nextClick:(UIButton *)sender {
    
    if (sender.tag==0) {
        //登录
        if ([NSString stringIsNull:self.accountTF.text]) {
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
            return;
        }
        [self judgeOpenPasskey];
    }else{
        //注册
        RegisterController*registerVC=[[RegisterController alloc]init];
        registerVC.type=0;
        [self.navigationController pushViewController:registerVC animated:YES];
    }

}

//校验用户是否开启了通行密钥
-(void)judgeOpenPasskey{
    self.indicatorView.hidden=NO;
    [self.indicatorView startAnimating];
   // [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager judgeOpenPasskeyOrNot:@{@"username":self.accountTF.text} success:^(id  _Nonnull data) {
        [self.indicatorView stopAnimating];
        self.indicatorView.hidden=YES;
     
      // [SVProgressHUD dismiss];
            if ([data[@"code"] intValue]==200) {
                if ([data[@"data"] intValue]==1) {
                    //开启了通行密钥
                    PassKeyController*passkeyVC=[[PassKeyController alloc]init];
                    passkeyVC.username=self.accountTF.text;
                    passkeyVC.pswBlock = ^{
                        //账户密码登录
                        LoginNextController*loginVC=[[LoginNextController alloc]init];
                        loginVC.account=self.accountTF.text;
                        [self.navigationController pushViewController:loginVC animated:YES];
                    };
                    [self.navigationController pushViewController:passkeyVC animated:YES];
                }else{
                    //未开启通行密钥，只能账户密码登录
                    LoginNextController*loginVC=[[LoginNextController alloc]init];
                    loginVC.account=self.accountTF.text;
                    [self.navigationController pushViewController:loginVC animated:YES];
                }
               
            }else{
               NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            }
        
          } fail:^(NSError * _Nonnull error) {
             // [SVProgressHUD dismiss];
              [self.indicatorView stopAnimating];
              self.indicatorView.hidden=YES;
             // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
              
       }];
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
