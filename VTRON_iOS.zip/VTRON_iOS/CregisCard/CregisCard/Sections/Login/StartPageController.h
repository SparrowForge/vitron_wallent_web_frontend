//
//  StartPageController.h
//  CregisCard
//
//  Created by 孙良 on 2024/8/5.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 自定义启动页
 */
NS_ASSUME_NONNULL_BEGIN

@interface StartPageController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *bottomIcon;
@property (weak, nonatomic) IBOutlet UIImageView *bottomIconEn;

@end

NS_ASSUME_NONNULL_END
