//
//  PassKeyController.h
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

typedef void(^PasswordBlock)(void);
NS_ASSUME_NONNULL_BEGIN

@interface PassKeyController : BaseViewController
@property (nonatomic, copy) PasswordBlock pswBlock;
@property(nonatomic,copy)NSString*username;

@end

NS_ASSUME_NONNULL_END
