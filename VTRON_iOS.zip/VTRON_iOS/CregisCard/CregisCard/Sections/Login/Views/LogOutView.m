//
//  LogOutView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/20.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "LogOutView.h"

@implementation LogOutView

+ (LogOutView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"LogOutView" owner:nil options:nil];
    LogOutView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 20+HOME_INDICATOR_HEIGHT, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
   
    return view;
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.cancelBtn.titleLabel.font=PingFangMediumFont(15);
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.titlelabel.text=LocalizationKey(@"退出登录");
    self.detailLabel.text=LocalizationKey(@"您确定要退出登录吗？");
    [self.cancelBtn setTitle:LocalizationKey(@"取消") forState:UIControlStateNormal];
    [self.okBtn setTitle:LocalizationKey(@"确定") forState:UIControlStateNormal];
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [self setCornerRadius:24.0];
}

- (IBAction)btnClick:(UIButton *)sender {
    
    [self hide];
}

@end
