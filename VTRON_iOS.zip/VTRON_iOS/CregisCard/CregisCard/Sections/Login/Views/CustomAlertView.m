//
//  CustomAlertView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/14.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CustomAlertView.h"

@interface CustomAlertView ()
@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *messageLabel;

@end


@implementation CustomAlertView

- (instancetype)initWithType:(PopupType)type message:(NSString *)message {
    self = [super initWithFrame:CGRectZero];
    if (self) {
        [self setupUIWithType:type message:message];
    }
    return self;
}

- (void)setupUIWithType:(PopupType)type message:(NSString *)message {
    // 根据类型设置图标
    NSString *imageName = (type == PopupTypeSuccess) ? @"successIcon" : @"failIcon";
    
    _iconImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    [self addSubview:_iconImageView];
    
    // 创建并配置提示语的标签
    _messageLabel = [[UILabel alloc] init];
    _messageLabel.text = message;
    _messageLabel.numberOfLines = 0; // 允许多行显示
    _messageLabel.textColor= (type == PopupTypeSuccess) ? [UIColor colorWithHexString:@"#6DD400" alpha:1.0]: [UIColor colorWithHexString:@"#EC312C" alpha:1.0];
    _messageLabel.backgroundColor=[UIColor clearColor];
    _messageLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:_messageLabel];
    
    // 设置弹窗背景颜色和圆角
//    self.backgroundColor = (type == PopupTypeSuccess) ? [UIColor colorWithHexString:@"#6DD400" alpha:0.06]: [UIColor colorWithHexString:@"#EC312C" alpha:0.06];
    self.backgroundColor = (type == PopupTypeSuccess) ? [UIColor colorWithHexString:@"#F4FCEB" alpha:1.0]: [UIColor colorWithHexString:@"#FEF3F3" alpha:1.0];
    //self.layer.cornerRadius = 10.0;
    
    // 设置阴影
//    self.layer.shadowColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.6] .CGColor;
//    self.layer.shadowOpacity = 0.5;
//    self.layer.shadowOffset = CGSizeMake(0, 0);
//    self.layer.shadowRadius = 5.0;
   
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
//    CGFloat maxWidth = CGRectGetWidth([UIScreen mainScreen].bounds) * 0.8; // 最大宽度为屏幕宽度的0.8倍
    CGFloat maxWidth = kWindowW-40; //
      // 设置图标的位置和大小
      _iconImageView.frame = CGRectMake(20, 15, 20, 20);
      
      CGSize fitSize = [_messageLabel sizeThatFits:CGSizeZero];
    
      // 计算提示语标签的最大宽度
      CGFloat labelWidth = MIN(fitSize.width, maxWidth-CGRectGetWidth(_iconImageView.frame)-27-20); // 最大宽度为 PopupView 的宽度减去图标宽度和间距
      // 计算提示语标签的大小
      CGSize labelSize = [_messageLabel sizeThatFits:CGSizeMake(labelWidth, CGFLOAT_MAX)];
      // 设置提示语标签的位置和大小
      _messageLabel.frame = CGRectMake(CGRectGetMaxX(_iconImageView.frame) + 7, CGRectGetMinY(_iconImageView.frame), labelWidth, labelSize.height);
     // _iconImageView.dn_centerY=_messageLabel.dn_centerY;
      // 设置弹窗的大小
      CGRect frame = self.frame;
      frame.size = CGSizeMake(CGRectGetMaxX(_messageLabel.frame) + 20, CGRectGetMaxY(_messageLabel.frame) + 15);
      self.frame = frame;
      self.dn_centerX=APPLICATION.window.dn_centerX;
//      self.layer.cornerRadius = self.frame.size.height/2.0;
    self.layer.cornerRadius = 12.0;
}

@end
