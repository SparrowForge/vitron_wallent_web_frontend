//
//  LoginAuthenticationView.h
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FWPanPopupView.h"
NS_ASSUME_NONNULL_BEGIN
typedef void(^VerifyBlock)(NSDictionary* _Nullable dic);//验证结束的回调

@interface LoginAuthenticationView : FWPanPopupView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIView *inputView;
@property (weak, nonatomic) IBOutlet UIButton *verifyBtn;
@property (weak, nonatomic) IBOutlet UITextField *verifyTF;
+ (LoginAuthenticationView *)instanceViewWithFrame:(CGRect)Rect withVerifyPermissionType:(int)permissionType withGoogleVerify:(BOOL)needGoogle;//0 登录 1注册 2 重置密码 3更改邮箱 4创建交易密码 5修改交易密码 6修改登录密码 7开启谷歌验证 8关闭谷歌验证 9绑定谷歌验证
-(void)showWithAccount:(NSString*_Nullable)account withPassword:(NSString*_Nullable)password withinviteCode:(NSString*_Nullable)inviteCode;
@property(nonatomic,assign)int permissionType;
@property (nonatomic, copy) VerifyBlock verifyBlock;

@end

NS_ASSUME_NONNULL_END
