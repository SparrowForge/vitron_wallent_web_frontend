//
//  LogOutView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/20.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface LogOutView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;

+ (LogOutView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *titlelabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;

@end

NS_ASSUME_NONNULL_END
