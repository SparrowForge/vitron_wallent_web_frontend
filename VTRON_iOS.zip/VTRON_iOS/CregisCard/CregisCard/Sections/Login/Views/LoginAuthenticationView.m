//
//  LoginAuthenticationView.m
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "LoginAuthenticationView.h"
#import "MineNetWorkManager.h"
@interface LoginAuthenticationView()

@property (weak, nonatomic) IBOutlet UILabel *emailAlertLabel;
@property(nonatomic,copy)   NSString*account;
@property(nonatomic,copy)   NSString*password;
@property(nonatomic,copy)   NSString*inviteCode;

@property(nonatomic,retain)dispatch_source_t _timer;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicator;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak, nonatomic) IBOutlet UILabel *okLabel;
@property (weak, nonatomic) IBOutlet UIView *googleView;
@property (weak, nonatomic) IBOutlet UITextField *googleTF;
@property (weak, nonatomic) IBOutlet UILabel *googleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property(nonatomic,assign)BOOL needGoogle;
@end


@implementation LoginAuthenticationView

+ (LoginAuthenticationView *)instanceViewWithFrame:(CGRect)Rect withVerifyPermissionType:(int)permissionType withGoogleVerify:(BOOL)needGoogle{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"LoginAuthenticationView" owner:nil options:nil];
    LoginAuthenticationView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setBorderView:view.inputView];
    [view setBorderView:view.googleView];
    view.cancelBtn.layer.borderWidth=0.5;
    view.cancelBtn.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    view.cancelBtn.titleLabel.font=PingFangMediumFont(15);
    view.okLabel.font=PingFangMediumFont(15);
    view.verifyBtn.titleLabel.font=PingFangMediumFont(13);
    view.permissionType=permissionType;
    view.indicator.hidden=YES;
    view.emailAlertLabel.hidden=YES;
    view.okBtn.enabled=NO;
    view.okLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2];
    view.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    [view.verifyTF addTarget:view action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    if (needGoogle) {
        view.googleView.hidden=NO;
        view.googleLabel.hidden=NO;
        view.topDistance.constant=142;
        [view.googleTF addTarget:view action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    }else{
        view.googleView.hidden=YES;
        view.googleLabel.hidden=YES;
        view.topDistance.constant=40;
    }
    view.needGoogle=needGoogle;
    [view setLanguage];
    view.emailLabel.font=PingFangMediumFont(13);
    view.googleLabel.font=PingFangMediumFont(13);
    view.titleLabel.font=PingFangMediumFont(19);
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
    
}

-(void)setBorderView:(UIView*)view{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
}

-(void)showWithAccount:(NSString*_Nullable)account withPassword:(NSString*_Nullable)password withinviteCode:(NSString*_Nullable)inviteCode{
    self.account=account;
    self.password=password;
    self.inviteCode=inviteCode;
    [self show];
}


//获取邮箱验证码
- (IBAction)getVerifyCode:(id)sender {
    if (self.permissionType==0) {
        //登录
        [self sendVerifyCodeForLogin];
    }else if (self.permissionType==1){
        //注册
        [self getRegisterCode];
    }else if (self.permissionType==2){
        //忘记密码
        [self getForgetCode];
    }else if (self.permissionType==3){
        //更换邮箱
        [self getCodeForChangeEmail];
    }else if (self.permissionType==4){
        //创建交易密码
        [self getCodeForChangePayPasswordForType:@"createPayPassword"];
    }else if (self.permissionType==5){
        //修改交易密码
        [self getCodeForChangePayPasswordForType:@"updatePayPassword"];
    }else if (self.permissionType==6){
        //修改登录密码
        [self getCodeForChangeLoginPassword];
    }
    else if (self.permissionType==7){
        //开启谷歌验证
        [self getCodeForGoogleWithStatus:@"openGoogle"];
    }
    else if (self.permissionType==8){
        //关闭谷歌验证
        [self getCodeForGoogleWithStatus:@"closeGoogle"];
    }
    else if (self.permissionType==9){
        //绑定谷歌验证
        [self getCodeForBindGoogle];
    }
    else{
        
        
    }
  
}
//发送登录验证码
-(void)sendVerifyCodeForLogin{
    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":@"login"} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
           
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
     
    }];
    
    
    
}

//获取注册的验证码,
-(void)getRegisterCode{
    
    [SVProgressHUD customShowWithStyle];
    NSDictionary*dic=@{@"email":self.account,@"type":@"register"};
    [LoginNetWorkManager getCodeForRegisterWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}


//获取忘记密码的验证码
-(void)getForgetCode{
 
    [SVProgressHUD customShowWithStyle];
    NSDictionary*dic=@{@"email":self.account,@"type":@"reset"};
    [LoginNetWorkManager getForgotCodeForRegisterWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//MARK:获取更改邮箱验证码
-(void)getCodeForChangeEmail{
    
    if ([NSString stringIsNull:self.account]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
        return;
    }
    if (![ToolUtil matchEmail:self.account]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入正确的邮箱"));
       
        return;
    }
    
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager sendCheckEmailInfoWithParams:@{@"email":self.account,@"type":@"changeEmail"} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
            
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

//MARK:获取修改交易密码验证码
-(void)getCodeForChangePayPasswordForType:(NSString*)type{
  
    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":type} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

//MARK:获取修改登录密码验证码
-(void)getCodeForChangeLoginPassword{
   
    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":@"updatePassword"} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

//MARK:开启谷歌验证
-(void)getCodeForGoogleWithStatus:(NSString*)status{

    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":status} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
  
    
}

//MARK:绑定/重置谷歌验证
-(void)getCodeForBindGoogle{
   
    NSString*googleType;
    if ([[UserWrapper shareUserInfo].googleStatus intValue]==2) {
        //首次绑定
        googleType=@"bindGoogle";
    }else{
        //重置
        googleType=@"resetGoogle";
    }
    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":googleType} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[self maskEmail:self.account]];
            self.emailAlertLabel.text=email;
            self.emailAlertLabel.hidden=NO;
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
}




/* 倒计时 */
- (void)CountDown:(int)timeDistance{
    __block NSInteger time = timeDistance; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    self._timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    dispatch_source_set_timer(self._timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(self._timer, ^{
        
        if(time <= 0){ //倒计时结束，关闭
            
            dispatch_source_cancel(self._timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置按钮的样式
                [self.verifyBtn setTitle:LocalizationKey(@"重新发送") forState:UIControlStateNormal];
                [self.verifyBtn setTitleColor:[UIColor baseColor] forState:UIControlStateNormal];
                self.verifyBtn.userInteractionEnabled = YES;
                
            });
            
        }else{
            
            int seconds = (int)time ;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //设置按钮显示读秒效果
                [self.verifyBtn setTitle:[NSString stringWithFormat:@"%.2ldS",(long)seconds] forState:UIControlStateNormal];
                [self.verifyBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0] forState:UIControlStateNormal];
                self.verifyBtn.userInteractionEnabled = NO;
            });
            time--;
        }
    });
    dispatch_resume(self._timer);
}

//确定
- (IBAction)okClick:(UIButton *)sender {
    
    if (self.permissionType==0) {
        //登录
        [self loginCheckWithcode:self.verifyTF.text];
    }else if (self.permissionType==1){
        //注册
        [self registerForAccount];
    }else if (self.permissionType==2){
        //忘记密码
        [self toResetPassword];
    }else if (self.permissionType==3){
        //更换邮箱
        [self toChangeEmail];
    }else if (self.permissionType==4){
        //创建交易密码
        [self confirmToSetPaypasswordForType:@"createPayPassword"];
    }else if (self.permissionType==5){
        //修改交易密码
        [self confirmToSetPaypasswordForType:@"updatePayPassword"];
    }else if (self.permissionType==6){
        //修改登录密码
        [self confirmToSetLoginpassword];
    }
    else if (self.permissionType==7){
        //开启谷歌验证
        [self confirmToControlsGooglewithStatus:@"1"];
    }else if (self.permissionType==8){
        //关闭谷歌验证
        [self confirmToControlsGooglewithStatus:@"0"];
    } else if (self.permissionType==9){
        //绑定谷歌验证
        [self confirmToBindGoogle];
    }
    else{
        
        
    }
   
}

//校验验证码
-(void)loginCheckWithcode:(NSString*)code{
    
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
    if ([self.account isEqualToString:Appstore_account]) {
        //appStore审核账号不校验验证码
        [self hide];
        [self getMemberInfo];
        return;
    }
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    [SVProgressHUD customShowWithNone];
    NSDictionary*dic=@{@"code":code,@"type":@"login"};
    [LoginNetWorkManager loginCheckWithParams:dic success:^(id  _Nonnull data) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
       
        if ([data[@"code"] intValue]==200) {
            [self hide];
            [self getMemberInfo];
           
        } else if ([data[@"code"] intValue]==20002) {
          
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//注册
-(void)registerForAccount{
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
    [SVProgressHUD customShowWithNone];
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    NSMutableDictionary*dic=[@{@"username":self.account,@"password":self.password,@"code":self.verifyTF.text,@"registerType":@"app"} mutableCopy];
    if (![NSString stringIsNull:self.inviteCode]) {
        [dic setValue:self.inviteCode forKey:@"inviteCode"];//邀请码
    }
    [LoginNetWorkManager toRegisterWithParams:dic success:^(id  _Nonnull data) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            [self endEditing:YES];
            [self hide];
           // ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"注册成功"));
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (self.verifyBlock) {
                    self.verifyBlock(data);
                }
              
            });
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}


//重置密码
-(void)toResetPassword{
    
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
    [SVProgressHUD customShowWithNone];
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    NSDictionary*dic=@{@"username":self.account,@"password":self.password,@"code":self.verifyTF.text};
    [LoginNetWorkManager toForgotWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        if ([data[@"code"] intValue]==200) {
            [self hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"重置成功"));
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (self.verifyBlock) {
                    self.verifyBlock(nil);
                }
                
            });
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//MARK:更改邮箱
-(void)toChangeEmail{
    
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
    
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    [SVProgressHUD customShowWithNone];
    NSMutableDictionary*dic=[@{@"email":self.account,@"type":@"changeEmail",@"code":self.verifyTF.text,@"password":self.password} mutableCopy];
    if (self.needGoogle) {
        [dic setValue:self.googleTF.text forKey:@"googleCode"];
    }
    
    [MineNetWorkManager modifyMemberInfoWithParams:dic success:^(id  _Nonnull data) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"更换邮箱成功"));
            [self hide];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (self.verifyBlock) {
                    self.verifyBlock(nil);
                }
                
            });
        
        }else{
            [SVProgressHUD dismiss];
            self.indicator.hidden=YES;
            [self.indicator stopAnimating];
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }

        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}


//确定修改登录密码
-(void)confirmToSetLoginpassword{
    
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
  
    [SVProgressHUD customShowWithNone];
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    NSMutableDictionary*dic=[@{@"type":@"updatePassword",@"code":self.verifyTF.text,@"password":self.password} mutableCopy];
    if (self.needGoogle) {
        [dic setValue:self.googleTF.text forKey:@"googleCode"];
    }
    
    [MineNetWorkManager modifyMemberInfoWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"修改登录密码成功"));
            [self hide];
            if (self.verifyBlock) {
                self.verifyBlock(nil);
            }
         
        }else{
          
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }

        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
}

//确定修改交易密码
-(void)confirmToSetPaypasswordForType:(NSString*)type{
   
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
      
        return;
    }

    [SVProgressHUD customShowWithNone];
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    NSMutableDictionary*dic=[@{@"code":self.verifyTF.text,@"payPassword":self.password} mutableCopy];

    [dic setValue:type forKey:@"type"];
    if (self.needGoogle) {
        [dic setValue:self.googleTF.text forKey:@"googleCode"];
    }
    
    [MineNetWorkManager modifyMemberInfoWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        if ([data[@"code"] intValue]==200) {
            NSString*messageType=LocalizationKey(@"修改交易密码成功");
            [self hide];
            if ([[UserWrapper shareUserInfo].isPayPassword intValue]!=1) {
                messageType=LocalizationKey(@"创建交易密码成功");//首次创建交易密码
            }
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,messageType);
            if (self.verifyBlock) {
                self.verifyBlock(nil);
            }
     
        }else{
        
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }

        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
}

//确定开启/关闭谷歌验证
-(void)confirmToControlsGooglewithStatus:(NSString*)status{
    if ([NSString stringIsNull:self.googleTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入谷歌验证码"));
        return;
    }
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    [SVProgressHUD customShowWithNone];
    [MineNetWorkManager changeGoogleStatusWithParams:@{@"googleStatus":status,@"type":@"2",@"emailCode":self.verifyTF.text,@"googleCode":self.googleTF.text} success:^(id  _Nonnull data) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
         
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"操作成功"));
            [UserWrapper shareUserInfo].googleStatus= status;
            [UserWrapper saveUser:[UserWrapper shareUserInfo]];
            [self hide];
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (self.verifyBlock) {
                    self.verifyBlock(nil);
                }
                
            });
         
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
    
    
}

//确定绑定/重置谷歌验证
-(void)confirmToBindGoogle{
    if ([NSString stringIsNull:self.googleTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入谷歌验证码"));
        return;
    }
    if ([NSString stringIsNull:self.verifyTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
  
    NSString*googleType;
    if ([[UserWrapper shareUserInfo].googleStatus intValue]==2) {
        //首次绑定
        googleType=@"3";
    }else{
        //重置
        googleType=@"2";
    }
    self.indicator.hidden=NO;
    [self.indicator startAnimating];
    [SVProgressHUD customShowWithNone];
    [MineNetWorkManager changeGoogleStatusWithParams:@{@"googleStatus":googleType,@"type":@"2",@"emailCode":self.verifyTF.text,@"googleCode":self.googleTF.text,@"googleSecretKey":self.inviteCode} success:^(id  _Nonnull data) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            [self hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"操作成功"));
            [UserWrapper shareUserInfo].googleStatus=@"1";//默认开启
            [UserWrapper saveUser:[UserWrapper shareUserInfo]];
            if (self.verifyBlock) {
                self.verifyBlock(nil);
            }
 
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        self.indicator.hidden=YES;
        [self.indicator stopAnimating];
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
}




- (IBAction)closeClick:(id)sender {
    [self hide];
}

//获取个人信息
-(void)getMemberInfo{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getMemberInfosuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        
        if ([data[@"code"] intValue]==200) {
            [UserWrapper getuserInfoWithDic:data[@"data"]];//存储用户信息
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (self.verifyBlock) {
                    self.verifyBlock(nil);
                }
               
            });

           
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
         
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

 -(NSString *)maskEmail:(NSString *)email {
         NSArray<NSString *> *components = [email componentsSeparatedByString:@"@"];
         if (components.count != 2) {
             return email; // 如果不是有效的邮箱地址，返回nil
         }
         
         NSString *localPart = components[0];
         NSString *domainPart = components[1];
         
         if (localPart.length < 3) {
             return email; // 如果本地部分少于3个字符，返回nil
         }
         
         NSString *maskedLocalPart = [NSString stringWithFormat:@"%@****", [localPart substringToIndex:3]];
         
         return [NSString stringWithFormat:@"%@@%@", maskedLocalPart, domainPart];
     }

-(void)setLanguage{
  
    [self.verifyTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.googleTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];

    [self.cancelBtn setTitle:LocalizationKey(@"取消") forState:UIControlStateNormal];
    self.titleLabel.text=LocalizationKey(@"安全验证");
    self.emailLabel.text=LocalizationKey(@"邮箱验证码");
    self.googleLabel.text=LocalizationKey(@"谷歌验证码");
 
    [self.verifyBtn setTitle:LocalizationKey(@"获取") forState:UIControlStateNormal];
    if (self.permissionType==7) {
        self.okLabel.text=LocalizationKey(@"确认开启");
    }else if (self.permissionType==8){
        self.okLabel.text=LocalizationKey(@"确认关闭");
    }else{
        self.okLabel.text=LocalizationKey(@"提交");
        
    }
    
    
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    [self judgeBtnStatus];
}

-(void)judgeBtnStatus{
    
    if (self.needGoogle) {
        if ([NSString stringIsNull:self.verifyTF.text]||[NSString stringIsNull:self.googleTF.text]) {
            self.okBtn.enabled=NO;
            self.okLabel.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        }else{
            self.okBtn.enabled=YES;
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
            self.okLabel.textColor=[UIColor whiteColor];
        }
  
        
    }else{
        
        if ([NSString stringIsNull:self.verifyTF.text]) {
            self.okBtn.enabled=NO;
            self.okLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        }else{
            self.okBtn.enabled=YES;
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
            self.okLabel.textColor=[UIColor whiteColor];
        }
        
    }
  
}

@end
