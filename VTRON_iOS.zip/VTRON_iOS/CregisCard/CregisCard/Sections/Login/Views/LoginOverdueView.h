//
//  LoginOverdueView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/20.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//


/**
 登录过期
 */
#import "FWPopupBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginOverdueView : FWPopupBaseView

@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;

+ (LoginOverdueView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
