//
//  PassKeyController.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PassKeyController.h"
#import <AuthenticationServices/AuthenticationServices.h>
#import "MineNetWorkManager.h"
#import "CustomTabBarController.h"


@interface PassKeyController ()<ASAuthorizationControllerDelegate,ASAuthorizationControllerPresentationContextProviding>
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIButton *passkeyBtn;
@property (weak, nonatomic) IBOutlet UIButton *pswBtn;
@property (weak, nonatomic) IBOutlet UIImageView *alertImageV;

@property(nonatomic,copy)   NSString*userHandle;
@property(nonatomic,copy)   NSString*assertionId;
@end

@implementation PassKeyController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.pswBtn.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    self.pswBtn.layer.borderWidth=0.5;
    self.pswBtn.titleLabel.font=PingFangMediumFont(15);
    self.passkeyBtn.titleLabel.font=PingFangMediumFont(15);
    [self.passkeyBtn setTitle:LocalizationKey(@"使用通行密钥验证") forState:UIControlStateNormal];
    [self.pswBtn setTitle:LocalizationKey(@"密码登录") forState:UIControlStateNormal];
    self.titleLabel.text=LocalizationKey(@"通行密钥验证中...");
    self.detailLabel.text=@"";
    self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon");
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self loginPasskeyForFirstStep];
        
    });
    

    // Do any additional setup after loading the view from its nib.
}


- (IBAction)passkeyClick:(UIButton *)sender {
    if (sender.tag==0) {
        //通行密钥登录
        [self loginPasskeyForFirstStep];
    }else{
        //账户密码登录
        [self.navigationController popViewControllerAnimated:NO];
        if (self.pswBlock) {
            self.pswBlock();
        }
    
    }
   
}
//通行密钥登录第一步
-(void)loginPasskeyForFirstStep{
    
    self.titleLabel.text=LocalizationKey(@"通行密钥验证中...");
    self.detailLabel.text=@"";
    self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon");

    [SVProgressHUD customShowWithNone];
    [MineNetWorkManager loginPasskeywithUserNameForFirstStep:@{@"username":self.username} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            self.assertionId=data[@"data"][@"assertionId"];
            NSString*challenge=data[@"data"][@"publicKeyCredentialRequestOptions"][@"challenge"];
            self.userHandle=data[@"data"][@"assertionRequest"][@"userHandle"];
            [self loginWithpassKeyWithassertionId:self.assertionId withchallenge:challenge withAllowedCredential:data[@"data"][@"credentialId"]];
            
        }else{
            self.titleLabel.text=LocalizationKey(@"验证失败");
            self.detailLabel.text=LocalizationKey(@"请重试或者切换密码登录");
            self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon_fail");
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
             ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
            
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            self.titleLabel.text=LocalizationKey(@"验证失败");
            self.detailLabel.text=LocalizationKey(@"请重试或者切换密码登录");
            self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon_fail");
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
   }];
    
}



//登录passkey
-(void)loginWithpassKeyWithassertionId:(NSString*)assertionId withchallenge:(NSString*)challengeBase64String withAllowedCredential:(NSString*)allowedCredentialId{
    
    NSString *base64String = challengeBase64String;
    base64String = [base64String stringByReplacingOccurrencesOfString:@"-" withString:@"+"];
    base64String = [base64String stringByReplacingOccurrencesOfString:@"_" withString:@"/"];

    // 检查是否需要添加填充字符
    NSInteger paddingLength = 4 - (base64String.length % 4);
    if (paddingLength < 4) {
        base64String = [base64String stringByPaddingToLength:base64String.length + paddingLength withString:@"=" startingAtIndex:0];
    }
    // 从服务器获取 challenge
    NSData *challenge =[[NSData alloc] initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSString *relyingPartyIdentifier = DOMAINCOM; // 替换为你的服务端域名
    // 创建 ASAuthorizationPlatformPublicKeyCredentialProvider
    if (@available(iOS 15.0, *)) {
        ASAuthorizationPlatformPublicKeyCredentialProvider *provider = [[ASAuthorizationPlatformPublicKeyCredentialProvider alloc] initWithRelyingPartyIdentifier:relyingPartyIdentifier];
        ASAuthorizationPlatformPublicKeyCredentialAssertionRequest *request = [provider createCredentialAssertionRequestWithChallenge:challenge];
        // 假设已存储的 Passkey Credential ID（从服务器获取）
        NSData *credentialID = [[NSData alloc] initWithBase64EncodedString:allowedCredentialId options:0];
       // 允许的 Passkey（仅允许此凭据进行身份验证）
        ASAuthorizationPlatformPublicKeyCredentialDescriptor *allowedCredential =
               [[ASAuthorizationPlatformPublicKeyCredentialDescriptor alloc] initWithCredentialID:credentialID];

        request.allowedCredentials = @[allowedCredential]; // 这里限制只能使用指定的 Passkey 登录
        // 创建 ASAuthorizationController
        ASAuthorizationController *authorizationController = [[ASAuthorizationController alloc] initWithAuthorizationRequests:@[request]];
        authorizationController.delegate = self;
        authorizationController.presentationContextProvider = self;
        // 开始认证流程
        [authorizationController performRequests];
    }
    
    
}

// 处理认证结果
#pragma mark - ASAuthorizationControllerDelegate
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithAuthorization:(ASAuthorization *)authorization  API_AVAILABLE(ios(13.0)){
    if (@available(iOS 15.0, *)) {
        //登录验证时的数据
        if ([authorization.credential isKindOfClass:[ASAuthorizationPlatformPublicKeyCredentialAssertion class]]) {
            ASAuthorizationPlatformPublicKeyCredentialAssertion *assertion =
            (ASAuthorizationPlatformPublicKeyCredentialAssertion *)authorization.credential;
            NSData *clientData = assertion.rawClientDataJSON;
            NSData *signature = assertion.signature;
            NSData *authenticatorData = assertion.rawAuthenticatorData;
            NSData *jsonData = clientData; // 假设这是包含 JSON 数据的 NSData 对象
            NSError *error;
            id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
            if (error) {
                NSLog(@"Failed to convert NSData to JSON: %@", error.localizedDescription);
            } else {
                NSLog(@"Converted JSON object: %@", jsonObject);
                
            }
            NSString *credentialID = [[NSString alloc] initWithData:assertion.credentialID encoding:NSUTF8StringEncoding];
            
            NSLog(@"Authentication succeeded!");
            NSLog(@"CredentialID: %@", credentialID);
            NSLog(@"ClientData: %@", clientData);
            NSLog(@"Signature: %@", signature);
            NSLog(@"AuthenticatorData: %@", authenticatorData);
            NSString*credentialIDBase64String
            =[assertion.credentialID base64EncodedStringWithOptions:0];
            NSString*rawClientDataJSONBase64String
            =[assertion.rawClientDataJSON base64EncodedStringWithOptions:0];
            NSString*rawAuthenticatorDataBase64String
            =[assertion.rawAuthenticatorData base64EncodedStringWithOptions:0];
            NSString*signatureBase64String
            =[assertion.signature base64EncodedStringWithOptions:0];
            NSString*userIDBase64String
            =[assertion.userID base64EncodedStringWithOptions:0];
            NSString *credentialIDBase64StringSafe = [credentialIDBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            credentialIDBase64StringSafe = [credentialIDBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
            NSString *rawClientDataJSONBase64StringSafe = [rawClientDataJSONBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            rawClientDataJSONBase64StringSafe = [rawClientDataJSONBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
            NSString *signatureBase64StringSafe = [signatureBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            signatureBase64StringSafe = [signatureBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
            NSString *rawAuthenticatorDataBase64StringSafe = [rawAuthenticatorDataBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            rawAuthenticatorDataBase64StringSafe = [rawAuthenticatorDataBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
            NSString *userIDBase64StringSafe = [userIDBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            userIDBase64StringSafe = [userIDBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
            
            NSMutableDictionary*dic=[[NSMutableDictionary alloc]init];
            [dic setValue:self.assertionId forKey:@"assertionId"];
            NSDictionary*credentialDic=@{@"type":@"public-key",@"id":credentialIDBase64StringSafe,@"rawId":credentialIDBase64StringSafe,@"response":@{@"clientDataJSON":rawClientDataJSONBase64StringSafe,@"authenticatorData":rawAuthenticatorDataBase64StringSafe,@"signature":signatureBase64StringSafe,@"userHandle":self.userHandle},@"clientExtensionResults":@{}};
            [dic setValue:credentialDic forKey:@"credential"];
            [dic setValue:@"passkey" forKey:@"authType"];

            [self loginPasskeywithUserNameForSecondStep:dic];
        }
        
    }
}

// 身份验证失败后的回调
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithError:(NSError *)error  API_AVAILABLE(ios(13.0)){
    self.titleLabel.text=LocalizationKey(@"验证失败");
    self.detailLabel.text=LocalizationKey(@"请重试或者切换密码登录");
    self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon_fail");
    NSLog(@"验证错误--Authorization failed: %@-错误码-%ld", error.localizedDescription,error.code);
}

// 提供 PresentationContext，指定使用当前视图控制器作为授权的展示上下文
- (ASPresentationAnchor)presentationAnchorForAuthorizationController:(ASAuthorizationController *)controller  API_AVAILABLE(ios(13.0)){
    return self.view.window;
}

    //登录通行密钥，弹窗验证之后调用
  -(void)loginPasskeywithUserNameForSecondStep:(NSDictionary*)dic{
      [SVProgressHUD customShowWithStyle];
      [MineNetWorkManager loginPasskeyForSecondStep:dic success:^(id  _Nonnull data) {
         // [SVProgressHUD dismiss];
          //NSLog(@"登录参数--%@",dic);
       
              if ([data[@"code"] intValue]==200) {
                  NSLog(@"登录成功了--%@",data);
                  [UBTNSUserDefaultUtil PutDefaults:ACCESS_TOKEN Value:[NSString stringWithFormat:@"%@%@",data[@"data"][@"token_type"],data[@"data"][@"access_token"]]];
                  [UBTNSUserDefaultUtil PutDefaults:REFRESH_TOKEN Value:[NSString stringWithFormat:@"%@",data[@"data"][@"refresh_token"]]];
                  [self getMemberInfo];

                 
              }else{
                  [SVProgressHUD dismiss];
                  self.titleLabel.text=LocalizationKey(@"验证失败");
                  self.detailLabel.text=LocalizationKey(@"请重试或者切换密码登录");
                  self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon_fail");
                 NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
                  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
              }
          
            } fail:^(NSError * _Nonnull error) {
                [SVProgressHUD dismiss];
                self.titleLabel.text=LocalizationKey(@"验证失败");
                self.detailLabel.text=LocalizationKey(@"请重试或者切换密码登录");
                self.alertImageV.image=UIIMAGE(@"passkeyLoginIcon_fail");
               // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
                
         }];
     
    }


//获取个人信息
-(void)getMemberInfo{
   
   // [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getMemberInfosuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        
        if ([data[@"code"] intValue]==200) {
            [UserWrapper getuserInfoWithDic:data[@"data"]];//存储用户信息
            [self initRootViewController];
            
           
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
         
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

-(void)initRootViewController{
  
    CustomTabBarController *tabbar = [[CustomTabBarController alloc] init];
    APPLICATION.window.rootViewController = tabbar;
    
   }
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
