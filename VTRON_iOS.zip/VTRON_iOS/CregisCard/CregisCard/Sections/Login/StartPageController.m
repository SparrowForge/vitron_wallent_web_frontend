//
//  StartPageController.m
//  CregisCard
//
//  Created by 孙良 on 2024/8/5.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "StartPageController.h"
#import "CustomTabBarController.h"
#import "LoginController.h"
#import "BaseNavigationController.h"
#import "CardsHomeController.h"
#import "AccountPageController.h"
#import "MineController.h"

@interface StartPageController ()

@end

@implementation StartPageController

- (void)viewDidLoad {
    [super viewDidLoad];
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self initRootViewController];
        
    });
   // self.bottomIconEn.hidden=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?NO:YES;
    // Do any additional setup after loading the view from its nib.
}

-(void)initRootViewController{
    
    if ([UserWrapper isLogIn]) {
        
        CustomTabBarController *tabbar = [[CustomTabBarController alloc] init];
        APPLICATION.window.rootViewController = tabbar;
      //  [self  setControlForSuper];
        
    }else{
        LoginController*loginVC=[[LoginController alloc]init];
        BaseNavigationController*loginVCNav=[[BaseNavigationController alloc]initWithRootViewController:loginVC];
        APPLICATION.window.rootViewController = loginVCNav;
          
    }
 
}


#pragma mark -- setControlForSuper
- (void)setControlForSuper
{
    CustomTabBarController *tabBarController = [[CustomTabBarController alloc] init];
    CardsHomeController * cardsVC = [[CardsHomeController alloc]init];
    BaseNavigationController * cardsVCNav = [[BaseNavigationController alloc]initWithRootViewController:cardsVC];

    AccountPageController * accountVC = [[AccountPageController alloc]init];
    BaseNavigationController * accountNav = [[BaseNavigationController alloc]initWithRootViewController:accountVC];

    MineController *mineVC = [[MineController alloc]init];
    BaseNavigationController * mineNav = [[BaseNavigationController alloc]initWithRootViewController:mineVC];
  
    tabBarController.viewControllers = @[accountNav,cardsVCNav,mineNav];
    APPLICATION.window.rootViewController = tabBarController;

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
