//
//  LoginNextController.h
//  CregisCard
//
//  Created by 孙良 on 2024/10/31.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface LoginNextController : BaseViewController
@property(nonatomic,copy) NSString*account;
@end

NS_ASSUME_NONNULL_END
