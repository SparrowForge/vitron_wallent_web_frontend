//
//  CommonInfoManager.m
//  CregisCard
//
//  Created by 孙良 on 2023/8/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CommonInfoManager.h"

@implementation CommonInfoManager
static CommonInfoManager *_manger = nil;

+ (CommonInfoManager *)sharedInstance
{
//用dispatch_once保证内存只分配一次
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manger = [[CommonInfoManager alloc] init];
    });
    
    return _manger;
}

@end
