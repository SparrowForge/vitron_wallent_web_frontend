//
//  CommonInfoManager.h
//  CregisCard
//
//  Created by 孙良 on 2023/8/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CommonInfoManager : NSObject

+ (CommonInfoManager *)sharedInstance;

@property (nonatomic, strong)NSDictionary* rateDic;//全局汇率
@property (nonatomic, strong)NSArray* coinsArray;//获取支持的所有币种，筛选账单流水使用
@end

NS_ASSUME_NONNULL_END
