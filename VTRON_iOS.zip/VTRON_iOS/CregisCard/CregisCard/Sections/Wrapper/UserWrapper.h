//
//  UserWrapper.h
//  component
//
//  Created by sunliang on 2019/2/15.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UserWrapper : NSObject<NSCoding>
@property(nonatomic,copy)NSString *areaCode;
@property(nonatomic,copy)NSString *appId;
@property(nonatomic,copy)NSString *email;
@property(nonatomic,copy)NSString *enterpriseFlag;
@property(nonatomic,copy)NSString *enterpriseIdentity;
@property(nonatomic,copy)NSString *headUrl;
@property(nonatomic,copy)NSString *ID;
@property(nonatomic,copy)NSString *phone;
@property(nonatomic,copy)NSString *ip;
@property(nonatomic,copy)NSString *port;
@property(nonatomic,copy)NSString *realName;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *registTime;
@property(nonatomic,copy)NSString *registerType;
@property(nonatomic,copy)NSString *showOneStatus;//展示状态(0:已展示 1：未展示)
@property(nonatomic,copy)NSString *status;//（状态(0：停用，1:在线，2：离线)）
@property(nonatomic,copy)NSString *username;
@property(nonatomic,copy)NSString *soundStatus;//音效开关 0 关 1开
@property(nonatomic,copy)NSString *memberWorkStatus;//该成员在本项目中的工作状态 0：离线 1：在线
@property(nonatomic,copy)NSString *memberNickName;//成员在某项目中的昵称
@property(nonatomic,copy)NSString *appMemberId;
@property(nonatomic,copy)NSString *memberId;
@property(nonatomic,copy)NSString *roleType;//1.负责人 2.管理员 3.普通成员 4.自定义角色
@property(nonatomic,copy)NSString *roleName;
@property(nonatomic,copy)NSString *roleId;
//关于项目
@property(nonatomic,copy)NSString *symbol;
@property(nonatomic,copy)NSString *appLogo;
@property(nonatomic,copy)NSString *appName;
@property(nonatomic,copy)NSString *appMemberHeadUrl;
@property(nonatomic,copy)NSString *account;//用户名

@property(nonatomic,copy)NSString *isPayPassword;//交易密码
@property(nonatomic,copy)NSString *kycRemark;
@property(nonatomic,copy)NSString *googleStatus;//谷歌认证 1 开启 0 未开启 2未绑定
@property(nonatomic,copy)NSString *kycStatus;//kyc认证,0.用户提交 1.后台审核完成 2. 待用户人脸识别 3.待 ipeakoin 审核 4.审核不通过 5.审核通过 7从未提交过kyc

@property(nonatomic,copy)NSString *distributorStatus;//分销商状态 0禁用 1正常 null非分销商

@property(nonatomic,copy)NSString *emailCheck;//1 安全验证时候需要邮箱/谷歌验证码 0 不需要验证码
/*  通过初始化userIfo并保存在本地(单利模式)   */
+(instancetype)getuserInfoWithDic:(NSDictionary *)dic;

/*  获取用户已登陆的信息 */
+(instancetype)shareUserInfo;

/*  判断用户时否登陆 */
+(BOOL)isLogIn;

/*  退出登陆 */
+(instancetype)logout;

/*  保存当前userInfo */
+(void)saveUser:(UserWrapper *)userInfo;


@end

NS_ASSUME_NONNULL_END
