//
//  UserWrapper.m
//  component
//
//  Created by sunliang on 2019/2/15.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import "UserWrapper.h"
#import "UserDecoder.h"

#define USERINFO @"USERINFO"

static UserWrapper *userInfo = nil;

@implementation UserWrapper

/*  通过初始化userIfo并保存在本地(单利模式)   */
+(instancetype)getuserInfoWithDic:(NSDictionary *)dic{
   
    userInfo = [[UserWrapper alloc] initWithDictionary:dic];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:userInfo];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:USERINFO];
    [[NSUserDefaults standardUserDefaults] synchronize];//及时存储数据
    return userInfo;
}

-(id)initWithDictionary:(NSDictionary *)dic{
    if (self = [super init]) {
        [self mj_setKeyValues:dic];
    }
    return self;
}

 + (NSDictionary *)mj_replacedKeyFromPropertyName {
   return @{@"ID" : @"id"
     };
 }

/*  获取用户已登陆的信息 */
+(instancetype)shareUserInfo{
    
    if (userInfo == nil) {
        NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:USERINFO];
        if (data) {
            userInfo =[NSKeyedUnarchiver unarchiveObjectWithData:data];
            return userInfo;
        }
    }
    return userInfo;
}

/*  判断用户是否登陆 */
+(BOOL)isLogIn{
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:USERINFO];
    if (data) {
        userInfo = [NSKeyedUnarchiver unarchiveObjectWithData:data];
        if (![NSString stringIsNull:userInfo.ID]) {
            return YES;
        }else{
            return NO;
        }
    }else{
        return NO;
    }
}

/*  退出登陆 */
+(instancetype)logout{
    userInfo = nil;
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:USERINFO];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:REFRESH_TOKEN];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:ACCESS_TOKEN];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:APPID_TOKEN];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *_tmpArray = [NSArray arrayWithArray:[cookieJar cookies]];
    for (id obj in _tmpArray) {
        [cookieJar deleteCookie:obj];//清除cookie缓存
        
    }
    return userInfo;
}

/*  保存当前userInfo */
+(void)saveUser:(UserWrapper *)userInfo{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:userInfo];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:USERINFO];
    [[NSUserDefaults standardUserDefaults] synchronize];//及时存储数据
}

- (NSString *)description
{
    return [self mj_keyValues].description;
}



WZLSERIALIZE_CODER_DECODER()

@end
