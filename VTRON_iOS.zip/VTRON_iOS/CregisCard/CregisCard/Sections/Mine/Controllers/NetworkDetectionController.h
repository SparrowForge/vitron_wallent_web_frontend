//
//  NetworkDetectionController.h
//  CregisCard
//
//  Created by sunliang on 2025/5/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface NetworkDetectionController : BaseViewController
@property(nonatomic,assign)int popType;//0 正常页面进入 1 登录页面进入
@end

NS_ASSUME_NONNULL_END
