//
//  InviteController.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "InviteController.h"
#import "InviteView.h"
#import "InviteRecordController.h"
#import "OriginalIncomeController.h"
#import "MineNetWorkManager.h"
#import "InviteDetailView.h"

@interface InviteController ()
@property(nonatomic,strong) InviteView*inviteView;
@property(nonatomic,strong) InviteDetailView*detailView;
@property(nonatomic,strong) NSDictionary*merchantDistributorInfoVo;
@end

@implementation InviteController

- (InviteDetailView *)detailView {
    if(!_detailView) {
        _detailView=[InviteDetailView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 220)];
    }
    return _detailView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    if (![NSString stringIsNull:[UserWrapper shareUserInfo].distributorStatus]) {
        if ([[UserWrapper shareUserInfo].distributorStatus intValue]==0) {
            //禁用
            [self RightsetupNavgationItemWithImage:UIIMAGE(@"inviteRecord") withColor:[UIColor blackColor]];
        }else{
            //正常
            [self setRightBarItem];
        }
    
    }
    UIView*footView=[[UIView alloc]initWithFrame:CGRectMake(0, kWindowH-100, kWindowW, 100)];
    UIButton*submitBtn=[[UIButton alloc]initWithFrame:CGRectMake(20, 30, kWindowW-40, 50)];
    [submitBtn setCornerRadius:25];
    [submitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    submitBtn.backgroundColor=[UIColor mainBtnColor];
    [submitBtn setTitle:LocalizationKey(@"立即邀请") forState:UIControlStateNormal];
    submitBtn.titleLabel.font=PingFangMediumFont(15);
    WEAKSELF
    [submitBtn dn_addActionHandler:^{
        [weakSelf showInviteDetailInfo];
    }];
    [footView addSubview:submitBtn];
    [self.view addSubview:footView];
    UIScrollView*scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT-100)];
    [self.view addSubview:scrollView];
    scrollView.contentSize=CGSizeMake(kWindowW,100+(kWindowW-27*2)*562/670+149+160+65);
    self.inviteView=[InviteView instanceViewWithFrame:CGRectMake(0, 0, kWindowW,100+(kWindowW-27*2)*562/670+149+160+65)];
    [scrollView addSubview:self.inviteView];
    [self.inviteView configUI];
    if ([NSString stringIsNull:[UserWrapper shareUserInfo].distributorStatus]) {
        //未开启分销商
        footView.hidden=YES;
        footView.frame=CGRectMake(0, kWindowH-100, kWindowW, 0);
        scrollView.frame=CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT);
    }else{
        if ([[UserWrapper shareUserInfo].distributorStatus intValue]==1) {
            //分销商功能正常
            footView.hidden=NO;
            footView.frame=CGRectMake(0, kWindowH-100, kWindowW, 100);
            scrollView.frame=CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT-100);

        }else{
            //分销商功能被禁用
            footView.hidden=YES;
            footView.frame=CGRectMake(0, kWindowH-100, kWindowW, 0);
            scrollView.frame=CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT);

        }
    }
    // Do any additional setup after loading the view.
}

-(void)setRightBarItem{
    //费率
    UIButton*firstButton=[[UIButton alloc]init];
    [firstButton setBackgroundImage:UIIMAGE(@"inviteFeeIcon") forState:UIControlStateNormal];
    [firstButton addTarget:self action:@selector(firstButtonAction) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *firstItem =[[UIBarButtonItem alloc] initWithCustomView:firstButton];
    //邀请记录
    UIButton*secondBtn=[[UIButton alloc]init];
    [secondBtn setBackgroundImage:UIIMAGE(@"inviteRecord") forState:UIControlStateNormal];
    [secondBtn addTarget:self action:@selector(rightTouchEvent) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *secondItem =[[UIBarButtonItem alloc] initWithCustomView:secondBtn];
    UIBarButtonItem *customSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    customSpace.width = 15;
    self.navigationItem.rightBarButtonItems = @[secondItem,customSpace,firstItem];
 
}

//初始费率
- (void)firstButtonAction {
    
    OriginalIncomeController*incomeVC=[[OriginalIncomeController alloc]init];
    incomeVC.merchantDistributorInfoVo=self.merchantDistributorInfoVo;
    [self.navigationController pushViewController:incomeVC animated:YES];
}

//邀请记录
- (void)rightTouchEvent {
    [self.navigationController pushViewController:[[InviteRecordController alloc]init] animated:YES];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
    [self getDistributorInfo];
}


//获取邀请信息
-(void)getDistributorInfo{
   [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getDistributorInfosuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            self.merchantDistributorInfoVo=data[@"data"][@"merchantDistributorInfoVo"];
            [self.inviteView configUIWithDic:data[@"data"]];
            [self.detailView configUIWithDic:data[@"data"]];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
            
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
    
}

-(void)showInviteDetailInfo{
    
    [self.detailView show];
    
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAutomatic;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
