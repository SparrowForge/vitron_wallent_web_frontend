//
//  EditIncomeController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/11.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "EditIncomeController.h"
#import "UserDetailHeaderView.h"
#import "EditIncomeCell.h"
#import "IdentityHeadView.h"
#import "MineNetWorkManager.h"

@interface EditIncomeController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property(nonatomic,strong) UserDetailHeaderView*userHeadView;
@property(nonatomic,strong) NSArray*titleArray;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) NSArray*placeholderArray;
@property(nonatomic,strong) NSMutableDictionary*contentDic;

@end

@implementation EditIncomeController

-(NSMutableDictionary*)contentDic{
    if (!_contentDic) {
        _contentDic=[[NSMutableDictionary  alloc]init];
    }
    return _contentDic;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"编辑");
    [self.okBtn setTitle:LocalizationKey(@"保存") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];

    if ([[ChangeLanguage userLanguage] isEqualToString:@"en"]) {
        self.titleArray=@[LocalizationKey(@"卡片申请佣金"),LocalizationKey(@"消费佣金"),LocalizationKey(@"退款佣金")];
        
    }else{
        self.titleArray=@[LocalizationKey(@"卡片申请佣金"),[NSString stringWithFormat:@"%@ (%@)",LocalizationKey(@"消费佣金"),LocalizationKey(@"固定值+百分比")],[NSString stringWithFormat:@"%@ (%@)",LocalizationKey(@"退款佣金"),LocalizationKey(@"固定值+百分比")]];
    
    }
   
    self.placeholderArray=@[@[LocalizationKey(@"请输入固定值")],@[LocalizationKey(@"请输入固定值"),LocalizationKey(@"请输入百分比")],@[LocalizationKey(@"请输入固定值"),LocalizationKey(@"请输入百分比")]];
    if (self.type==0) {
        self.contentArray=[@[@[[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initApplyCard"] doubleValue]]],@[[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initConsumerFee"] doubleValue]],[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initConsumerFeeRate"] doubleValue]]],@[[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initOutCardFee"] doubleValue]],[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initOutCardFeeRate"] doubleValue]]]] mutableCopy];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initApplyCard"] doubleValue]] forKey:@"initApplyCard"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initConsumerFee"] doubleValue]] forKey:@"initConsumerFee"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initConsumerFeeRate"] doubleValue]] forKey:@"initConsumerFeeRate"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initOutCardFee"] doubleValue]] forKey:@"initOutCardFee"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initOutCardFeeRate"] doubleValue]] forKey:@"initOutCardFeeRate"];
    }else{
        //从用户详情进来
        self.contentArray=[@[@[[NSString formattedStringWithDouble:[self.inviteModel.applyCard doubleValue]]],@[[NSString formattedStringWithDouble:[self.inviteModel.consumerFee doubleValue]],[NSString formattedStringWithDouble:[self.inviteModel.consumerFeeRate doubleValue]]],@[[NSString formattedStringWithDouble:[self.inviteModel.outCardFee doubleValue]],[NSString formattedStringWithDouble:[self.inviteModel.outCardFeeRate doubleValue]]]] mutableCopy];
      
        
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.inviteModel.applyCard doubleValue]] forKey:@"applyCard"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.inviteModel.consumerFee doubleValue]] forKey:@"consumerFee"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.inviteModel.consumerFeeRate doubleValue]] forKey:@"consumerFeeRate"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.inviteModel.outCardFee doubleValue]] forKey:@"outCardFee"];
        [self.contentDic setValue:[NSString formattedStringWithDouble:[self.inviteModel.consumerFeeRate doubleValue]] forKey:@"outCardFeeRate"];
    }
    
   
    [self configTableView];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
}
-(void)configTableView{
    
    if (self.type==1) {
        //从用户详情进来
        //延迟执行
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 120)];
            self.userHeadView=[UserDetailHeaderView instanceViewWithFrame:headView.bounds];
            self.userHeadView.model=self.inviteModel;
            [headView addSubview:self.userHeadView];
            self.tableView.tableHeaderView=self.userHeadView;
        });
       
    }
    
    [self.tableView registerNib:[UINib nibWithNibName:@"EditIncomeCell" bundle:nil] forCellReuseIdentifier:@"EditIncomeCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityHeadView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"IdentityHeadView"];
    self.tableView.rowHeight=64;
    self.tableView.tableFooterView=[UIView new];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    EditIncomeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EditIncomeCell"];
    [cell configDataAtIndexPath:indexPath withContentArray:self.contentArray withplaceholderArray:self.placeholderArray];
    WEAKSELF
    cell.incomeBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString, int tag) {
        [weakSelf dealWithDataWithtypeString:typeString withvalueString:valueString withtag:tag];
        
    };
    return cell;
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 50;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.titleArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section==0) {
        return 1;
    }
    return 2;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    IdentityHeadView*sectionView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"IdentityHeadView"];
    [sectionView editIncomeInSection:section withtitleArray:self.titleArray];
    return sectionView;
}
//保存
- (IBAction)toSave:(id)sender {
    
    NSLog(@"最终的数据是--%@",self.contentDic);
    NSString*applyCardKey=self.type==0?@"initApplyCard":[self dealwithTypeWithOrignal:@"initApplyCard"];
    NSString*consumerFeeKey=self.type==0?@"initConsumerFee":[self dealwithTypeWithOrignal:@"initConsumerFee"];
    NSString*consumerFeeRateKey=self.type==0?@"initConsumerFeeRate":[self dealwithTypeWithOrignal:@"initConsumerFeeRate"];
    NSString*outCardFeeKey=self.type==0?@"initOutCardFee":[self dealwithTypeWithOrignal:@"initOutCardFee"];
    NSString*outCardFeeRateKey=self.type==0?@"initOutCardFeeRate":[self dealwithTypeWithOrignal:@"initOutCardFeeRate"];
    if ([NSString stringIsNull:self.contentDic[applyCardKey]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入卡片申请佣金"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[consumerFeeKey]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入消费佣金固定值"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[consumerFeeRateKey]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入消费佣金百分比"));
        return;
    }
    if ([self.contentDic[consumerFeeRateKey] doubleValue]>100) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"消费佣金百分比不能大于100%"));
        return;
    }
  
    if ([NSString stringIsNull:self.contentDic[outCardFeeKey]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入退款佣金固定值"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[outCardFeeRateKey]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入退款佣金百分比"));
        return;
    }
    
    if ([self.contentDic[outCardFeeRateKey] doubleValue]>100) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"退款佣金百分比不能大于100%"));
        return;
    }
  
    if (self.type==0) {
        //从编辑初始加点进来
       [SVProgressHUD customShowWithStyle];
        [MineNetWorkManager  editDistributorInfoWithParams:self.contentDic success:^(id  _Nonnull data) {
            [SVProgressHUD dismiss];
            if ([data[@"code"] intValue]==200) {
                ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"编辑成功"));
                [self.view endEditing:YES];
                if (self.infoblock) {
                    self.infoblock(self.contentDic);
                }
                //延迟执行
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self.navigationController popViewControllerAnimated:YES];
                });
            }else{
                NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
                
            }
                
            } fail:^(NSError * _Nonnull error) {
                [SVProgressHUD dismiss];
               // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            }];
    }else{
       //从用户详情进来
        [self.contentDic setValue:self.inviteModel.merchantId forKey:@"merchantId"];
       [SVProgressHUD customShowWithStyle];
        [MineNetWorkManager  editDistributorSomeoneInfoWithParams:self.contentDic success:^(id  _Nonnull data) {
            [SVProgressHUD dismiss];
            if ([data[@"code"] intValue]==200) {
                ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"编辑成功"));
                [self.view endEditing:YES];
                if (self.infoblock) {
                    self.infoblock(self.contentDic);
                }
                //延迟执行
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self.navigationController popViewControllerAnimated:YES];
                });
            }else{
                NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
                
            }
                
            } fail:^(NSError * _Nonnull error) {
                [SVProgressHUD dismiss];
              //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            }];
    }
    
   
   
}


-(void)dealWithDataWithtypeString:(NSString *)typeString withvalueString:(NSString *)valueString withtag:(int)tag{
    if (self.type==0) {
        [self.contentDic setValue:valueString forKey:typeString];
    }else{
        //从用户详情进来
        [self.contentDic setValue:valueString forKey:[self dealwithTypeWithOrignal:typeString]];
    }
  
    if (tag==0) {
        [self.contentArray replaceObjectAtIndex:0 withObject:@[valueString]];
        
    }else if(tag==1){
        
        NSMutableArray*dataArray=[[NSMutableArray alloc]initWithArray:[self.contentArray objectAtIndex:1]];
        [dataArray replaceObjectAtIndex:0 withObject:valueString];
        [self.contentArray replaceObjectAtIndex:1 withObject:dataArray];
        
    }else if(tag==3){
        NSMutableArray*dataArray=[[NSMutableArray alloc]initWithArray:[self.contentArray objectAtIndex:1]];
        [dataArray replaceObjectAtIndex:1 withObject:valueString];
        [self.contentArray replaceObjectAtIndex:1 withObject:dataArray];
        
    }else if(tag==2){
        NSMutableArray*dataArray=[[NSMutableArray alloc]initWithArray:[self.contentArray objectAtIndex:2]];
        [dataArray replaceObjectAtIndex:0 withObject:valueString];
        [self.contentArray replaceObjectAtIndex:2 withObject:dataArray];
        
    }else if(tag==4){
        NSMutableArray*dataArray=[[NSMutableArray alloc]initWithArray:[self.contentArray objectAtIndex:2]];
        [dataArray replaceObjectAtIndex:1 withObject:valueString];
        [self.contentArray replaceObjectAtIndex:2 withObject:dataArray];
        
    }else{
        //不存在
    }
    [self judgeBtnStatus];
}

-(NSString*)dealwithTypeWithOrignal:(NSString*)type{
    if ([type isEqualToString:@"initApplyCard"]) {
        return @"applyCard";
    }else if ([type isEqualToString:@"initConsumerFee"]){
        return @"consumerFee";
    }
    else if ([type isEqualToString:@"initConsumerFeeRate"]){
        return @"consumerFeeRate";
    }else if ([type isEqualToString:@"initOutCardFee"]){
        return @"outCardFee";
    }else if ([type isEqualToString:@"initOutCardFeeRate"]){
        return @"outCardFeeRate";
    }
    
    return @"";
}

-(void)judgeBtnStatus{
    
    NSString*applyCardKey=self.type==0?@"initApplyCard":[self dealwithTypeWithOrignal:@"initApplyCard"];
    NSString*consumerFeeKey=self.type==0?@"initConsumerFee":[self dealwithTypeWithOrignal:@"initConsumerFee"];
    NSString*consumerFeeRateKey=self.type==0?@"initConsumerFeeRate":[self dealwithTypeWithOrignal:@"initConsumerFeeRate"];
    NSString*outCardFeeKey=self.type==0?@"initOutCardFee":[self dealwithTypeWithOrignal:@"initOutCardFee"];
    NSString*outCardFeeRateKey=self.type==0?@"initOutCardFeeRate":[self dealwithTypeWithOrignal:@"initOutCardFeeRate"];
    if ([NSString stringIsNull:self.contentDic[applyCardKey]]||[NSString stringIsNull:self.contentDic[consumerFeeKey]]||[NSString stringIsNull:self.contentDic[consumerFeeRateKey]]||[NSString stringIsNull:self.contentDic[outCardFeeKey]]||[NSString stringIsNull:self.contentDic[outCardFeeRateKey]]) {
            self.okBtn.enabled=NO;
            [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    }else{
        
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
  
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
