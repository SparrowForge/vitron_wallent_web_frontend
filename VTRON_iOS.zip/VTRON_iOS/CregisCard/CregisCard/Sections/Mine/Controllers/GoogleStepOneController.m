//
//  GoogleStepOneController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "GoogleStepOneController.h"
#import "GoogleStepTwoController.h"
#import "LoginAuthenticationView.h"
@interface GoogleStepOneController ()
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIView *googleView;
@property (weak, nonatomic) IBOutlet UIImageView *googleIcon;
@property (weak, nonatomic) IBOutlet UILabel *alertLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconStatus;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *resetBtnHeight;
@property (weak, nonatomic) IBOutlet UILabel *googleTitleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;

@property(nonatomic,strong) LoginAuthenticationView*loginAuthView;
@end

@implementation GoogleStepOneController

- (LoginAuthenticationView *)loginAuthView {
    int type=[[UserWrapper shareUserInfo].googleStatus intValue]==0?7:8;
    if(!_loginAuthView) {
        _loginAuthView=[LoginAuthenticationView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320+0+106) withVerifyPermissionType:type withGoogleVerify:YES];
    }
    return _loginAuthView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"谷歌认证");
    self.googleTitleLabel.text=LocalizationKey(@"谷歌验证器");
    [self.okBtn setTitle:LocalizationKey(@"立即绑定") forState:UIControlStateNormal];
    self.googleTitleLabel.font=PingFangMediumFont(17);
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self.resetBtn setTitle:LocalizationKey(@"重置") forState:UIControlStateNormal];
    self.resetBtn.titleLabel.font=PingFangMediumFont(15);
    [self setupNavigationBarTheme];
    [self setBorderView:self.googleView];
    [self setGoogleStatus];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
  }

-(void)setGoogleStatus{
    
    if ([[UserWrapper shareUserInfo].googleStatus intValue]==0) {
        //当前是未开启状态
        self.alertLabel.text=LocalizationKey(@"已关闭");
        [self.okBtn setTitle:LocalizationKey(@"开启") forState:UIControlStateNormal];
        self.iconStatus.image=UIIMAGE(@"googleRow");
        self.resetBtn.hidden=NO;
        self.resetBtnHeight.constant=50;
        self.topDistance.constant=10;
       
    }else if ([[UserWrapper shareUserInfo].googleStatus intValue]==1)
    {
        //当前是开启状态
        self.alertLabel.text=LocalizationKey(@"使用中");
        [self.okBtn setTitle:LocalizationKey(@"关闭") forState:UIControlStateNormal];
        self.iconStatus.image=UIIMAGE(@"google_Normal");
        self.resetBtn.hidden=NO;
        self.resetBtnHeight.constant=50;
        self.topDistance.constant=10;
    }else{
        //当前是未绑定状态
        self.alertLabel.text=LocalizationKey(@"未绑定");
        [self.okBtn setTitle:LocalizationKey(@"立即绑定") forState:UIControlStateNormal];
        self.iconStatus.image=UIIMAGE(@"googleRow");
        self.resetBtn.hidden=YES;
        self.resetBtnHeight.constant=0;
        self.topDistance.constant=0;
    }

}


-(void)setBorderView:(UIView*)view{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
}
/*
- (void)setupNavigationBarTheme
{
    UINavigationBar *appearance = [UINavigationBar appearance];
    // 设置普通标题属性
    NSMutableDictionary *textAttrs            = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor mainTextColor];
    textAttrs[NSFontAttributeName]            = [UIFont boldSystemFontOfSize:18];
    [appearance setTitleTextAttributes:textAttrs];
    [appearance setShadowImage:nil];
    [appearance setTranslucent:YES]; // 默认为YES
    // 设置导航按钮颜色
    appearance.tintColor = [UIColor whiteColor];
    // 设置导航栏背景颜色
    appearance.barTintColor =[UIColor whiteColor];
    // 设置状态样式
    appearance.barStyle = UIBarStyleBlackOpaque;

    if (@available(iOS 15.0, *)) {
        UINavigationBarAppearance *barApp = [UINavigationBarAppearance new];
        barApp.backgroundColor = [UIColor whiteColor];
        // 设置大标题属性
        NSMutableDictionary *largeTitleTextAttrs = [NSMutableDictionary dictionary];
        largeTitleTextAttrs[NSForegroundColorAttributeName] = [UIColor blackColor];
        largeTitleTextAttrs[NSFontAttributeName] = [UIFont boldSystemFontOfSize:15];
        barApp.largeTitleTextAttributes = largeTitleTextAttrs;
        
        // 设置普通标题属性
        barApp.titleTextAttributes = textAttrs;

        self.navigationController.navigationBar.scrollEdgeAppearance = barApp;
        self.navigationController.navigationBar.standardAppearance = barApp;
    } else if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground];
        appearance.shadowColor = [UIColor clearColor]; // 导航黑线
        appearance.backgroundColor = [UIColor whiteColor];
        
        // 设置大标题属性
        NSMutableDictionary *largeTitleTextAttrs = [NSMutableDictionary dictionary];
        largeTitleTextAttrs[NSForegroundColorAttributeName] = [UIColor blackColor];
        largeTitleTextAttrs[NSFontAttributeName] = [UIFont boldSystemFontOfSize:15];
        appearance.largeTitleTextAttributes = largeTitleTextAttrs;

        // 设置普通标题属性
        appearance.titleTextAttributes = textAttrs;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // 处理早期版本的设置
    }
}
*/

- (void)setupNavigationBarTheme {
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground]; // 配置不透明背景
        appearance.backgroundColor = [UIColor whiteColor]; // 设置背景颜色
        appearance.shadowColor = [UIColor clearColor]; // 去掉黑线
        // 设置普通标题属性
        NSDictionary *titleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:18]
        };
        appearance.titleTextAttributes = titleTextAttributes;

        // 设置大标题属性
        NSDictionary *largeTitleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:29]
        };//文字太大，一行显示不完。系统默认的大标题（Large Title）的字体大小为 34 points
        appearance.largeTitleTextAttributes = largeTitleTextAttributes;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // iOS 13 以下版本，使用 shadowImage 方式去掉黑线
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

- (IBAction)tipsClick:(UIButton *)sender {
    
    if ([[UserWrapper shareUserInfo].googleStatus intValue]==0) {
        //当前是未开启状态，去开启
        [self.loginAuthView showWithAccount:[UserWrapper shareUserInfo].email withPassword:nil withinviteCode:nil];
        WEAKSELF
        self.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable dic) {
            [weakSelf.navigationController popViewControllerAnimated:YES];
        };
        
    }else if ([[UserWrapper shareUserInfo].googleStatus intValue]==1)
    {
        //当前是开启状态，去关闭
        
       
    }else{
        //未绑定
        GoogleStepTwoController*googleVC=[[GoogleStepTwoController alloc]init];
        googleVC.type=0;
        [self.navigationController pushViewController:googleVC animated:YES];
    }
    
}



//MARK: 立即开始
- (IBAction)benginClick:(id)sender {
    UIButton*btn=(UIButton*)sender;
    if (btn.tag==0) {
        
        
    }else if (btn.tag==1)
    {
      //开启，关闭， 去绑定
        if ([[UserWrapper shareUserInfo].googleStatus intValue]==0) {
            //当前是未开启状态，去开启
            [self.loginAuthView showWithAccount:[UserWrapper shareUserInfo].email withPassword:nil withinviteCode:nil];
            WEAKSELF
            self.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable dic) {
                [weakSelf.navigationController popViewControllerAnimated:YES];
            };
            
        }else if ([[UserWrapper shareUserInfo].googleStatus intValue]==1)
        {
            //当前是开启状态，去关闭
            [self.loginAuthView showWithAccount:[UserWrapper shareUserInfo].email withPassword:nil withinviteCode:nil];
            WEAKSELF
            self.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable dic) {
                [weakSelf.navigationController popViewControllerAnimated:YES];
            };
           
        }else{
            //未绑定
            GoogleStepTwoController*googleVC=[[GoogleStepTwoController alloc]init];
            googleVC.type=0;
            [self.navigationController pushViewController:googleVC animated:YES];
        }
        
        
    }else{
        //重置
        GoogleStepTwoController*googleVC=[[GoogleStepTwoController alloc]init];
        googleVC.type=1;
        [self.navigationController pushViewController:googleVC animated:YES];
        
        
    }
 
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
