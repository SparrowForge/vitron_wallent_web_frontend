//
//  SafeCenterController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "SafeCenterController.h"
#import "ModifyEmailController.h"
#import "GoogleStatusCell.h"
#import "BasicInfoCell.h"
#import "PayPasswordController.h"
#import "GooglePermissionView.h"
#import "MineNetWorkManager.h"
#import "GoogleStepOneController.h"
#import "LogOutView.h"
#import "LoginController.h"
#import "PassKeySetController.h"
#import "NetworkDetectionController.h"

@interface SafeCenterController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic)  UITableView *tableView;
@property(nonatomic,strong)    LogOutView *logoutView;
@property(nonatomic,strong)    GooglePermissionView*googleView;
@property(nonatomic,strong)    NSMutableArray*titleArray;
@property(nonatomic,strong)    NSMutableArray*imageArray;
@property(nonatomic,strong)    NSMutableArray*contentArray;
@end

@implementation SafeCenterController

- (LogOutView *)logoutView {
    if(!_logoutView) {
        _logoutView=[LogOutView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
    }
    return _logoutView;
}
- (GooglePermissionView *)googleView {
    if(!_googleView) {
        _googleView=[GooglePermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350)];
     
    }
    return _googleView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"账户安全");
    self.imageArray=[@[@"changeEmailIcon",@"passKeySetIcon",@"changeGoogleIcon",@"changeTradepswIcon",@"changeloginpswIcon",@"netDetectionIcon"] mutableCopy];
    self.titleArray=[@[LocalizationKey(@"更换邮箱"),LocalizationKey(@"通行密钥"),LocalizationKey(@"谷歌认证"),LocalizationKey(@"交易密码"),LocalizationKey(@"登录密码"),LocalizationKey(@"网络诊断")] mutableCopy];
    if ([Appstore_account isEqualToString:[UserWrapper shareUserInfo].email]) {
        [self.titleArray addObject:LocalizationKey(@"注销账户")];
        [self.imageArray addObject:@"cancelAccount"];
    }
    
    [self setTableViewConfig];
  
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAlways;
    [self setupNavigationBarTheme];
    NSString*passwordStatus=[[UserWrapper shareUserInfo].isPayPassword intValue]==0?LocalizationKey(@"去设置"):LocalizationKey(@"修改");
    self.contentArray=[@[@"",@"",@"",passwordStatus,LocalizationKey(@"修改"),@""] mutableCopy];
    if ([Appstore_account isEqualToString:[UserWrapper shareUserInfo].email]) {
        [self.contentArray addObject:@""];
    }
    [self.tableView reloadData];
   
}

- (void)setupNavigationBarTheme {
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground]; // 配置不透明背景
        appearance.backgroundColor = [UIColor whiteColor]; // 设置背景颜色
        appearance.shadowColor = [UIColor clearColor]; // 去掉黑线
        // 设置普通标题属性
        NSDictionary *titleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:18]
        };
        appearance.titleTextAttributes = titleTextAttributes;

        // 设置大标题属性
        NSDictionary *largeTitleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:29]
        };//系统默认的大标题（Large Title）的字体大小为 34 points
        appearance.largeTitleTextAttributes = largeTitleTextAttributes;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // iOS 13 以下版本，使用 shadowImage 方式去掉黑线
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

-(void)setTableViewConfig{
    
    UIButton*logoutBtn=[[UIButton alloc]initWithFrame:CGRectMake(20, kWindowH-50-20-HOME_INDICATOR_HEIGHT, kWindowW-40, 50)];
    [logoutBtn setCornerRadius:25.0];
    [logoutBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [logoutBtn setTitle:LocalizationKey(@"退出登录") forState:UIControlStateNormal];
    logoutBtn.titleLabel.font=PingFangMediumFont(15);
    logoutBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    WEAKSELF
    [logoutBtn dn_addActionHandler:^{
        [weakSelf logoOut];
    }];
    [self.view addSubview:logoutBtn];
    
    self.tableView =[[UITableView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-(50+20+HOME_INDICATOR_HEIGHT+20)) style:UITableViewStylePlain];
    self.tableView.backgroundColor=[UIColor whiteColor];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.tableView registerNib:[UINib nibWithNibName:@"BasicInfoCell" bundle:nil] forCellReuseIdentifier:@"BasicInfoCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"GoogleStatusCell" bundle:nil] forCellReuseIdentifier:@"GoogleStatusCell"];
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 18)];
    self.tableView.tableHeaderView=headView;
    self.tableView.tableFooterView=[UIView new];
    [self.view addSubview:self.tableView];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count        ;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==2) {
        //谷歌验证
        GoogleStatusCell*cell=[tableView dequeueReusableCellWithIdentifier:@"GoogleStatusCell"];
        [cell setButtonStyle];
        /*
        WEAKSELF
        [cell.resetBtn dn_addActionHandler:^{
           //重置/去开启
            [weakSelf.navigationController pushViewController:[[GoogleStepOneController alloc]init] animated:YES];
        }];
        
        [cell.statusBtn dn_addActionHandler:^{
            int type=[[UserWrapper shareUserInfo].googleStatus intValue]==0?0:1;
            [weakSelf.googleView showGoogleViewWitype:type success:^(BOOL success) {
                [weakSelf.tableView reloadData];
                
            }];
        }];
         */
        return cell;
    }else{
        
        BasicInfoCell*cell=[tableView dequeueReusableCellWithIdentifier:@"BasicInfoCell"];
        [cell configSafeCenterWithTitle:self.titleArray[indexPath.row] withContent:self.contentArray[indexPath.row] withImageName:self.imageArray[indexPath.row] AtIndexPath:indexPath];
        return cell;
    }
   
    
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        //更换邮箱
        [self.navigationController pushViewController:[[ModifyEmailController alloc]init] animated:YES];
    }else  if (indexPath.row==1) {
        //通行密钥
        PassKeySetController*passKeyVC=[[PassKeySetController alloc]init];
        [self.navigationController pushViewController:passKeyVC animated:YES];
    }
    else  if (indexPath.row==2) {
        //谷歌验证
        [self.navigationController pushViewController:[[GoogleStepOneController alloc]init] animated:YES];
      

    }  else  if (indexPath.row==3) {
       
        //交易密码
        PayPasswordController*pswVC=[[PayPasswordController alloc]init];
        pswVC.type=1;
        [self.navigationController pushViewController:pswVC animated:YES];
    }
    else if (indexPath.row==4){
        //登录密码
        PayPasswordController*pswVC=[[PayPasswordController alloc]init];
        pswVC.type=0;
        [self.navigationController pushViewController:pswVC animated:YES];
    } else if (indexPath.row==5){
        //网络诊断
        NetworkDetectionController*netVC=[[NetworkDetectionController alloc]init];
        [self.navigationController pushViewController:netVC animated:YES];
    }
    else{
        //注销账户
        [self closeAccount];
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==1) {
        return 0.001;//隐藏通行密钥
    }
    return 60;
}

//MARK:退出登录
-(void)logoOut{
    
    [self.logoutView show];
    WEAKSELF
    [self.logoutView.okBtn dn_addActionHandler:^{
         [weakSelf.logoutView hide];
         [weakSelf postLogoutRequest];
         [weakSelf initRootViewController];
         [UserWrapper logout];
            
    }];
}

-(void)initRootViewController{
    LoginController*loginVC=[[LoginController alloc]init];
    BaseNavigationController*loginNav=[[BaseNavigationController alloc]initWithRootViewController:loginVC];
    APPLICATION.window.rootViewController = loginNav;
}

//MARK: 退出登录请求
-(void)postLogoutRequest{
    
    [LoginNetWorkManager logoutsuccess:^(id  _Nonnull data) {
        
        if ([data[@"code"] intValue]==200) {
            NSLog(@"退出登录成功");
        }
        
    } fail:^(NSError * _Nonnull error) {
        
    }];
    
}

//注销账户
-(void)closeAccount{
   
    WEAKSELF
    [weakSelf addUIAlertControlWithString:LocalizationKey(@"确定注销账户?") withActionBlock:^{
        [weakSelf toCloseAccount];
       
        } andCancel:^{
            
        }];
}

//注销账户
-(void)toCloseAccount{
    [self postLogoutRequest];
    [UserWrapper logout];
    [self initRootViewController];
   
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
