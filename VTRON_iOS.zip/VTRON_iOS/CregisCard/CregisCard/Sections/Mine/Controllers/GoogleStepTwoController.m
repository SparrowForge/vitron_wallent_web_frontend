//
//  GoogleStepTwoController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "GoogleStepTwoController.h"
#import "YCMenuView.h"
#import "MineNetWorkManager.h"
#import "LoginAuthenticationView.h"
#import "CustomPopView.h"

@interface GoogleStepTwoController ()
@property (weak, nonatomic) IBOutlet UILabel *secretLabel;
@property (weak, nonatomic) IBOutlet UIImageView *erCodeImageV;

@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIButton *copyeBtn;
@property(nonatomic,strong) LoginAuthenticationView*loginAuthView;
@property(nonatomic,strong) CustomPopView*customPopView;
@end

@implementation GoogleStepTwoController

- (CustomPopView *)customPopView {
    if(!_customPopView) {
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?280:200;
        _customPopView=[CustomPopView instanceViewWithFrame:CGRectMake(0, 0, kWindowW-40, height) withMenuType:GoogleVerify];
    }
    return _customPopView;
}
- (LoginAuthenticationView *)loginAuthView {
    if(!_loginAuthView) {
        _loginAuthView=[LoginAuthenticationView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320+0+106) withVerifyPermissionType:9 withGoogleVerify:YES];
    }
    return _loginAuthView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"谷歌认证");
    self.secretLabel.font=PingFangMediumFont(15);
    self.detailLabel.text=LocalizationKey(@"打开Google Authenticator应用扫码，或复制密钥至应用。完成绑定。");
    [self.copyeBtn setTitle:[NSString stringWithFormat:@" %@",LocalizationKey(@"复制")] forState:UIControlStateNormal];
    if (self.type==0) {
        [self.okBtn setTitle:LocalizationKey(@"立即绑定") forState:UIControlStateNormal];
    }else{
        [self.okBtn setTitle:LocalizationKey(@"点击重置") forState:UIControlStateNormal];
    }
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self RightsetupNavgationItemWithImage:UIIMAGE(@"introduce_icon") withColor:[UIColor blackColor]];
    [self getGoogleSecretString];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
   
}

-(void)rightTouchEvent{
    [self.customPopView show];
    return;
    YCMenuAction*action = [YCMenuAction actionWithTitle:LocalizationKey(@"如何绑定？\n1.下载“Google Authentication”应用。\n2.安装完成后打开Google Authentication，扫描下方二维码或手动输入秘钥；\n3.添加成功后，您将得到一个有一定时效的6位数验证码，请在过期前填入。") image:nil handler:^(YCMenuAction *action) {
        
           }];
           
        NSMutableArray * array =  [NSMutableArray array];
        [array addObject:action];
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?300:230;
        YCMenuView*menuView = [YCMenuView menuWithActions:array width:230 relyonView:self.navigationItem.rightBarButtonItem];
        menuView.menuColor=[UIColor whiteColor];
        menuView.menuCellHeight=height;
        menuView.showType=2;
        menuView.textColor=[UIColor blackColor];
        menuView.maxDisplayCount = 1;
        [menuView show];
    
}

//MARK: 获取谷歌绑定二维码
-(void)getGoogleSecretString{
   [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getGoogleQrcodesuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            self.secretLabel.text=data[@"data"][@"secret"];
            self.erCodeImageV.image=[self creatCIQRCodeImage:data[@"data"][@"url"]];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}
//复制
- (IBAction)copyClick:(id)sender {
    
    if (![NSString stringIsNull:self.secretLabel.text]) {
        UIPasteboard *pboard = [UIPasteboard generalPasteboard];
        pboard.string = self.secretLabel.text;
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
      
    }
   
}

//MARK: 下一步
- (IBAction)nextStepClick:(id)sender {
   
    [self.loginAuthView showWithAccount:[UserWrapper shareUserInfo].email withPassword:nil withinviteCode:self.secretLabel.text];
    WEAKSELF
    self.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable dic) {
        //延迟执行
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController popToRootViewControllerAnimated:YES];
        });
        
    };
   
    
}



/**
 *  生成二维码
 */
- (UIImage *)creatCIQRCodeImage:(NSString *)dataStr{
    //创建过滤器，这里的@"CIQRCodeGenerator"是固定的
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    //恢复默认设置
    [filter setDefaults];
    //给过滤器添加数据
    NSData *data = [dataStr dataUsingEncoding:NSUTF8StringEncoding];
    //value必须是NSData类型
    [filter setValue:data forKeyPath:@"inputMessage"];
    //生成二维码
    CIImage *outputImage = [filter outputImage];
    //显示二维码
    return [self creatNonInterpolatedUIImageFormCIImage:outputImage withSize:150.0];
}

- (UIImage *)creatNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat)size {
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    //创建bitmap
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    //保存bitmap图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
