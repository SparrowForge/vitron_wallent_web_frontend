//
//  PayPasswordController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "PayPasswordController.h"
#import "LoginAuthenticationView.h"
#import "PasswordAlertCell.h"

@interface PayPasswordController ()<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    int _maxLength;//输入最大位数
}
@property (weak, nonatomic) IBOutlet UILabel *googleTips;

@property (weak, nonatomic) IBOutlet UILabel *alertLabel;
@property (weak, nonatomic) IBOutlet UILabel *psw1Tips;
@property (weak, nonatomic) IBOutlet UILabel *psw2Tips;
@property (weak, nonatomic) IBOutlet UIView *pswAlertView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) LoginAuthenticationView*loginAuthView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswAlertHeight;
@property (weak, nonatomic) IBOutlet UILabel *pswAlertLabel1;
@property (weak, nonatomic) IBOutlet UILabel *pswAlertLabel2;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswAlertHeight1;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tipsDistance;

@property (nonatomic, assign) BOOL isPswViewExpanded;  // 用于跟踪视图是否展开

@end

@implementation PayPasswordController


- (LoginAuthenticationView *)loginAuthView {
    if(!_loginAuthView) {
        int type=self.type==0?6:([[UserWrapper shareUserInfo].isPayPassword intValue]!=1?4:5);
        BOOL needGoogle=[[UserWrapper shareUserInfo].googleStatus intValue]==1?YES:NO;
       
        CGFloat additionalHeight=needGoogle?106:0;
        _loginAuthView=[LoginAuthenticationView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320+0+additionalHeight) withVerifyPermissionType:type withGoogleVerify:needGoogle];//HOME_INDICATOR_HEIGHT
    }
    return _loginAuthView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setBorderView:self.okPswView];
    [self setBorderView:self.pswView];
    [self setBorderView:self.googleView];
    self.oKBtn.enabled=NO;
    [self.oKBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
    self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.pswAlertHeight.constant = 0; //初始隐藏
    self.pswAlertView.hidden=YES;
    [self setTextFieldObserverWithtextField:self.pswTF];
    [self setTextFieldObserverWithtextField:self.okPswTF];
   // [self setTextFieldObserverWithtextField:self.googleTF];
    _maxLength=self.type==0?20:6;
    NSString*navTitle=self.type==0?LocalizationKey(@"修改登录密码"):([[UserWrapper shareUserInfo].isPayPassword intValue]!=1?LocalizationKey(@"交易密码"):LocalizationKey(@"修改交易密码"));
    self.title=navTitle;
    self.alertLabel.text=self.type==0?LocalizationKey(@"修改登录密码"):([[UserWrapper shareUserInfo].isPayPassword intValue]!=1?LocalizationKey(@""):LocalizationKey(@"修改交易密码"));
    //一直隐藏
    self.googleH.constant=0;
    self.googleTips.hidden=YES;
    self.googleView.hidden=YES;
    if (self.type==1) {
        self.pswTF.keyboardType=UIKeyboardTypeNumberPad;
        self.okPswTF.keyboardType=UIKeyboardTypeNumberPad;//数字键盘
    }
    self.pswTF.delegate=self;
    self.okPswTF.delegate=self;
    self.psw1Tips.text=self.type==0?LocalizationKey(@"新密码"):LocalizationKey(@"新密码");
    self.psw2Tips.text=self.type==0?LocalizationKey(@"确认密码"):LocalizationKey(@"确认密码");
    NSString*pswPlaceholder=self.type==0?LocalizationKey(@"请输入"):LocalizationKey(@"请输入六位数字密码");
    [self.pswTF setStyleWithPlaceholder:pswPlaceholder];
  
    NSString*okPswPlaceholder=self.type==0?LocalizationKey(@"请输入"):LocalizationKey(@"请输入");
    [self.okPswTF setStyleWithPlaceholder:okPswPlaceholder];
    [self.googleTF setStyleWithPlaceholder:LocalizationKey(@"谷歌验证码")];
    [self.oKBtn setTitle:LocalizationKey(@"下一步") forState:UIControlStateNormal];
    self.oKBtn.titleLabel.font=PingFangMediumFont(15);
    self.pswAlertLabel1.text=LocalizationKey(@"密码规则不正确");
    self.pswAlertLabel2.text=LocalizationKey(@"密码规则不正确");
    self.pswAlertLabel1.hidden=YES;
    self.pswAlertLabel2.hidden=YES;
    self.pswAlertHeight1.constant=0;
    self.tipsDistance.constant=0;
    self.psw1Tips.font=PingFangMediumFont(13);
    self.psw2Tips.font=PingFangMediumFont(13);
    [self setUptableView];
    // Do any additional setup after loading the view from its nib.
}

-(void)setUptableView{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PasswordAlertCell" bundle:nil] forCellReuseIdentifier:@"PasswordAlertCell"];
    self.tableView.rowHeight=32;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
   
}
-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
    
}
-(void)setTextFieldObserverWithtextField:(UITextField *)textField{
    [textField addTarget:self action:@selector(textFieldDidBegin:) forControlEvents:UIControlEventEditingDidBegin];
    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [textField addTarget:self action:@selector(textFieldDidEndEditingAction:) forControlEvents:UIControlEventEditingDidEnd];
}
//MARK: 监听输入框开始编辑
- (void)textFieldDidBegin:(UITextField *)textField {
    if ([textField isEqual:self.pswTF]) {
        //密码
        if (!self.isPswViewExpanded) {
            [self expandPswAlertView];
        }

    }
    
}
//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    if ([textField isEqual:self.pswTF]) {
        //密码
        [self judgeCorrectpassword:self.pswTF.text];
    }else{
        //确认密码
        [self judgeCorrectConfirmPassword:self.okPswTF.text];
    }
    if ([[UserWrapper shareUserInfo].googleStatus intValue]==1){
       //有谷歌验证码
        if (self.type==0) {
            //登录密码
            if ([ToolUtil isOrNoPasswordStyle:self.pswTF.text]&&[ToolUtil isOrNoPasswordStyle:self.okPswTF.text]) {
                self.oKBtn.enabled=YES;
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                [self.oKBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }else{
                
                self.oKBtn.enabled=NO;
                [self.oKBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
            }
            [self judgeCorrectPassword:[ToolUtil isOrNoPasswordStyle:textField.text] withTextField:textField];
            [self.tableView reloadData];
        }else{
            //交易密码
            if (self.pswTF.text.length==6&&self.okPswTF.text.length==6) {
                self.oKBtn.enabled=YES;
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                [self.oKBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }else{
                
                self.oKBtn.enabled=NO;
                [self.oKBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
            }
            
        }
       
    
    }else{
        //无谷歌验证码
        if (self.type==0) {
            //登录密码
            if ([ToolUtil isOrNoPasswordStyle:self.pswTF.text]&&[ToolUtil isOrNoPasswordStyle:self.okPswTF.text]) {
                self.oKBtn.enabled=YES;
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                [self.oKBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }else{
                
                self.oKBtn.enabled=NO;
                [self.oKBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
            }
            [self judgeCorrectPassword:[ToolUtil isOrNoPasswordStyle:textField.text] withTextField:textField];
            [self.tableView reloadData];
        }else{
            //交易密码
            if (self.pswTF.text.length==6&&self.okPswTF.text.length==6) {
                self.oKBtn.enabled=YES;
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                [self.oKBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }else{
                
                self.oKBtn.enabled=NO;
                [self.oKBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
                self.oKBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
            }
            
        }
    }
}

- (void)textFieldDidEndEditingAction:(UITextField *)textField {
    if ([textField isEqual:self.pswTF]) {
        [self collapsePswAlertView];
    }
    NSLog(@"TextField 失去第一响应者");
}
//MARK: 点击事件
- (IBAction)eventClick:(UIButton *)sender {
    
    if (sender.tag==0) {
        sender.selected=!sender.selected;
        self.pswTF.secureTextEntry=sender.selected?NO:YES;
    }else if (sender.tag==1){
        sender.selected=!sender.selected;
        self.okPswTF.secureTextEntry=sender.selected?NO:YES;
    }else if (sender.tag==2){
        //获取验证码
     
    }else{
        //确定

        if (self.type==0) {
            //登录密码
            if ([NSString stringIsNull:self.pswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入新密码"));
                return;
            }
            if (![ToolUtil isOrNoPasswordStyle:self.pswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"数字+大小写字母的8-20字符"));
              
                return;
            }
            if ([NSString stringIsNull:self.okPswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请确认密码"));
                return;
            }
            if (![self.pswTF.text isEqualToString:self.okPswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"两次密码不一致"));
                return;
            }
           
            
        }else{
            //交易密码
            if ([NSString stringIsNull:self.pswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入新密码"));
                return;
            }
            if ([NSString stringIsNull:self.okPswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请确认密码"));
                return;
            }
            if (![self.pswTF.text isEqualToString:self.okPswTF.text]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"两次密码不一致"));
                return;
            }
      
        }
        [self.loginAuthView showWithAccount:[UserWrapper shareUserInfo].email withPassword:self.okPswTF.text withinviteCode:nil];
        WEAKSELF
        self.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable dic) {
            if (weakSelf.type==0) {
                //登录密码
                [weakSelf.view endEditing:YES];
                //延迟执行
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [weakSelf.navigationController popViewControllerAnimated:YES];
                });
                
            }else{
               //交易密码
                [weakSelf.view endEditing:YES];
                [UserWrapper shareUserInfo].isPayPassword=@"1";
                [UserWrapper saveUser:[UserWrapper shareUserInfo]];
                //延迟执行
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [weakSelf.navigationController popViewControllerAnimated:NO];
                    if (weakSelf.pushType!=0) {
                        if (weakSelf.pushBlock) {
                            weakSelf.pushBlock(weakSelf.pushType);
                        }
                    }
                  
                });
                
            }
    
        };
   
    }
   
}





//限制只能输入6位数字
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // 获取当前文本框的文本
    NSString *currentText = textField.text;
    
    // 计算替换后的文本
    NSString *updatedText = [currentText stringByReplacingCharactersInRange:range withString:string];
    // 检查文本长度是否超过最大字符
    if (updatedText.length > _maxLength) {
        return NO; // 返回NO，表示不允许输入
    } else {
        return YES; // 返回YES，表示允许输入
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PasswordAlertCell*cell=[tableView dequeueReusableCellWithIdentifier:@"PasswordAlertCell"];
    [cell configDataWithIndexpath:indexPath withpassword:self.pswTF.text];
    return cell;
    
}


// 展开 view
- (void)expandPswAlertView {
    if (self.type!=0) {
        return;
    }
    self.pswAlertView.hidden = NO; // 先显示 view
    [UIView animateWithDuration:0.3 animations:^{
        self.pswAlertHeight.constant = 130;  // 设置展开后的高度
        [self.view layoutIfNeeded]; // 激活动画
    } completion:^(BOOL finished) {
        self.isPswViewExpanded=YES;
    }];
}

// 收起 view
- (void)collapsePswAlertView {
    if (self.type!=0) {
        return;
    }
    [UIView animateWithDuration:0.3 animations:^{
        self.pswAlertHeight.constant = 0; // 设置高度为 0
        [self.view layoutIfNeeded]; // 激活动画

    } completion:^(BOOL finished) {
        self.pswAlertView.hidden = YES; // 动画结束后隐藏
        self.isPswViewExpanded=NO;
    }];
}


//判断密码格式是否正确
-(void)judgeCorrectPassword:(BOOL)isCorrect withTextField:(UITextField*)textField{
    
    if (isCorrect) {
        if ([textField isEqual:self.pswTF]) {
           // self.pswAlertLabel.hidden=YES;
            self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
            self.pswView.backgroundColor=[UIColor whiteColor];
           // self.pswTitleHeight.constant=0;
        }else{
            // self.pswAlertLabel.hidden=YES;
             self.okPswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
             self.okPswView.backgroundColor=[UIColor whiteColor];
            // self.pswTitleHeight.constant=0;
            
            
            
        }
        
       
    }else{
        if ([textField isEqual:self.pswTF]){
            
          //  self.pswAlertLabel.hidden=NO;
            self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
            self.pswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
          //  self.pswTitleHeight.constant=15;
        }else{
            
            //  self.pswAlertLabel.hidden=NO;
              self.okPswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
              self.okPswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
            //  self.pswTitleHeight.constant=15;
        }
       
    }
  
}

//判断密码是否正确
-(void)judgeCorrectpassword:(NSString*)text{
    
    BOOL isCorrect=NO;
    if (self.type==0) {
        //登录密码
        isCorrect=[ToolUtil isOrNoPasswordStyle:text];
    }else{
        //交易密码
        isCorrect=text.length==6?YES:NO;
    }
    
    if (isCorrect) {
        self.pswAlertLabel1.hidden=YES;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.pswView.backgroundColor=[UIColor whiteColor];
        self.pswAlertHeight1.constant=0;
        self.tipsDistance.constant=0;

    }else{
        self.pswAlertLabel1.hidden=NO;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.pswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.pswAlertHeight1.constant=15;
        self.tipsDistance.constant=8;

    }
   
}


//判断密码格式是否正确
-(void)judgeCorrectConfirmPassword:(NSString*)text{
    BOOL isCorrect=NO;
    if (self.type==0) {
        //登录密码
        isCorrect=[ToolUtil isOrNoPasswordStyle:text];
    }else{
        //交易密码
        isCorrect=text.length==6?YES:NO;
    }
    if (isCorrect) {
        self.pswAlertLabel2.hidden=YES;
        self.okPswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.okPswView.backgroundColor=[UIColor whiteColor];
    }else{
        self.pswAlertLabel2.hidden=NO;
        self.okPswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.okPswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
    }
    
    
}



-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
   
}

@end
