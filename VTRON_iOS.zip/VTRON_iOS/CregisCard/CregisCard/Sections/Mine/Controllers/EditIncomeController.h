//
//  EditIncomeController.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/11.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"
#import "InviteModel.h"
NS_ASSUME_NONNULL_BEGIN

typedef void(^DistributorInfoBlock)(NSDictionary*infoDic);

@interface EditIncomeController : BaseViewController
@property(nonatomic,assign) int type;//0 编辑初始收益 1 用户详情编辑
@property(nonatomic,strong) NSDictionary*merchantDistributorInfoVo;
@property(nonatomic,strong)InviteModel*inviteModel;
@property (nonatomic, copy)   DistributorInfoBlock infoblock;
@end

NS_ASSUME_NONNULL_END
