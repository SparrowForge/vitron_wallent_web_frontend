//
//  NetworkDetectionController.m
//  CregisCard
//
//  Created by sunliang on 2025/5/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "NetworkDetectionController.h"
#import "NetworkDetectionCell.h"
#import "DetectionModel.h"
#import "Reachability.h"
#include <ifaddrs.h>
#include <arpa/inet.h>
#import <resolv.h>
#import <netinet/in.h>
#import <netdb.h>
#import "PingManager.h"
#import "Masonry/Masonry.h"
#import "NotesDetectionView.h"
#import "SelectMenuView.h"
#import "HostManager.h"

typedef void (^RequestStatsCompletion)(NSInteger successCount, double averageTime);

@interface NetworkDetectionController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) NotesDetectionView*NotesView;
@property (strong, nonatomic) UITableView *tableView;
@property(nonatomic,strong)   NSMutableArray*contentArray;
@property (nonatomic, strong) PingManager *pinManager;
@property (nonatomic, strong) UIView*backView;
@property (nonatomic, strong) UIActivityIndicatorView *indicatorView;
@property (nonatomic, strong) UILabel*ipLabel;
@property(nonatomic,strong) SelectMenuView*selectView;
@property(nonatomic,strong) NSDictionary*currentNoteDic;
@end

@implementation NetworkDetectionController

- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 160+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectNotes];
    }
    return _selectView;
}
-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"网络诊断");
    [self setTableViewConfig];
    NSArray*iconNameArray=@[@"netDetection_permission",@"netDetection_link",@"netDetection_DNS",@"netDetection_strength",@"netDetection_server"];
    NSArray*titleArray=@[LocalizationKey(@"应用网络权限"),LocalizationKey(@"网络连接"),LocalizationKey(@"DNS"),LocalizationKey(@"信号强度"),LocalizationKey(@"主服务器")];
    for (int i=0; i<titleArray.count; i++) {
        DetectionModel*model=[[DetectionModel alloc]init];
        model.iconName=iconNameArray[i];
        model.name=titleArray[i];
        model.iconStatus=0;
        model.detail=@"";
        model.delayTime=@"";
        [self.contentArray addObject:model];
    }
    [self todetection:nil];//一进来就主动调用
    self.currentNoteDic=[[UBTNSUserDefaultUtil GetDefaults:NOTE_EXCLUSIVE] intValue]==1?@{LocalizationKey(@"迪拜节点"):@"1"}:@{LocalizationKey(@"全球节点"):@"0"};//初始化
    
   // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
//    if (self.popType==1) {
//        self.navigationController.navigationBar.prefersLargeTitles = YES;
//        self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAutomatic;
//    }
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
}

-(void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:YES];
    if (self.popType==1) {
        self.navigationController.navigationBar.prefersLargeTitles = NO;
        self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
    }
   
}


-(void)setTableViewConfig{
    
    self.tableView =[[UITableView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-(50+20+HOME_INDICATOR_HEIGHT+20)) style:UITableViewStylePlain];
    self.tableView.backgroundColor=[UIColor whiteColor];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.tableView registerNib:[UINib nibWithNibName:@"NetworkDetectionCell" bundle:nil] forCellReuseIdentifier:@"NetworkDetectionCell"];
 
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 25+60+4)];
    self.NotesView=[NotesDetectionView instanceViewWithFrame:CGRectMake(0, 25, kWindowW, 60)];
    
    WEAKSELF
    [self.NotesView.noteBtn dn_addActionHandler:^{
        //节点切换
       // [weakSelf showNoteSelectView];
    }];
    [headView addSubview:self.NotesView];
    self.tableView.tableHeaderView=headView;
    [self.view addSubview:self.tableView];
    [self createFootView];
    [self createBtnView];
}

-(void)createBtnView{
    
    self.backView=[[UIView alloc]initWithFrame:CGRectMake(16, kWindowH-50-20-HOME_INDICATOR_HEIGHT, kWindowW-32, 50)];
    [self.backView setCornerRadius:25.0];
    self.backView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    [self.view addSubview:self.backView];

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(todetection:)];
    [self.backView addGestureRecognizer:tapGesture];

    UILabel*titleLabel=[[UILabel alloc]init];
    titleLabel.font=PingFangMediumFont(15);
    titleLabel.text=LocalizationKey(@"诊断");
    titleLabel.textColor=[UIColor whiteColor];
    [self.backView addSubview:titleLabel];
    //在页面居中显示
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.backView);
        make.centerY.equalTo(self.backView);
     
    }];

    self.indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [self.backView addSubview:self.indicatorView];

    [self.indicatorView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.backView);
        make.right.mas_equalTo(titleLabel.mas_left).offset(-10);
    }];
    
}

-(void)createFootView{
    
    UIView*footView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 60+32)];
    self.tableView.tableFooterView=footView;
    
    UIView*boardView=[[UIView alloc]init];
    boardView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F " alpha:0.2].CGColor;
    boardView.layer.borderWidth=0.33;
    [boardView setCornerRadius:12.0];
    [footView addSubview:boardView];
    [boardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(footView).offset(32);
        make.bottom.mas_equalTo(footView);
        make.left.mas_equalTo(footView.mas_left).offset(16);
        make.right.mas_equalTo(footView.mas_right).offset(-16);
        
    }];
    UILabel*ipTitleLabel=[[UILabel alloc]init];
    ipTitleLabel.text=LocalizationKey(@"设备IP");
    ipTitleLabel.textColor=[UIColor blackColor];
    ipTitleLabel.font=PingFangMediumFont(17);
    [boardView addSubview:ipTitleLabel];
    [ipTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(boardView);
        make.left.mas_equalTo(boardView).offset(24);
    }];
    
    self.ipLabel=[[UILabel alloc]init];
    self.ipLabel.text=@"--";
    self.ipLabel.numberOfLines=0;
    self.ipLabel.textAlignment=NSTextAlignmentRight;
    self.ipLabel.textColor=[UIColor blackColor];
    self.ipLabel.font=PingFangMediumFont(17);
    [boardView addSubview:self.ipLabel];

    [self.ipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(boardView);
        make.left.mas_equalTo(ipTitleLabel.mas_right).offset(24);
        make.right.mas_equalTo(boardView).offset(-24);
    }];
    
}





- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NetworkDetectionCell*cell=[tableView dequeueReusableCellWithIdentifier:@"NetworkDetectionCell"];
    [cell configModel:self.contentArray[indexPath.row] withIdexPath:indexPath];
    return cell;
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 60+8;
}


//诊断
-(void)todetection:(UITapGestureRecognizer *)gesture{
    [self startDiagnosis];
    [self.contentArray enumerateObjectsUsingBlock:^(DetectionModel* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.iconStatus=0;
    }];
    [self.tableView reloadData];//重置之前的数据，重新检测
 
    DetectionModel*permissionModel=[self.contentArray firstObject];
    permissionModel.iconStatus=1;
    [self.tableView reloadData];
    //检测网络权限
    BOOL isPermission=[self checkNetworkPermission];
    if (isPermission) {
        permissionModel.iconStatus=2;
        [self.tableView reloadData];
        //检测网络连接
        BOOL isLink=[self checkNetworkStatus];
        DetectionModel*linkModel=[self.contentArray objectAtIndex:1];
        linkModel.iconStatus=1;
        [self.tableView reloadData];
        if (isLink) {
            //网络连接正常
            linkModel.iconStatus=2;
            [self.tableView reloadData];
            //开始DNS解析
            DetectionModel*DNSModel=[self.contentArray objectAtIndex:2];
            DNSModel.iconStatus=1;
            [self.tableView reloadData];
            NSURL *url = [NSURL URLWithString:[HostManager sharedManager].host];
            NSString *host = url.host;
            NSArray*dnsArray=[self resolveDNSWithHost:host];
            NSLog(@"DNS域名解析%@:%@",host,dnsArray);
            if (dnsArray.count>0) {
                //DNS解析成功
                DNSModel.iconStatus=2;
                [self.tableView reloadData];
                //开始ping命令
                DetectionModel*pingModel=[self.contentArray objectAtIndex:3];
                pingModel.iconStatus=1;
                [self.tableView reloadData];
                WEAKSELF
                NSURL *url = [NSURL URLWithString:[HostManager sharedManager].host];
                NSString *host = url.host;
                //NSLog(@"ping的域名：%@",host);
                self.pinManager = [[PingManager alloc] initWithHost:host count:10 timeout:60 resultCallback:^(NSInteger successCount, double averageDelay) {
                    NSLog(@"最终结果: 成功 %ld 次，平均延迟 %.2f ms", (long)successCount, averageDelay);
                    if (successCount>0) {
                        //ping成功了至少一次
                        pingModel.iconStatus=2;
                        pingModel.detail=[NSString stringWithFormat:@"%ld/10",(long)successCount];
                        pingModel.delayTime=[NSString stringWithFormat:@"%.0fms",averageDelay];
                        [weakSelf.tableView reloadData];
                        
                        //开始连接主机服务器
                        DetectionModel*serverModel=[weakSelf.contentArray objectAtIndex:4];
                        serverModel.iconStatus=1;
                        [weakSelf.tableView reloadData];
                        NSDictionary *headers = @{
                          
                        };
                        [weakSelf performSerialGetRequestFiveTimesWithURL:[NSString stringWithFormat:@"%@/merchant-server/check/health",[HostManager sharedManager].host]
                                                               timeout:60
                                                               headers:headers
                                                            completion:^(NSInteger successCount, double averageTime) {
                            NSLog(@"连接主服务器成功次数: %ld", (long)successCount);
                            NSLog(@"平均耗时: %.2f 毫秒", averageTime);
                            if (successCount>0) {
                                //至少成功了一次
                                serverModel.iconStatus=2;
                                serverModel.detail=[NSString stringWithFormat:@"%ld/5",(long)successCount];
                                serverModel.delayTime=[NSString stringWithFormat:@"%.0fms",averageTime];
                                [weakSelf.tableView reloadData];
                                /** 全部检测完成*/
                                [weakSelf stopDiagnosis];
                                
                            }else{
                                //连接主服务器失败
                                serverModel.iconStatus=3;
                                [weakSelf.tableView reloadData];
                                [weakSelf stopDiagnosis];
                                return;
                                
                            }
                          
                        }];
                   
                    }else{
                        //ping失败
                        pingModel.iconStatus=3;
                        [weakSelf.tableView reloadData];
                        [weakSelf stopDiagnosis];
                        return;
                    }
               
                }];
                [weakSelf.pinManager startPing];
               
            }else{
                //DNS解析失败
                DNSModel.iconStatus=3;
                [self.tableView reloadData];
                [self stopDiagnosis];
                return;
            }
            
            
        }else{
            //网络连接异常
            linkModel.iconStatus=3;
            [self.tableView reloadData];
            [self stopDiagnosis];
            return;
        }
            
        
        
        
    }else{
        //无网络权限，停止诊断
        permissionModel.iconStatus=3;
        [self.tableView reloadData];
        [self stopDiagnosis];
        return;
    }
  
    
}


// 网络连接检查，返回布尔值
- (BOOL)checkNetworkPermission {
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reachability currentReachabilityStatus];
    
    switch (status) {
        case NotReachable:
         //   [self.view makeToast:@"网络连接：无"];
            return NO;
        case ReachableViaWiFi:
         //   [self.view makeToast:@"网络连接：WiFi"];
            return YES;
        case ReachableViaWWAN:
           // [self.view makeToast:@"网络连接：蜂窝"];
            return YES;
    }
}




// 网络连接检查，返回布尔值
- (BOOL)checkNetworkStatus {
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reachability currentReachabilityStatus];
    
    switch (status) {
        case NotReachable:
         //   [self.view makeToast:@"网络连接：无"];
            return NO;
        case ReachableViaWiFi:
         //   [self.view makeToast:@"网络连接：WiFi"];
            return YES;
        case ReachableViaWWAN:
           // [self.view makeToast:@"网络连接：蜂窝"];
            return YES;
    }
}


//获取域名的DNS（IP）
- (NSArray<NSString *> *)resolveDNSWithHost:(NSString *)host {
    NSMutableArray *results = [NSMutableArray array];

    struct addrinfo hints, *res, *p;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;     // 支持 IPv4 和 IPv6
    hints.ai_socktype = SOCK_STREAM; // 任意类型
    hints.ai_protocol = IPPROTO_TCP;

    int error = getaddrinfo([host UTF8String], NULL, &hints, &res);
    if (error == 0) {
        for (p = res; p != NULL; p = p->ai_next) {
            char ipstr[INET6_ADDRSTRLEN];
            void *addr;

            if (p->ai_family == AF_INET) { // IPv4
                struct sockaddr_in *ipv4 = (struct sockaddr_in *)p->ai_addr;
                addr = &(ipv4->sin_addr);
            } else if (p->ai_family == AF_INET6) { // IPv6
                struct sockaddr_in6 *ipv6 = (struct sockaddr_in6 *)p->ai_addr;
                addr = &(ipv6->sin6_addr);
            } else {
                continue;
            }

            inet_ntop(p->ai_family, addr, ipstr, sizeof(ipstr));
            [results addObject:[NSString stringWithUTF8String:ipstr]];
        }
        freeaddrinfo(res);
    }

    return results;
}


//获取公网IP（接口一）
- (void)getPublicIPAddressWithCompletion:(void (^)(NSString *ipAddress))completion {
    NSURL *url = [NSURL URLWithString:@"https://httpbin.org/ip"];
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url
                                                             completionHandler:^(NSData * _Nullable data,
                                                                                 NSURLResponse * _Nullable response,
                                                                                 NSError * _Nullable error) {
        if (error) {
            NSLog(@"获取公网IP1报错了--%@--%@",error,response);
            if (completion) {
                          dispatch_async(dispatch_get_main_queue(), ^{
                              completion(@"" /* 空字符串表示失败 */);
                          });
                      }
            return;
        }
        if (data && !error) {
        
            NSError *jsonError;
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
            if ([json isKindOfClass:[NSDictionary class]] && json[@"origin"]) {
                NSString *ipAddress = json[@"origin"];
                if (completion) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        completion(ipAddress);
                    });
                }
                return;
            }
        }
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(@"");
            });
        }
    }];
    [task resume];
}

//获取公网IP（接口二）
- (void)getPublicIP2AddressWithCompletion:(void (^)(NSString *ipAddress))completion {
    NSURL *url = [NSURL URLWithString:@"https://icanhazip.com"];
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url
                                                             completionHandler:^(NSData * _Nullable data,
                                                                                 NSURLResponse * _Nullable response,
                                                                                 NSError * _Nullable error) {
        if (error) {
            NSLog(@"获取公网IP2报错了--%@--%@",error,response);
            if (completion) {
                          dispatch_async(dispatch_get_main_queue(), ^{
                              completion(@"" /* 空字符串表示失败 */);
                          });
                      }
            return;
        }
        if (data && !error) {
            NSString *textIP = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"纯文本IP:%@",textIP);
            if (completion&&![NSString stringIsNull:textIP]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    completion(textIP);
                });
            }
            return;

        }
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(@"");
            });
        }
    }];
    [task resume];
}

//获取公网IP（接口三）
- (void)getPublicIP3AddressWithCompletion:(void (^)(NSString *ipAddress))completion {
    NSURL *url = [NSURL URLWithString:@"https://ipinfo.io/ip"];
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url
                                                             completionHandler:^(NSData * _Nullable data,
                                                                                 NSURLResponse * _Nullable response,
                                                                                 NSError * _Nullable error) {
        if (error) {
            NSLog(@"获取公网IP3报错了--%@--%@",error,response);
            if (completion) {
                          dispatch_async(dispatch_get_main_queue(), ^{
                              completion(@"" /* 空字符串表示失败 */);
                          });
                      }
            return;
        }
        if (data && !error) {
            NSString *textIP = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"纯文本IP:%@",textIP);
            if (completion&&![NSString stringIsNull:textIP]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    completion(textIP);
                });
            }
            return;

        }
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(@"");
            });
        }
    }];
    [task resume];
}


//按顺序请求5次，计算平均请求时间（只计算成功的平均时间）
- (void)performSerialGetRequestFiveTimesWithURL:(NSString *)urlString
                                        timeout:(NSTimeInterval)timeout
                                        headers:(NSDictionary<NSString *, NSString *> *)headers
                                     completion:(RequestStatsCompletion)completion {
    
 
    __block NSInteger successCount = 0;
    __block double totalDurationMs = 0; // 毫秒
    __block NSInteger currentAttempt = 0;

    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    config.timeoutIntervalForRequest = timeout;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config];
    
    __block void (^strongBlock)(void);
    
    strongBlock = ^{
        if (currentAttempt >= 5) {
            double averageTimeMs = 0;
            if (successCount > 0) {
                averageTimeMs = totalDurationMs / successCount;
                averageTimeMs = round(averageTimeMs * 100) / 100.0; // 保留两位小数
            }

            dispatch_async(dispatch_get_main_queue(), ^{
                if (completion) {
                    completion(successCount, averageTimeMs);
                }
            });
            return;
        }
        
        currentAttempt++;
        NSLog(@"🚀 开始第 %ld 次请求", (long)currentAttempt);
        NSDate *startTime = [NSDate date];
        
        NSURL *url = [NSURL URLWithString:urlString];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        request.HTTPMethod = @"GET";
        for (NSString *key in headers) {
            [request setValue:headers[key] forHTTPHeaderField:key];
        }

        NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData * _Nullable data,
                                                                    NSURLResponse * _Nullable response,
                                                                    NSError * _Nullable error) {
            NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
            NSInteger statusCode = httpResponse.statusCode;
            NSLog(@"第 %ld 次请求结果--%@--%@",(long)currentAttempt,error,httpResponse);
            if (!error && statusCode == 200) {
                NSTimeInterval duration = [[NSDate date] timeIntervalSinceDate:startTime];
                double durationMs = duration * 1000.0;
                durationMs = round(durationMs * 100) / 100.0; // 保留两位小数
                successCount++;
                totalDurationMs += durationMs;
                NSLog(@"✅ 第 %ld 次请求成功，用时 %.2f 毫秒", (long)currentAttempt, durationMs);
            } else {
                NSLog(@"❌ 第 %ld 次请求失败，状态码: %ld，错误: %@", (long)currentAttempt, (long)statusCode, error.localizedDescription);
            }

            // 调用下一次
            strongBlock();
        }];
        
        [task resume];
    };

    // 启动第一次请求
    strongBlock();
}
//开始诊断
-(void)startDiagnosis{
    
    self.backView.userInteractionEnabled=NO;
    [self.indicatorView startAnimating];
   
    
}

//停止诊断
-(void)stopDiagnosis{
    
    self.backView.userInteractionEnabled=YES;
    [self.indicatorView stopAnimating];
    WEAKSELF
    [self tryGetPublicIPWithCompletion:^(NSString *ip) {
            if (![NSString stringIsNull:ip]) {
                weakSelf.ipLabel.text =ip;
            }
    }];
    
}

//封装嵌套请求
- (void)tryGetPublicIPWithCompletion:(void (^)(NSString *ip))completion {
    WEAKSELF
    [self getPublicIPAddressWithCompletion:^(NSString *ipAddress) {
        NSString *ip = [ipAddress stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (![NSString stringIsNull:ip]) {
            completion(ip);
        } else {
            [weakSelf getPublicIP2AddressWithCompletion:^(NSString *ipAddress) {
                NSString *ip = [ipAddress stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                if (![NSString stringIsNull:ip]) {
                    completion(ip);
                } else {
                    [weakSelf getPublicIP3AddressWithCompletion:^(NSString *ipAddress) {
                        NSString *ip = [ipAddress stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                        if (![NSString stringIsNull:ip]) {
                            completion(ip);
                        } else {
                            completion(nil); // 最终失败
                        }
                    }];
                }
            }];
        }
    }];
}

//MARK: 选择节点
-(void)showNoteSelectView{
  //  self.NotesView.noteTips.image=UIIMAGE(@"note_up");
    [self.selectView show];
    self.selectView.currentDic=self.currentNoteDic;
    [self.selectView reloadDataWithArray:@[@{LocalizationKey(@"全球节点"):@"0"},@{LocalizationKey(@"迪拜节点"):@"1"}]];
    WEAKSELF
    self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
        [weakSelf.contentArray enumerateObjectsUsingBlock:^(DetectionModel* obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.iconStatus=0;
        }];
        [weakSelf.tableView reloadData];//重置之前的数据，重新检测
        weakSelf.backView.userInteractionEnabled=YES;
        [weakSelf.indicatorView stopAnimating];
        [weakSelf.pinManager stopPing];
      //  weakSelf.NotesView.noteTips.image=UIIMAGE(@"note_down");
        NSString*key= [[dic allKeys] objectAtIndex:0];
        weakSelf.NotesView.noteNameLabel.text=key;
        [UBTNSUserDefaultUtil PutDefaults:NOTE_EXCLUSIVE Value:[dic objectForKey:key]];
        weakSelf.currentNoteDic=dic;
        if ([[dic objectForKey:key] intValue] ==0) {
            weakSelf.NotesView.noteIcon.image=UIIMAGE(@"note_global");
            [HostManager sharedManager].host=HOST_Global;
        }else{
            weakSelf.NotesView.noteIcon.image=UIIMAGE(@"note_dubai");
            [HostManager sharedManager].host=HOST_Exclusive;
        }
        
    };
    
}

-(void)dealloc{
    NSLog(@"网络诊断页面释放了");
    [self.pinManager stopPing];

}











/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
