//
//  OriginalIncomeController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/10.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "OriginalIncomeController.h"
#import "EditIncomeController.h"
#import "YCMenuView.h"
#import "CustomPopView.h"
@interface OriginalIncomeController ()
@property (weak, nonatomic) IBOutlet UILabel *openCardLabel;
@property (weak, nonatomic) IBOutlet UILabel *tradeLabel;
@property (weak, nonatomic) IBOutlet UILabel *refundLabel;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UILabel *openCardTitle;
@property (weak, nonatomic) IBOutlet UILabel *tradeTitle;
@property (weak, nonatomic) IBOutlet UILabel *refundTitle;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property(nonatomic,strong) CustomPopView*customPopView;
@end

@implementation OriginalIncomeController


- (CustomPopView *)customPopView {
    if(!_customPopView) {
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?140:120;
        _customPopView=[CustomPopView instanceViewWithFrame:CGRectMake(0, 0, kWindowW-40, height) withMenuType:CommissionRate];
    }
    return _customPopView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.openCardTitle.text=LocalizationKey(@"卡片申请佣金");
    self.tradeTitle.text=LocalizationKey(@"消费佣金");
    self.refundTitle.text=LocalizationKey(@"退款佣金");
    self.title=LocalizationKey(@"佣金费率");
    [self.okBtn setTitle:LocalizationKey(@"编辑") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    if ([[UserWrapper shareUserInfo].distributorStatus intValue]==1) {
        [self RightsetupNavgationItemWithImage:UIIMAGE(@"wenhao_account") withColor:[UIColor blackColor]];
        
    }
 
    [self configData];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
}

-(void)setRightBarItem{
    //编辑
    UIButton*firstButton=[[UIButton alloc]init];
    [firstButton setBackgroundImage:UIIMAGE(@"editIcon") forState:UIControlStateNormal];
    [firstButton addTarget:self action:@selector(firstButtonAction) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *firstItem =[[UIBarButtonItem alloc] initWithCustomView:firstButton];
    //提示
    UIButton*secondBtn=[[UIButton alloc]init];
    [secondBtn setBackgroundImage:UIIMAGE(@"wenhao_account") forState:UIControlStateNormal];
    [secondBtn addTarget:self action:@selector(rightTouchEvent) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *secondItem =[[UIBarButtonItem alloc] initWithCustomView:secondBtn];
    UIBarButtonItem *customSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    customSpace.width = 15;
    self.navigationItem.rightBarButtonItems = @[secondItem,customSpace,firstItem];
 
}

-(void)firstButtonAction{
    
    EditIncomeController*editVC=[[EditIncomeController alloc]init];
    editVC.type=0;
    editVC.merchantDistributorInfoVo=self.merchantDistributorInfoVo;
    WEAKSELF
    editVC.infoblock = ^(NSDictionary * _Nonnull infoDic) {
        weakSelf.merchantDistributorInfoVo=infoDic;
        [weakSelf configData];
    };
    [self.navigationController pushViewController:editVC animated:YES];
    
}


-(void)rightTouchEvent{
    
    [self.customPopView show];
    return;
    //
    NSString *text = LocalizationKey(@"初始收益是邀请新用户初始默认的收益费率;您也可在邀请记录中对已邀请用户进行费率的调整。");
    YCMenuAction*action = [YCMenuAction actionWithTitle:text image:nil handler:^(YCMenuAction *action) {
        
           }];
        NSMutableArray * array =  [NSMutableArray array];
        [array addObject:action];
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?130:100;
        YCMenuView*menuView = [YCMenuView menuWithActions:array width:230 relyonView:self.navigationItem.rightBarButtonItem];
        menuView.menuColor=[UIColor whiteColor];
        menuView.menuCellHeight=height;
        menuView.showType=2;
        menuView.textColor=[UIColor blackColor];
        menuView.maxDisplayCount =4;
        [menuView show];
    
    
}


-(void)configData{
    
    NSString *text = LocalizationKey(@"初始收益是邀请新用户初始默认的收益费率;您也可在邀请记录中对已邀请用户进行费率的调整。");
    // 创建一个可变的富文本字符串
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
    // 设置行间距
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 6;
    paragraphStyle.alignment = NSTextAlignmentLeft;
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    self.tipsLabel.attributedText=attributedText;
    
    self.openCardLabel.text=[NSString stringWithFormat:@"%@USD",[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initApplyCard"] doubleValue]]];//开卡收益
    self.tradeLabel.text=[NSString stringWithFormat:@"%@USD+%@%%",[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initConsumerFee"] doubleValue]],[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initConsumerFeeRate"] doubleValue]]];//交易收益
    self.refundLabel.text=[NSString stringWithFormat:@"%@USD+%@%%",[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initOutCardFee"] doubleValue]],[NSString formattedStringWithDouble:[self.merchantDistributorInfoVo[@"initOutCardFeeRate"] doubleValue]]];//交易退款收益
    
}

//编辑
- (IBAction)okClick:(id)sender {
    [self firstButtonAction];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
