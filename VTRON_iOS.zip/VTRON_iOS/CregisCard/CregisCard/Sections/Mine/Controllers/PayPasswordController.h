//
//  PayPasswordController.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

typedef void(^PushBlock)(int pushType);

NS_ASSUME_NONNULL_BEGIN

@interface PayPasswordController : BaseViewController

@property(nonatomic,assign) int type;//0 修改登录密码 1 修改or创建交易密码
@property (weak, nonatomic) IBOutlet UIView *pswView;
@property (weak, nonatomic) IBOutlet UIView *okPswView;

@property (weak, nonatomic) IBOutlet UIView *googleView;

@property (weak, nonatomic) IBOutlet UIButton *oKBtn;
@property (weak, nonatomic) IBOutlet UITextField *pswTF;
@property (weak, nonatomic) IBOutlet UITextField *okPswTF;

@property (weak, nonatomic) IBOutlet UITextField *googleTF;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *googleH;
@property(nonatomic,assign) int pushType;//1 提币 2 转账，标记设置完交易密码后直接跳转到指定页面
@property (nonatomic, copy) PushBlock pushBlock;



@end

NS_ASSUME_NONNULL_END
