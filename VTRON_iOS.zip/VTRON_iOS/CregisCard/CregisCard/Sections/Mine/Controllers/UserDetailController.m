//
//  UserDetailController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/10.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "UserDetailController.h"
#import "UserDetailHeaderView.h"
#import "IdentityInreviewCell.h"
#import "EditIncomeController.h"

@interface UserDetailController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property(nonatomic,strong) UserDetailHeaderView*userHeadView;
@property(nonatomic,strong) NSArray*titleArray;
@property(nonatomic,strong) NSArray*contentArray;
@end

@implementation UserDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.okBtn setTitle:LocalizationKey(@"编辑") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.okBtn.hidden=YES;
    if ([[UserWrapper shareUserInfo].distributorStatus intValue]==1) {
        self.okBtn.hidden=NO;
    }
  
    self.titleArray=@[LocalizationKey(@"注册时间"),LocalizationKey(@"卡片申请佣金"),LocalizationKey(@"消费佣金"),LocalizationKey(@"退款佣金")];
    [self configTableView];
    [self configData];
    // Do any additional setup after loading the view from its nib.
}


-(void)configData{
    self.contentArray=@[self.inviteModel.createTime,[NSString stringWithFormat:@"%@USD",[NSString formattedStringWithDouble:[self.inviteModel.applyCard doubleValue]]],[NSString stringWithFormat:@"%@USD+%@%%",[NSString formattedStringWithDouble:[self.inviteModel.consumerFee doubleValue]],[NSString formattedStringWithDouble:[self.inviteModel.consumerFeeRate doubleValue]]],[NSString stringWithFormat:@"%@USD+%@%%",[NSString formattedStringWithDouble:[self.inviteModel.outCardFee doubleValue]],[NSString formattedStringWithDouble:[self.inviteModel.outCardFeeRate doubleValue]]]];
    [self.tableView reloadData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
}
-(void)configTableView{
    
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 120)];
        self.userHeadView=[UserDetailHeaderView instanceViewWithFrame:headView.bounds];
        self.userHeadView.model=self.inviteModel;
        [headView addSubview:self.userHeadView];
        self.tableView.tableHeaderView=self.userHeadView;
    });
   
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityInreviewCell" bundle:nil] forCellReuseIdentifier:@"IdentityInreviewCell"];
    self.tableView.estimatedRowHeight=60;
    self.tableView.rowHeight=UITableViewAutomaticDimension;
    self.tableView.tableFooterView=[UIView new];
    
    
}


-(void)rightTouchEvent{
    
    EditIncomeController*editVC=[[EditIncomeController alloc]init];
    editVC.inviteModel=self.inviteModel;
    WEAKSELF
    editVC.infoblock = ^(NSDictionary * _Nonnull infoDic) {
        weakSelf.inviteModel.applyCard=infoDic[@"applyCard"];
        weakSelf.inviteModel.outCardFee=infoDic[@"outCardFee"];
        weakSelf.inviteModel.outCardFeeRate=infoDic[@"outCardFeeRate"];
        weakSelf.inviteModel.consumerFee=infoDic[@"consumerFee"];
        weakSelf.inviteModel.consumerFeeRate=infoDic[@"consumerFeeRate"];
        [weakSelf configData];
    };
    editVC.type=1;
    [self.navigationController pushViewController:editVC animated:YES];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IdentityInreviewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"IdentityInreviewCell"];
    cell.titleLabel.text=self.titleArray[indexPath.row];
    cell.contentLabel.text=self.contentArray[indexPath.row];
    cell.contentLabel.numberOfLines=0;
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

- (IBAction)okClick:(id)sender {
    [self rightTouchEvent];
}



-(void)dealloc{
    
}







/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
