//
//  NotificationCenterController.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/14.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NotificationCenterController.h"
#import "NotificationCell.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "NSObject+UBTrackerModel.h"
#import "MineNetWorkManager.h"
#import "NotificationModel.h"
#import "TABAnimated.h"
#import "FilterListView.h"
#import "NotificationAuthView.h"

@interface NotificationCenterController ()<UITableViewDelegate,UITableViewDataSource>
{
    int _pageNO;
}
@property (strong, nonatomic)  UITableView *tableView;
@property(nonatomic,strong) FilterListView*filterStatusView;
@property(nonatomic,strong) NotificationAuthView*notificationAuthView;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) NSMutableDictionary*otherDic;

@end

@implementation NotificationCenterController

-(NSMutableDictionary*)otherDic{
    if (!_otherDic) {
        _otherDic=[[NSMutableDictionary  alloc]init];
    }
    return _otherDic;
}
-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (FilterListView *)filterStatusView {
    if(!_filterStatusView) {
        _filterStatusView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 3*68+HOME_INDICATOR_HEIGHT+60)withSelectMenuType:NotificationCenter];
        _filterStatusView.currentDic=@{@"name":LocalizationKey(@"所有类型"),@"kind":@"-1"};
    }
    return _filterStatusView;
}


- (NotificationAuthView *)notificationAuthView {
    if(!_notificationAuthView) {
        _notificationAuthView=[NotificationAuthView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 380+HOME_INDICATOR_HEIGHT)];
     
    }
    return _notificationAuthView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"通知");
   // [self RightsetupNavgationItemWithImage:UIIMAGE(@"orderScreen") withColor:[UIColor blackColor]];
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    [self setTableViewConfig];
    self.otherDic=[@{} mutableCopy];//默认查询待授权的状态数据
    [self getmessageswithFirst:YES];
    [self readAllMesssage];
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAutomatic;
}

-(void)rightTouchEvent{
    
    [self.filterStatusView show];
     WEAKSELF
     self.filterStatusView.filterMenuBlock = ^(NSString * _Nullable name, NSString * _Nullable status) {
     
         status=[status isEqualToString:@"-1"]?@"":status;
         [weakSelf.otherDic setValue:status forKey:@"type"];
         self->_pageNO=1;
         [weakSelf getmessageswithFirst:NO];
        
    };
    
    
}
-(void)setTableViewConfig{
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.tableView];
    [NSLayoutConstraint activateConstraints:@[
        [self.tableView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor]
    ]];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.tableView registerNib:[UINib nibWithNibName:@"NotificationCell" bundle:nil] forCellReuseIdentifier:@"NotificationCell"];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 20)];
    self.tableView.tableHeaderView=headView;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.backgroundColor=[UIColor whiteColor];
    [self headRefreshWithScrollerView:self.tableView];
    [self footRefreshWithScrollerView:self.tableView];
    self.tableView.tabAnimated= [TABTableAnimated animatedWithCellClass:[NotificationCell class] cellHeight:206];
    [self.tableView tab_startAnimation];
    
}
-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NotificationCell*cell=[tableView dequeueReusableCellWithIdentifier:@"NotificationCell"];
    cell.model=self.contentArray[indexPath.row];
    return cell;
    
}

//行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NotificationModel* model=self.contentArray[indexPath.row];

    if ([model.type intValue]==2) {
        //激活码
        return 180;
    }else{
        //3DS验证码
        return 206;
    }
  
}

//MARK: 上拉加载更多
- (void)refreshFooterAction{
    _pageNO+=1;
    [self getmessageswithFirst:NO];
}

//MARK: 下拉刷新
- (void)refreshHeaderAction{
    _pageNO=1;
    [self.tableView.mj_footer resetNoMoreData];
    [self getmessageswithFirst:NO];
  
}
//获取消息
-(void)getmessageswithFirst:(BOOL)isFirst{
    
    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10)} mutableCopy];
    [dic addEntriesFromDictionary:self.otherDic];

    if (!isFirst) {
        [SVProgressHUD customShowWithStyle];
    }
    [MineNetWorkManager getNotificationCenterWithParams:dic success:^(id  _Nonnull data) {
        if (!isFirst) {
            [SVProgressHUD dismiss];
        }
        
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
        if ([data[@"code"] intValue]==200) {
            if(self->_pageNO==1){
                [self.contentArray removeAllObjects];
            }
            NSArray*onceArray=(NSMutableArray*)[NotificationModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
            if(onceArray.count>0){
                [self.contentArray addObjectsFromArray:onceArray];
            }
            [self.tableView reloadData];
            if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                [self.tableView.mj_footer endRefreshingWithNoMoreData];
            }
            
        }else{
            
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
      
        [self.tableView reloadData];
    
        } fail:^(NSError * _Nonnull error) {
            if (!isFirst) {
                [SVProgressHUD dismiss];
            }
            [self.tableView tab_endAnimation];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
            [self configEmptyViewForTableView];
          //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
   }];
    
}

//一键已读
-(void)readAllMesssage{
    
    [MineNetWorkManager messageCenterAllreadsuccess:^(id  _Nonnull data) {
        if ([data[@"code"] intValue]==200) {
            
            NSLog(@"消息一键已读成功");
            
        }
            
        } fail:^(NSError * _Nonnull error) {
            
            
 }];
  
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
