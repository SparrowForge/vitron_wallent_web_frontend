//
//  GoogleStepTwoController.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GoogleStepTwoController : BaseViewController
@property(nonatomic,assign) int type;//0 绑定 1重置
@end

NS_ASSUME_NONNULL_END
