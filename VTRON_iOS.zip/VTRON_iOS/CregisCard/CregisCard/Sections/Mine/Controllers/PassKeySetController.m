//
//  PassKeySetController.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PassKeySetController.h"
#import "PassKeyTipsCell.h"
#import "PasskeyEditView.h"
#import "PassKeyDeleteView.h"
#import "PassKeyRenameView.h"
#import "CardDetailPermissionView.h"
#import "MineNetWorkManager.h"
#import <AuthenticationServices/AuthenticationServices.h>

@interface PassKeySetController ()<ASAuthorizationControllerDelegate,ASAuthorizationControllerPresentationContextProviding>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *btnTitleLabel;

@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;

@property (weak, nonatomic) IBOutlet UIView *btnView;

@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property(nonatomic,strong) PasskeyEditView*passKeyView;
@property(nonatomic,strong) PassKeyDeleteView*passKeyDeleteView;
@property(nonatomic,strong) PassKeyRenameView*passKeyRenameView;
@property(nonatomic,strong) NSMutableArray*imageArray;
@property(nonatomic,strong) NSMutableArray*titleArray;
@property(nonatomic,strong) NSMutableArray*detailArray;
@property(nonatomic,strong) CardDetailPermissionView*addVerifyView;
@property(nonatomic,strong)CardDetailPermissionView*deleteVerifyView;
@property(nonatomic,copy)  NSString*registrationId;
@property(nonatomic,strong)NSDictionary*dataDic;
@end

@implementation PassKeySetController



- (PasskeyEditView *)passKeyView {
 WEAKSELF
if(!_passKeyView) {
    _passKeyView=[PasskeyEditView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 60*2+24+25+HOME_INDICATOR_HEIGHT)];
    _passKeyView.editblock = ^(int type) {
        [weakSelf dealWithEditMenuViewWithType:type];//重命名或删除通行密钥
    };
}
   return _passKeyView;
}

- (PassKeyRenameView *)passKeyRenameView {
 WEAKSELF
if(!_passKeyRenameView) {
    _passKeyRenameView=[PassKeyRenameView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 270+HOME_INDICATOR_HEIGHT)];
    _passKeyRenameView.nameBlock = ^(NSString * _Nullable name) {
        [weakSelf reNameSuccessWithName:name];
    };
}
   return _passKeyRenameView;
}


- (PassKeyDeleteView *)passKeyDeleteView {
 WEAKSELF
if(!_passKeyDeleteView) {
    
    CGFloat totalHeight=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?330:300;
    _passKeyDeleteView=[PassKeyDeleteView instanceViewWithFrame:CGRectMake(0, 0, kWindowW-16*2, totalHeight)];
    _passKeyDeleteView.menublock = ^(int type) {
        //移除通行密钥
        [weakSelf deletePassKey];
    };
  
}
   return _passKeyDeleteView;
}

- (CardDetailPermissionView *)addVerifyView {
    if(!_addVerifyView) {
        _addVerifyView=[CardDetailPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320) withVerifyPermissionType:AddPasskey];
        
    }
    return _addVerifyView;
}

- (CardDetailPermissionView *)deleteVerifyView {
    if(!_deleteVerifyView) {
        _deleteVerifyView=[CardDetailPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320) withVerifyPermissionType:DeletePasskey];
    }
    return _deleteVerifyView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"通行密钥");
    self.tipsLabel.text=LocalizationKey(@"添加通行密钥");
    self.btnTitleLabel.text=LocalizationKey(@"添加通行密钥");
    self.btnTitleLabel.font=PingFangMediumFont(15);
    self.imageArray=[@[@"passkey_face",@"passkey_device",@"passkey_dun"] mutableCopy];
    self.titleArray=[@[LocalizationKey(@"无需密码或验证码验证"),LocalizationKey(@"跨设备使用"),LocalizationKey(@"比密码更安全")] mutableCopy];
    self.detailArray=[@[LocalizationKey(@"使用面部或者指纹识别替代密码"),LocalizationKey(@"用通行密钥可从任意同步设备登录"),LocalizationKey(@"抵御网络攻击，安全有保障")] mutableCopy];
    [self configTableView];
    [self getpasskeyList];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
   
}
-(void)getpasskeyList{
    
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getPasskeyList:@{} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            self.dataDic=data[@"data"];
            if ([self.dataDic isKindOfClass:[NSDictionary class]]) {
                //已经设置过通行密钥
                self.tipsLabel.text=@"";
                self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
                self.btnTitleLabel.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
                self.okBtn.userInteractionEnabled=NO;
            }else{
                //未设置通行密钥
                self.tipsLabel.text=LocalizationKey(@"添加通行密钥");
                self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                self.btnTitleLabel.textColor=[UIColor whiteColor];
                self.okBtn.userInteractionEnabled=YES;
                
            }
            [self.tableView reloadData];
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
 
}


-(void)configTableView{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PassKeyTipsCell" bundle:nil] forCellReuseIdentifier:@"PassKeyTipsCell"];
    self.tableView.tableFooterView=[UIView new];
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataDic isKindOfClass:[NSDictionary class]] ?1:3;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.dataDic isKindOfClass:[NSDictionary class]]) {
        PassKeyTipsCell*cell=[tableView dequeueReusableCellWithIdentifier:@"PassKeyTipsCell"];
        [cell configDataWithTitle:self.dataDic[@"displayName"] withDetail:[NSString stringWithFormat:@"%@:%@",LocalizationKey(@"添加于"),[self transferTimeWithTimeString:self.dataDic[@"bindTime"]]] withImage:@"passKeySetIcon" withStyle:1];
        return cell;
    }else{
        
        PassKeyTipsCell*cell=[tableView dequeueReusableCellWithIdentifier:@"PassKeyTipsCell"];
        NSString*imageName=self.imageArray[indexPath.row];
        [cell configDataWithTitle:self.titleArray[indexPath.row] withDetail:self.detailArray[indexPath.row] withImage:imageName withStyle:0];
        WEAKSELF
        [cell.editBtn dn_addActionHandler:^{
            [weakSelf.passKeyView show];
         }];
        return cell;
    }
   
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewAutomaticDimension;
}

//添加通行密钥
- (IBAction)addpassKey:(id)sender {
    [self.addVerifyView show];
    WEAKSELF
    self.addVerifyView.verifyBlock = ^(NSString * _Nullable code, int type) {
        [weakSelf verifyAuthoritywithcode:code withType:type];
    };
}

-(void)dealWithEditMenuViewWithType:(int)type{
    if (type==0) {
        //重命名
        [self.passKeyRenameView show];
        
    }else{
        //删除
        [self.passKeyDeleteView show];
      
    }
  
}

//删除passkey
-(void)deletePassKey{
    
    WEAKSELF
    [self.deleteVerifyView show];
     self.deleteVerifyView.verifyBlock = ^(NSString * _Nullable code, int type) {
         [weakSelf deletePasskeywithcode:code withType:type];
    };
    
}
//删除通行密钥
-(void)deletePasskeywithcode:(NSString*)code withType:(int)type{
    NSString*codeType=type==0?@"code":@"googleCode";
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager deletePasskey:@{codeType:code} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            [self.deleteVerifyView hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"删除成功"));
            [self getpasskeyList];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
             ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
}

//重命名
-(void)reNameSuccessWithName:(NSString*)name{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager renamePasskey:@{@"displayName":name} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
           
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"重命名成功"));
            [self getpasskeyList];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
             ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
}


//MARK: 验证验证码是否正确
-(void)verifyAuthoritywithcode:(NSString*)code withType:(int)type{
    NSString*codeType=type==0?@"code":@"googleCode";
    [self registerPasskeywithUserNameForFirstStep:@{codeType:code}];
    
}

//注册通行密钥第一步，弹窗前调用
-(void)registerPasskeywithUserNameForFirstStep:(NSDictionary*)dic{
    [self.addVerifyView startAnimation];
    [SVProgressHUD customShowWithNone];
    [MineNetWorkManager registerPasskeywithUserNameForFirstStep:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            NSLog(@"这是注册通行密钥第一步--%@",data);
            //请求成功
            NSString*challenge=data[@"data"][@"publicKeyCredentialCreationOptions"][@"challenge"];
            NSString*userName=data[@"data"][@"publicKeyCredentialCreationOptions"][@"user"][@"name"];
           // NSString*userId=data[@"data"][@"publicKeyCredentialCreationOptions"][@"user"][@"id"];
           self.registrationId=data[@"data"][@"registrationId"];
            NSLog(@"这是--%@--%@---%@",challenge,self.registrationId,userName);
            if ([NSString stringIsNull:challenge]) {
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"操作异常，请稍后再试..."));
                return;
            }
            [self passkeyForRegisterWithUserName:userName withUserID:[UserWrapper shareUserInfo].ID withchallenge:challenge];
        }else{
            [self.addVerifyView stopAnimation];
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    
        } fail:^(NSError * _Nonnull error) {
            [self.addVerifyView stopAnimation];
            [SVProgressHUD dismiss];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        }];
   
  
}


//注册passkey
-(void)passkeyForRegisterWithUserName:(NSString*)userName withUserID:(NSString*)userID withchallenge:(NSString*)challengeBase64String{
    NSString *base64String = challengeBase64String;
    base64String = [base64String stringByReplacingOccurrencesOfString:@"-" withString:@"+"];
    base64String = [base64String stringByReplacingOccurrencesOfString:@"_" withString:@"/"];

    // 检查是否需要添加填充字符
    NSInteger paddingLength = 4 - (base64String.length % 4);
    if (paddingLength < 4) {
        base64String = [base64String stringByPaddingToLength:base64String.length + paddingLength withString:@"=" startingAtIndex:0];
    }
    // 初始化凭证提供器
    NSString *relyingPartyIdentifier = DOMAINCOM;
    // 从服务器获取 challenge
    NSData *challenge =[[NSData alloc] initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    if (@available(iOS 15.0, *)) {
      
        ASAuthorizationPlatformPublicKeyCredentialProvider *credentialProvider =
        [[ASAuthorizationPlatformPublicKeyCredentialProvider alloc] initWithRelyingPartyIdentifier:relyingPartyIdentifier];
        
        ASAuthorizationPlatformPublicKeyCredentialRegistrationRequest *registrationRequest =
            [credentialProvider createCredentialRegistrationRequestWithChallenge:challenge
                                                                            name:userName
                                                                          userID:[userID dataUsingEncoding:NSUTF8StringEncoding]];
       // registrationRequest.excludedCredentials
        //安全密钥
        ASAuthorizationSecurityKeyPublicKeyCredentialProvider *securityKeyProvider =
            [[ASAuthorizationSecurityKeyPublicKeyCredentialProvider alloc] initWithRelyingPartyIdentifier:relyingPartyIdentifier];
        
        // 创建安全密钥注册请求
        ASAuthorizationSecurityKeyPublicKeyCredentialRegistrationRequest *securityKeyRequest=[securityKeyProvider  createCredentialRegistrationRequestWithChallenge:challenge displayName:userName name:userName userID: [userID dataUsingEncoding:NSUTF8StringEncoding]];
//        // 你可以通过这种方式设置算法支持

//        securityKeyRequest.credentialParameters= @[
//            @(ASCOSEEllipticCurveIdentifierP256), // 例如: ES256
//            @(ASCOSEAlgorithmIdentifierES256)  // 例如: RS256
//        ];
        // 创建ASAuthorizationPublicKeyCredentialParameters对象
        ASAuthorizationPublicKeyCredentialParameters *param1 = [[ASAuthorizationPublicKeyCredentialParameters alloc] initWithAlgorithm:ASCOSEEllipticCurveIdentifierP256];
        ASAuthorizationPublicKeyCredentialParameters *param2 = [[ASAuthorizationPublicKeyCredentialParameters alloc] initWithAlgorithm:ASCOSEAlgorithmIdentifierES256];
        securityKeyRequest.credentialParameters= @[
          // 例如: ES256
            param1,param2  // 例如: RS256
        ];
        // 创建授权控制器
        ASAuthorizationController *authorizationController = [[ASAuthorizationController alloc] initWithAuthorizationRequests:@[registrationRequest]];//securityKeyRequest
        authorizationController.delegate = self;
        authorizationController.presentationContextProvider = self;
        [authorizationController performRequests];
    } else {
        // Fallback on earlier versions
    }

    
}

//处理认证结果
#pragma mark - ASAuthorizationControllerDelegate
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithAuthorization:(ASAuthorization *)authorization  API_AVAILABLE(ios(13.0)){
    if (@available(iOS 15.0, *)) {
        //注册通行密钥时的数据
        if ([authorization.credential isKindOfClass:[ASAuthorizationPlatformPublicKeyCredentialRegistration class]]) {
            ASAuthorizationPlatformPublicKeyCredentialRegistration *registration =
                (ASAuthorizationPlatformPublicKeyCredentialRegistration *)authorization.credential;
            // 获取注册结果
            NSData *credentialID = registration.credentialID;
            NSData *rawAttestationObject = registration.rawAttestationObject; // 证明生成公钥的对象
    
            NSData *rawClientDataJSON = registration.rawClientDataJSON;
            
            // 将 credentialID 和其他数据传递到服务端存储
            NSLog(@"Registration succeeded!--%@",credentialID);
            NSLog(@"CredentialID的Base64编码: %@",  [credentialID base64EncodedStringWithOptions:0]);
            NSLog(@"AttestationObject的Base64编码: %@", [rawAttestationObject base64EncodedStringWithOptions:0]);
            NSLog(@"ClientDataJSON的Base64编码: %@", [rawClientDataJSON base64EncodedStringWithOptions:0]);
        
        NSMutableDictionary*dic=[[NSMutableDictionary alloc]init];
        [dic setValue:self.registrationId forKey:@"registrationId"];
        NSString*credentialIDBase64String
            =[credentialID base64EncodedStringWithOptions:0];
        NSString*rawClientDataJSONBase64String
            =[rawClientDataJSON base64EncodedStringWithOptions:0];
        NSString*rawAttestationObjectBase64String
            =[rawAttestationObject base64EncodedStringWithOptions:0];
             
        NSString *credentialIDBase64StringSafe = [credentialIDBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            credentialIDBase64StringSafe = [credentialIDBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
        NSString *rawClientDataJSONBase64StringSafe = [rawClientDataJSONBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
            rawClientDataJSONBase64StringSafe = [rawClientDataJSONBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
        NSString *rawAttestationObjectBase64StringSafe = [rawAttestationObjectBase64String stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
        rawAttestationObjectBase64StringSafe = [rawAttestationObjectBase64StringSafe stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
        NSDictionary*credentialDic=@{@"type":@"public-key",@"id":credentialIDBase64StringSafe,@"rawId":credentialIDBase64StringSafe,@"response":@{@"clientDataJSON":rawClientDataJSONBase64StringSafe,@"attestationObject":rawAttestationObjectBase64StringSafe},@"clientExtensionResults":@{}};
                [dic setValue:credentialDic forKey:@"credential"];
        [self registerPasskeywithUserNameForSecondStep:dic];
            
            
        }
      
        
    }
}

// 身份验证失败后的回调
-(void)authorizationController:(ASAuthorizationController *)controller didCompleteWithError:(NSError *)error  API_AVAILABLE(ios(13.0)){
    [self.addVerifyView stopAnimation];
    NSLog(@"验证错误--Authorization failed: %@", error.localizedDescription);
    ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"添加失败，请重试"));
}

// 提供 PresentationContext，指定使用当前视图控制器作为授权的展示上下文
- (ASPresentationAnchor)presentationAnchorForAuthorizationController:(ASAuthorizationController *)controller  API_AVAILABLE(ios(13.0)){
    return self.view.window;
}

//注册通行密钥，弹窗验证之后调用
-(void)registerPasskeywithUserNameForSecondStep:(NSDictionary*)dic{
    [SVProgressHUD customShowWithNone];
    NSLog(@"注册的参数--%@",dic);
    [MineNetWorkManager registerPasskeyForSecondStep:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.addVerifyView stopAnimation];
            if ([data[@"code"] intValue]==200) {
                [self.addVerifyView hide];
                ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"添加成功"));
                [self getpasskeyList];
            }else{
               NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
                ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            }
        
          } fail:^(NSError * _Nonnull error) {
              [SVProgressHUD dismiss];
              [self.addVerifyView stopAnimation];
            //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
              
       }];
   
  }

-(NSString*)transferTimeWithTimeString:(NSString*)dateTimeString{
    
    // 创建日期格式化对象
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
   // formatter.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"]; // 设置时区（可根据需要修改）

    // 将字符串转换为 NSDate
    NSDate *date = [formatter dateFromString:dateTimeString];

    // 重新设置格式化器，仅保留日期
    formatter.dateFormat = @"yyyy-MM-dd";

    // 转换回字符串
    NSString *dateString = [formatter stringFromDate:date];
    
    return  dateString;
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
