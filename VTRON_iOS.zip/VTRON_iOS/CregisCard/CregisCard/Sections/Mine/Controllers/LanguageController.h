//
//  LanguageController.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/29.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LanguageController : BaseViewController

@end

NS_ASSUME_NONNULL_END
