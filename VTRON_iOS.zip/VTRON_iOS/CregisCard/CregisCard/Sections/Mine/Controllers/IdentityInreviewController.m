//
//  IdentityInreviewController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "IdentityInreviewController.h"
#import "MineNetWorkManager.h"
#import "IdentityInreviewCell.h"
#import "CountryModel.h"
#import "NSObject+UBTrackerModel.h"
#import "TABAnimated.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "IdentityRejectView.h"


@interface IdentityInreviewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) NSArray*titleArray;
@property(nonatomic,strong) NSMutableArray*contentArray;

@end

@implementation IdentityInreviewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"身份认证");
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    [self setUpUI];
    [self getKycDetail];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAutomatic;
}
-(void)setUpUI{
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityInreviewCell" bundle:nil] forCellReuseIdentifier:@"IdentityInreviewCell"];
  
    if ([[UserWrapper shareUserInfo].kycStatus intValue]==5) {
        //审核通过
        UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 20)];
        self.tableView.tableHeaderView=headView;
    }else{
        //审核中
        NSString*allRemark=[NSString stringWithFormat:LocalizationKey(@"您的身份信息正在审核中，预计需要数小时")];
        CGFloat height=[ToolUtil getLabelHeightWithText:allRemark width:(kWindowW-(20+16)*2-16-8) font:[UIFont systemFontOfSize:15] withLineSpacing:5];
        UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, ceilf(height)+50)];
        IdentityRejectView*rejectView=[IdentityRejectView instanceViewWithFrame:headView.bounds];
        [rejectView configcardholderUIForBulkMail];
        NSMutableAttributedString *attriString =
        [[NSMutableAttributedString alloc] initWithString:allRemark];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineSpacing:5];
        //设置距离
        [attriString addAttribute:NSParagraphStyleAttributeName
                                        value:paragraphStyle
                                        range:NSMakeRange(0, [allRemark length])];
        rejectView.reasonLabel.attributedText=attriString;
        [headView addSubview:rejectView];
        self.tableView.tableHeaderView=headView;
    }

    self.tableView.tabAnimated= [TABTableAnimated animatedWithCellClass:[IdentityInreviewCell class] cellHeight:55];

    [self.tableView tab_startAnimation];
    
}

-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}
//MARK: 获取kyc实名详情
-(void)getKycDetail{
  //  [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getKycDetailsuccess:^(id  _Nonnull data) {
       // [SVProgressHUD dismiss];
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
        if ([data[@"code"] intValue]==200) {

            CountryModel*currentCountry=[CountryModel utr_modelWithKeyValue:data[@"data"][@"country"]];
            NSDictionary* contentDic=[[NSMutableDictionary alloc]initWithDictionary:data[@"data"][@"kyc"]];//重置数据
            NSString*identityStatus=[[UserWrapper shareUserInfo].kycStatus intValue]==0?LocalizationKey(@"审核中"):LocalizationKey(@"已认证");
            NSString*cardType;
            if ([contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
                cardType=LocalizationKey(@"护照");
            }else if ([contentDic[@"idType"] isEqualToString:@"Government-Issued ID Card"]||[contentDic[@"idType"] isEqualToString:@"CN-RIC"]){
                cardType=LocalizationKey(@"身份证");
            }else if ([contentDic[@"idType"] isEqualToString:@"HK-HKID"]){
                cardType=LocalizationKey(@"香港身份证");
            }else{
                cardType=LocalizationKey(@"未知");
            }
            NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?currentCountry.usName:currentCountry.cnName;
            self.titleArray=@[LocalizationKey(@"认证状态"),LocalizationKey(@"姓"),LocalizationKey(@"名"),LocalizationKey(@"国家/地区"),LocalizationKey(@"证件类型"),LocalizationKey(@"证件号码"),LocalizationKey(@"出生日期"),LocalizationKey(@"州/省"),LocalizationKey(@"城市"),LocalizationKey(@"地址"),LocalizationKey(@"邮政编码")];
           
            NSString*cityName=data[@"data"][@"city"];
            self.contentArray=[@[identityStatus,[NSString stringWithFormat:@"%@",contentDic[@"lastName"]],[NSString stringWithFormat:@"%@",contentDic[@"firstName"]],countryName,cardType,contentDic[@"idNumber"],[self dealDateStringWithOrignalString:contentDic[@"birthday"]],contentDic[@"state"],cityName,contentDic[@"address"],contentDic[@"postCode"]] mutableCopy];
           
            [self.tableView reloadData];
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
       // [SVProgressHUD dismiss];
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.titleArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IdentityInreviewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentityInreviewCell"];
    cell.titleLabel.text=self.titleArray[indexPath.section];
    cell.contentLabel.numberOfLines=0;
    cell.contentLabel.text=self.contentArray[indexPath.section];
    cell.contentLabel.font=PingFangMediumFont(15);
    if (indexPath.section==0) {
        cell.statusView.hidden=NO;
        cell.contentLabel.hidden=YES;
        if ([[UserWrapper shareUserInfo].kycStatus intValue]==5) {
            //认证通过
            cell.statusLabel.textColor=[UIColor colorWithHexString:@"#6DD400" alpha:1.0];
            cell.statusView.backgroundColor= [[UIColor colorWithHexString:@"#6DD400" alpha:1.0] colorWithAlphaComponent:0.1];
            cell.statusLabel.text=self.contentArray[indexPath.section];
        }else{
            //认证中
            cell.statusLabel.textColor=[UIColor colorWithHexString:@"#FA6400" alpha:1.0];
            cell.statusView.backgroundColor= [UIColor colorWithHexString:@"#FA6400" alpha:0.06];
            cell.statusLabel.text=self.contentArray[indexPath.section];
        }
      
    }else{
        cell.statusView.hidden=YES;
        cell.contentLabel.hidden=NO;

    }
  
    return cell;
}

//行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
  
    return UITableViewAutomaticDimension;
}

//处理时间字符串
-(NSString*)dealDateStringWithOrignalString:(NSString*)dateString{
    if (dateString.length == 0) return @"";
       
       NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
       inputFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
       
       // 判断是否包含时间
       if ([dateString containsString:@" "]) {
           inputFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
       } else {
           inputFormatter.dateFormat = @"yyyy-MM-dd";
       }
       
       NSDate *date = [inputFormatter dateFromString:dateString];
       if (!date) return dateString;
       
       NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
       outputFormatter.dateFormat = @"yyyy-MM-dd";
       
       return [outputFormatter stringFromDate:date];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
