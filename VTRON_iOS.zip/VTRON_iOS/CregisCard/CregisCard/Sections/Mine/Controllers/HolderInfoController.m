//
//  HolderInfoController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "HolderInfoController.h"
#import "IdentityInputCell.h"
#import "AllNameCell.h"
#import "DeadlineCell.h"
#import "PhoneInfoCell.h"
#import "CardPictureCell.h"
#import "PassportPictureCell.h"
#import "IdentityHeadView.h"
#import "AllNameHeadView.h"
#import "BRDatePickerView.h"
#import "MineNetWorkManager.h"
#import "HomeCardNetWorkManager.h"
#import "IdentityRejectView.h"
#import "CountrysSelectView.h"
#import "NSObject+UBTrackerModel.h"
#import "CountryModel.h"
#import "CityCode.h"
#import "SelectMenuView.h"
#import "CustomTabBarController.h"
#import "FootAlertView.h"
#import "ApplySuccessView.h"



@interface HolderInfoController ()
@property(nonatomic,strong) SelectMenuView*selectView;//选择证件类型
@property(nonatomic,strong) SelectMenuView*selectSexView;//选择性别
@property(nonatomic,strong) SelectMenuView*selectWorkView;//选择职业
@property(nonatomic,strong) NSMutableArray*titleArray;
@property(nonatomic,strong) NSArray*placeholderArray;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) NSMutableDictionary*contentDic;//存储姓，名，身份证正，反，手持等信息
@property(nonatomic,strong) CountrysSelectView*countryView;
@property(nonatomic,strong) UIButton*okBtn;
@property(nonatomic,strong) CountryModel*currentCountry;//当前选择的国家
@property(nonatomic,strong) CountryModel*aredModel;//当前选择的手机区号

@property(nonatomic,strong) NSDictionary*curentSexDic;//性别
@property(nonatomic,strong) NSDictionary*curentCertificateDic;//证件类型
@property(nonatomic,strong) NSDictionary*curentWorkDic;//职业
@end

@implementation HolderInfoController

- (CountryModel *)currentCountry {
    if(!_currentCountry) {
        _currentCountry=[[CountryModel alloc]init];
    }
    return _currentCountry;
}


- (CountryModel*)aredModel {
    if(!_aredModel) {
        _aredModel=[[CountryModel alloc]init];
    }
    return _aredModel;
}

- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 180+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:IdentifyType];
    }
    return _selectView;
}

- (SelectMenuView *)selectSexView {
    if(!_selectSexView) {
        _selectSexView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 180+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectSex];
    }
    return _selectSexView;
}
- (SelectMenuView *)selectWorkView {
    if(!_selectWorkView) {
        _selectWorkView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 460+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectOccupation];
    }
    return _selectWorkView;
}
- (CountrysSelectView *)countryView {
    if(!_countryView) {
        _countryView=[CountrysSelectView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-10)];
    }
    return _countryView;
}
-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
-(NSMutableDictionary*)contentDic{
    if (!_contentDic) {
        _contentDic=[[NSMutableDictionary  alloc]init];
    }
    return _contentDic;
}

- (instancetype)init {
    // 关键代码：指定使用 Plain 样式
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
      
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    [self backBtnNoNavBar:NO normalBack:YES];
    [self setUpUI];
    self.titleArray=[@[LocalizationKey(@"姓名"),LocalizationKey(@"性别"),LocalizationKey(@"职业"),LocalizationKey(@"年薪"),LocalizationKey(@"账户用途"),LocalizationKey(@"月交易额"),LocalizationKey(@"国家/地区"),LocalizationKey(@"州/省"),LocalizationKey(@"城市"),LocalizationKey(@"地址"),LocalizationKey(@"邮政编码"),LocalizationKey(@"手机号"),LocalizationKey(@"证件"),LocalizationKey(@"证件号码"),LocalizationKey(@"出生日期"),LocalizationKey(@"截止日期")] mutableCopy];
    self.placeholderArray=@[LocalizationKey(@""),LocalizationKey(@"请选择"),LocalizationKey(@"请选择"),LocalizationKey(@"请输入"),LocalizationKey(@"请输入"),LocalizationKey(@"请输入"),LocalizationKey(@"请选择"),LocalizationKey(@"请输入"),LocalizationKey(@"请输入"),LocalizationKey(@"请输入"),LocalizationKey(@"请输入"),LocalizationKey(@"请输入"),LocalizationKey(@"请选择"),LocalizationKey(@"请输入"),LocalizationKey(@"请选择"),@""];
    self.contentArray=[@[@"这是名字",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",LocalizationKey(@"护照"),@"",@"",@"这是签发日期"] mutableCopy];
   
    if (self.type==0) {
        //身份认证
        self.title=LocalizationKey(@"身份认证");

        if ([[UserWrapper shareUserInfo].kycStatus intValue]==7) {
            //未认证
            
            self.curentSexDic=@{LocalizationKey(@"未知"):@"-1"};
            self.curentWorkDic=@{LocalizationKey(@"未知"):@"-1"};
            self.curentCertificateDic=@{LocalizationKey(@"护照"):@"PASSPORT"};//默认护照
            [self.contentDic setValue:@"PASSPORT" forKey:@"idType"];//默认护照认证
            [self.contentDic setValue:@"1" forKey:@"areaCode"];//默认美国
            self.aredModel.code=@"1";
        }else{
            //审核失败
            self.contentArray=[@[@"这是名字",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"这是签发日期"] mutableCopy];
            [self getKycDetail];
            
        }
        
    }else{
       //持卡人
        if ([NSString stringIsNull:self.binModel.cardHolderStatus]){
            self.title=LocalizationKey(@"创建持卡人");
            [self getKycDetail];//获取kyc详情
        }else if ([self.binModel.cardHolderStatus isEqualToString:@"INACTIVE"]){
            self.title=LocalizationKey(@"修改持卡人");
            [self getCardHolderDetail];//获取持卡人详情
        }
       
    }
   
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAutomatic;

}

-(void)setUpUI{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"AllNameCell" bundle:nil] forCellReuseIdentifier:@"AllNameCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityInputCell" bundle:nil] forCellReuseIdentifier:@"IdentityInputCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"CardPictureCell" bundle:nil] forCellReuseIdentifier:@"CardPictureCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"PassportPictureCell" bundle:nil] forCellReuseIdentifier:@"PassportPictureCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"DeadlineCell" bundle:nil] forCellReuseIdentifier:@"DeadlineCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"PhoneInfoCell" bundle:nil] forCellReuseIdentifier:@"PhoneInfoCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityHeadView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"IdentityHeadView"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AllNameHeadView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"AllNameHeadView"];
    [self.tableView registerNib:[UINib nibWithNibName:@"FootAlertView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"FootAlertView"];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    NSString*allRemark=[NSString stringWithFormat:@"%@",LocalizationKey(@"表格只能用英文填写")];
    CGFloat height=[ToolUtil getLabelHeightWithText:allRemark width:(kWindowW-(20+16)*2-16-8) font:[UIFont systemFontOfSize:15] withLineSpacing:5];
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, ceilf(height)+50)];
    IdentityRejectView*rejectView=[IdentityRejectView instanceViewWithFrame:headView.bounds];
    [rejectView configcardholderUIForBulkMail];
    NSMutableAttributedString *attriString =
    [[NSMutableAttributedString alloc] initWithString:allRemark];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:5];
    //设置距离
    [attriString addAttribute:NSParagraphStyleAttributeName
                                    value:paragraphStyle
                                    range:NSMakeRange(0, [allRemark length])];
    rejectView.reasonLabel.attributedText=attriString;
    [headView addSubview:rejectView];
    self.tableView.tableHeaderView=headView;
    
    UIView*footView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 100)];
    footView.backgroundColor=[UIColor whiteColor];
    self.tableView.tableFooterView=footView;
    self.okBtn=[[UIButton alloc]initWithFrame:CGRectMake(20, 30, kWindowW-40, 50)];
    [self.okBtn setCornerRadius:25];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    [self.okBtn setTitle:LocalizationKey(@"提交") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);

    WEAKSELF
    [self.okBtn dn_addActionHandler:^{
        if (weakSelf.type==0) {
            //身份认证
            [weakSelf toSubmitAuthentication];
        }else{
            //持卡人
            if ([NSString stringIsNull:self.binModel.cardHolderStatus]){
                //添加持卡人
                [weakSelf toAddCardHolder];
            }else if ([self.binModel.cardHolderStatus isEqualToString:@"INACTIVE"]){
                //修改持卡人
                [self toUpdateCardHolder];
            }
            
            
            
        }
       
    }];
    [footView addSubview:self.okBtn];
    
}

//MARK: 获取kyc实名详情
-(void)getKycDetail{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getKycDetailsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
          
            self.currentCountry=[CountryModel utr_modelWithKeyValue:data[@"data"][@"country"]];
          
            self.contentDic=[[NSMutableDictionary alloc]initWithDictionary:data[@"data"][@"kyc"]];//重置数据
            NSString*occupationString=self.contentDic[@"occupation"];
            [self.contentDic setValue:self.contentDic[@"occupationValue"] forKey:@"occupation"];
            [self.contentDic setValue:[self dealDateStringWithOrignalString:self.contentDic[@"startTime"]] forKey:@"startTime"];
            [self.contentDic setValue:[self dealDateStringWithOrignalString:self.contentDic[@"endTime"]] forKey:@"endTime"];
            self.aredModel=[[CountryModel alloc]init];
            self.aredModel.code=self.contentDic[@"areaCode"];
            
            self.curentWorkDic=@{occupationString:self.contentDic[@"occupationValue"]};//默认职业
            if ([self.contentDic[@"gender"] isEqualToString:@"Male"]) {
                self.curentSexDic=@{LocalizationKey(@"男"):@"Male"};//设置默认性别
            }else{
                self.curentSexDic=@{LocalizationKey(@"女"):@"Female"};//设置默认性别
            }
            if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
                self.curentCertificateDic=@{LocalizationKey(@"护照"):@"PASSPORT"};
            }else if ([self.contentDic[@"idType"] isEqualToString:@"Government-Issued ID Card"]){
                //国外身份证
                self.curentCertificateDic=@{LocalizationKey(@"身份证"):@"Government-Issued ID Card"};
                
            }else if ([self.contentDic[@"idType"] isEqualToString:@"CN-RIC"]){
                //中国大陆身份证
                self.curentCertificateDic=@{LocalizationKey(@"身份证"):@"CN-RIC"};
                
            }
            else{
                self.curentCertificateDic=@{LocalizationKey(@"香港身份证"):@"HK-HKID"};
                
            }
            
            
            NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?self.currentCountry.usName:self.currentCountry.cnName;
            NSString*sex=[self.contentDic[@"gender"] isEqualToString:@"Male"]?LocalizationKey(@"男"):LocalizationKey(@"女");
            NSString*idType=[self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]?LocalizationKey(@"护照"):([self.contentDic[@"idType"] isEqualToString:@"HK-HKID"]?LocalizationKey(@"香港身份证"):LocalizationKey(@"身份证"));
            self.contentArray=[@[@"这是名字",sex,occupationString,self.contentDic[@"annualSalary"],self.contentDic[@"accountPurpose"],self.contentDic[@"expectedMonthlyVolume"],countryName,self.contentDic[@"state"],data[@"data"][@"city"],self.contentDic[@"address"],self.contentDic[@"postCode"],self.contentDic[@"phone"],idType,self.contentDic[@"idNumber"],[self dealDateStringWithOrignalString:self.contentDic[@"birthday"]],@"这是签发日期"] mutableCopy];

            NSString*remark=self.contentDic[@"remark"];//拒绝原因
            if (![NSString stringIsNull:remark]) {
                NSString*allRemark=[NSString stringWithFormat:@"%@：%@",LocalizationKey(@"拒绝原因"),remark];
                CGFloat height=[ToolUtil getLabelHeightWithText:allRemark width:(kWindowW-(20+16)*2-16-8) font:[UIFont systemFontOfSize:15] withLineSpacing:5];
                UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, ceilf(height)+50)];
                IdentityRejectView*rejectView=[IdentityRejectView instanceViewWithFrame:headView.bounds];
                NSMutableAttributedString *attriString =
                [[NSMutableAttributedString alloc] initWithString:allRemark];
                NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
                [paragraphStyle setLineSpacing:5];
                //设置距离
                [attriString addAttribute:NSParagraphStyleAttributeName
                                                value:paragraphStyle
                                                range:NSMakeRange(0, [allRemark length])];
                rejectView.reasonLabel.attributedText=attriString;
                [headView addSubview:rejectView];
                self.tableView.tableHeaderView=headView;
            
            }
        
            [self.tableView reloadData];
            [self juadgeBtnStatus];
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//MARK: 获取持卡人详情
-(void)getCardHolderDetail{
    [SVProgressHUD customShowWithStyle];
    [HomeCardNetWorkManager getSinglecardUserInfoWithparams:@{@"bin":self.binModel.bin} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
          
            self.currentCountry=[CountryModel utr_modelWithKeyValue:data[@"data"][@"country"]];
            
            self.contentDic=[[NSMutableDictionary alloc]initWithDictionary:data[@"data"]];//重置数据
            NSString*occupationString=self.contentDic[@"occupation"];
            [self.contentDic setValue:self.contentDic[@"occupationValue"] forKey:@"occupation"];
            [self.contentDic setValue:self.contentDic[@"city"] forKey:@"city"];
            [self.contentDic setValue:self.contentDic[@"country"][@"id"] forKey:@"countryId"];
            [self.contentDic setValue:[self dealDateStringWithOrignalString:self.contentDic[@"startTime"]] forKey:@"startTime"];
            [self.contentDic setValue:[self dealDateStringWithOrignalString:self.contentDic[@"endTime"]] forKey:@"endTime"];
            self.aredModel=[[CountryModel alloc]init];
            self.aredModel.code=self.contentDic[@"areaCode"];
            self.curentWorkDic=@{occupationString:self.contentDic[@"occupationValue"]};//默认职业
            if ([self.contentDic[@"gender"] isEqualToString:@"Male"]) {
                self.curentSexDic=@{LocalizationKey(@"男"):@"Male"};//设置默认性别
            }else{
                self.curentSexDic=@{LocalizationKey(@"女"):@"Female"};//设置默认性别
            }
            if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
                self.curentCertificateDic=@{LocalizationKey(@"护照"):@"PASSPORT"};
            }else if ([self.contentDic[@"idType"] isEqualToString:@"Government-Issued ID Card"]){
                //国外身份证
                self.curentCertificateDic=@{LocalizationKey(@"身份证"):@"Government-Issued ID Card"};
                
            }else if ([self.contentDic[@"idType"] isEqualToString:@"CN-RIC"]){
                //中国大陆身份证
                self.curentCertificateDic=@{LocalizationKey(@"身份证"):@"CN-RIC"};
                
            }else{
                self.curentCertificateDic=@{LocalizationKey(@"香港身份证"):@"HK-HKID"};
            }
        
            NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?self.currentCountry.usName:self.currentCountry.cnName;
            NSString*sex=[self.contentDic[@"gender"] isEqualToString:@"Male"]?LocalizationKey(@"男"):LocalizationKey(@"女");
            NSString*idType=[self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]?LocalizationKey(@"护照"):([self.contentDic[@"idType"] isEqualToString:@"HK-HKID"]?LocalizationKey(@"香港身份证"):LocalizationKey(@"身份证"));
            self.contentArray=[@[@"这是名字",sex,occupationString,self.contentDic[@"annualSalary"],self.contentDic[@"accountPurpose"],self.contentDic[@"expectedMonthlyVolume"],countryName,self.contentDic[@"state"],data[@"data"][@"city"],self.contentDic[@"address"],self.contentDic[@"postCode"],self.contentDic[@"phone"],idType,self.contentDic[@"idNumber"],[self dealDateStringWithOrignalString:self.contentDic[@"birthday"]],@"这是签发日期"] mutableCopy];

            NSString*remark=self.contentDic[@"remark"];//拒绝原因
            if (![NSString stringIsNull:remark]) {
                NSString*allRemark=[NSString stringWithFormat:@"%@：%@",LocalizationKey(@"拒绝原因"),remark];
                CGFloat height=[ToolUtil getLabelHeightWithText:allRemark width:(kWindowW-(20+16)*2-16-8) font:[UIFont systemFontOfSize:15] withLineSpacing:5];
                UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, ceilf(height)+50)];
                IdentityRejectView*rejectView=[IdentityRejectView instanceViewWithFrame:headView.bounds];
                NSMutableAttributedString *attriString =
                [[NSMutableAttributedString alloc] initWithString:allRemark];
                NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
                [paragraphStyle setLineSpacing:5];
                //设置距离
                [attriString addAttribute:NSParagraphStyleAttributeName
                                                value:paragraphStyle
                                                range:NSMakeRange(0, [allRemark length])];
                rejectView.reasonLabel.attributedText=attriString;
                [headView addSubview:rejectView];
                self.tableView.tableHeaderView=headView;
            
            }
        
            [self.tableView reloadData];
            [self juadgeBtnStatus];
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.titleArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section==12) {
        return 2;
    }
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0) {
        //姓名
        AllNameCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AllNameCell"];
        cell.firstNameTF.text=self.contentDic[@"lastName"];
        cell.lastNameTF.text=self.contentDic[@"firstName"];
        WEAKSELF
        cell.nameBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString) {
            [weakSelf.contentDic setValue:valueString forKey:typeString];
            [weakSelf juadgeBtnStatus];
            AllNameHeadView *headerView = (AllNameHeadView*)[self.tableView headerViewForSection:0];
            [headerView configDataInSection:0 withDataDic:self.contentDic];//更新区头显示的数据
            
            NSLog(@"这是--%@--%@",typeString,valueString);
            
        };
        
        cell.nameEndBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString) {
            //编辑结束
            [weakSelf.tableView reloadData];
            
        };
        return cell;
    }else if (indexPath.section==11){
        //手机号
        PhoneInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PhoneInfoCell"];
        [cell configDataWithAreaCode:self.aredModel withPhone:self.contentArray[indexPath.section]];
        WEAKSELF
        cell.phoneAreablock = ^(NSString * _Nullable typeString, CountryModel*_Nullable areaModel ) {
            [weakSelf.contentDic setValue:areaModel.code forKey:typeString];
            weakSelf.aredModel=areaModel;
            [weakSelf juadgeBtnStatus];
            
        };
        cell.phoneNumBlock = ^(NSString * _Nullable typeString, NSString * _Nullable phoneNum) {
            [weakSelf.contentDic setValue:phoneNum forKey:typeString];
            [weakSelf.contentArray replaceObjectAtIndex:11 withObject:phoneNum];
            [weakSelf juadgeBtnStatus];
        };
        
        cell.endblock = ^{
            [weakSelf.tableView reloadData];
        };
        return cell;
        
        
    }else if (indexPath.section==12){
        //证件类型
        if (indexPath.row==0) {
            IdentityInputCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentityInputCell"];
            [cell configDataAtIndexPath:indexPath withContentArray:self.contentArray withplaceholderArray:self.placeholderArray];
            return cell;
        }else{
            
            if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
                //护照
                PassportPictureCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PassportPictureCell"];
                [cell configImageWithidFrontUrl:self.contentDic[@"idFrontUrl"] withidBackUrl:self.contentDic[@"idBackUrl"] withidHoldUrl:self.contentDic[@"idHoldUrl"]];
                WEAKSELF
                cell.identityImage = ^(NSString * _Nullable identityType, NSDictionary * _Nullable imageDic) {
                    if ([identityType isEqualToString:@"idFrontId"]) {
                        [weakSelf.contentDic setValue:imageDic[@"fileUrl"] forKey:@"idFrontUrl"];
                    }else if ([identityType isEqualToString:@"idBackId"]){
                        [weakSelf.contentDic setValue:imageDic[@"fileUrl"] forKey:@"idBackUrl"];
                    }else{
                        [weakSelf.contentDic setValue:imageDic[@"fileUrl"] forKey:@"idHoldUrl"];
                    }
                    [weakSelf.contentDic setValue:imageDic[@"id"] forKey:identityType];
                    if ([identityType isEqualToString:@"idFrontId"]) {
                        //护照认证时候，背面默认和正面照片一样
                       // [weakSelf.contentDic setValue:imageDic[@"id"] forKey:@"idBackId"];
                    }
                    [weakSelf.tableView reloadData];
                    [weakSelf juadgeBtnStatus];
                    NSLog(@"当前是护照--%@--%@",identityType,weakSelf.contentDic);
                };
                return cell;
                
            }else{
                //身份证和香港身份证
                CardPictureCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CardPictureCell"];
                [cell configImageWithidFrontUrl:self.contentDic[@"idFrontUrl"] withidBackUrl:self.contentDic[@"idBackUrl"] withidHoldUrl:self.contentDic[@"idHoldUrl"]];
                WEAKSELF
                cell.identityImage = ^(NSString * _Nullable identityType, NSDictionary * _Nullable imageDic) {
                    if ([identityType isEqualToString:@"idFrontId"]) {
                        [weakSelf.contentDic setValue:imageDic[@"fileUrl"] forKey:@"idFrontUrl"];
                    }else if ([identityType isEqualToString:@"idBackId"]){
                        [weakSelf.contentDic setValue:imageDic[@"fileUrl"] forKey:@"idBackUrl"];
                    }else{
                        [weakSelf.contentDic setValue:imageDic[@"fileUrl"] forKey:@"idHoldUrl"];
                    }
                    [weakSelf.contentDic setValue:imageDic[@"id"] forKey:identityType];
                    [weakSelf.tableView reloadData];
                    [weakSelf juadgeBtnStatus];
                    NSLog(@"当前是身份证类型--%@--%@",identityType,imageDic);
                };
                return cell;
            }
          
        }
     
        
    }else if (indexPath.section==15){
        //签发日期
        DeadlineCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DeadlineCell"];
        [cell configDatawithStartTime:[self dealDateStringWithOrignalString:self.contentDic[@"startTime"]] withEndTime: [self dealDateStringWithOrignalString:self.contentDic[@"endTime"]]];
        WEAKSELF
        cell.deadlineBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString) {
            NSLog(@"选择的--%@--%@",typeString,valueString);
            [self.contentDic setValue:[NSString stringWithFormat:@"%@ %@",valueString,@"00:00:00"] forKey:typeString];
            [weakSelf.tableView reloadData];
            [weakSelf juadgeBtnStatus];
            
        };
        return cell;
   
        
    }else{
        //其他
        IdentityInputCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentityInputCell"];
        [cell configDataAtIndexPath:indexPath withContentArray:self.contentArray withplaceholderArray:self.placeholderArray];
        WEAKSELF
        cell.identityAuthenticationBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString, int indexPathSection) {
            [weakSelf.contentArray replaceObjectAtIndex:indexPathSection withObject:valueString];
            [weakSelf.contentDic setValue:valueString forKey:typeString];
            [weakSelf juadgeBtnStatus];
            
        };
        cell.endEditBlock = ^{
            [weakSelf.tableView reloadData];
        };
        return cell;
  
    }
   
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==1) {
        //性别
        [self.selectSexView show];
        self.selectSexView.currentDic=self.curentSexDic;
        [self.selectSexView reloadDataWithArray:@[@{LocalizationKey(@"男"):@"Male"},@{LocalizationKey(@"女"):@"Female"}]];
        WEAKSELF
        self.selectSexView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
            NSString*key= [[dic allKeys] objectAtIndex:0];
            NSString*type=[dic objectForKey:key];
            [weakSelf.contentDic setValue:type forKey:@"gender"];
            [weakSelf.contentArray replaceObjectAtIndex:1 withObject:key];
            [weakSelf.tableView reloadData];
            weakSelf.curentSexDic=dic;
            [weakSelf juadgeBtnStatus];
        };
    }else if (indexPath.section==2){
        //职业
        [self getOccupationList];

    }
    else if (indexPath.section==6){
        //选择国家
        [self getAllCountrys];
        
    }else if (indexPath.section==12){
        //选择证件类型
        if ([NSString stringIsNull:self.contentDic[@"countryId"]]) {
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请先选择国家"));
            return;
        }
        NSArray*certificateArray=[[NSArray alloc]init];
        if ([self.contentDic[@"countryId"] intValue] ==181) {
            //中国大陆
            certificateArray=@[@{LocalizationKey(@"护照"):@"PASSPORT"},@{LocalizationKey(@"身份证"):@"CN-RIC"}];
        }else if([self.contentDic[@"countryId"] intValue] ==177){
            //中国香港
            certificateArray=@[@{LocalizationKey(@"护照"):@"PASSPORT"},@{LocalizationKey(@"香港身份证"):@"HK-HKID"}];
        }else{
            
            certificateArray=@[@{LocalizationKey(@"护照"):@"PASSPORT"},@{LocalizationKey(@"身份证"):@"Government-Issued ID Card"}];
        }
        
        [self.selectView show];
        self.selectView.currentDic=self.curentCertificateDic;
        [self.selectView reloadDataWithArray:certificateArray];
        WEAKSELF
        self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
            NSString*key= [[dic allKeys] objectAtIndex:0];
            NSString*type=[dic objectForKey:key];
            [weakSelf.contentDic setValue:type forKey:@"idType"];
            weakSelf.curentCertificateDic=dic;
            [weakSelf.contentArray replaceObjectAtIndex:12 withObject:key];
            [weakSelf.tableView reloadData];
            [weakSelf juadgeBtnStatus];
        };
        
        
    }else if (indexPath.section==14){
        //选择出生日期
        [self creatDatePickerViewAtIndexPath:indexPath];
        
    }else{
        
        
        
    }
    
    
}
//选择出生日期
-(void)creatDatePickerViewAtIndexPath:(NSIndexPath *)indexPath{
    
    // 1.创建日期选择器
    BRDatePickerView *datePickerView = [[BRDatePickerView alloc]init];
  
    // 2.设置属性
    datePickerView.pickerMode = BRDatePickerModeYMD;
    datePickerView.title = LocalizationKey(@"选择时间");
    
//    datePickerView.selectValue = @"2019-10-30";
    // datePickerView.selectDate = [NSDate br_setYear:2019 month:10 day:30];
    datePickerView.minDate = [NSDate br_setYear:1949 month:3 day:12];
    //datePickerView.maxDate = [NSDate date];
    datePickerView.isAutoSelect = NO;
    WEAKSELF
    datePickerView.resultBlock = ^(NSDate *selectDate, NSString *selectValue) {
         //选择日期
        [weakSelf.contentArray replaceObjectAtIndex:indexPath.section withObject:selectValue];
        //出生日期
        [self.contentDic setValue:[NSString stringWithFormat:@"%@ %@",selectValue,@"00:00:00"] forKey:@"birthday"];
        [weakSelf.contentArray replaceObjectAtIndex:14 withObject:selectValue];
        NSLog(@"选择的值：%@", self.contentDic);
        [weakSelf.tableView reloadData];
        [weakSelf juadgeBtnStatus];

    };
    // 设置自定义样式
    BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
    customStyle.pickerColor = [UIColor whiteColor];
    customStyle.pickerTextColor = [UIColor blackColor];
    customStyle.separatorColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.2];
    customStyle.cancelBtnTitle=LocalizationKey(@"取消");
    customStyle.doneBtnTitle=LocalizationKey(@"确定");
    if ([[ChangeLanguage userLanguage] isEqualToString:@"en"]) {
        datePickerView.showUnitType=BRShowUnitTypeNone;//不显示单位
    }
    datePickerView.pickerStyle = customStyle;
    // 3.显示
    [datePickerView show];
    
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 50;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section==0||section==15) {
        AllNameHeadView*sectionView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"AllNameHeadView"];
        [sectionView configDataInSection:section withDataDic:self.contentDic];
        return sectionView;
    }else{
        IdentityHeadView*sectionView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"IdentityHeadView"];
        [sectionView configDataInSection:section withtitleArray:self.titleArray];
        return sectionView;
        
    }
    
}


// 返回区尾高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    
    if (section==0) {
        //姓名
        NSString*lastName=self.contentDic[@"lastName"];
        NSString*firstName=self.contentDic[@"firstName"];

        if ((![self nameIsEnglishAndSpaceOnlyWithLengthLimit:lastName]&&![NSString stringIsNull:lastName])||(![self nameIsEnglishAndSpaceOnlyWithLengthLimit:firstName]&&![NSString stringIsNull:firstName])) {
            CGFloat textHeight=[ToolUtil getLabelHeightWithText:LocalizationKey(@"格式限制英文、空格") width:(kWindowW-40-8)/2.0 font:[UIFont systemFontOfSize:13]];
            return textHeight+10;
        }
        return 0.01f; // 自定义高度
    }else if (section==4){
        //账户用途
        NSString*accountPurpose=self.contentDic[@"accountPurpose"];
        if (![self accountPurposeIsEnglishOnlyWithLengthLimit:accountPurpose]&&![NSString stringIsNull:accountPurpose]) {
            return 30.0f; // 自定义高度
        }
            return 0.01f;
        
    }else if (section==7){
        //州/省
        NSString*state=self.contentDic[@"state"];
        if (![self stateIsValidInput:state]&&![NSString stringIsNull:state]) {
            CGFloat textHeight=[ToolUtil getLabelHeightWithText:LocalizationKey(@"格式限制英文、空格") width:(kWindowW-40) font:[UIFont systemFontOfSize:13]];
            return textHeight+1+10; // 自定义高度
        }
            return 0.01f;
        
    }else if (section==8){
        //城市
        NSString*city=self.contentDic[@"city"];
        if (![self stateIsValidInput:city]&&![NSString stringIsNull:city]) {
            CGFloat textHeight=[ToolUtil getLabelHeightWithText:LocalizationKey(@"格式限制英文、空格") width:(kWindowW-40) font:[UIFont systemFontOfSize:13]];
            return textHeight+1+10; // 自定义高度
        }
            return 0.01f;
        
    }
    else if (section==9){
        //地址
        NSString*address=self.contentDic[@"address"];
        if (![self addressIsValidInput:address]&&![NSString stringIsNull:address]) {
            CGFloat textHeight=[ToolUtil getLabelHeightWithText:LocalizationKey(@"格式限制英文、数字、空格、-") width:(kWindowW-40) font:[UIFont systemFontOfSize:13]];
            return textHeight+1+10; // 自定义高度
        }
            return 0.01f;
        
    }else if (section==10){
        //邮编
        NSString*postalCode=self.contentDic[@"postCode"];
        if (![self postalCodeIsValidEnglishNumber:postalCode]&&![NSString stringIsNull:postalCode]) {
            return 30.0f; // 自定义高度
        }
        return 0.01f; // 自定义高度
    }
    else if (section==11){
        //手机号
        NSString*phone=self.contentDic[@"phone"];
        if (![NSString stringIsNull:phone]&&phone.length>20) {
            return 30.0f; // 自定义高度
        }
        return 0.01f; // 自定义高度
    }
    else if (section==13){
        //证件号码
        NSString*cardNo=self.contentDic[@"cardNo"];
        if (![self addressIsValidInput:cardNo]&&![NSString stringIsNull:cardNo]) {
            return 30.0f; // 自定义高度
        }
        return 0.01f; // 自定义高度
    }else{
        return 0.01f; // 自定义高度
    }

   
}

// 返回区尾视图
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    if (section==0) {
        //姓名
        FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
        footerView.lastName.hidden=YES;
        footerView.firstName.hidden=YES;
        NSString*lastName=self.contentDic[@"lastName"];
        NSString*firstName=self.contentDic[@"firstName"];
        if (![self nameIsEnglishAndSpaceOnlyWithLengthLimit:lastName]&&![NSString stringIsNull:lastName]) {
            footerView.nameView.hidden=NO;
            footerView.lastName.hidden=NO;
           
        }
        if (![self nameIsEnglishAndSpaceOnlyWithLengthLimit:firstName]&&![NSString stringIsNull:firstName]) {
            footerView.nameView.hidden=NO;
            footerView.firstName.hidden=NO;
            
        }
            return footerView;
            
    }else if (section==4){
        //账户用途
        NSString*accountPurpose=self.contentDic[@"accountPurpose"];
        if (![self accountPurposeIsEnglishOnlyWithLengthLimit:accountPurpose]&&![NSString stringIsNull:accountPurpose]) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=LocalizationKey(@"格式限制英文、空格");
            return footerView;
        }
        return [UIView new];
    } else if (section==7){
        //州/省
        NSString*state=self.contentDic[@"state"];
        if (![self stateIsValidInput:state]&&![NSString stringIsNull:state]) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=LocalizationKey(@"格式限制英文、空格");
            return footerView;
        }
        return [UIView new];
    }
    else if (section==8){
        //城市
        NSString*city=self.contentDic[@"city"];
        if (![self stateIsValidInput:city]&&![NSString stringIsNull:city]) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=LocalizationKey(@"格式限制英文、空格");
            return footerView;
        }
        return [UIView new];
    }
    else if (section==9){
        //地址
        NSString*address=self.contentDic[@"address"];
        if (![self addressIsValidInput:address]&&![NSString stringIsNull:address]) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=LocalizationKey(@"格式限制英文、数字、空格、-");
            return footerView;
        }
        return [UIView new];
    }else if (section==10){
        //邮编
        NSString*postalCode=self.contentDic[@"postCode"];
        if (![self postalCodeIsValidEnglishNumber:postalCode]&&![NSString stringIsNull:postalCode]) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=LocalizationKey(@"格式限制英文、数字");
            return footerView;
        }
        return [UIView new];
       
    }
    else if (section==11){
        //手机号
        NSString*phone=self.contentDic[@"phone"];
        if (![NSString stringIsNull:phone]&&phone.length>20) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=[NSString stringWithFormat:@"5-20 %@",LocalizationKey(@"字符")];
            return footerView;
        }
        return [UIView new];
       
    }
    else if (section==13){
        //证件号码
        NSString*cardNo=self.contentDic[@"cardNo"];
        if (![self idCardIsValidLength:cardNo]&&![NSString stringIsNull:cardNo]) {
            FootAlertView*footerView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"FootAlertView"];
            footerView.nameView.hidden=YES;
            footerView.alertLabel.text=[NSString stringWithFormat:@"0-50 %@",LocalizationKey(@"字符")];
            return footerView;
        }
           return [UIView new];
        
    }else{
        return [UIView new];
    }
    
}



//行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==12) {
        //证件
        if (indexPath.row==0) {
            return 50;
        }
        if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
            //护照认证
            return 190;
        }else{
            //身份证认证
            return 340;
        }
    
    }
    return 50;
}

//提交kyc认证
-(void)toSubmitAuthentication{
    
  
    NSLog(@"最终的数据-%@",self.contentDic);
    
    if ([NSString stringIsNull:self.contentDic[@"lastName"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入姓氏"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"firstName"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入名字"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"gender"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择性别"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"occupation"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择职业"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"annualSalary"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入年薪"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"accountPurpose"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入账户用途"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"expectedMonthlyVolume"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入月交易额"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"countryId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择国家"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"state"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入州/省"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"city"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入城市"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"address"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入地址"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"postCode"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮政编码"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"phone"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入手机号"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idFrontId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传证件正面"));
   
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idBackId"]]&&![self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传证件背面"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idHoldId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传手持证件"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idNumber"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入证件号码"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"birthday"]]) {
     
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择出生日期"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"startTime"]]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择签发日期"));
        return;
    }
    
    if ([NSString stringIsNull:self.contentDic[@"endTime"]]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择截止日期"));
        return;
    }
    NSDictionary*copyDic=[[NSMutableDictionary alloc]initWithDictionary:self.contentDic];
    [copyDic setValue:[self fixDateString:copyDic[@"endTime"]] forKey:@"endTime"];
    [copyDic setValue:[self fixDateString:copyDic[@"startTime"]] forKey:@"startTime"];
    [copyDic setValue:[self fixDateString:copyDic[@"birthday"]] forKey:@"birthday"];
    if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        //护照认证，默认证件背面和正面一致
        [copyDic setValue:copyDic[@"idFrontId"] forKey:@"idBackId"];
    }
    
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager submitMemberInfoWithParams:copyDic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"提交成功"));
            [self.view endEditing:YES];
            [UserWrapper shareUserInfo].kycStatus=@"0";
            [UserWrapper saveUser:[UserWrapper shareUserInfo]];
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                [self.navigationController popViewControllerAnimated:YES];
            });
            
        }else{
          
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
}

//添加持卡人
-(void)toAddCardHolder{
    
    [self.contentDic setValue:self.binModel.bin forKey:@"cardBin"];
  
    
    if ([NSString stringIsNull:self.contentDic[@"lastName"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入姓氏"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"firstName"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入名字"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"gender"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择性别"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"occupation"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择职业"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"annualSalary"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入年薪"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"accountPurpose"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入账户用途"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"expectedMonthlyVolume"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入月交易额"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"countryId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择国家"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"state"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入州/省"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"city"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入城市"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"address"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入地址"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"postCode"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮政编码"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"phone"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入手机号"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idFrontId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传证件正面"));
   
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idBackId"]]&&![self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传证件背面"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idHoldId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传手持证件"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idNumber"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入证件号码"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"birthday"]]) {
     
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择出生日期"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"startTime"]]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择签发日期"));
        return;
    }
    
    if ([NSString stringIsNull:self.contentDic[@"endTime"]]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择截止日期"));
        return;
    }
    NSDictionary*copyDic=[[NSMutableDictionary alloc]initWithDictionary:self.contentDic];
    [copyDic setValue:[self fixDateString:copyDic[@"endTime"]] forKey:@"endTime"];
    [copyDic setValue:[self fixDateString:copyDic[@"startTime"]] forKey:@"startTime"];
    [copyDic setValue:[self fixDateString:copyDic[@"birthday"]] forKey:@"birthday"];
    if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        //护照认证，默认证件背面和正面一致
        [copyDic setValue:copyDic[@"idFrontId"] forKey:@"idBackId"];
    }
    NSLog(@"创建持卡人最终的数据-%@",copyDic);
    [SVProgressHUD customShowWithStyle];
    [HomeCardNetWorkManager addcardUserInfoWithparams:copyDic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
          
            [self.view endEditing:YES];
            ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
            successView.titleLabel.text=LocalizationKey(@"温馨提示");
            successView.detailLabel.text=LocalizationKey(@"持卡人信息提交成功，正在审核中");
            successView.tipsImageV.image=UIIMAGE(@"orderSuccess");
            WEAKSELF
            [successView.okBtn dn_addActionHandler:^{
                [successView hide];
                [weakSelf.navigationController popViewControllerAnimated:YES];
            }];
            [successView show];
            [[NSNotificationCenter defaultCenter] postNotificationName:ReloadBIN object:nil];
            
        }else{
          
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
}

//更新持卡人
-(void)toUpdateCardHolder{
    
  
    if ([NSString stringIsNull:self.contentDic[@"lastName"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入姓氏"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"firstName"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入名字"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"gender"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择性别"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"occupation"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择职业"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"annualSalary"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入年薪"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"accountPurpose"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入账户用途"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"expectedMonthlyVolume"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入月交易额"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"countryId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择国家"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"state"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入州/省"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"city"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入城市"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"address"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入地址"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"postCode"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮政编码"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"phone"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入手机号"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idFrontId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传证件正面"));
   
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idBackId"]]&&![self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传证件背面"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idHoldId"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请上传手持证件"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"idNumber"]]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入证件号码"));
     
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"birthday"]]) {
     
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择出生日期"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"startTime"]]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择签发日期"));
        return;
    }
    if ([NSString stringIsNull:self.contentDic[@"endTime"]]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请选择截止日期"));
        return;
    }
    NSDictionary*copyDic=[[NSMutableDictionary alloc]initWithDictionary:self.contentDic];
    [copyDic setValue:[self fixDateString:copyDic[@"endTime"]] forKey:@"endTime"];
    [copyDic setValue:[self fixDateString:copyDic[@"startTime"]] forKey:@"startTime"];
    [copyDic setValue:[self fixDateString:copyDic[@"birthday"]] forKey:@"birthday"];
    if ([self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        //护照认证，默认证件背面和正面一致
        [copyDic setValue:copyDic[@"idFrontId"] forKey:@"idBackId"];
    }
    NSLog(@"更新持卡人最终的数据-%@",copyDic);
    [SVProgressHUD customShowWithStyle];
    [HomeCardNetWorkManager updateCardUserInfoListWithparams:copyDic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
          
            [self.view endEditing:YES];
            ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
            successView.titleLabel.text=LocalizationKey(@"温馨提示");
            successView.detailLabel.text=LocalizationKey(@"持卡人信息提交成功，正在审核中");
            successView.tipsImageV.image=UIIMAGE(@"orderSuccess");
            WEAKSELF
            [successView.okBtn dn_addActionHandler:^{
                [successView hide];
                [weakSelf.navigationController popViewControllerAnimated:YES];
            }];
            [successView show];
            [[NSNotificationCenter defaultCenter] postNotificationName:ReloadBIN object:nil];
            
        }else{
          
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
}



//MARK: 获取支持的全部国家
-(void)getAllCountrys{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getAllcountrysuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*countryArray=(NSMutableArray*)[CountryModel utr_modelsWithKeyValues:data[@"data"]];
            [self.countryView show];
            [self.countryView clearTextFieldContent];
            [self.countryView  reloadDataWithArray:countryArray withDefalutModel:self.currentCountry withType:0];
            WEAKSELF
            self.countryView.countryBlock = ^(CountryModel *country) {
                weakSelf.currentCountry=country;
                [weakSelf.contentDic setValue:country.ID forKey:@"countryId"];
                NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?country.usName:country.cnName;
                [weakSelf.contentArray replaceObjectAtIndex:6 withObject:countryName];
                //因为国家不同，证件类型不同，所以切换国家时候重置证件类型，默认护照认证
                [weakSelf.contentDic setValue:@"PASSPORT" forKey:@"idType"];
                [weakSelf.contentArray replaceObjectAtIndex:12 withObject:LocalizationKey(@"护照")];
                weakSelf.curentCertificateDic=@{LocalizationKey(@"护照"):@"PASSPORT"};
                [weakSelf.tableView reloadData];
                [weakSelf juadgeBtnStatus];
                
            };
            
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
    }];
   
}

//获取职业列表
-(void)getOccupationList{
    
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getOccupationListsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*occupationArray=data[@"data"];
            NSMutableArray*selectArray=[[NSMutableArray alloc]init];
            [occupationArray enumerateObjectsUsingBlock:^(NSDictionary* obj, NSUInteger idx, BOOL * _Nonnull stop) {
                
                NSDictionary*dic=@{obj[@"label"]:obj[@"value"]};
                [selectArray addObject:dic];
                            
            }];
      
            [self.selectWorkView show];
            self.selectWorkView.currentDic=self.curentWorkDic;
            [self.selectWorkView reloadDataWithArray:selectArray];
            WEAKSELF
            self.selectWorkView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
                NSString*key= [[dic allKeys] objectAtIndex:0];
                NSString*type=[dic objectForKey:key];
                [weakSelf.contentDic setValue:type forKey:@"occupation"];
                [weakSelf.contentArray replaceObjectAtIndex:2 withObject:key];
                [weakSelf.tableView reloadData];
                weakSelf.curentWorkDic=dic;
                [weakSelf juadgeBtnStatus];
            };
    
        }else{
            
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
             ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
    }];
    
}


//处理时间字符串
-(NSString*)dealDateStringWithOrignalString:(NSString*)dateString{
    
    if (dateString.length == 0) return @"";
       
       NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
       inputFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
       
       // 判断是否包含时间
       if ([dateString containsString:@" "]) {
           inputFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
       } else {
           inputFormatter.dateFormat = @"yyyy-MM-dd";
       }
       
       NSDate *date = [inputFormatter dateFromString:dateString];
       if (!date) return dateString;
       
       NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
       outputFormatter.dateFormat = @"yyyy-MM-dd";
    return [outputFormatter stringFromDate:date];

}

- (NSString *)fixDateString:(NSString *)dateString {
    if (dateString.length == 0) return dateString;
    
    // 判断是否包含时间部分
    if ([dateString containsString:@" "]) {
        // 已经有时分秒，不需要修改
        return dateString;
    } else {
        // 没有时间部分，补上 " 00:00:00"
        return [NSString stringWithFormat:@"%@ 00:00:00", dateString];
    }
}
//判断按钮可点击状态
-(void)juadgeBtnStatus{
    
    BOOL firstName=YES;
    if ([NSString stringIsNull:self.contentDic[@"firstName"]]) {
        firstName=NO;
    }
    BOOL lastName=YES;
    if ([NSString stringIsNull:self.contentDic[@"lastName"]]) {
        lastName=NO;
    }
    
    BOOL gender=YES;
    if ([NSString stringIsNull:self.contentDic[@"gender"]]) {
        gender=NO;
    }
    BOOL occupation=YES;
    if ([NSString stringIsNull:self.contentDic[@"occupation"]]) {
        occupation=NO;
    }
    BOOL annualSalary=YES;
    if ([NSString stringIsNull:self.contentDic[@"annualSalary"]]) {
        annualSalary=NO;
    }
    BOOL accountPurpose=YES;
    if ([NSString stringIsNull:self.contentDic[@"accountPurpose"]]) {
        accountPurpose=NO;
    }
    BOOL expectedMonthlyVolume=YES;
    if ([NSString stringIsNull:self.contentDic[@"expectedMonthlyVolume"]]) {
        expectedMonthlyVolume=NO;
    }
    BOOL countryId=YES;
    if ([NSString stringIsNull:self.contentDic[@"countryId"]]) {
        countryId=NO;
    }
    BOOL state=YES;
    if ([NSString stringIsNull:self.contentDic[@"state"]]) {
        state=NO;
    }
    BOOL city=YES;
    if ([NSString stringIsNull:self.contentDic[@"city"]]) {
        city=NO;
    }
    BOOL address=YES;
    if ([NSString stringIsNull:self.contentDic[@"address"]]) {
        address=NO;
        
    }
    BOOL postalCode=YES;
    if ([NSString stringIsNull:self.contentDic[@"postCode"]]) {
        postalCode=NO;
        
    }
    BOOL phone=YES;
    if ([NSString stringIsNull:self.contentDic[@"phone"]]) {
        phone=NO;
        
    }
    
    BOOL idFrontId=YES;
    BOOL idBackId=YES;
    BOOL idHoldId=YES;
    if ([NSString stringIsNull:self.contentDic[@"idFrontId"]]) {
        idFrontId=NO;
    }
    if ([NSString stringIsNull:self.contentDic[@"idBackId"]]&&![self.contentDic[@"idType"] isEqualToString:@"PASSPORT"]) {
        idBackId=NO;
    }
    if ([NSString stringIsNull:self.contentDic[@"idHoldId"]]) {
        idHoldId=NO;
    }
    BOOL idNumber=YES;
    if ([NSString stringIsNull:self.contentDic[@"idNumber"]]) {
        idNumber=NO;
    }
    BOOL birthday=YES;
    if ([NSString stringIsNull:self.contentDic[@"birthday"]]) {
        birthday=NO;
    }
    BOOL startTime=YES;
    if ([NSString stringIsNull:self.contentDic[@"startTime"]]) {
        startTime=NO;
        
    }
    BOOL endTime=YES;
    if ([NSString stringIsNull:self.contentDic[@"endTime"]]) {
        endTime=NO;
        
    }
    
    if (!firstName||!lastName||!gender||!occupation||!annualSalary||!accountPurpose||!expectedMonthlyVolume||!countryId||!city||!address||!postalCode||!phone||!idFrontId||!idBackId||!idHoldId||!idNumber||!birthday||!startTime||!endTime) {
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.06];
    }else{
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    
    
}

//判断姓，名是否符合规则
- (BOOL)nameIsEnglishAndSpaceOnlyWithLengthLimit:(NSString *)string {
    if (string == nil) {
        return NO;
    }
    
    // 使用正则匹配：只允许英文和空格，长度 0~32
    NSString *pattern = @"^[A-Za-z ]{0,32}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pattern];
    return [predicate evaluateWithObject:string];
}

//判断账户用途
- (BOOL)accountPurposeIsEnglishOnlyWithLengthLimit:(NSString *)string {
    if (string == nil) {
        return NO;
    }
    
    // 允许英文和空格，长度 0~255
    NSString *pattern = @"^[A-Za-z ]{0,255}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pattern];
    return [predicate evaluateWithObject:string];
}

//判断地址是否符合
- (BOOL)addressIsValidInput:(NSString *)string {
    if (string == nil) {
        return NO;
    }
    
    // 正则表达式：允许 A-Z、a-z、0-9、空格、-，长度 2~40
    NSString *pattern = @"^[A-Za-z0-9\\- ]{2,40}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pattern];
    BOOL isValid = [predicate evaluateWithObject:string];
    
    if (!isValid) {
        NSLog(@"❌ 格式限制英文、数字、空格、-（连字符），长度2-40个字符");
    }
    
    return isValid;
}
//判断邮编是否符合
- (BOOL)postalCodeIsValidEnglishNumber:(NSString *)string {
    if (string == nil) {
        return NO;
    }
    
    // 正则表达式：只允许英文字母和数字，长度2-15
    NSString *pattern = @"^[A-Za-z0-9]{2,15}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pattern];
    BOOL isValid = [predicate evaluateWithObject:string];
    
    if (!isValid) {
        NSLog(@"❌ 格式限制英文、数字，长度2-15个字符");
    }
    
    return isValid;
}


//判断证件
- (BOOL)idCardIsValidLength:(NSString *)string {
    if (string == nil) {
        return NO;
    }
    
    NSInteger length = string.length;
    if (length >= 0 && length <= 50) {
        return YES;
    } else {
        NSLog(@"❌ 长度限制0-50个字符");
        return NO;
    }
}

// 判断内容是否只允许英文和空格，长度为 0~60
- (BOOL)stateIsValidInput:(NSString *)string {
    if (string == nil) {
        return NO;
    }
    
    // 正则表达式：只允许 A-Z、a-z、空格，长度 1~32
    NSString *pattern = @"^[A-Za-z ]{0,60}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pattern];
    BOOL isValid = [predicate evaluateWithObject:string];
    
    if (!isValid) {
        NSLog(@"❌ 只能输入英文和空格，长度 0-60 个字符");
    }
    
    return isValid;
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
