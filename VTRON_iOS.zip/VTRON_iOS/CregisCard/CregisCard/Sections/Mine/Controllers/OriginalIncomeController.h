//
//  OriginalIncomeController.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/10.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface OriginalIncomeController : BaseViewController
@property(nonatomic,strong) NSDictionary*merchantDistributorInfoVo;
@end

NS_ASSUME_NONNULL_END
