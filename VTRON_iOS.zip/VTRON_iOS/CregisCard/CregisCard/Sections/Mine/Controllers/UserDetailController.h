//
//  UserDetailController.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/10.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"
#import "InviteModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface UserDetailController : BaseViewController
@property(nonatomic,strong)InviteModel*inviteModel;
@end

NS_ASSUME_NONNULL_END
