//
//  ModifyEmailController.m
//  CregisCard
//
//  Created by sunliang on 2023/2/10.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "ModifyEmailController.h"
#import "MineNetWorkManager.h"
#import "LoginController.h"
#import "LoginAuthenticationView.h"

@interface ModifyEmailController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIView *emailView;
@property (weak, nonatomic) IBOutlet UITextField *pswTF;
@property (weak, nonatomic) IBOutlet UITextField *emailTF;
@property (weak, nonatomic) IBOutlet UITextField *googleTF;
@property (weak, nonatomic) IBOutlet UIView *pswView;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIView *googleView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *googleH;
@property (weak, nonatomic) IBOutlet UILabel *accountTips;
@property (weak, nonatomic) IBOutlet UILabel *pswTips;
@property (weak, nonatomic) IBOutlet UILabel *googleTips;
@property (weak, nonatomic) IBOutlet UILabel *alertLabel;
@property(nonatomic,strong) LoginAuthenticationView*loginAuthView;
@property (weak, nonatomic) IBOutlet UILabel *accountTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *pswTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailAlertLabel;
@property (weak, nonatomic) IBOutlet UILabel *pswAlertLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emailTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tipsDistance;


@end

@implementation ModifyEmailController

- (LoginAuthenticationView *)loginAuthView {
    if(!_loginAuthView) {
        BOOL needGoogle=[[UserWrapper shareUserInfo].googleStatus intValue]==1?YES:NO;
        CGFloat additionalHeight=needGoogle?106:0;
        _loginAuthView=[LoginAuthenticationView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320+0+additionalHeight) withVerifyPermissionType:3 withGoogleVerify:needGoogle];
    }
    return _loginAuthView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"更换邮箱");
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.alertLabel.text=[NSString stringWithFormat:@"%@%@",[NSString maskEmail:[UserWrapper shareUserInfo].email],LocalizationKey(@"已绑定")];
    [self.pswTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.googleTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.okBtn setTitle:LocalizationKey(@"下一步") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.accountTitleLabel.text=LocalizationKey(@"新邮箱");
    self.pswTitleLabel.text=LocalizationKey(@"登录密码");
    //修改邮箱
    [self.emailTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    self.pswTF.delegate=self;
    [self setBorderView:self.emailView];
    [self setBorderView:self.pswView];
    [self setBorderView:self.googleView];
    [self setTextFieldObserverWithtextField:self.emailTF];
    [self setTextFieldObserverWithtextField:self.pswTF];
    //[self setTextFieldObserverWithtextField:self.googleTF];
    //一直隐藏
    self.googleH.constant=0;
    self.googleView.hidden=YES;
    self.googleTips.hidden=YES;
    self.emailAlertLabel.text=LocalizationKey(@"电子邮件格式不正确");
    self.pswAlertLabel.text=LocalizationKey(@"密码规则不正确");
    self.pswAlertLabel.hidden=YES;
    self.emailAlertLabel.hidden=YES;
    self.emailTitleHeight.constant=0;
    self.tipsDistance.constant=0;
    self.pswTitleHeight.constant=0;
    self.accountTitleLabel.font=PingFangMediumFont(13);
    self.pswTitleLabel.font=PingFangMediumFont(13);
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
}

-(void)setTextFieldObserverWithtextField:(UITextField *)textField{
    [textField addTarget:self action:@selector(textFieldDidBegin:) forControlEvents:UIControlEventEditingDidBegin];
    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
}

-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
    
}


- (IBAction)eyeClick:(UIButton*)sender {
    sender.selected=!sender.selected;
    self.pswTF.secureTextEntry=sender.selected?NO:YES;
}


//下一步
- (IBAction)okClick:(id)sender {
    if ([NSString stringIsNull:self.emailTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
        return;
    }
    if (![ToolUtil matchEmail:self.emailTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入正确的邮箱"));
        return;
    }
    if ([NSString stringIsNull:self.pswTF.text]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入登录密码"));
        return;
    }
    if (![ToolUtil isOrNoPasswordStyle:self.pswTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"数字+大小写字母的8-20字符"));
      
        return;
    }
   
    [self.loginAuthView showWithAccount:self.emailTF.text withPassword:self.pswTF.text withinviteCode:nil];
    WEAKSELF
    self.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable dic) {
        [weakSelf.view endEditing:YES];
        //延迟执行
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf logoOut];
        });
        
    };
   
}


//MARK:退出登录
-(void)logoOut{
 
    [self postLogoutRequest];
    [self initRootViewController];
    [UserWrapper logout];
}

-(void)initRootViewController{
    LoginController*loginVC=[[LoginController alloc]init];
    BaseNavigationController*loginNav=[[BaseNavigationController alloc]initWithRootViewController:loginVC];
    APPLICATION.window.rootViewController = loginNav;
}

//MARK: 退出登录请求
-(void)postLogoutRequest{
    [LoginNetWorkManager logoutsuccess:^(id  _Nonnull data) {
        
        if ([data[@"code"] intValue]==200) {
            NSLog(@"退出登录成功");
        }
        
    } fail:^(NSError * _Nonnull error) {
        
    }];
    
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];

}


//MARK: 监听输入框开始编辑
- (void)textFieldDidBegin:(UITextField *)textField {
   
    
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    if ([textField isEqual:self.emailTF]) {
        //邮箱
        [self judgeCorrectEmail:[ToolUtil matchEmail:textField.text]];
    }else{
        //密码
        [self judgeCorrectPassword:[ToolUtil isOrNoPasswordStyle:textField.text]];
    }
    
    if ([[UserWrapper shareUserInfo].googleStatus intValue]==1){
       //有谷歌验证码
        if ([ToolUtil matchEmail:self.emailTF.text]&&[ToolUtil isOrNoPasswordStyle:self.pswTF.text]) {
            self.okBtn.enabled=YES;
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
            [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }else{
            
            self.okBtn.enabled=NO;
            [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        }
    
    }else{
        //无谷歌验证码
        if ([ToolUtil matchEmail:self.emailTF.text]&&[ToolUtil isOrNoPasswordStyle:self.pswTF.text]) {
            self.okBtn.enabled=YES;
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
            [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }else{
            
            self.okBtn.enabled=NO;
            [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
            self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        }
    
        
    }
  
}


//限制只能输入6位数字
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // 获取当前文本框的文本
    NSString *currentText = textField.text;
    
    // 计算替换后的文本
    NSString *updatedText = [currentText stringByReplacingCharactersInRange:range withString:string];
    // 检查文本长度是否超过最大字符
    if (updatedText.length > 20) {
        return NO; // 返回NO，表示不允许输入
    } else {
        return YES; // 返回YES，表示允许输入
    }
}

//判断电子邮件是否正确
-(void)judgeCorrectEmail:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.emailAlertLabel.hidden=YES;
        self.emailView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.emailView.backgroundColor=[UIColor whiteColor];
        self.emailTitleHeight.constant=0;
        self.tipsDistance.constant=0;
    }else{
        self.emailAlertLabel.hidden=NO;
        self.emailView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.emailView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.emailTitleHeight.constant=15;
        self.tipsDistance.constant=8;
    }
   
}


//判断密码格式是否正确
-(void)judgeCorrectPassword:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.pswAlertLabel.hidden=YES;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.pswView.backgroundColor=[UIColor whiteColor];
        self.pswTitleHeight.constant=0;
    }else{
        self.pswAlertLabel.hidden=NO;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.pswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.pswTitleHeight.constant=15;
    }
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
