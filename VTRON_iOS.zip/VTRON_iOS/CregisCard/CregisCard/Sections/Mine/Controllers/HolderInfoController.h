//
//  HolderInfoController.h
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BinModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface HolderInfoController : UITableViewController
@property(nonatomic,assign) int type;//0 身份认证 1 创建持卡人，更新持卡人
@property(nonatomic,strong)BinModel*binModel;
@end

NS_ASSUME_NONNULL_END
