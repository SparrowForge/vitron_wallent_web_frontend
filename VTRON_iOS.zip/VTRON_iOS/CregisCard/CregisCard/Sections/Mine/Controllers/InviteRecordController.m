//
//  InviteRecordController.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "InviteRecordController.h"
#import "InviteCell.h"
#import "NSObject+UBTrackerModel.h"
#import "OrderSearchView.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "UserDetailController.h"
#import "InviteSearchController.h"
#import "MineNetWorkManager.h"
#import "InviteModel.h"
#import "TABAnimated.h"

@interface InviteRecordController ()<UITableViewDelegate,UITableViewDataSource>
{
    int _pageNO;
}
@property (strong, nonatomic)  UITableView *tableView;
@property(nonatomic,strong) OrderSearchView*searchView;
@property(nonatomic,strong) NSMutableArray*contentArray;
@end

@implementation InviteRecordController

-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"邀请记录");
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    _pageNO=1;
    [self setTableViewConfig];
    [self getInviteRecordswithFirst:YES];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
    
    
}
-(void)setTableViewConfig{
    
    self.tableView =[[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.tableView registerNib:[UINib nibWithNibName:@"InviteCell" bundle:nil] forCellReuseIdentifier:@"InviteCell"];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 80)];
    self.searchView=[OrderSearchView instanceViewWithFrame:CGRectMake(0, 10, kWindowW, 70)];
    self.searchView.inputTF.enabled=NO;
    WEAKSELF
    self.searchView.searchblock = ^(NSString * _Nullable text) {
        [weakSelf searchSingleOrderWithUsername:text];
    };
    self.searchView.inputTF.placeholder=LocalizationKey(@"请输入客户ID、邮箱");
    [headView addSubview:self.searchView];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture:)];
    [headView addGestureRecognizer:tapGesture];
    self.tableView.tableHeaderView=headView;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.rowHeight=110;
    self.tableView.backgroundColor=[UIColor whiteColor];
    [self headRefreshWithScrollerView:self.tableView];
    [self footRefreshWithScrollerView:self.tableView];
    self.tableView.tabAnimated= [TABTableAnimated animatedWithCellClass:[InviteCell class] cellHeight:110];
    [self.tableView tab_startAnimation];
   
}

-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    InviteCell*cell=[tableView dequeueReusableCellWithIdentifier:@"InviteCell"];
    cell.model=self.contentArray[indexPath.row];
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UserDetailController*userVC=[[UserDetailController alloc]init];
    userVC.inviteModel=self.contentArray[indexPath.row];
    [self.navigationController pushViewController:userVC animated:YES];
}

//搜索单个订单记录
-(void)searchSingleOrderWithUsername:(NSString*)username{
    _pageNO=1;
 }

//MARK: 上拉加载更多
- (void)refreshFooterAction{
    _pageNO+=1;
    [self getInviteRecordswithFirst:NO];
}
//MARK: 下拉刷新
- (void)refreshHeaderAction{
    _pageNO=1;
    [self.tableView.mj_footer resetNoMoreData];
    [self getInviteRecordswithFirst:NO];
}
//获取邀请记录
-(void)getInviteRecordswithFirst:(BOOL)isFirst{
    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10)} mutableCopy];
    if (!isFirst) {
        [SVProgressHUD customShowWithStyle];
    }
    [MineNetWorkManager getInvitedRecordsWithParams:dic success:^(id  _Nonnull data) {
        if (!isFirst){
            [SVProgressHUD dismiss];
        }
      
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
        if ([data[@"code"] intValue]==200) {
            
                 if(self->_pageNO==1){
                     [self.contentArray removeAllObjects];
                 }
                 NSArray*onceArray=[InviteModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
                 if(onceArray.count>0){
                     [self.contentArray addObjectsFromArray:onceArray];
                 }
                 [self.tableView reloadData];
                 if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                     [self.tableView.mj_footer endRefreshingWithNoMoreData];
                 }
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
            
        } fail:^(NSError * _Nonnull error) {
            if (!isFirst){
                [SVProgressHUD dismiss];
            }
            [self.tableView tab_endAnimation];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
            [self configEmptyViewForTableView];
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//点击搜索
 -(void)tapGesture:(id)sender
 {
     InviteSearchController*searchVC=[[InviteSearchController alloc]init];
     [self.navigationController pushViewController:searchVC animated:NO];
 }
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
