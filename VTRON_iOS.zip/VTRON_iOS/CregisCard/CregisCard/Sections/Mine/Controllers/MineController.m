//
//  MineController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/2.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "MineController.h"
#import "MineNetWorkManager.h"
#import "MineHeadView.h"
#import "MineCell.h"
#import "SafeCenterController.h"
#import "HolderInfoController.h"
#import "IdentityInreviewController.h"
#import "InviteController.h"
#import "NotificationCenterController.h"
#import "LanguageController.h"
#import "TransferController.h"
#import "AccountNetWorkManager.h"
#import "UIImage+GIFImage.h"


@interface MineController ()

{
    BOOL _haveNotification;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSArray*iconArray;
@property(nonatomic,strong)NSArray*nameArray;
@property(nonatomic,strong)NSArray*titleArray;
@property(nonatomic,strong)  MineHeadView*mineView;


@end

@implementation MineController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    [self setTableViewConfig];
    // Do any additional setup after loading the view from its nib.
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    [self setupNavigationBarTheme];
    self.tableView.contentInset = UIEdgeInsetsMake(-STATUS_BAR_HEIGHT, 0, 0, 0);
    [self getMemberInfo];
    [self getNotificationMessages];
    if ( [CommonInfoManager sharedInstance].coinsArray.count==0) {
        [self getAssetDetail]; //获取系统支持的币种
    }
   
   
}




#pragma mark -- 获取系统支持的币种
-(void)getAssetDetail{
    return;
    [AccountNetWorkManager merchantWalletListsuccess:^(id  _Nonnull data) {
        if ([data[@"code"] intValue]==200) {
            NSArray*coinsArray=data[@"data"];
            NSMutableArray*allCoins=[[NSMutableArray alloc]init];
            [coinsArray enumerateObjectsUsingBlock:^(NSDictionary* obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [allCoins addObject:obj[@"currency"]];
            }];
            [CommonInfoManager sharedInstance].coinsArray=allCoins;
     
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
     } fail:^(NSError * _Nonnull error) {
        // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}
-(void)setTableViewConfig{
    self.iconArray=@[@[@"SafeIcon",@"IDIcon"],@[@"HelpIcon",@"languageIcon",@"VersonIcon"]];
    self.nameArray=@[@[LocalizationKey(@"账户安全"),LocalizationKey(@"身份认证")],@[LocalizationKey(@"通知"),LocalizationKey(@"语言"),LocalizationKey(@"版本")]];
    self.titleArray=@[LocalizationKey(@"安全"),LocalizationKey(@"关于")];
    [self.tableView registerNib:[UINib nibWithNibName:@"MineCell" bundle:nil] forCellReuseIdentifier:@"MineCell"];
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 200)];
    self.mineView=[MineHeadView instanceViewWithFrame:headView.bounds];
    [headView addSubview:self.mineView];
    self.tableView.tableHeaderView=headView;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.backgroundColor=[UIColor whiteColor];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray*nameArray=self.nameArray[section];
    return nameArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MineCell*cell=[tableView dequeueReusableCellWithIdentifier:@"MineCell"];
    [cell configDataWithIconImage:self.iconArray withName:self.nameArray AtIndexPath:indexPath withHaveNotification:_haveNotification];
    
    return cell;
    
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return [NSString stringWithFormat:@" %@",self.titleArray[section]];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 50.0;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            //账户安全
            [self.navigationController pushViewController:[[SafeCenterController alloc]init] animated:YES];
        }else{
           //身份认证

            if ([[UserWrapper shareUserInfo].kycStatus intValue]==4||[[UserWrapper shareUserInfo].kycStatus intValue]==7) {
                //未提交或者审核拒绝
                HolderInfoController*identityVC=[[HolderInfoController alloc]init];
                identityVC.type=0;
                [self.navigationController pushViewController:identityVC animated:YES];
            }else{
                //审核中或者审核通过
                IdentityInreviewController*identityVC=[[IdentityInreviewController alloc]init];
                [self.navigationController pushViewController:identityVC animated:YES];
            }
            
        }
        
    }else{
        if (indexPath.row==0) {
           //通知中心
            [self.navigationController pushViewController:[[NotificationCenterController alloc]init] animated:YES];
        } else if (indexPath.row==1) {
            //语言
            [self.navigationController pushViewController:[[LanguageController alloc]init] animated:YES];
        }else{
            //版本
        }
   
    }
   
}

//获取个人信息
-(void)getMemberInfo{
    //[SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getMemberInfosuccess:^(id  _Nonnull data) {
       // [SVProgressHUD dismiss];
        
        if ([data[@"code"] intValue]==200) {
            [UserWrapper shareUserInfo].kycStatus=data[@"data"][@"kycStatus"];
           
            [UserWrapper shareUserInfo].googleStatus=data[@"data"][@"googleStatus"];
            [UserWrapper shareUserInfo].distributorStatus=data[@"data"][@"distributorStatus"];
            [UserWrapper shareUserInfo].isPayPassword=data[@"data"][@"isPayPassword"];
            [UserWrapper saveUser:[UserWrapper shareUserInfo]];
            self.mineView.nameLabel.text=[UserWrapper shareUserInfo].realName;
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];//刷新实名认证状态
           
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
       // [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 60;
}

//获取消息
-(void)getNotificationMessages{
    
    NSMutableDictionary*dic=[@{@"pageIndex":@(1),@"pageSize":@(1)} mutableCopy];
    [MineNetWorkManager getNotificationCenterWithParams:dic success:^(id  _Nonnull data) {
      
        if ([data[@"code"] intValue]==200) {
            NSArray*dataArray=data[@"data"][@"records"];
            if (dataArray.count>0) {
                NSDictionary*dic=[dataArray firstObject];
                if ([dic[@"authStatus"] intValue]==0) {
                    //有未读消息
                    self->_haveNotification=YES;
                }else{
                    self->_haveNotification=NO;
                }
            }else{
                self->_haveNotification=NO;
            }
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:1];
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        }
        else{
          
            }
      
        } fail:^(NSError * _Nonnull error) {
          
   }];
    
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}


- (void)setupNavigationBarTheme {
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground]; // 配置不透明背景
        appearance.backgroundColor = [UIColor whiteColor]; // 设置背景颜色
        appearance.shadowColor = [UIColor clearColor]; // 去掉黑线
        // 设置普通标题属性
        NSDictionary *titleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:18]
        };
        appearance.titleTextAttributes = titleTextAttributes;

        // 设置大标题属性
        NSDictionary *largeTitleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:29]
        };//系统默认的大标题（Large Title）的字体大小为 34 points
        appearance.largeTitleTextAttributes = largeTitleTextAttributes;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // iOS 13 以下版本，使用 shadowImage 方式去掉黑线
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
