//
//  LanguageController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/29.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "LanguageController.h"
#import "LanguageCell.h"
#import "CustomTabBarController.h"

@interface LanguageController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSInteger _currentIndex;
}

@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong) NSArray*contentArray;
@property(nonatomic,strong) NSArray*languageIDArray;
@end

@implementation LanguageController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"语言");
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self setUpUI];
        
    });
   
    self.contentArray=@[LocalizationKey(@"简体中文"),LocalizationKey(@"English")];
    self.languageIDArray=@[@"zh-Hans",@"en"];
   
    [self.languageIDArray enumerateObjectsUsingBlock:^(NSString* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isEqualToString:[ChangeLanguage userLanguage]]) {
            _currentIndex=idx;
            *stop=YES;
        }
    }];
    [self.tableView reloadData];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeAlways;
}

-(void)setUpUI{
    
    self.tableView =[[UITableView alloc] initWithFrame:self.view.bounds];
    self.tableView.backgroundColor=[UIColor whiteColor];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 20)];
    self.tableView.tableHeaderView=headView;
    [self.view addSubview:self.tableView];
    [self.tableView registerNib:[UINib nibWithNibName:@"LanguageCell" bundle:nil] forCellReuseIdentifier:@"LanguageCell"];
    self.tableView.rowHeight=56;
    self.tableView.tableFooterView=[UIView new];
}
#pragma mark --UITableViewDataSoure
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  
    static NSString *TableSampleIdentifier = @"LanguageCell";
    LanguageCell *cell = [tableView dequeueReusableCellWithIdentifier:TableSampleIdentifier];
    cell.nameLabel.text=self.contentArray[indexPath.row];
    cell.dotView.hidden=indexPath.row == _currentIndex?NO:YES;
    cell.iconImageV.image=indexPath.row==0?UIIMAGE(@"china_icon"):UIIMAGE(@"english_icon");
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_currentIndex==indexPath.row) {
        return;
    }
    NSString*languageStr=self.languageIDArray[indexPath.row];
    [ChangeLanguage setUserlanguage:languageStr];
    _currentIndex = indexPath.row;
    [self.tableView reloadData];
 
    //[SVProgressHUD showWithStatus:LocalizationKey(@"切换中...") ];
    [SVProgressHUD customShowWithStyle];
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self initRootViewController];//简单粗暴
       
    });
   
}


-(void)initRootViewController{

    CustomTabBarController *tabbar = [[CustomTabBarController alloc] init];
    APPLICATION.window.rootViewController = tabbar;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
