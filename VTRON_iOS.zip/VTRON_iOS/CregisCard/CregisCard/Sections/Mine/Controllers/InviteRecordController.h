//
//  InviteRecordController.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface InviteRecordController : BaseViewController

@end

NS_ASSUME_NONNULL_END
