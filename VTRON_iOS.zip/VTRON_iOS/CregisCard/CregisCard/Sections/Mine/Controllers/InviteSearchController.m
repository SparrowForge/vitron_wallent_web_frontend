//
//  InviteSearchController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/11.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "InviteSearchController.h"
#import "UserDetailController.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "InviteCell.h"
#import "MineNetWorkManager.h"
#import "NSObject+UBTrackerModel.h"
#import "OrderSearchView.h"
#import "MineNetWorkManager.h"

@interface InviteSearchController ()
{
    int _pageNO;
    NSString* _userName;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) OrderSearchView*searchView;
@property(nonatomic,strong) NSMutableArray*contentArray;
@end

@implementation InviteSearchController

-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _pageNO=1;
    [self rightBarItemWithTitle:LocalizationKey(@"取消") color:[UIColor baseColor]];
    [self setTableViewConfig];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode =  UINavigationItemLargeTitleDisplayModeNever;
}

-(void)rightTouchEvent{
    [self.navigationController popViewControllerAnimated:NO];
}

-(void)setTableViewConfig{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"InviteCell" bundle:nil] forCellReuseIdentifier:@"InviteCell"];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    UIView*titleView=[[UIView alloc]initWithFrame:CGRectMake(0, 0,kWindowW, 65)];
    self.searchView=[OrderSearchView instanceViewWithFrame:titleView.bounds];
    self.searchView.topDistance.constant=0;
    self.searchView.bottomDistance.constant=0;
    self.searchView.inputTF.tintColor=[UIColor blackColor];
    WEAKSELF
    self.searchView.searchblock = ^(NSString * _Nullable text) {
        [weakSelf searchSingleOrderWithUsername:text];
    };
    self.searchView.inputTF.placeholder=LocalizationKey(@"请输入客户ID、邮箱");
    [self.searchView.inputTF becomeFirstResponder];
    [titleView addSubview:self.searchView];

    self.navigationItem.titleView=titleView;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.rowHeight=130;
    self.tableView.backgroundColor=[UIColor whiteColor];
    [self headRefreshWithScrollerView:self.tableView];
    [self footRefreshWithScrollerView:self.tableView];
    LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"nosearchRecords" titleStr:LocalizationKey(@"未查询到客户信息")];
    emptyView.titleLabTextColor = [UIColor lightGrayColor];
    self.tableView.ly_emptyView = emptyView;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    InviteCell*cell=[tableView dequeueReusableCellWithIdentifier:@"InviteCell"];
    cell.model=self.contentArray[indexPath.row];

    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UserDetailController*userVC=[[UserDetailController alloc]init];
    userVC.inviteModel=self.contentArray[indexPath.row];
    [self.navigationController pushViewController:userVC animated:YES];
    
}
//搜索单个订单记录
-(void)searchSingleOrderWithUsername:(NSString*)username{
    _userName=username;
    [self getInviteRecordsWithUsername:username];
}
//MARK: 上拉加载更多
- (void)refreshFooterAction{
    _pageNO+=1;
    [self getInviteRecordsWithUsername:_userName];
}
//MARK: 下拉刷新
- (void)refreshHeaderAction{
    _pageNO=1;
    [self.tableView.mj_footer resetNoMoreData];
    [self getInviteRecordsWithUsername:_userName];
}
//获取邀请记录
-(void)getInviteRecordsWithUsername:(NSString*)username{
    if ([NSString stringIsNull:username]) {
        return;
    }
    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10),@"email":username} mutableCopy];
    
    [MineNetWorkManager getInvitedRecordsWithParams:dic success:^(id  _Nonnull data) {
        if ([data[@"code"] intValue]==200) {
            
                 if(self->_pageNO==1){
                     [self.contentArray removeAllObjects];
                 }
                 NSArray*onceArray=[InviteModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
                 if(onceArray.count>0){
                     [self.contentArray addObjectsFromArray:onceArray];
                 }
                 [self.tableView reloadData];
                 if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                     [self.tableView.mj_footer endRefreshingWithNoMoreData];
                 }
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
            
        } fail:^(NSError * _Nonnull error) {
            
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
