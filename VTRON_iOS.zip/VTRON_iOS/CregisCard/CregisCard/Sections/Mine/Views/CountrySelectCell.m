//
//  CountrySelectCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CountrySelectCell.h"

@implementation CountrySelectCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.backView setCornerRadius:16];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configUIWithMenuType:(SelectMenuType)menuType withIndexPath:(NSIndexPath*)indexPath{
    if (menuType==SelectLanguage) {
        //切换语言
        self.iconWidth.constant=25;
        self.leadDistance.constant=15;
        if (indexPath.row==0) {
            self.iconImageV.image=UIIMAGE(@"china_icon");
        }else{
            self.iconImageV.image=UIIMAGE(@"english_icon");
        }
        
    }else if(menuType==SelectNotes){
        //切换节点
        self.iconWidth.constant=25;
        self.leadDistance.constant=15;
        if (indexPath.row==0) {
            self.iconImageV.image=UIIMAGE(@"note_global");
        }else{
            self.iconImageV.image=UIIMAGE(@"note_dubai");
        }
        
    }
    else{
        self.iconWidth.constant=0;
        self.leadDistance.constant=0;

    }
    
}
@end
