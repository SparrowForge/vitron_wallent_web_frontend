//
//  VersionUpdateView.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "VersionUpdateView.h"

@implementation VersionUpdateView

+ (VersionUpdateView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"VersionUpdateView" owner:nil options:nil];
    VersionUpdateView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
//    property.popupAlignment = FWPopupAlignmentCenter;
//    property.popupAnimationStyle = FWPopupAnimationStyleScale3D;
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.4];
    view.vProperty = property;
    [view.boardView setCornerRadius:20];
    [view.updateBtn setTitle:LocalizationKey(@"立即更新") forState:UIControlStateNormal];
    view.updateBtn.titleLabel.font=PingFangMediumFont(15);
    view.titleLabel.text=LocalizationKey(@"发现新版本");
    [view.updateBtn dn_addActionHandler:^{
    //更新
    [view checkVersionActionWithURLString:view.dic[@"url"]];
    }];
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        CGFloat imageWidth=kWindowW-(26+25)*2;
        CGFloat imageHeight=imageWidth*588/536.0;
        self.topDistance.constant=imageHeight-100;
        
    });
   
}
-(void)setDic:(NSDictionary *)dic{
    _dic=dic;
    if(![NSString stringIsNull:dic[@"updateContent"]]){
        self.contentLabel.text=dic[@"updateContent"];
    }
    self.versionLabel.text=[NSString stringWithFormat:@"%@ V%@",LocalizationKey(@"版本号"),dic[@"version"]];
}

//跳转到Appstore
-(void)checkVersionActionWithURLString:(NSString*)urling{
   // urling= [urling stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];//去掉首尾空格
    NSURL *url = [NSURL URLWithString:[urling stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]];
    if([[UIDevice currentDevice].systemVersion floatValue] >= 10.0){
        if ([[UIApplication sharedApplication] respondsToSelector:@selector(openURL:options:completionHandler:)]) {
            if (@available(iOS 10.0, *)) {
                [[UIApplication sharedApplication] openURL:url options:@{}
                                         completionHandler:^(BOOL success) {
                    NSLog(@"Open %d",success);
                }];
            } else {
                
            }
        } else {
            if (@available(iOS 10.0, *)) {
                [[UIApplication sharedApplication] openURL:url options:@{}
                                         completionHandler:^(BOOL success) {
                    NSLog(@"Open %d",success);
                }];
            } else {
                // Fallback on earlier versions
            }
        }
    }
    
}



@end
