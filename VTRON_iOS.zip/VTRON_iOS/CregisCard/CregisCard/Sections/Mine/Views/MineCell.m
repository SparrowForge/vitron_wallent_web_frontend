//
//  MineCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "MineCell.h"

@implementation MineCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.nameLabel.font=PingFangMediumFont(17);
    self.dotView.hidden=YES;
    // Initialization code
}
-(void)configDataWithIconImage:(NSArray*)imageNameArray withName:(NSArray*)nameArray AtIndexPath:(NSIndexPath *)indexPath withHaveNotification:(BOOL)haveNotification{
    NSArray*imageStringArray=imageNameArray[indexPath.section];
    NSArray*nameStringArray=nameArray[indexPath.section];
    self.IconImageV.image=UIIMAGE(imageStringArray[indexPath.row]);
    self.nameLabel.text=nameStringArray[indexPath.row];
    self.statusView.hidden=((indexPath.section==0 &&indexPath.row==1)||(indexPath.section==1 &&indexPath.row==2))?NO:YES;
//    if ((indexPath.section==0 &&indexPath.row==1)) {
//        //认证状态
//        if ([[UserWrapper shareUserInfo].kycStatus intValue]==5) {
//            self.statusView.hidden=YES;//已认证时隐藏
//        }
//    }
    
    if (indexPath.section==0 &&indexPath.row==1) {
        self.tipsLabel.text=[self getIDStatus];
        self.statusView.backgroundColor=[self getIDViewColor];
        self.tipsLabel.textColor=[self getIDTextColor];
    }
    if (indexPath.section==1 &&indexPath.row==2) {
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
        self.tipsLabel.text=[NSString stringWithFormat:@"V %@",app_Version];
        self.tipsLabel.textColor=[UIColor lightGrayColor];
        self.statusView.backgroundColor=[UIColor clearColor];
    }
    self.trailDistance.constant=(indexPath.section==1&&indexPath.row==2)?-7:10;
    self.rowIcon.hidden=(indexPath.section==1 &&indexPath.row==2)?YES:NO;
    if (indexPath.section==1&&indexPath.row==0) {
        //通知中心红点
        self.dotView.hidden=haveNotification?NO:YES;
    }else{
        self.dotView.hidden=YES;
    }
    
}

-(NSString*)getIDStatus{
    switch ([[UserWrapper shareUserInfo].kycStatus intValue]) {
        case 0:
            return LocalizationKey(@"审核中");
            break;
        case 1:
            return LocalizationKey(@"后台审核完成");
            break;
        case 2:
            return LocalizationKey(@"待用户人脸识别");
            break;
        case 3:
            return LocalizationKey(@"待 ipeakoin审核");
            break;
        case 4:
            return LocalizationKey(@"未通过");
            break;
        case 5:
            return LocalizationKey(@"已认证");
            break;
       
        case 7:
            return LocalizationKey(@"未认证");
            break;
        default:
            return LocalizationKey(@"未知");
            break;
    }
    
}

-(UIColor*)getIDTextColor{
    switch ([[UserWrapper shareUserInfo].kycStatus intValue]) {
        case 0://审核中
            return  [UIColor colorWithHexString:@"#FA6400" alpha:1.0];
            break;
        case 1://后台审核完成
            return [UIColor baseColor];
            break;
        case 2://待用户人脸识别
            return [UIColor baseColor];
            break;
        case 3://待 ipeakoin审核
            return [UIColor baseColor];
            break;
        case 4://未通过
            return [UIColor colorWithHexString:@"#EC312C" alpha:1.0];
            break;
        case 5://已认证
            return [UIColor colorWithHexString:@"#6DD400" alpha:1.0];
            break;
       
        case 7://未认证
            return [UIColor colorWithHexString:@"#F7B500" alpha:1.0];
            break;
        default:
            return [UIColor alertColor];
            break;
    }
    
}

-(UIColor*)getIDViewColor{
    switch ([[UserWrapper shareUserInfo].kycStatus intValue]) {
        case 0://审核中
            return  [UIColor colorWithHexString:@"#FA6400" alpha:0.04];
            break;
        case 1://后台审核完成
            return [UIColor baseColor];
            break;
        case 2://待用户人脸识别
            return [UIColor baseColor];
            break;
        case 3://待 ipeakoin审核
            return [UIColor baseColor];
            break;
        case 4://未通过
            return [UIColor colorWithHexString:@"#EC312C" alpha:0.04];
            break;
        case 5://已认证
            return [[UIColor colorWithHexString:@"#6DD400" alpha:1.0] colorWithAlphaComponent:0.1];
            break;
       
        case 7://未认证
            return [UIColor colorWithHexString:@"#F7B500" alpha:0.1];
            break;
        default:
            return [UIColor alertColor];
            break;
    }
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
