//
//  InviteCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "InviteCell.h"

@implementation InviteCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentView.backgroundColor=[UIColor whiteColor];
    [self.boardView setCornerRadius:10];
    //四边添加阴影
    self.boardView.layer.shadowColor = [UIColor grayColor].CGColor;//阴影颜色
    self.boardView.layer.shadowOffset = CGSizeMake(0, 0);//阴影的偏移量
    self.boardView.layer.shadowOpacity = 0.2;//阴影透明度
    self.boardView.layer.shadowRadius = 10.0;//阴影圆角
    self.boardView.clipsToBounds=NO;//这个属性为NO是必须的，不然阴影不会显示
    [self.headImageV setCornerRadius:25];
    self.nameLabel.font=PingFangMediumFont(19);
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setModel:(InviteModel *)model{
    _model=model;
    self.nameLabel.text=model.email;
    self.IDLabel.text=model.merchantId;
    [self.headImageV UBTracker_yy_setImageWithURL:[NSURL URLWithString:[model.headUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]] placeholder:UIIMAGE(@"noImage")];
    
}


@end
