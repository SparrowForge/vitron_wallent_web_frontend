//
//  InviteDetailView.m
//  CregisCard
//
//  Created by 孙良 on 2024/11/4.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "InviteDetailView.h"

@implementation InviteDetailView

+ (InviteDetailView *)instanceViewWithFrame:(CGRect)Rect{
    
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"InviteDetailView" owner:nil options:nil];
    InviteDetailView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;

    return view;
    
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(30, 30)];
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.inviteCodeTitle.text=LocalizationKey(@"邀请码");
    self.inviteLinkTitle.text=LocalizationKey(@"邀请链接");
}
-(void)configUIWithDic:(NSDictionary*)dataDic{
    
    self.inviteCodeLabel.text=dataDic[@"merchantDistributorInviteVo"][@"inviteCode"];
    self.inviteLinkLabel.text=dataDic[@"merchantDistributorInviteVo"][@"inviteUrl"];
    
}

- (IBAction)copyClick:(UIButton *)sender {
    if(sender.tag==1){
        //复制邀请码
        if (![NSString stringIsNull:self.inviteCodeLabel.text]) {
            UIPasteboard *pboard = [UIPasteboard generalPasteboard];
            pboard.string = self.inviteCodeLabel.text;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
          
        }
    }else{
        //复制链接
        if (![NSString stringIsNull:self.inviteLinkLabel.text]) {
            UIPasteboard *pboard = [UIPasteboard generalPasteboard];
            pboard.string = self.inviteLinkLabel.text;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
          
        }
    }
    
}

@end
