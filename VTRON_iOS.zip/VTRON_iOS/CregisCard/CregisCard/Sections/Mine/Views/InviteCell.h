//
//  InviteCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "InviteModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface InviteCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;

@property (weak, nonatomic) IBOutlet UILabel *IDLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headImageV;
@property(nonatomic,strong)InviteModel*model;

@end

NS_ASSUME_NONNULL_END
