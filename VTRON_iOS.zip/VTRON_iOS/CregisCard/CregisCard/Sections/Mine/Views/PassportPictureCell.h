//
//  PassportPictureCell.h
//  CregisCard
//
//  Created by sunliang on 2025/11/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
typedef void(^IdentityPassPortImage)(NSString* _Nullable identityType,NSDictionary* _Nullable imageDic);
NS_ASSUME_NONNULL_BEGIN

@interface PassportPictureCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardLabel1;
@property (weak, nonatomic) IBOutlet UILabel *cardLabel2;
@property (weak, nonatomic) IBOutlet UIView *frontalView;
@property (weak, nonatomic) IBOutlet UIView *handView;
@property (nonatomic, copy) IdentityPassPortImage identityImage;
-(void)configImageWithidFrontUrl:(NSString*)idFrontUrl withidBackUrl:(NSString*)idBackUrl withidHoldUrl:(NSString*)idHoldUrl;
@end

NS_ASSUME_NONNULL_END
