//
//  CardPictureCell.m
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CardPictureCell.h"
#import "CameraManager.h"
#import "MineNetWorkManager.h"
#import "UIButton+UBTracker_YYWebImage.h"


@interface CardPictureCell ()<CameraManagerDelegate>

{
    int _currentPhotosIndex;
}
@property (weak, nonatomic) IBOutlet UIButton *cardBtn1;//正面
@property (weak, nonatomic) IBOutlet UIButton *cardBtn2;//反面
@property (weak, nonatomic) IBOutlet UIButton *cardBtn3;//手持


@end
@implementation CardPictureCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.tipsLabel.text=LocalizationKey(@"2M以内JPG，PNG格式");
    self.cardLabel1.text=LocalizationKey(@"正面");
    self.cardLabel2.text=LocalizationKey(@"反面");
    self.cardLabel3.text=LocalizationKey(@"手持");
    [CameraManager shareInstance].delegate=self;

    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self addDashedBorderToView:self.frontalView];
        [self addDashedBorderToView:self.reverseView];
        [self addDashedBorderToView:self.handView];
        
    });
   
 
    // Initialization code
}


//上传图片
- (IBAction)btnClick:(UIButton *)sender {
    
    _currentPhotosIndex=(int)sender.tag;
    [[CameraManager shareInstance] openCameraOrPhotoLibraryWithCameraDeviceType:@"Behind" AndController:[UBTrackerFindController findCurrentShowingViewController]];

    
}
/** 事件回调*/
- (void)cameraCallBack:(UIImage *)image{
    
    UIButton*currentButton=_currentPhotosIndex==0?self.cardBtn1:(_currentPhotosIndex==1?self.cardBtn2:self.cardBtn3);
    
    NSString*imageType=_currentPhotosIndex==0?@"idFrontId":(_currentPhotosIndex==1?@"idBackId":@"idHoldId");
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager uplodFileWithData:[self imageZipToData:image]  success:^(NSData * _Nonnull successData) {
        [SVProgressHUD dismiss];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:successData options:NSJSONReadingMutableContainers error:nil];
        if ([dic[@"code"] intValue]==200) {
            [currentButton setBackgroundImage:image forState:UIControlStateNormal];
            NSDictionary*imageDic=dic[@"data"];
            if (self.identityImage) {
                self.identityImage(imageType, imageDic);
            }
            
        }else{
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,dic[@"msg"]);
        
        }
    } error:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
      //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

-(void)configImageWithidFrontUrl:(NSString*)idFrontUrl withidBackUrl:(NSString*)idBackUrl withidHoldUrl:(NSString*)idHoldUrl{
    
    if (![NSString stringIsNull:idFrontUrl]) {
        [self.cardBtn1 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:idFrontUrl] forState:UIControlStateNormal options:UBTracker_YYWebImageOptionShowNetworkActivity];
    
    }
    
    if (![NSString stringIsNull:idBackUrl]) {
        [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:idBackUrl] forState:UIControlStateNormal options:UBTracker_YYWebImageOptionShowNetworkActivity];
    }
    
    if (![NSString stringIsNull:idHoldUrl]) {
        [self.cardBtn3 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:idHoldUrl] forState:UIControlStateNormal options:UBTracker_YYWebImageOptionShowNetworkActivity];
    }
    
    
}
/**
 *  压缩图片
 */
-(NSData *)imageZipToData:(UIImage *)newImage{
    
    NSData *data = UIImageJPEGRepresentation(newImage, 1.0);
    
    if (data.length > 500 * 1024) {
        
        if (data.length>1024 * 1024) {//1M以及以上
            
            data = UIImageJPEGRepresentation(newImage, 0.5);
            
        }else if (data.length>512*1024) {//0.5M-1M
            
            data=UIImageJPEGRepresentation(newImage, 0.6);
            
        }else if (data.length>200*1024) { //0.25M-0.5M
            
            data=UIImageJPEGRepresentation(newImage, 0.9);
        }
    }
    return data;
}
- (void)addDashedBorderToView:(UIView *)view {
    // 创建虚线图层
    CAShapeLayer *dashedBorder = [CAShapeLayer layer];
    dashedBorder.strokeColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.3].CGColor; // 虚线颜色
    dashedBorder.fillColor = nil;
    dashedBorder.lineDashPattern = @[@4, @2]; // 虚线样式：[实线长度, 间隙长度]
    dashedBorder.lineWidth = 1.0; // 虚线宽度
    dashedBorder.frame = view.bounds;
    dashedBorder.path = [UIBezierPath bezierPathWithRect:view.bounds].CGPath;
    
    [view.layer addSublayer:dashedBorder];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


/**
 * 通过 CAShapeLayer 方式绘制虚线
 *
 * param lineView: 需要绘制成虚线的view
 * param lineLength: 虚线的宽度
 * param lineSpacing: 虚线的间距
 * param lineColor: 虚线的颜色
 * param lineDirection 虚线的方向 YES 为水平方向， NO 为垂直方向
 **/
- (void)drawLineOfDashByCAShapeLayer:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor lineDirection:(BOOL)isHorizonal {

    CAShapeLayer *shapeLayer = [CAShapeLayer layer];

    [shapeLayer setBounds:lineView.bounds];

    if (isHorizonal) {

        [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame))];

    } else{
        [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame)/2)];
    }

    [shapeLayer setFillColor:[UIColor clearColor].CGColor];
    // 设置虚线颜色为blackColor
    [shapeLayer setStrokeColor:lineColor.CGColor];
    // 设置虚线宽度
    if (isHorizonal) {
        [shapeLayer setLineWidth:CGRectGetHeight(lineView.frame)];
    } else {

        [shapeLayer setLineWidth:CGRectGetWidth(lineView.frame)];
    }
    [shapeLayer setLineJoin:kCALineJoinRound];
    // 设置线宽，线间距
    [shapeLayer setLineDashPattern:[NSArray arrayWithObjects:[NSNumber numberWithInt:lineLength], [NSNumber numberWithInt:lineSpacing], nil]];
    // 设置路径
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 0, 0);

    if (isHorizonal) {
        CGPathAddLineToPoint(path, NULL,CGRectGetWidth(lineView.frame), 0);
    } else {
        CGPathAddLineToPoint(path, NULL, 0, CGRectGetHeight(lineView.frame));
    }

    [shapeLayer setPath:path];
    CGPathRelease(path);
    // 把绘制好的虚线添加上来
    [lineView.layer addSublayer:shapeLayer];
}

@end
