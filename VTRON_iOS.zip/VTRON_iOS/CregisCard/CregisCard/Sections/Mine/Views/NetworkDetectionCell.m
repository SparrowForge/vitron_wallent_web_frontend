//
//  NetworkDetectionCell.m
//  CregisCard
//
//  Created by sunliang on 2025/5/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "NetworkDetectionCell.h"

@implementation NetworkDetectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.nameLabel.font=PingFangMediumFont(17);
    self.detailLabel.font=PingFangMediumFont(15);
    self.delayLabel.font=PingFangMediumFont(15);

    // Initialization code
}

-(void)configModel:(DetectionModel*)model withIdexPath:(NSIndexPath*)indexPath{
   
    if (indexPath.row==3||indexPath.row==4) {
      int
        width=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?140:90;
        self.widthConst.constant=width;
        
    }else{
        
    }
    self.iconImageV.image=UIIMAGE(model.iconName);
    self.nameLabel.text=model.name;
    self.detailLabel.text=model.detail;
    self.delayLabel.text=model.delayTime;
    if ([model.delayTime intValue]<=100) {
        self.delayLabel.textColor=[UIColor colorWithHexString:@"#6DD400" alpha:1.0];
    }else{
        self.delayLabel.textColor=[UIColor colorWithHexString:@"#F7B500" alpha:1.0];
    }
    if (model.iconStatus==0) {
        //还未开始检测
        self.statusImageV.hidden=YES;
        [self.indicator stopAnimating];
        self.indicator.hidden=YES;
        
    }else if (model.iconStatus==1){
        //检测中
        self.statusImageV.hidden=YES;
        [self.indicator startAnimating];
        self.indicator.hidden=NO;
        
    }else if (model.iconStatus==2){
        //检测正常
        self.statusImageV.hidden=NO;
        self.statusImageV.image=UIIMAGE(@"netDetection_good");
        [self.indicator stopAnimating];
        self.indicator.hidden=YES;
    }else{
        //检测失败
        self.statusImageV.hidden=NO;
        self.statusImageV.image=UIIMAGE(@"netDetection_poor");
        [self.indicator stopAnimating];
        self.indicator.hidden=YES;
    }
    
    if (model.iconStatus==2&&([model.name isEqualToString:LocalizationKey(@"信号强度")]||[model.name isEqualToString:LocalizationKey(@"主服务器")])) {
        self.detailLabel.hidden=NO;
        self.delayLabel.hidden=NO;
        self.statusImageV.hidden=YES;

    }else{
        self.detailLabel.hidden=YES;
        self.delayLabel.hidden=YES;
      
       
    
    }
    
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
