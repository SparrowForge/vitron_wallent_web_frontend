//
//  NotesDetectionView.m
//  CregisCard
//
//  Created by sunliang on 2025/5/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "NotesDetectionView.h"

@implementation NotesDetectionView

+ (NotesDetectionView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"NotesDetectionView" owner:nil options:nil];
    NotesDetectionView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.noteNameLabel.font=PingFangMediumFont(17);
    view.noteNameLabel.text=[[UBTNSUserDefaultUtil GetDefaults:NOTE_EXCLUSIVE] intValue]==1?LocalizationKey(@"迪拜节点"):LocalizationKey(@"全球节点");
    NSString*iamgeName=[[UBTNSUserDefaultUtil GetDefaults:NOTE_EXCLUSIVE] intValue]==1?@"note_dubai":@"note_global";
    view.noteIcon.image=UIIMAGE(iamgeName);
    return view;
}

@end
