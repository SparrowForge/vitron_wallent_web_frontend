//
//  CountrySelectCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "SelectMenuView.h"
NS_ASSUME_NONNULL_BEGIN

@interface CountrySelectCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *countryNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *selectedIcon;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageV;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *iconWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leadDistance;
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *frontDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *behindDistance;

-(void)configUIWithMenuType:(SelectMenuType)menuType withIndexPath:(NSIndexPath*)indexPath;
@end

NS_ASSUME_NONNULL_END
