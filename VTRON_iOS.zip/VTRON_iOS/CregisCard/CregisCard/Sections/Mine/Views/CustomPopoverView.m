#import "CustomPopoverView.h"

@interface CustomPopoverView ()
@property (nonatomic, strong) UIView *overlayView; // 黑色遮罩
@property (nonatomic, strong) UIView *contentView; // 提示框内容视图
@end

@implementation CustomPopoverView

static CustomPopoverView *currentPopover;

+ (void)showWithContentView:(UIView *)contentView
                 relativeTo:(UIView *)button
                    inView:(UIView *)inView {
    // 如果已经有弹出框，先隐藏
    if (currentPopover) {
        [self hide];
    }
    
    // 获取主窗口（覆盖全屏）
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    if (!keyWindow) return;
    
    // 创建 CustomPopoverView
    CustomPopoverView *popover = [[CustomPopoverView alloc] initWithFrame:keyWindow.bounds];
    popover.backgroundColor = [UIColor clearColor];
    
    // 添加遮罩
    UIView *overlay = [[UIView alloc] initWithFrame:popover.bounds];
    overlay.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    overlay.userInteractionEnabled = YES;
    [overlay addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hide)]];
    [popover addSubview:overlay];
    popover.overlayView = overlay;
    
    // 配置并添加内容视图
    CGFloat maxWidth = CGRectGetWidth(keyWindow.bounds) - 40; // 距屏幕左右各20像素
    contentView.frame = CGRectMake(0, 0, maxWidth, CGRectGetHeight(contentView.bounds));
    contentView.layer.cornerRadius = 24;
    contentView.layer.masksToBounds = YES;
    contentView.backgroundColor = [UIColor whiteColor];
    [popover addSubview:contentView];
    popover.contentView = contentView;
    // 添加到主窗口
    [keyWindow addSubview:popover];
    currentPopover = popover;
    
    // 计算提示框位置
    CGRect buttonFrame = [button.superview convertRect:button.frame toView:keyWindow];
    CGFloat contentHeight = CGRectGetHeight(contentView.bounds);
    CGFloat space = 20; // 距离按钮的间距
    
    CGFloat contentX = 20; // 固定左右间距20像素
    CGFloat buttonTopSpace = CGRectGetMinY(buttonFrame); // 按钮到屏幕顶部的距离
    CGFloat buttonBottomSpace = CGRectGetHeight(keyWindow.bounds) - CGRectGetMaxY(buttonFrame); // 按钮到屏幕底部的距离
    CGFloat contentY;
    
    if (contentHeight + space < buttonBottomSpace) {
        // 在按钮下方
        contentY = CGRectGetMaxY(buttonFrame) + space;
    } else if (contentHeight + space < buttonTopSpace) {
        // 在按钮上方
        contentY = CGRectGetMinY(buttonFrame) - space - contentHeight;
    } else {
        // 居中显示
        contentY = (CGRectGetHeight(keyWindow.bounds) - contentHeight) / 2;
    }
    
    contentView.frame = CGRectMake(contentX, contentY, maxWidth, contentHeight);
    
    // 初始化位置（稍微缩小并透明）
    contentView.transform = CGAffineTransformMakeScale(0.5, 0.5);
    contentView.alpha = 0;

    // 添加弹簧动画
    [UIView animateWithDuration:0.4
                          delay:0
         usingSpringWithDamping:0.7
          initialSpringVelocity:1
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         contentView.transform = CGAffineTransformIdentity; // 恢复正常大小
                         contentView.alpha = 1; // 变为不透明
                     } completion:nil];
}

+ (void)hide {
    if (currentPopover) {
        [UIView animateWithDuration:0.25 animations:^{
            currentPopover.alpha = 0;
        } completion:^(BOOL finished) {
            [currentPopover removeFromSuperview];
            currentPopover = nil;
        }];
    }
}


@end
