//
//  AllNameCell.h
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

typedef void(^IdentityNameBlock)(NSString* _Nullable typeString,NSString* _Nullable valueString);
typedef void(^IdentityNameEndBlock)(NSString* _Nullable typeString,NSString* _Nullable valueString);
NS_ASSUME_NONNULL_BEGIN

@interface AllNameCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *firstView;
@property (weak, nonatomic) IBOutlet UIView *lastView;
@property (weak, nonatomic) IBOutlet UITextField *firstNameTF;
@property (weak, nonatomic) IBOutlet UITextField *lastNameTF;
@property (nonatomic, copy)   IdentityNameBlock nameBlock;
@property (nonatomic, copy)   IdentityNameEndBlock nameEndBlock;

@end

NS_ASSUME_NONNULL_END
