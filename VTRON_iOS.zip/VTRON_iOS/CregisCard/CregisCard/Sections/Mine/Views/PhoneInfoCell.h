//
//  PhoneInfoCell.h
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "CountryModel.h"
typedef void(^PhoneAreaBlock)(NSString* _Nullable typeString,CountryModel*_Nullable areaModel);
typedef void(^EndBlock)(void);
typedef void(^PhoneNumBlock)(NSString* _Nullable typeString,NSString*_Nullable phoneNum);
typedef void(^EndBlock)(void);
NS_ASSUME_NONNULL_BEGIN

@interface PhoneInfoCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *areaView;
@property (weak, nonatomic) IBOutlet UIView *phoneView;
@property (nonatomic, copy)   PhoneAreaBlock phoneAreablock;
@property (nonatomic, copy)   PhoneNumBlock  phoneNumBlock;

@property (nonatomic, copy)   EndBlock   endblock;
-(void)configDataWithAreaCode:(CountryModel*)areaModel withPhone:(NSString*)phoneNum;
@end

NS_ASSUME_NONNULL_END
