//
//  NotificationCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/14.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "NotificationModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface NotificationCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *kindLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardTitle;
@property (weak, nonatomic) IBOutlet UILabel *amountTitle;
@property (weak, nonatomic) IBOutlet UILabel *timeTitle;
@property (weak, nonatomic) IBOutlet UILabel *cardNoLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *timelLabel;
@property (weak, nonatomic) IBOutlet UIButton *pasterBtn;

-(void)configStyleWithType:(int)type;
@property(nonatomic,strong)NotificationModel*model;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *top1Distance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *top2Distance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *height1Distance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *height2Distance;



@end

NS_ASSUME_NONNULL_END
