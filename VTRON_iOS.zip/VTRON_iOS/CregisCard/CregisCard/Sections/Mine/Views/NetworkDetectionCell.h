//
//  NetworkDetectionCell.h
//  CregisCard
//
//  Created by sunliang on 2025/5/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetectionModel.h"
#import "BaseTableViewCell.h"
NS_ASSUME_NONNULL_BEGIN

@interface NetworkDetectionCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImageV;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIImageView *statusImageV;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicator;
@property (weak, nonatomic) IBOutlet UILabel *delayLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *widthConst;


-(void)configModel:(DetectionModel*)model withIdexPath:(NSIndexPath*)path;
@end

NS_ASSUME_NONNULL_END
