//
//  IdentityCardCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "IdentityCardCell.h"
#import "CameraManager.h"
#import "MineNetWorkManager.h"
#import "UIButton+UBTracker_YYWebImage.h"

@interface IdentityCardCell ()<CameraManagerDelegate>
{
    int _currentPhotosIndex;
}
@end
@implementation IdentityCardCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [CameraManager shareInstance].delegate=self;
    self.detailLabel1.text=LocalizationKey(@"点击上传身份证正面");
    self.detailLabel2.text=LocalizationKey(@"点击上传身份证背面");
    self.topDistance.constant=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?0:6;
//    if ([[ChangeLanguage userLanguage] isEqualToString:@"en"]) {
//        self.detailLabel1.textAlignment=NSTextAlignmentLeft;
//        self.detailLabel2.textAlignment=NSTextAlignmentLeft;
//    }
    
}
//-(void)setContentDic:(NSDictionary *)contentDic{
//    _contentDic=contentDic;
//    
//    if ([contentDic[@"type"] isEqualToString:@"id"]) {
//        //身份证认证
//        self.cardBtn1.hidden=NO;
//        self.detailLabel1.hidden=NO;
//        self.detailLabel2.text=LocalizationKey(@"点击上传身份证背面");
//        if (![NSString stringIsNull:contentDic[@"frontImg"]]) {
//            [self.cardBtn1 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:contentDic[@"frontImg"]] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_guohui")];
//        }
//        if (![NSString stringIsNull:contentDic[@"backImg"]]) {
//            [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:contentDic[@"backImg"]] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_head")];
//        }
//    }else{
//        //护照认证
//        self.cardBtn1.hidden=YES;
//        self.detailLabel1.hidden=YES;
//        self.detailLabel2.text=LocalizationKey(@"点击上传护照正面");
//        if (![NSString stringIsNull:contentDic[@"frontImg"]]) {
//            [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:contentDic[@"frontImg"]] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_head")];
//        }
//    }
//    
//}


-(void)setContentDic:(NSDictionary *)contentDic{
    _contentDic=contentDic;
    if (![NSString stringIsNull:contentDic[@"frontImg"]]) {
        [self.cardBtn1 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:contentDic[@"frontImg"]] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_guohui")];
    }
    if ([contentDic[@"type"] isEqualToString:@"id"]) {
        //身份证认证
        self.cardBtn2.hidden=NO;
        self.detailLabel2.hidden=NO;
        self.detailLabel1.text=LocalizationKey(@"点击上传身份证正面");
        if (![NSString stringIsNull:contentDic[@"backImg"]]) {
            [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:contentDic[@"backImg"]] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_head")];
        }
    }else{
        //护照认证
        self.cardBtn2.hidden=YES;
        self.detailLabel2.hidden=YES;
        self.detailLabel1.text=LocalizationKey(@"点击上传护照正面");
    }
    
}




//上传证件
- (IBAction)uploadImageClick:(UIButton *)sender {
    _currentPhotosIndex=(int)sender.tag;
    [[CameraManager shareInstance] openCameraOrPhotoLibraryWithCameraDeviceType:@"Behind" AndController:[UBTrackerFindController findCurrentShowingViewController]];
    
}

/** 事件回调*/
- (void)cameraCallBack:(UIImage *)image{
    UIButton*currentButton=_currentPhotosIndex==0?self.cardBtn1:self.cardBtn2;
    [currentButton setBackgroundImage:image forState:UIControlStateNormal];
    NSString*imageType=_currentPhotosIndex==0?@"frontImg":@"backImg";
    [MineNetWorkManager uplodFileWithData:[self imageZipToData:image]  success:^(NSData * _Nonnull successData) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:successData options:NSJSONReadingMutableContainers error:nil];
        if ([dic[@"code"] intValue]==200) {
            NSString*imageUrl=dic[@"data"];
            if (self.identityImage) {
                self.identityImage(imageType, imageUrl);
            }
            
        }else{
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,dic[@"msg"]);
        
        }
    } error:^(NSError * _Nonnull error) {
      //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//审核中或已认证
-(void)configDataWithfrontImg:(NSString*)frontImg withbackImg:(NSString*)backImg withcardType:(NSString*)type{
    
    self.detailLabel1.hidden=YES;
    self.detailLabel2.hidden=YES;
    self.cardBtn1.userInteractionEnabled=NO;
    self.cardBtn2.userInteractionEnabled=NO;
  
    if ([type isEqualToString:@"id"]) {
        //身份证认证
        self.cardBtn1.hidden=NO;
        if (![NSString stringIsNull:frontImg]) {
            [self.cardBtn1 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:frontImg] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_guohui")];
        }
        if (![NSString stringIsNull:backImg]) {
            [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:backImg] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_head")];
        }
    }else{
        //护照认证
        self.cardBtn1.hidden=YES;
        if (![NSString stringIsNull:frontImg]) {
            [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:frontImg] forState:UIControlStateNormal placeholder:UIIMAGE(@"IDcard_head")];
        }
   
    }
    
    
}

/**
 *  压缩图片
 */
-(NSData *)imageZipToData:(UIImage *)newImage{
    
    NSData *data = UIImageJPEGRepresentation(newImage, 1.0);
    
    if (data.length > 500 * 1024) {
        
        if (data.length>1024 * 1024) {//1M以及以上
            
            data = UIImageJPEGRepresentation(newImage, 0.5);
            
        }else if (data.length>512*1024) {//0.5M-1M
            
            data=UIImageJPEGRepresentation(newImage, 0.6);
            
        }else if (data.length>200*1024) { //0.25M-0.5M
            
            data=UIImageJPEGRepresentation(newImage, 0.9);
        }
    }
    return data;
}
@end
