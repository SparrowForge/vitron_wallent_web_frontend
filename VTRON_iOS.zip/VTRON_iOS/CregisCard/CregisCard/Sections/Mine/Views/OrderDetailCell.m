//
//  OrderDetailCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "OrderDetailCell.h"

@implementation OrderDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.font=RegularFont(15);
    self.detailLabel.font=RegularFont(15);
    self.titleLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.4];
    self.detailBtn.hidden=YES;
    // Initialization code
}


-(void)configDataWithModel:(OrderRecordModel*)orderModel AtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray withType:(int)type{
    [self.detailBtn setBackgroundImage:UIIMAGE(@"feeTips") forState:UIControlStateNormal];
    [self.pasteBtn setBackgroundImage:UIIMAGE(@"copy_gray") forState:UIControlStateNormal];
    self.model=orderModel;
    self.contentArray=contentArray;
    self.pasteBtn.tag=indexPath.row;
    self.titleLabel.textColor=[UIColor colorWithHexString:@"000000" alpha:0.4];
    self.detailLabel.textColor=[UIColor colorWithHexString:@"000000" alpha:1.0];
    self.titleLabel.text=titleArray[indexPath.row];
    self.detailLabel.text=contentArray[indexPath.row];
    
    if (type==0) {
        //钱包流水
        if ([orderModel.type isEqualToString:@"deposit_card"]) {
            //卡片充值
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            
            
        }else if([orderModel.type isEqualToString:@"withdrawal"]){
            //提币
            if ([self.titleLabel.text isEqualToString:LocalizationKey(@"审核结果")]) {
                self.detailLabel.numberOfLines=0;
            }else{
                self.detailLabel.numberOfLines=1;

            }
            
            if (indexPath.row<titleArray.count-3) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                if ([self.detailLabel.text isEqualToString:@"--"]||[NSString stringIsNull:self.detailLabel.text]) {
                    //无内容时候，不显示复制按钮
                    self.pasteBtn.hidden=YES;
                    self.pasteBtnWidth.constant=0;
                    self.trailDistance.constant=18;
                }else{
                    self.pasteBtn.hidden=NO;
                    self.pasteBtnWidth.constant=17;
                    self.trailDistance.constant=24;
                }
              
            }
            
        }else if([orderModel.type isEqualToString:@"program_fee_card"]){
           //卡手续费
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }else if([orderModel.type isEqualToString:@"create_card"]){
            //卡片申请
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }else if([orderModel.type isEqualToString:@"correction"]){
            //卡片冲正
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            
        }
        else if([orderModel.type isEqualToString:@"receive"]){
            //收款
            if (indexPath.row<titleArray.count-2) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            if (indexPath.row==titleArray.count-2) {
                //付款方换行显示
                self.detailLabel.numberOfLines=0;

            }else{
                self.detailLabel.numberOfLines=1;
  
            }
            
        } else if([orderModel.type isEqualToString:@"transfer"]){
            //转账
            if (indexPath.row<titleArray.count-2) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            if (indexPath.row==titleArray.count-2) {
                //收款方换行显示
                self.detailLabel.numberOfLines=0;

            }else{
                self.detailLabel.numberOfLines=1;
  
            }
        
            
        }else if([orderModel.type isEqualToString:@"top_up"]){
            //充值
            if (indexPath.row<titleArray.count-3) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            
        }else if([orderModel.type isEqualToString:@"withdraw_card"]){
            //卡片提现
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            
        }
        else{
            
            
        }
    }else{
       //卡流水
        if ([orderModel.type isEqualToString:@"deposit_card"]) {
            //卡片充值
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            
            
        }else if([orderModel.type isEqualToString:@"fee_card"]){
            //卡费
            if (indexPath.row<titleArray.count-2) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
            
        }else if([orderModel.type isEqualToString:@"verification_card"]){
           //验证
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }else if([orderModel.type isEqualToString:@"refund_card"]){
            //退款
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }else if([orderModel.type isEqualToString:@"program_fee_card"]){
            //消费
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }else if([orderModel.type isEqualToString:@"withdraw_card"]){
            //卡片提现
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }
        else if([orderModel.type isEqualToString:@"reversal_card"]){
            //撤销
            if (indexPath.row<titleArray.count-2) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }else if([orderModel.type isEqualToString:@"atm_fee_card"]){
            //ATM
            if (indexPath.row<titleArray.count-1) {
                self.pasteBtn.hidden=YES;
                self.pasteBtnWidth.constant=0;
                self.trailDistance.constant=18;

            }else{
                self.pasteBtn.hidden=NO;
                self.pasteBtnWidth.constant=17;
                self.trailDistance.constant=24;

            }
        }
        else{
            
            
        }
        
    }
   
    WEAKSELF
    [self.pasteBtn dn_addActionHandler:^{
        [weakSelf copyClick:weakSelf.pasteBtn];
    }];
    
    
}


//复制
-(void)copyClick:(UIButton*)sender{
    
    if ([self.model.type isEqualToString:@"top_up"]||[self.model.type isEqualToString:@"withdrawal"]) {
        //充值和提币的地址和哈希被缩写了，要单独处理
        NSString*copytext=@"--";
        if (sender.tag==self.contentArray.count-1) {
            //交易ID
            copytext=self.model.orderId;
        }else if (sender.tag==self.contentArray.count-2){
            //交易哈希
            copytext=self.model.hashId;
        }else if (sender.tag==self.contentArray.count-3){
            //地址
            copytext=self.model.address;

        }else{
            
            
            
        }
        
        if (![NSString stringIsNull:copytext]) {
            UIPasteboard *pboard = [UIPasteboard generalPasteboard];
            pboard.string = copytext;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
        }
        
        return;
    }
  //转账和收款，复制的是ID
    NSString*copytext=self.detailLabel.text;
    if ([copytext containsString:@"(ID)"]) {
        NSArray * array = [copytext componentsSeparatedByString:@"(ID)"];
        if (array.count>0) {
            copytext= [array firstObject];
            
        }
    }
    
    if (![NSString stringIsNull:copytext]) {
        UIPasteboard *pboard = [UIPasteboard generalPasteboard];
        pboard.string = copytext;
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
    }
    
}











@end
