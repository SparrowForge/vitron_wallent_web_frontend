//
//  IdentityInputCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
typedef void(^IdentityAuthenticationBlock)(NSString* _Nullable typeString,NSString* _Nullable valueString,int indexPathSection);
typedef void(^InputEndEditBlock)(void);
NS_ASSUME_NONNULL_BEGIN

@interface IdentityInputCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UITextField *inputTF;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageV;
@property (weak, nonatomic) IBOutlet UILabel *usdLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *iconWidth;

@property (nonatomic, copy)   IdentityAuthenticationBlock identityAuthenticationBlock;
@property (nonatomic, copy)   InputEndEditBlock endEditBlock;
//实名认证
-(void)configDataAtIndexPath:(NSIndexPath *)indexPath withContentArray:(NSArray*)contentArray withplaceholderArray:(NSArray*)placeholderArray;



//卡片邮寄
-(void)configCardMailDataAtIndexPath:(NSIndexPath *)indexPath withContentArray:(NSArray*)contentArray withplaceholderArray:(NSArray*)placeholderArray;


@end

NS_ASSUME_NONNULL_END
