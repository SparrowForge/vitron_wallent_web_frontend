//
//  LanguageCell.m
//  BytesTrack
//
//  Created by sunliang on 2022/5/23.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "LanguageCell.h"

@implementation LanguageCell

- (void)awakeFromNib {
    [super awakeFromNib];
   // self.nameLabel.font=[UIFont fontWithName:@"PingFang SC" size:19];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
