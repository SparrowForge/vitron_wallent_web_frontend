//
//  UserDetailHeaderView.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/10.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "UserDetailHeaderView.h"

@implementation UserDetailHeaderView


+ (UserDetailHeaderView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"UserDetailHeaderView" owner:nil options:nil];
    UserDetailHeaderView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.nameLabel.font=PingFangMediumFont(21);
    [view.headImageV setCornerRadius:30.0];
    return view;
}

-(void)setModel:(InviteModel *)model{
    _model=model;
  
    self.nameLabel.text=model.email;
    self.IdLabel.text=model.merchantId;
    [self.headImageV UBTracker_yy_setImageWithURL:[NSURL URLWithString:[model.headUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]] placeholder:UIIMAGE(@"noImage")];
    
}

@end
