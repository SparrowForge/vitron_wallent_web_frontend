//
//  MineHeadView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "MineHeadView.h"

@implementation MineHeadView

+ (MineHeadView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"MineHeadView" owner:nil options:nil];
    MineHeadView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.IDLabel.text=[NSString stringWithFormat:@"ID: %@",[UserWrapper shareUserInfo].ID];
    view.IDLabel.font=PingFangMediumFont(15);
    [view.headImageV UBTracker_yy_setImageWithURL:[NSURL URLWithString:[[UserWrapper shareUserInfo].headUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]] placeholder:UIIMAGE(@"noImage")];
    [view.headImageV setCornerRadius:35];
    view.nameLabel.text=[UserWrapper shareUserInfo].realName;
   
    return view;
}


//MARK: 复制ID
- (IBAction)pushDetailVC:(id)sender {
    
    if (![NSString stringIsNull:[UserWrapper shareUserInfo].ID]) {
        UIPasteboard *pboard = [UIPasteboard generalPasteboard];
        pboard.string = [UserWrapper shareUserInfo].ID;
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
    }
}

@end
