//
//  AllNameHeadView.h
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AllNameHeadView : UITableViewHeaderFooterView
@property (weak, nonatomic) IBOutlet UILabel *firstLabel;
@property (weak, nonatomic) IBOutlet UILabel *lastLabel;
@property (weak, nonatomic) IBOutlet UILabel *firstNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *lastNumLabel;
//实名认证
-(void)configDataInSection:(NSInteger)section withDataDic:(NSDictionary*)dic;

//邮寄
-(void)configCardMailDataInSection:(NSInteger)section;
@end

NS_ASSUME_NONNULL_END
