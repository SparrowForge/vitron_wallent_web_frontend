//
//  IdentityCardCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
typedef void(^IdentityImage)(NSString* _Nullable identityType,NSString* _Nullable imageUrl);
NS_ASSUME_NONNULL_BEGIN

@interface IdentityCardCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIButton *cardBtn1;
@property (weak, nonatomic) IBOutlet UIButton *cardBtn2;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel1;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel2;
@property(nonatomic,strong) NSDictionary* contentDic;//照片信息
@property (nonatomic, copy) IdentityImage identityImage;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;

//审核中或已认证
-(void)configDataWithfrontImg:(NSString*)frontImg withbackImg:(NSString*)backImg withcardType:(NSString*)type;
@end

NS_ASSUME_NONNULL_END
