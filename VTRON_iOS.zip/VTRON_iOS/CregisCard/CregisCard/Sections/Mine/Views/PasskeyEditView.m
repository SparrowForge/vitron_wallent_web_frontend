//
//  PasskeyEditView.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PasskeyEditView.h"

@implementation PasskeyEditView


+ (PasskeyEditView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"PasskeyEditView" owner:nil options:nil];
    PasskeyEditView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setUpUI];
    return view;
}
-(void)setUpUI{
    
    [self.reNameBtn setTitle:LocalizationKey(@"重命名") forState:UIControlStateNormal];
    self.reNameBtn.titleLabel.font=PingFangMediumFont(17);
    [self.deleteBtn setTitle:LocalizationKey(@"删除") forState:UIControlStateNormal];
    self.deleteBtn.titleLabel.font=PingFangMediumFont(17);
    
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}


- (IBAction)okClick:(UIButton *)sender {
    [self hide];
    if (sender.tag==0) {
        //重命名
        if (self.editblock) {
            self.editblock(0);
        }
    }else{
        //删除
        if (self.editblock) {
            self.editblock(1);
        }
    }
   
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
