//
//  IdentityInputCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "IdentityInputCell.h"

@interface IdentityInputCell ()<UITextFieldDelegate>
@property(nonatomic,assign) int type;//0 实名认证 1 邮寄地址

@end

@implementation IdentityInputCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setBorderView:self.boardView];
    [self.inputTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    [self.inputTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingDidEnd];
    self.inputTF.delegate=self;
    self.inputTF.font=PingFangMediumFont(15);
}

-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"000000" alpha:0.2].CGColor;
    [view setCornerRadius:12];
    
}

//实名认证
-(void)configDataAtIndexPath:(NSIndexPath *)indexPath withContentArray:(NSArray*)contentArray withplaceholderArray:(NSArray*)placeholderArray{
    self.type=0;
    self.inputTF.tag=indexPath.section;
    self.inputTF.placeholder=placeholderArray[indexPath.section];
    self.inputTF.text=contentArray[indexPath.section];
    
    if (indexPath.section==1||indexPath.section==2||indexPath.section==6||indexPath.section==12) {
        //请选择
        self.inputTF.enabled=NO;
        self.iconImageV.hidden=NO;
        self.usdLabel.hidden=YES;
        self.iconImageV.image=UIIMAGE(@"moreDownIconBlack");

    }else if(indexPath.section==14){
        //出生日期
        self.inputTF.enabled=NO;
        self.iconImageV.hidden=NO;
        self.iconImageV.image=UIIMAGE(@"dateIcon");
        self.usdLabel.hidden=YES;
        
    }else if(indexPath.section==3||indexPath.section==5){
        //年薪，月交易额
        self.inputTF.enabled=YES;
        self.iconImageV.hidden=YES;
        self.usdLabel.hidden=NO;
        self.inputTF.keyboardType=UIKeyboardTypeNumberPad;
        
    }else if(indexPath.section==4||indexPath.section==7||indexPath.section==8||indexPath.section==9||indexPath.section==10||indexPath.section==13){
        //账户用途，省，城市，地址,邮编，证件号码
        self.inputTF.enabled=YES;
        self.iconImageV.hidden=YES;
        self.usdLabel.hidden=YES;
        self.inputTF.keyboardType=UIKeyboardTypeASCIICapable;

        
    }

    else{
        self.inputTF.keyboardType=UIKeyboardTypeASCIICapable;

    }
    if(indexPath.section==14){
        //出生日期
        self.iconWidth.constant=20;
        
    }else{
        self.iconWidth.constant=25;

    }
    
}
- (void)textFieldDidEnd:(UITextField *)textField{
    
    if (self.endEditBlock) {
        self.endEditBlock();
    }
}

- (void)textFieldChange:(UITextField *)textField {
    
    NSString*typeString=[self getTypeStringWithTextField:textField];
    if (self.identityAuthenticationBlock) {
        self.identityAuthenticationBlock(typeString, textField.text,(int)textField.tag);
    }
    if (self.type==1) {
        //邮寄地址
        if (textField.tag==5) {
            //城市
            self.usdLabel.text=[NSString stringWithFormat:@"%lu/20",(unsigned long)textField.text.length];
        }else if(textField.tag==6) {
            //地址
            self.usdLabel.text=[NSString stringWithFormat:@"%lu/50",(unsigned long)textField.text.length];
        }
        
    }
    
}

//获取类型
-(NSString*)getTypeStringWithTextField:(UITextField *)textField{
    if (self.type==0) {
        //实名认证
        switch (textField.tag) {
            case 3:
                return @"annualSalary";
                break;
            case 4:
                return @"accountPurpose";
                break;
            case 5:
                return @"expectedMonthlyVolume";
                break;
            case 7:
                return @"state";
                break;
            case 8:
                return @"city";
                break;
            case 9:
                return @"address";
                break;
            case 10:
                return @"postCode";
                break;
            case 13:
                return @"idNumber";
                break;
          
            default:
                return LocalizationKey(@"未知");
                break;
        }
        
    }else{
        //邮寄地址
       
        switch (textField.tag) {
            case 4:
                return LocalizationKey(@"zone");
                break;
            case 5:
                return LocalizationKey(@"city");
                break;
            case 6:
                return LocalizationKey(@"address");
                break;
            case 7:
                return LocalizationKey(@"address2");
                break;
            case 8:
                return LocalizationKey(@"postCode");
                break;
           
            default:
                return LocalizationKey(@"未知");
                break;
        }
       
        
    }
   
    
}

//卡片邮寄
-(void)configCardMailDataAtIndexPath:(NSIndexPath *)indexPath withContentArray:(NSArray*)contentArray withplaceholderArray:(NSArray*)placeholderArray{
    self.type=1;
    self.inputTF.tag=indexPath.section;
    self.inputTF.placeholder=placeholderArray[indexPath.section];
    self.inputTF.text=contentArray[indexPath.section];
    if (indexPath.section==0) {
        //卡号
        self.inputTF.enabled=NO;
        self.iconImageV.hidden=YES;
        self.usdLabel.hidden=YES;
        self.boardView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.04];
     
    }else if (indexPath.section==3){
        //国家和地区
        self.inputTF.enabled=NO;
        self.iconImageV.hidden=NO;
        self.usdLabel.hidden=YES;
        self.boardView.backgroundColor=[UIColor whiteColor];
     
    
    }else if (indexPath.section==5||indexPath.section==6){
        //城市和地址
        self.inputTF.enabled=YES;
        self.iconImageV.hidden=YES;
        self.usdLabel.hidden=NO;
        self.boardView.backgroundColor=[UIColor whiteColor];
        if (indexPath.section==5) {
            self.usdLabel.text=[NSString stringWithFormat:@"%lu/20",(unsigned long)self.inputTF.text.length];
        }else{
            self.usdLabel.text=[NSString stringWithFormat:@"%lu/50",(unsigned long)self.inputTF.text.length];
        }
        
    }else{
        self.inputTF.enabled=YES;
        self.iconImageV.hidden=YES;
        self.usdLabel.hidden=YES;
        self.boardView.backgroundColor=[UIColor whiteColor];
    }
    
    self.inputTF.keyboardType=UIKeyboardTypeASCIICapable;
}

//限制输入位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *currentText = textField.text;
    NSUInteger newLength = [currentText length] + [string length] - range.length;
    int maxLength=1000;
    if (self.type==1) {
        //邮寄地址
        if (textField.tag==5) {
            //城市
            maxLength=60;
        }else if(textField.tag==6) {
            //地址
            maxLength=50;
        }
    }else{
        //实名认证
        if (textField.tag==7) {
            //省份
            maxLength=60;
        }else if (textField.tag==8) {
            //城市
            maxLength=60;
        }
        else if (textField.tag==9) {
            //地址
            maxLength=40;
        }else if(textField.tag==10) {
            //邮编
            maxLength=15;
        }else if(textField.tag==13) {
            //证件号码
            maxLength=50;
        }else if(textField.tag==3) {
            //年薪
            maxLength=20;
        }else if(textField.tag==4) {
            //账户用途
            maxLength=255;
        }else if(textField.tag==5) {
            //月交易额
            maxLength=20;
        }
      
    }
    return newLength <= maxLength;
}



//日期转为字符串
- (NSString *)dateToString:(NSDate *)date
{
  NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
  [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
  NSString *strDate = [dateFormatter stringFromDate:date];
  return strDate;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
