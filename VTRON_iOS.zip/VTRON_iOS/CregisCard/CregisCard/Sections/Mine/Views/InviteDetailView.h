//
//  InviteDetailView.h
//  CregisCard
//
//  Created by 孙良 on 2024/11/4.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FWPanPopupView.h"
NS_ASSUME_NONNULL_BEGIN

@interface InviteDetailView : FWPanPopupView
+ (InviteDetailView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UILabel *inviteCodeLabel;
@property (weak, nonatomic) IBOutlet UILabel *inviteLinkLabel;
@property (weak, nonatomic) IBOutlet UILabel *inviteCodeTitle;
@property (weak, nonatomic) IBOutlet UILabel *inviteLinkTitle;
@property (weak, nonatomic) IBOutlet UIView *boardView;

-(void)configUIWithDic:(NSDictionary*)dataDic;

@end

NS_ASSUME_NONNULL_END
