//
//  DeadlineCell.m
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "DeadlineCell.h"
#import "BRDatePickerView.h"

@implementation DeadlineCell

- (IBAction)btnClick:(UIButton *)sender {
    
    [self creatDatePickerViewWithBtn:sender];

}

-(void)creatDatePickerViewWithBtn:(UIButton *)sender{
    
    // 1.创建日期选择器
    BRDatePickerView *datePickerView = [[BRDatePickerView alloc]init];
    
    // 2.设置属性
    datePickerView.pickerMode = BRDatePickerModeYMD;
    datePickerView.title = LocalizationKey(@"选择时间");
    
    //    datePickerView.selectValue = @"2019-10-30";
    // datePickerView.selectDate = [NSDate br_setYear:2019 month:10 day:30];
    datePickerView.minDate = [NSDate br_setYear:1949 month:3 day:12];
    //datePickerView.maxDate = [NSDate date];
    datePickerView.isAutoSelect = NO;
    WEAKSELF
    datePickerView.resultBlock = ^(NSDate *selectDate, NSString *selectValue) {
        NSString*type=sender.tag==0?@"startTime":@"endTime";
        if (sender.tag==0) {
            weakSelf.startTF.text=selectValue;
        }else{
            weakSelf.endTF.text=selectValue;
        }
        if (weakSelf.deadlineBlock) {
            weakSelf.deadlineBlock(type,  selectValue);
        }
      
    };
    // 设置自定义样式
    BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
    customStyle.pickerColor = [UIColor whiteColor];
    customStyle.pickerTextColor = [UIColor blackColor];
    customStyle.separatorColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.2];
    customStyle.cancelBtnTitle=LocalizationKey(@"取消");
    customStyle.doneBtnTitle=LocalizationKey(@"确定");
    if ([[ChangeLanguage userLanguage] isEqualToString:@"en"]) {
        datePickerView.showUnitType=BRShowUnitTypeNone;//不显示单位
    }
    datePickerView.pickerStyle = customStyle;
    // 3.显示
    [datePickerView show];
    
    
}



- (void)awakeFromNib {
    [super awakeFromNib];
    [self setBorderView:self.beginView];
    [self setBorderView:self.endView];
    self.startTF.font=PingFangMediumFont(15);
    self.startTF.font=PingFangMediumFont(15);
    self.endTF.font=PingFangMediumFont(15);
    self.startTF.placeholder=LocalizationKey(@"请选择");
    self.endTF.placeholder=LocalizationKey(@"请选择");
    // Initialization code
}

-(void)configDatawithStartTime:(NSString*)startTime withEndTime:(NSString*)endTime{
    self.startTF.text=startTime;
    self.endTF.text=endTime;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
