#import <UIKit/UIKit.h>

@interface CustomPopoverView : UIView

/// 显示提示框
/// @param contentView 自定义内容视图（高度不固定）
/// @param button 按钮（提示框相对的参照物）
/// @param inView 父视图
+ (void)showWithContentView:(UIView *)contentView
                 relativeTo:(UIView *)button
                    inView:(UIView *)inView;

/// 隐藏提示框
+ (void)hide;

@end
