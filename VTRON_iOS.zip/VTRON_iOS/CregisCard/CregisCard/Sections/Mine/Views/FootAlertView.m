//
//  FootAlertView.m
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FootAlertView.h"

@implementation FootAlertView

-(void)awakeFromNib{
    [super awakeFromNib];
    self.firstName.text=LocalizationKey(@"格式限制英文、空格");
    self.lastName.text=LocalizationKey(@"格式限制英文、空格");
}

@end
