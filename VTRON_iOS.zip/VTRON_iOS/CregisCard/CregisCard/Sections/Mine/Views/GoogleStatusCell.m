//
//  GoogleStatusCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/14.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "GoogleStatusCell.h"

@implementation GoogleStatusCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.text=LocalizationKey(@"谷歌认证");
    self.titleLabel.font=PingFangMediumFont(17);
    // Initialization code
}

-(void)setButtonStyle{
   
        if ([[UserWrapper shareUserInfo].googleStatus intValue]==0) {
            //当前是未开启状态
            [self.statusBtn setTitle:LocalizationKey(@"开启") forState:UIControlStateNormal];
            [self.resetBtn setTitle:LocalizationKey(@"重置") forState:UIControlStateNormal];
            self.statusBtn.hidden=YES;
            self.resetBtn.hidden=YES;
            [self.resetBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
           
        }else if ([[UserWrapper shareUserInfo].googleStatus intValue]==1)
        {
            //当前是开启状态
            [self.statusBtn setTitle:LocalizationKey(@"关闭") forState:UIControlStateNormal];
            [self.resetBtn setTitle:LocalizationKey(@"重置") forState:UIControlStateNormal];
            self.statusBtn.hidden=YES;
            self.resetBtn.hidden=YES;
            [self.resetBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];

        }else{
            //当前是未绑定状态
            self.statusBtn.hidden=YES;
            self.resetBtn.hidden=NO;
            [self.resetBtn setTitle:LocalizationKey(@"去开启") forState:UIControlStateNormal];
            [self.resetBtn setTitleColor:[UIColor colorWithHexString:@"#F7B500" alpha:1.0] forState:UIControlStateNormal];
        }
   
    
}

@end
