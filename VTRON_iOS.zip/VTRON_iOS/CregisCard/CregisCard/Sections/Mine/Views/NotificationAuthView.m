//
//  NotificationAuthView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "NotificationAuthView.h"

@interface NotificationAuthView()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountTitle;
@property (weak, nonatomic) IBOutlet UILabel *dsTitle;
@property (weak, nonatomic) IBOutlet UILabel *cardNoTitle;
@property (weak, nonatomic) IBOutlet UILabel *timeTitle;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UILabel *dsLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardNoLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;




@end


@implementation NotificationAuthView


+ (NotificationAuthView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"NotificationAuthView" owner:nil options:nil];
    NotificationAuthView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setUpUI];
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

-(void)setUpUI{
    
    self.titleLabel.font=PingFangMediumFont(19);
    self.titleLabel.text=LocalizationKey(@"授权");
    self.amountTitle.text=LocalizationKey(@"交易金额");
    self.cardNoTitle.text=LocalizationKey(@"卡号");
    self.timeTitle.text=LocalizationKey(@"时间");
    [self.cancelBtn setTitle:LocalizationKey(@"拒绝") forState:UIControlStateNormal];
    [self.okBtn setTitle:LocalizationKey(@"同意") forState:UIControlStateNormal];
    [self.cancelBtn setborderColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] withborderWidth:0.5];
    self.cancelBtn.titleLabel.font=PingFangMediumFont(15);
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    
}

- (IBAction)okClick:(UIButton *)sender {
    
    [self hide];
    
    if (sender.tag==0) {
        //拒绝
        if (self.authBlock) {
            self.authBlock((int)sender.tag);
        }
    }else if (sender.tag==1) {
        //同意
        if (self.authBlock) {
            self.authBlock((int)sender.tag);
        }
    }else{
        
    }
    
    
}

-(void)setModel:(NotificationModel *)model{
    _model=model;
//    self.amountLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:model.transactionAmount],model.transactionCurrency];
//    self.cardNoLabel.text=[NSString stringWithFormat:@"....%@",model.cardNo];
//    self.dsLabel.text=model.initiateActionId;
//    self.timeLabel.text=[NSString convertDateString:model.transactionTimestamp];
    
    
}


@end
