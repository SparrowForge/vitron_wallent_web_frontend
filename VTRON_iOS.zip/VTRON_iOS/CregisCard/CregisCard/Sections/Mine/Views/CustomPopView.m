//
//  CustomPopView.m
//  CregisCard
//
//  Created by sunliang on 2025/7/8.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CustomPopView.h"

@implementation CustomPopView

+ (CustomPopView *)instanceViewWithFrame:(CGRect)Rect withMenuType:(ShowMenuType)menuType{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"CustomPopView" owner:nil options:nil];
    CustomPopView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];

    property.popupAlignment = FWPopupAlignmentCenter;
    property.popupAnimationStyle = FWPopupAnimationStyleScale3D;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 20);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor whiteColor];
    view.vProperty = property;
    view.menuType=menuType;
    [view setCornerRadius:20];
    [view setUpUI];
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

-(void)setUpUI{
    
    if (self.menuType==CommissionRate) {
       
        [self  setText:LocalizationKey(@"佣金费率说明") lineSpacing:3];
    }else if (self.menuType==GoogleVerify){
        
        [self  setText:LocalizationKey(@"如何绑定？\n1.下载“Google Authentication”应用。\n2.安装完成后打开Google Authentication，扫描下方二维码或手动输入秘钥；\n3.添加成功后，您将得到一个有一定时效的6位数验证码，请在过期前填入。") lineSpacing:3];
        
    }else{
        
        [self  setText:LocalizationKey(@"未知") lineSpacing:3];
    }
    
   
}

//身份证认证提示
-(void)configTipsString:(NSString*)tips{
    
    [self  setText:tips lineSpacing:3];
   
}

- (void)setText:(NSString *)text lineSpacing:(CGFloat)lineSpacing {
    if (!text) {
        return;
    }
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = lineSpacing;
    
    NSDictionary *attributes = @{
        NSParagraphStyleAttributeName: paragraphStyle
    };
    
    self.titleLabel.attributedText = [[NSAttributedString alloc] initWithString:text attributes:attributes];
}




@end
