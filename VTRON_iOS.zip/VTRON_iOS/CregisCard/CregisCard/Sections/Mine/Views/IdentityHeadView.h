//
//  IdentityHeadView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomPopView.h"

NS_ASSUME_NONNULL_BEGIN

@interface IdentityHeadView : UITableViewHeaderFooterView
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *typeBtn;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UILabel *flagLabel;
@property (weak, nonatomic) IBOutlet UIButton *tipsBtn;
@property(nonatomic,strong) CustomPopView*customPopView;

//实名认证
-(void)configDataInSection:(NSInteger)section withtitleArray:(NSArray*)titleArray;
//邮寄地址
-(void)configCardShipInSection:(NSInteger)section withtitleArray:(NSArray*)titleArray;
//编辑收益
-(void)editIncomeInSection:(NSInteger)section withtitleArray:(NSArray*)titleArray;
@end

NS_ASSUME_NONNULL_END
