//
//  AllNameHeadView.m
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "AllNameHeadView.h"

@implementation AllNameHeadView

-(void)awakeFromNib{
    [super awakeFromNib];
    self.firstLabel.font=PingFangMediumFont(13);
    self.lastLabel.font=PingFangMediumFont(13);

}

//实名认证
-(void)configDataInSection:(NSInteger)section withDataDic:(NSDictionary*)dic{
    
    self.contentView.backgroundColor=[UIColor whiteColor];
    NSString*firstName=dic[@"firstName"];
    NSString*lastName=dic[@"lastName"];
    self.firstNumLabel.text=[NSString stringWithFormat:@"%lu/32",(unsigned long)lastName.length];
    self.lastNumLabel.text=[NSString stringWithFormat:@"%lu/32",(unsigned long)firstName.length];
    
    if (section==0) {
        //姓名
        self.firstLabel.text=LocalizationKey(@"姓");
        self.lastLabel.text=LocalizationKey(@"名");
        self.firstNumLabel.hidden=NO;
        self.lastNumLabel.hidden=NO;

    }else{
        //截止日期
        self.firstLabel.text=LocalizationKey(@"签发日期");
        self.lastLabel.text=LocalizationKey(@"截止日期");
        self.firstNumLabel.hidden=YES;
        self.lastNumLabel.hidden=YES;
        
    }
    
    
}

//卡邮寄
-(void)configCardMailDataInSection:(NSInteger)section{
    
    self.firstLabel.text=LocalizationKey(@"姓");
    self.lastLabel.text=LocalizationKey(@"名");
    self.firstNumLabel.hidden=NO;
    self.lastNumLabel.hidden=NO;
   
    
}
@end
