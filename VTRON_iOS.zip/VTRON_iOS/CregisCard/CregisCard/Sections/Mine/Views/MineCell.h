//
//  MineCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MineCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *IconImageV;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailDistance;
@property (weak, nonatomic) IBOutlet UIImageView *rowIcon;
@property (weak, nonatomic) IBOutlet UIView *statusView;
@property (weak, nonatomic) IBOutlet UIView *dotView;

-(void)configDataWithIconImage:(NSArray*)imageNameArray withName:(NSArray*)nameArray AtIndexPath:(NSIndexPath *)indexPath withHaveNotification:(BOOL)haveNotification;
@end

NS_ASSUME_NONNULL_END
