//
//  PassKeyDeleteView.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PassKeyDeleteView.h"


@implementation PassKeyDeleteView


+ (PassKeyDeleteView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"PassKeyDeleteView" owner:nil options:nil];
    PassKeyDeleteView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 16, 10+HOME_INDICATOR_HEIGHT, 16);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    
    [view setUpUI];
    return view;
}
-(void)setUpUI{
    self.deleteBtn.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    self.deleteBtn.layer.borderWidth=0.5;
    [self.deleteBtn setTitle:LocalizationKey(@"移除") forState:UIControlStateNormal];
    [self.keepBtn setTitle:LocalizationKey(@"保持现状") forState:UIControlStateNormal];
    [self.deleteBtn setTitleColor: [UIColor mainBtnColor] forState:UIControlStateNormal];
    self.deleteBtn.backgroundColor=[UIColor whiteColor];
    self.deleteBtn.titleLabel.font=PingFangMediumFont(15);
    [self.keepBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.keepBtn.backgroundColor=[UIColor mainBtnColor];
    self.keepBtn.titleLabel.font=PingFangMediumFont(15);
    self.titleLabel.text=LocalizationKey(@"删除通行密钥");
    self.detailLabel.text=LocalizationKey(@"通行密钥可保护您的账户安全，删除后将从您的所有设备中删除。我们建议保留以获得额外的保护。");

}

-(void)layoutSubviews{
    [super layoutSubviews];
    self.boardView.layer.cornerRadius=24;
    self.boardView.clipsToBounds=YES;
}

- (IBAction)okClick:(UIButton *)sender {
    [self hide];
    if (sender.tag==0) {
        //移除
        if (self.menublock) {
            self.menublock(0);
        }
    }else{
        //保持现状
      
    }
    
}






/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
