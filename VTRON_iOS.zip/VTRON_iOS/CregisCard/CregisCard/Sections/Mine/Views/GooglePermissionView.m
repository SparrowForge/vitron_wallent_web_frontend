//
//  GooglePermissionView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "GooglePermissionView.h"
#import "MineNetWorkManager.h"

@interface GooglePermissionView()

@end

@implementation GooglePermissionView

+ (GooglePermissionView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"GooglePermissionView" owner:nil options:nil];
    GooglePermissionView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStyleFrame;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self setBorderView:self.pswView];
    [self setBorderView:self.codeView];
    self.cancelBtn.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    self.okBtn.titleLabel.font=[UIFont boldSystemFontOfSize:15.0];
    [self.googleTF setStyleWithPlaceholder:LocalizationKey(@"谷歌验证码")];
    [self.codeTF setStyleWithPlaceholder:LocalizationKey(@"邮箱验证码")];
    [self.verifyCodeBtn setTitle:LocalizationKey(@"获取验证码") forState:UIControlStateNormal];
    [self.cancelBtn setTitle:LocalizationKey(@"取消") forState:UIControlStateNormal];
    [self.okBtn setTitle:LocalizationKey(@"确定") forState:UIControlStateNormal];
}


-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}



- (IBAction)closeClick:(id)sender {
    [self hide];
}


- (IBAction)eventClick:(UIButton *)sender {
    if (sender.tag==0) {
        //发送邮箱验证码
        [self getEmailVerifyCode];
    } else{
        //点击确定按钮
        [self confirmTochangeStatus];
    }
    
}
//MARK: 确定
-(void)confirmTochangeStatus{
    if ([NSString stringIsNull:self.googleTF.text]) {
      
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入谷歌验证码"));
        return;
    }
    if ([NSString stringIsNull:self.codeTF.text]) {
    
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        return;
    }
   
    [self changeGoogleStatus];
    
}


//MARK: 发送邮箱验证码
-(void)getEmailVerifyCode{
    NSString*googleStatusString=self.type==0?@"openGoogle":@"closeGoogle";
   [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":googleStatusString} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            [self CountDown:59];
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

/* 倒计时 */
- (void)CountDown:(int)timeDistance{
    __block NSInteger time = timeDistance; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    self._timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    dispatch_source_set_timer(self._timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(self._timer, ^{
        
        if(time <= 0){ //倒计时结束，关闭
            
            dispatch_source_cancel(self._timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置按钮的样式
                [self.verifyCodeBtn setTitle:LocalizationKey(@"重新发送") forState:UIControlStateNormal];
                [self.verifyCodeBtn setTitleColor:[UIColor baseColor] forState:UIControlStateNormal];
                self.verifyCodeBtn.userInteractionEnabled = YES;
                
            });
            
        }else{
            
            int seconds = (int)time ;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //设置按钮显示读秒效果
                [self.verifyCodeBtn setTitle:[NSString stringWithFormat:@"%.2ldS",(long)seconds] forState:UIControlStateNormal];
                [self.verifyCodeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                self.verifyCodeBtn.userInteractionEnabled = NO;
            });
            time--;
        }
    });
    dispatch_resume(self._timer);
}

- (IBAction)eyeClick:(UIButton *)sender {
    sender.selected=!sender.selected;
    self.googleTF.secureTextEntry=sender.selected?NO:YES;
}



//type 0 开启谷歌验证 1关闭谷歌验证
-(void)showGoogleViewWitype:(int)type success:(void (^)(BOOL success))success {
    self.type=type;
    self.googleBlock = success;
    self.titleLabel.text=type==0?LocalizationKey(@"开启谷歌验证"):LocalizationKey(@"关闭谷歌认证");
    [self show];
}


//重置验证码
-(void)resetVerifyCode{
    if (self._timer) {
        dispatch_source_cancel(self._timer);
    }
    [self.verifyCodeBtn setTitle:LocalizationKey(@"获取验证码") forState:UIControlStateNormal];
    [self.verifyCodeBtn setTitleColor:[UIColor baseColor] forState:UIControlStateNormal];
    self.verifyCodeBtn.userInteractionEnabled = YES;
    
}



//提交请求
-(void)changeGoogleStatus{
    
    NSString*googleStatus=self.type==0?@"1":@"0";
   [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager changeGoogleStatusWithParams:@{@"googleStatus":googleStatus,@"type":@"2",@"emailCode":self.codeTF.text,@"googleCode":self.googleTF.text} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
         
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"操作成功"));
            [UserWrapper shareUserInfo].googleStatus= googleStatus;
            [UserWrapper saveUser:[UserWrapper shareUserInfo]];
            [self hide];
            self.googleTF.text=@"";
            self.codeTF.text=@"";
            [self resetVerifyCode];//重置验证码
            if (self.googleBlock) {
                self.googleBlock(YES);
            }
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
      //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}




@end
