//
//  PhoneInfoCell.m
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PhoneInfoCell.h"
#import "CountrysSelectView.h"
#import "NSObject+UBTrackerModel.h"
#import "MineNetWorkManager.h"

@interface PhoneInfoCell ()<UITextFieldDelegate>
@property(nonatomic,strong) CountrysSelectView*countrySelectView;
@property (weak, nonatomic) IBOutlet UILabel *areaLabel;
@property(nonatomic,strong) NSArray*countryAreaCodeArray;
@property (weak, nonatomic) IBOutlet UITextField *phoneTF;

@property(nonatomic,strong) CountryModel*currentCountry;//手机号对应的国家地区
@end


@implementation PhoneInfoCell

- (CountrysSelectView *)countrySelectView {
    if(!_countrySelectView) {
        _countrySelectView=[CountrysSelectView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-10)];
    }
    return _countrySelectView;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    self.phoneTF.placeholder=LocalizationKey(@"请输入");
    self.areaLabel.font=PingFangMediumFont(15);
    self.phoneTF.font=PingFangMediumFont(15);
    [self setBorderView:self.areaView];
    [self setBorderView:self.phoneView];
    [self.phoneTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    [self.phoneTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingDidEnd];
    self.phoneTF.delegate=self;
    // Initialization code
}

- (void)textFieldChange:(UITextField *)textField {
    if (self.phoneNumBlock) {
        self.phoneNumBlock(@"phone", textField.text);
    }
    
}
- (void)textFieldDidEnd:(UITextField *)textField {
    if (self.endblock) {
        self.endblock();
    }
    
}


//选择区号
- (IBAction)selectAreaCode:(UIButton *)sender {
    [self endEditing:YES];
    if (self.countryAreaCodeArray.count>0) {
        [self.countrySelectView show];
        [self.countrySelectView  reloadDataWithArray:self.countryAreaCodeArray withDefalutModel:self.currentCountry withType:1];
        WEAKSELF
        self.countrySelectView.countryBlock = ^(CountryModel *country) {
            //手机区号
            weakSelf.currentCountry=country;
            weakSelf.areaLabel.text=[NSString stringWithFormat:@"+%@",country.code];
            if (weakSelf.phoneAreablock) {
                weakSelf.phoneAreablock(@"areaCode", country);
            }
        };
    }else{
        [self getAllCountryAreaCode];
    }
    
}

-(void)configDataWithAreaCode:(CountryModel*)areaModel withPhone:(NSString*)phoneNum{
    
    self.currentCountry=areaModel;
    self.areaLabel.text=[NSString stringWithFormat:@"+%@",areaModel.code];
    self.phoneTF.text=phoneNum;
    
    
}
//MARK: 获取支持的全部国家手机区号
-(void)getAllCountryAreaCode{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getCardShipWithcountryAreaCodesuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*countryArray=(NSMutableArray*)[CountryModel utr_modelsWithKeyValues:data[@"data"]];
            self.countryAreaCodeArray=countryArray;
            [self.countrySelectView show];
            [self.countrySelectView  reloadDataWithArray:countryArray withDefalutModel:self.currentCountry withType:1];
            WEAKSELF
            self.countrySelectView.countryBlock = ^(CountryModel *country) {
                //手机区号
                weakSelf.currentCountry=country;
                weakSelf.areaLabel.text=[NSString stringWithFormat:@"+%@",country.code];
                if (weakSelf.phoneAreablock) {
                    weakSelf.phoneAreablock(@"areaCode", country);
                }
         
            };
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
    }];
  
}

//限制输入位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *currentText = textField.text;
    NSUInteger newLength = [currentText length] + [string length] - range.length;
    int maxLength=20;
   
    return newLength <= maxLength;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
