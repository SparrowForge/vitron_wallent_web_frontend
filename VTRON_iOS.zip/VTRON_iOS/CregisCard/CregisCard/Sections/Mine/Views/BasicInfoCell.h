//
//  BasicInfoCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface BasicInfoCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageV;

@property (weak, nonatomic) IBOutlet UIImageView *rowIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rowIconW;
-(void)configDataWithTitle:(NSString*)title withContent:(NSString*)content AtIndexPath:(NSIndexPath *)indexPath;
-(void)configSafeCenterWithTitle:(NSString*)title withContent:(NSString*)content withImageName:(NSString*)imageName AtIndexPath:(NSIndexPath *)indexPath;
@end

NS_ASSUME_NONNULL_END
