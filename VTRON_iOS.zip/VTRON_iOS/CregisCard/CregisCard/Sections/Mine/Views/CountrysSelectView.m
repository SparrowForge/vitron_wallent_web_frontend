//
//  CountrysSelectView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CountrysSelectView.h"
#import "CountrySelectCell.h"
@interface CountrysSelectView()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UITextField *searchTF;

@property(nonatomic,strong) NSArray*contentArray;
@property(nonatomic,strong) NSArray*originalArray;
@property(nonatomic,strong) CountryModel*currentModel;
@property(nonatomic,assign) int type;
@end

@implementation CountrysSelectView

+ (CountrysSelectView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"CountrysSelectView" owner:nil options:nil];
    CountrysSelectView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setUpUI];
    return view;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}
-(void)setUpUI{

    self.searchView.backgroundColor=[UIColor colorWithHexString:@"#1F211F " alpha:0.05];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.searchView setCornerRadius:16.0];
    [self.tableView registerNib:[UINib nibWithNibName:@"CountrySelectCell" bundle:nil] forCellReuseIdentifier:@"CountrySelectCell"];
    self.tableView.tableFooterView=[UIView new];
    self.tableView.rowHeight=60;
    [self.searchTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    self.tipsLabel.text=LocalizationKey(@"搜索");
    self.tipsLabel.font=PingFangMediumFont(13);
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CountrySelectCell*cell=[tableView dequeueReusableCellWithIdentifier:@"CountrySelectCell"];
    CountryModel*model=self.contentArray[indexPath.row];
    NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?model.usName:model.cnName;
    if (self.type==0) {
        cell.countryNameLabel.text=countryName;
    }else{
        cell.countryNameLabel.text=[NSString stringWithFormat:@"%@ (%@)",countryName,model.code];
    }
    cell.selectedIcon.hidden=[model.ID intValue]==[self.currentModel.ID intValue]?NO:YES;
    cell.iconWidth.constant=0;
    cell.leadDistance.constant=0;
    cell.frontDistance.constant=0;
    cell.behindDistance.constant=0;
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.currentModel=self.contentArray[indexPath.row];
    [self.tableView reloadData];
    [self hide];
    if (self.countryBlock) {
        self.countryBlock(self.currentModel);
    }
    
}

-(void)reloadDataWithArray:(NSArray*)dataArray withDefalutModel:(CountryModel*)model withType:(int)type{
    self.currentModel=model;
    self.originalArray=dataArray;
    self.contentArray=dataArray;
    self.type=type;
    [self.tableView reloadData];
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    self.searchIcon.hidden=textField.text.length>0?YES:NO;
    self.tipsLabel.hidden=textField.text.length>0?YES:NO;
    [self getSomeOneWithSting:textField.text];
    
}



-(void)getSomeOneWithSting:(NSString*)searchText{
  
    BOOL isEnglish=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?YES:NO;
    //在子线程中做搜索操作
       NSMutableArray*listArray=[[NSMutableArray alloc]init];
        dispatch_queue_t globalQueue = dispatch_get_global_queue(0, 0);
        dispatch_async(globalQueue, ^{
            if (searchText != nil && searchText.length > 0) {
                for (CountryModel *model in self.originalArray) {
                    NSString*countryName=isEnglish?model.usName:model.cnName;
                    NSString *pinyin = [self transformToPinyin:countryName];
                    NSLog(@"字符拼音：%@",pinyin);
                    if ([pinyin rangeOfString:searchText options:NSCaseInsensitiveSearch].length > 0) {
                        [listArray addObject:model];
                    }
                }
                self.contentArray=listArray;
            }else {
                self.contentArray=self.originalArray;
            }
            
            //回到主线程刷新表格
                    dispatch_async(dispatch_get_main_queue(), ^{
                       
                        [self.tableView reloadData];
                    });
            
        });

}
/**
  把汉字字符串转为拼音

 @param aString 汉字字符串
 @return 拼音字符串
  */
 -(NSString*)transformToPinyin:(NSString *)aString
      {
        //转成了可变字符串
       NSMutableString *str = [NSMutableString stringWithString:aString];
         CFStringTransform((CFMutableStringRef)str,NULL, kCFStringTransformMandarinLatin,NO);

        //再转换为不带声调的拼音
        CFStringTransform((CFMutableStringRef)str,NULL, kCFStringTransformStripDiacritics,NO);
       NSArray *pinyinArray = [str componentsSeparatedByString:@" "];
       NSMutableString *allString = [NSMutableString new];
       int count = 0;

                               for (int  i = 0; i < pinyinArray.count; i++)
                               {
                                   for(int i = 0; i < pinyinArray.count;i++)
                                   {
                                       if (i == count) {
                                           [allString appendString:@"#"];
                                           //区分第几个字母
                                       }
                                       [allString appendFormat:@"%@",pinyinArray[i]];
                                   }
                                   [allString appendString:@","];
                                   count ++;
                               }
                               NSMutableString *initialStr = [NSMutableString new];
                               //拼音首字母
                               for (NSString *s in pinyinArray)
                               {
                                   if (s.length > 0)
                                   {
                                       [initialStr appendString:  [s substringToIndex:1]];
                                   }
                               }
                               [allString appendFormat:@"#%@",initialStr];
                               [allString appendFormat:@",#%@",aString];
                               return allString;
          
      }


-(void)clearTextFieldContent{
    self.searchTF.text=@"";
    self.searchIcon.hidden=NO;
    self.tipsLabel.hidden=NO;
}
@end
