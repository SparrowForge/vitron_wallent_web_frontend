//
//  PasskeyEditView.h
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

typedef void(^EditMemuBlock)(int  type);
NS_ASSUME_NONNULL_BEGIN

@interface PasskeyEditView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIButton *reNameBtn;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;
@property (nonatomic, copy)   EditMemuBlock editblock;
+ (PasskeyEditView *)instanceViewWithFrame:(CGRect)Rect;

@end

NS_ASSUME_NONNULL_END
