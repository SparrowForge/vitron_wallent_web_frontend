//
//  BasicInfoCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/3.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BasicInfoCell.h"

@implementation BasicInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.font=PingFangMediumFont(17);
    // Initialization code
}

-(void)configDataWithTitle:(NSString*)title withContent:(NSString*)content AtIndexPath:(NSIndexPath *)indexPath{
    self.titleLabel.text=title;
    self.contentLabel.text=content;
    self.rowIcon.hidden=indexPath.row==2?YES:NO;
    self.rowIconW.constant=indexPath.row==2?8:30;
}

-(void)configSafeCenterWithTitle:(NSString*)title withContent:(NSString*)content withImageName:(NSString*)imageName AtIndexPath:(NSIndexPath *)indexPath{
    self.titleLabel.text=title;
    self.contentLabel.text=content;
    self.iconImageV.image=UIIMAGE(imageName);
    if (indexPath.row==0) {
        //更换邮箱
        self.contentLabel.textColor=[UIColor lightGrayColor];

    }
    else if (indexPath.row==1) {
        //通行密钥
    }
   else if (indexPath.row==2) {
       //谷歌认证
       
      
    }else  if (indexPath.row==3) {
        //交易密码
        if ([[UserWrapper shareUserInfo].isPayPassword intValue]==0) {
            self.contentLabel.textColor=[UIColor colorWithHexString:@"#F7B500" alpha:1.0];
        }else{
            self.contentLabel.textColor=[UIColor lightGrayColor];
        }
        
    }else{
        //登录密码
        self.contentLabel.textColor=[UIColor lightGrayColor];
    }
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
