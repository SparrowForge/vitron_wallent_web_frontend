//
//  UserDetailHeaderView.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/10.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InviteModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface UserDetailHeaderView : UIView
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *IdLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headImageV;

@property(nonatomic,strong)InviteModel*model;

+ (UserDetailHeaderView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
