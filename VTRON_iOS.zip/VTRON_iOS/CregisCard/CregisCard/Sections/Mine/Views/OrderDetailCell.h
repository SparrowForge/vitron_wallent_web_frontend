//
//  OrderDetailCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "OrderRecordModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailDistance;
@property (weak, nonatomic) IBOutlet UIButton *pasteBtn;
@property (weak, nonatomic) IBOutlet UIButton *detailBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *btnWid;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pasteBtnWidth;

@property(nonatomic,strong) OrderRecordModel*model;
@property(nonatomic,strong) NSArray*contentArray;


-(void)configDataWithModel:(OrderRecordModel*)orderModel AtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray withType:(int)type;

@end

NS_ASSUME_NONNULL_END
