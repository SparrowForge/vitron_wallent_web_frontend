//
//  PassportPictureCell.m
//  CregisCard
//
//  Created by sunliang on 2025/11/4.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PassportPictureCell.h"
#import "CameraManager.h"
#import "MineNetWorkManager.h"
#import "UIButton+UBTracker_YYWebImage.h"

@interface PassportPictureCell ()<CameraManagerDelegate>
{
    int _currentPhotosIndex;
}
@property (weak, nonatomic) IBOutlet UIButton *cardBtn1;
@property (weak, nonatomic) IBOutlet UIButton *cardBtn2;


@end

@implementation PassportPictureCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.tipsLabel.text=LocalizationKey(@"2M以内JPG，PNG格式");
    self.cardLabel1.text=LocalizationKey(@"正面");
    self.cardLabel2.text=LocalizationKey(@"手持");
    [CameraManager shareInstance].delegate=self;
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self addDashedBorderToView:self.frontalView];
        [self addDashedBorderToView:self.handView];
        
    });
    // Initialization code
}


- (IBAction)btnClick:(UIButton*)sender {
    _currentPhotosIndex=(int)sender.tag;
    [[CameraManager shareInstance] openCameraOrPhotoLibraryWithCameraDeviceType:@"Behind" AndController:[UBTrackerFindController findCurrentShowingViewController]];
  
}

/** 事件回调*/
- (void)cameraCallBack:(UIImage *)image{
    
    UIButton*currentButton=_currentPhotosIndex==0?self.cardBtn1:self.cardBtn2;
 
    NSString*imageType=_currentPhotosIndex==0?@"idFrontId":@"idHoldId";
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager uplodFileWithData:[self imageZipToData:image]  success:^(NSData * _Nonnull successData) {
        [SVProgressHUD dismiss];
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:successData options:NSJSONReadingMutableContainers error:nil];
        if ([dic[@"code"] intValue]==200) {
            NSDictionary*imageDic=dic[@"data"];
            [currentButton setBackgroundImage:image forState:UIControlStateNormal];
            if (self.identityImage) {
                self.identityImage(imageType, imageDic);
            }
            
        }else{
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,dic[@"msg"]);
        
        }
    } error:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
      //  ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

-(void)configImageWithidFrontUrl:(NSString*)idFrontUrl withidBackUrl:(NSString*)idBackUrl withidHoldUrl:(NSString*)idHoldUrl{
    
    if (![NSString stringIsNull:idFrontUrl]) {
        [self.cardBtn1 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:idFrontUrl] forState:UIControlStateNormal options:UBTracker_YYWebImageOptionShowNetworkActivity];
    
    }
    
    if (![NSString stringIsNull:idHoldUrl]) {
        [self.cardBtn2 UBTracker_yy_setBackgroundImageWithURL:[NSURL URLWithString:idHoldUrl] forState:UIControlStateNormal options:UBTracker_YYWebImageOptionShowNetworkActivity];
    }
   
    
}
- (void)addDashedBorderToView:(UIView *)view {
    // 创建虚线图层
    CAShapeLayer *dashedBorder = [CAShapeLayer layer];
    dashedBorder.strokeColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.3].CGColor; // 虚线颜色
    dashedBorder.fillColor = nil;
    dashedBorder.lineDashPattern = @[@4, @2]; // 虚线样式：[实线长度, 间隙长度]
    dashedBorder.lineWidth = 1.0; // 虚线宽度
    dashedBorder.frame = view.bounds;
    dashedBorder.path = [UIBezierPath bezierPathWithRect:view.bounds].CGPath;
    
    [view.layer addSublayer:dashedBorder];
}

/**
 *  压缩图片
 */
-(NSData *)imageZipToData:(UIImage *)newImage{
    
    NSData *data = UIImageJPEGRepresentation(newImage, 1.0);
    
    if (data.length > 500 * 1024) {
        
        if (data.length>1024 * 1024) {//1M以及以上
            
            data = UIImageJPEGRepresentation(newImage, 0.5);
            
        }else if (data.length>512*1024) {//0.5M-1M
            
            data=UIImageJPEGRepresentation(newImage, 0.6);
            
        }else if (data.length>200*1024) { //0.25M-0.5M
            
            data=UIImageJPEGRepresentation(newImage, 0.9);
        }
    }
    return data;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
