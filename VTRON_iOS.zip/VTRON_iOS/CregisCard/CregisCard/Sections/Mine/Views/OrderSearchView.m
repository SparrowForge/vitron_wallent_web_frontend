//
//  OrderSearchView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "OrderSearchView.h"

@interface OrderSearchView() <UITextFieldDelegate>

@end

@implementation OrderSearchView

+ (OrderSearchView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView = [[NSBundle mainBundle] loadNibNamed:@"OrderSearchView" owner:nil options:nil];
    OrderSearchView*view=[nibView objectAtIndex:0];
    [view.boardView setCornerRadius:16.0];
    view.backgroundColor=[UIColor whiteColor];
    view.boardView.backgroundColor=[UIColor colorWithHexString:@"#1F211F " alpha:0.05];
    view.inputTF.returnKeyType = UIReturnKeySearch;
    view.inputTF.delegate=view;
    view.frame=Rect;
    view.inputTF.font=PingFangMediumFont(13);
    return view;
}
-(void)awakeFromNib{
    [super awakeFromNib];
    //四边添加阴影
    self.boardView.layer.shadowColor = [UIColor grayColor].CGColor;//阴影颜色
    self.boardView.layer.shadowOffset = CGSizeMake(0, 0);//阴影的偏移量
    self.boardView.layer.shadowOpacity = 0.2;//阴影透明度
    self.boardView.layer.shadowRadius = 10.0;//阴影圆角
    self.boardView.clipsToBounds=NO;//这个属性为NO是必须的，不然阴影不会显示
}

//点击搜索
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{

    [self.inputTF resignFirstResponder];
    return YES;

}
//结束编辑
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    if (self.searchblock) {
        self.searchblock(textField.text);
    }
}




@end
