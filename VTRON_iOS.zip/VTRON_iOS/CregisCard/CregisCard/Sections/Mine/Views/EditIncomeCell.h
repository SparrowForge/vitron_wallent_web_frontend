//
//  EditIncomeCell.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/11.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewCell.h"
typedef void(^IncomeBlock)(NSString* _Nullable typeString,NSString* _Nullable valueString,int tag);
NS_ASSUME_NONNULL_BEGIN

@interface EditIncomeCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UITextField *inputTF;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (nonatomic, copy)   IncomeBlock incomeBlock;
-(void)configDataAtIndexPath:(NSIndexPath *)indexPath withContentArray:(NSArray*)contentArray withplaceholderArray:(NSArray*)placeholderArray;


@end

NS_ASSUME_NONNULL_END
