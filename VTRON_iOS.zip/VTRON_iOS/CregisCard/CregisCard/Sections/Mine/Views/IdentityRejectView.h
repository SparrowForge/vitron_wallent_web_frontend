//
//  IdentityRejectView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IdentityRejectView : UIView
@property (weak, nonatomic) IBOutlet UILabel *reasonLabel;
@property (weak, nonatomic) IBOutlet UIView *boadrView;
@property (weak, nonatomic) IBOutlet UIImageView *alertImageV;

+ (IdentityRejectView *)instanceViewWithFrame:(CGRect)Rect;
-(void)configcardholderUI;
-(void)configcardholderUIForBulkMail;//批量邮寄
@end

NS_ASSUME_NONNULL_END
