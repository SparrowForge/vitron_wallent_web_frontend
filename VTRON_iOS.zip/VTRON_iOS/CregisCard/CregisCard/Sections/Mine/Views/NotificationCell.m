//
//  NotificationCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/14.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NotificationCell.h"

@implementation NotificationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.boardView setCornerRadius:12];
    self.numberLabel.font=[UIFont boldSystemFontOfSize:25];
//    //四边添加阴影
//    self.boardView.layer.shadowColor = [UIColor grayColor].CGColor;//阴影颜色
//    self.boardView.layer.shadowOffset = CGSizeMake(0, 0);//阴影的偏移量
//    self.boardView.layer.shadowOpacity = 0.2;//阴影透明度
//    self.boardView.layer.shadowRadius = 10.0;//阴影圆角
//    self.boardView.clipsToBounds=NO;//这个属性为NO是必须的，不然阴影不会显示
    
    self.amountLabel.font=PingFangMediumFont(13);
    self.cardTitle.text=LocalizationKey(@"卡号");
    self.amountTitle.text=LocalizationKey(@"通知中心交易金额");
    self.timeTitle.text=LocalizationKey(@"时间");
    // Initialization code
}

-(void)configStyleWithType:(int)type{
    
    if (type==2) {
        //激活码
        self.kindLabel.text=LocalizationKey(@"激活码");
        self.top1Distance.constant=0;
        self.top2Distance.constant=10;
        self.height1Distance.constant=0;
        self.height2Distance.constant=0;
        self.amountTitle.hidden=YES;
        self.amountLabel.hidden=YES;
        
    }else{
        //3DS验证码
        self.kindLabel.text=LocalizationKey(@"3DS验证码");
        self.top1Distance.constant=10;
        self.top2Distance.constant=10;
        self.height1Distance.constant=16;
        self.height2Distance.constant=16;
        self.amountTitle.hidden=NO;
        self.amountLabel.hidden=NO;
        
    }
    
}
-(void)setModel:(NotificationModel *)model{
    [self.pasterBtn setBackgroundImage:UIIMAGE(@"noticeCopy") forState:UIControlStateNormal];
    self.kindLabel.text=[model.type intValue]==1?LocalizationKey(@"3DS验证码"):LocalizationKey(@"激活码");
    self.numberLabel.text=model.opt;
    self.cardNoLabel.text=[NSString stringWithFormat:@"....%@",model.cardNo];
    self.timelLabel.text=[self convertDateString:model.createTime];
    self.amountLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:model.amount],model.currency];
    [self configStyleWithType:[model.type intValue]];
}

//复制
- (IBAction)btnCopy:(UIButton *)sender {
    
    if (![NSString stringIsNull:self.numberLabel.text]) {
        UIPasteboard *pboard = [UIPasteboard generalPasteboard];
        pboard.string = self.numberLabel.text;
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
      
    }
}


// 日期格式转换工具方法（把日期字符串2024-11-16 23:40:21改成2024.11.16  23:40:21 ）
-(NSString *)convertDateString:(NSString *)originalDateString {
    
    
  
  
    // 检查入参是否有效
    if (!originalDateString || originalDateString.length == 0) {
        return nil; // 入参为空，返回 nil
    }

    // 创建日期格式化器
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    // 设置原始日期格式
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    
    // 将原始字符串解析为 NSDate
    NSDate *date = [dateFormatter dateFromString:originalDateString];
    if (!date) {
        return nil; // 解析失败，返回 nil
    }
    
    // 设置目标日期格式
    dateFormatter.dateFormat = @"yyyy.MM.dd HH:mm:ss";
    
    // 将 NSDate 格式化为目标字符串
    NSString *formattedDateString = [dateFormatter stringFromDate:date];
    
    return formattedDateString;
     
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
