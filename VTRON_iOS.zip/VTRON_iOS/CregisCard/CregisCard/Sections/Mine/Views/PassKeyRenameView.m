//
//  PassKeyRenameView.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PassKeyRenameView.h"


@interface PassKeyRenameView()<UITextFieldDelegate>

@end
@implementation PassKeyRenameView

+ (PassKeyRenameView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"PassKeyRenameView" owner:nil options:nil];
    PassKeyRenameView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;//FWPopupAnimationStyleFrame无动画效果
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0,0,0,0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setUpUI];
    return view;
}
-(void)setUpUI{
    self.nameTF.delegate=self;
    self.cancelBtn.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    self.cancelBtn.layer.borderWidth=0.5;
    [self.cancelBtn setTitleColor: [UIColor blackColor] forState:UIControlStateNormal];
    [self.cancelBtn setTitle:LocalizationKey(@"取消") forState:UIControlStateNormal];
    [self.confirmBtn setTitle:LocalizationKey(@"确认") forState:UIControlStateNormal];
    [self.confirmBtn setTitleColor: [UIColor mainBtnColor] forState:UIControlStateNormal];
    self.confirmBtn.backgroundColor=[UIColor whiteColor];
    [self.confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.confirmBtn.backgroundColor=[UIColor mainBtnColor];
    self.cancelBtn.titleLabel.font=PingFangMediumFont(15);
    self.confirmBtn.titleLabel.font=PingFangMediumFont(15);
    self.nameView.layer.borderWidth=0.5;
    self.nameView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [self.nameView setCornerRadius:12.0];
    self.confirmBtn.enabled=NO;
    [self.confirmBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
    self.confirmBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.titleLabel.text=LocalizationKey(@"重命名");
    [self.nameTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

- (IBAction)btnClick:(UIButton *)sender {
    [self hide];
    if (sender.tag==1) {
        //确认
        if ([NSString stringIsNull:self.nameTF.text]) {
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入名称"));
            return;
        }
        if (self.nameBlock) {
            self.nameBlock(self.nameTF.text);
        }
        
    }
    
}

- (IBAction)inputName:(UITextField *)sender {
    self.numLabel.text=[NSString stringWithFormat:@"%lu/40",(unsigned long)sender.text.length];
    [self judgeBtnStatus];
}

-(void)judgeBtnStatus{
    
    if ([NSString stringIsNull:self.nameTF.text]) {
        self.confirmBtn.enabled=NO;
        [self.confirmBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.confirmBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    }else{
        self.confirmBtn.enabled=YES;
        self.confirmBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *currentText = textField.text;
    NSUInteger newLength = [currentText length] + [string length] - range.length;
    return newLength <= 40;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
