//
//  CountrysSelectView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FWPanPopupView.h"
#import "CountryModel.h"
typedef void(^CountrySelectBlock)(CountryModel* _Nullable country);
NS_ASSUME_NONNULL_BEGIN

@interface CountrysSelectView : FWPanPopupView
+ (CountrysSelectView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UIView *boardView;

@property (weak, nonatomic) IBOutlet UIView *searchView;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UIImageView *searchIcon;

-(void)reloadDataWithArray:(NSArray*)dataArray withDefalutModel:(CountryModel*)model withType:(int)type;
@property (nonatomic, copy)   CountrySelectBlock countryBlock;
-(void)clearTextFieldContent;
@end

NS_ASSUME_NONNULL_END
