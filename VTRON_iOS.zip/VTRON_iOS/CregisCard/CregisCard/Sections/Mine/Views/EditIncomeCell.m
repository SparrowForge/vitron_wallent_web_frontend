//
//  EditIncomeCell.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/11.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "EditIncomeCell.h"

@interface EditIncomeCell()<UITextFieldDelegate>

@end
@implementation EditIncomeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setBorderView:self.boardView];
    [self.inputTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingChanged];
    self.inputTF.delegate=self;
    self.inputTF.font=PingFangMediumFont(15);
}

-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"000000" alpha:0.2].CGColor;
    [view setCornerRadius:12];
    
}

-(void)configDataAtIndexPath:(NSIndexPath *)indexPath withContentArray:(NSArray*)contentArray withplaceholderArray:(NSArray*)placeholderArray{
    NSArray*placeArray=placeholderArray[indexPath.section];
    NSArray*titleArray=contentArray[indexPath.section];
    self.inputTF.tag=indexPath.section+indexPath.row*2;
    self.inputTF.placeholder=placeArray[indexPath.row];
    self.inputTF.text=titleArray[indexPath.row];
    self.tipsLabel.text=indexPath.row==0?@"USD":@"%";
   
}


- (void)textFieldDidEnd:(UITextField *)textField {
    
    NSString*typeString=[self getTypeStringWithTextField:textField];
    if (self.incomeBlock) {
        self.incomeBlock(typeString, textField.text,(int)textField.tag);
    }
    
}

-(NSString*)getTypeStringWithTextField:(UITextField *)textField{
    
    switch (textField.tag) {
        case 0://开卡收益固定值
            return @"initApplyCard";
            break;
        case 1://交易收益固定值
            return @"initConsumerFee";
            break;
        case 3://交易收益百分比
            return @"initConsumerFeeRate";
            break;
        case 2://交易退款固定值
            return @"initOutCardFee";
            break;
        case 4://交易退款百分比
            return @"initOutCardFeeRate";
            break;
       
        default:
            return @"";
            break;
    }
    
}


//限制只能输入2位小数
// 实现UITextFieldDelegate协议方法，控制小数位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // 获取当前输入的文本
    NSString *currentText = [textField.text stringByReplacingCharactersInRange:range withString:string];

    // 检查是否是有效的数字，以及小数位数是否超过两位
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *number = [formatter numberFromString:currentText];

    if (number || [currentText isEqualToString:@""]) { // 检查是否是有效的数字或为空
        NSArray *components = [currentText componentsSeparatedByString:@"."];
        if (components.count > 1) {
            NSString *decimalPart = components[1];
            return decimalPart.length <= 2; // 限制小数位数为两位
        }
        return YES;
    } else {
        return NO; // 输入无效，不允许修改
    }
}
@end
