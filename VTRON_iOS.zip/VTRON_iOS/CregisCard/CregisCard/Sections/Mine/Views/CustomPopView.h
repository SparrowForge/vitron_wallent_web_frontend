//
//  CustomPopView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/8.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"
typedef NS_ENUM(NSInteger, ShowMenuType) {
    CommissionRate,//佣金费用
    GoogleVerify,//谷歌验证
    IdentityVerify,//身份认证
};
NS_ASSUME_NONNULL_BEGIN

@interface CustomPopView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property(nonatomic,assign) ShowMenuType menuType;
+ (CustomPopView *)instanceViewWithFrame:(CGRect)Rect withMenuType:(ShowMenuType)menuType;
-(void)configTipsString:(NSString*)tips;
@end

NS_ASSUME_NONNULL_END
