//
//  LogisticsInfoCell.h
//  CregisCard
//
//  Created by 孙良 on 2024/11/7.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LogisticsInfoCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIButton *pasteBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *btnWidth;


//物流信息
-(void)configlogisticsInfoAtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray;
@end

NS_ASSUME_NONNULL_END
