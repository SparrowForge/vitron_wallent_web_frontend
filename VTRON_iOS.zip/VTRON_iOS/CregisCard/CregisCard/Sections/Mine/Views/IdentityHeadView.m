//
//  IdentityHeadView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "IdentityHeadView.h"

@interface IdentityHeadView ()
{
    int _type;// 1 实名认证 2 邮寄地址
    int _section;
    
}
@end


@implementation IdentityHeadView

- (CustomPopView *)customPopView {
    if(!_customPopView) {
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?80:60;
        _customPopView=[CustomPopView instanceViewWithFrame:CGRectMake(0, 0, kWindowW-40, height) withMenuType:IdentityVerify];
    }
    return _customPopView;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.tipsLabel.text=LocalizationKey(@"长期");
    self.titleLabel.font=PingFangMediumFont(13);
    self.tipsBtn.hidden=YES;
}

//实名认证
-(void)configDataInSection:(NSInteger)section withtitleArray:(NSArray*)titleArray {
    _type=1;
    self.titleLabel.text=titleArray[section];
    if (section==3||section==4||section==5||section==7||section==8||section==9||section==10) {
        self.tipsBtn.hidden=NO;
    }else{
        self.tipsBtn.hidden=YES;
    }
    _section=(int)section;
}

//邮寄地址
-(void)configCardShipInSection:(NSInteger)section withtitleArray:(NSArray*)titleArray{
    _type=2;
    self.titleLabel.text=titleArray[section];
    if (section==4||section==5) {
        self.tipsBtn.hidden=NO;
    }else{
        self.tipsBtn.hidden=YES;
    }
    _section=(int)section;
}

-(void)editIncomeInSection:(NSInteger)section withtitleArray:(NSArray*)titleArray{
    
    self.titleLabel.text=titleArray[section];
    self.typeBtn.hidden=YES;
    self.tipsLabel.hidden=YES;
}

- (IBAction)tipShow:(UIButton *)sender {
    
    if (_type==1) {
        //实名认证
        if (_section==3) {
            //年薪
            [self.customPopView configTipsString:LocalizationKey(@"最大20字符，支持正整数")];
        }else if(_section==4){
            //账户用途
            [self.customPopView configTipsString:LocalizationKey(@"最大255字符，支持英文、空格")];
        }else if(_section==5){
            //月交易额
            [self.customPopView configTipsString:LocalizationKey(@"最大20字符，支持正整数")];
        }else if(_section==7){
            //州/省
            NSString*stateTipsString=LocalizationKey(@"最大60字符，州/县/省/地区。支持英文、空格。如果国家是美国或加拿大，使用区/县的两位字母代码");
            CGFloat textHeight=[ToolUtil getLabelHeightWithText:stateTipsString width:kWindowW-100 font:[UIFont systemFontOfSize:15] withLineSpacing:3]+1;
            self.customPopView.frame=CGRectMake(0, 0, kWindowW-40, textHeight+40);
            [self.customPopView configTipsString:stateTipsString];
        }else if(_section==8){
            //城市
            [self.customPopView configTipsString:LocalizationKey(@"最大60字符，支持英文、空格")];
        }
        else if(_section==9){
            //地址
            [self.customPopView configTipsString:LocalizationKey(@"最大40字符，支持英文、数字、空格、- 符号")];
        }else if(_section==10){
            //邮编
            [self.customPopView configTipsString:LocalizationKey(@"最大15字符，支持英文、数字")];
        }
        
    }else{
        //邮寄地址
        if(_section==4){
            //区域
            NSString*stateTipsString=LocalizationKey(@"最大60字符，州/县/省/地区。支持英文、空格。如果国家是美国或加拿大，使用区/县的两位字母代码");
            CGFloat textHeight=[ToolUtil getLabelHeightWithText:stateTipsString width:kWindowW-100 font:[UIFont systemFontOfSize:15] withLineSpacing:3]+1;
            self.customPopView.frame=CGRectMake(0, 0, kWindowW-40, textHeight+40);
            [self.customPopView configTipsString:stateTipsString];
        }else if(_section==5){
            //城市
            [self.customPopView configTipsString:LocalizationKey(@"最大60字符，支持英文、空格")];
        }
        
    }
    
    [self.customPopView show];
    
    
}



@end
