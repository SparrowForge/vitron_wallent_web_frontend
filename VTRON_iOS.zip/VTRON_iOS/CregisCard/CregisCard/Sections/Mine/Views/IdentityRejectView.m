//
//  IdentityRejectView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "IdentityRejectView.h"

@implementation IdentityRejectView

+ (IdentityRejectView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"IdentityRejectView" owner:nil options:nil];
    IdentityRejectView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
   
    return view;
}

-(void)configcardholderUI{
    self.boadrView.backgroundColor=[UIColor colorWithHexString:@"#FF6900" alpha:0.06];
    self.reasonLabel.textColor=[UIColor colorWithHexString:@"#FF6900" alpha:1.0];
    self.alertImageV.image=UIIMAGE(@"applyAlertIcon");
    
}
-(void)configcardholderUIForBulkMail{
    self.boadrView.backgroundColor=[UIColor colorWithHexString:@"#FF6900" alpha:0.04];
    self.reasonLabel.textColor=[UIColor colorWithHexString:@"#FA6400" alpha:1.0];
    self.alertImageV.image=UIIMAGE(@"applyAlertIcon");
    
}
@end
