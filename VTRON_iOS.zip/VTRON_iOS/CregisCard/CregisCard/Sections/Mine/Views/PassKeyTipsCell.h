//
//  PassKeyTipsCell.h
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface PassKeyTipsCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIImageView *passkeyIcon;
@property (weak, nonatomic) IBOutlet UIButton *editBtn;
@property (weak, nonatomic) IBOutlet UIImageView *passkeyAlreadyIcon;

-(void)configDataWithTitle:(NSString*)title withDetail:(NSString*)detail withImage:(NSString*)imageName withStyle:(int)style;
@end

NS_ASSUME_NONNULL_END
