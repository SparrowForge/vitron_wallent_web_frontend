//
//  PassKeyDeleteView.h
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

typedef void(^DeleteMemuBlock)(int  type);
NS_ASSUME_NONNULL_BEGIN

@interface PassKeyDeleteView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;

@property (weak, nonatomic) IBOutlet UIButton *keepBtn;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;

@property (nonatomic, copy)   DeleteMemuBlock menublock;
+ (PassKeyDeleteView *)instanceViewWithFrame:(CGRect)Rect;

@end

NS_ASSUME_NONNULL_END
