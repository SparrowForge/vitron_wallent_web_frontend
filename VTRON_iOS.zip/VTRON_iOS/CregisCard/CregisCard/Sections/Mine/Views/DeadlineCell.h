//
//  DeadlineCell.h
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

typedef void(^ DeadlineBlock)(NSString* _Nullable typeString,NSString* _Nullable valueString);
NS_ASSUME_NONNULL_BEGIN

@interface DeadlineCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *beginView;
@property (weak, nonatomic) IBOutlet UIView *endView;
@property (weak, nonatomic) IBOutlet UIButton *startBtn;
@property (weak, nonatomic) IBOutlet UIButton *endBtn;
@property (weak, nonatomic) IBOutlet UITextField *startTF;
@property (weak, nonatomic) IBOutlet UITextField *endTF;
@property (nonatomic, copy)   DeadlineBlock deadlineBlock;
-(void)configDatawithStartTime:(NSString*)startTime withEndTime:(NSString*)endTime;


@end

NS_ASSUME_NONNULL_END
