//
//  AllNameCell.m
//  CregisCard
//
//  Created by sunliang on 2025/10/9.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "AllNameCell.h"

@interface AllNameCell()<UITextFieldDelegate>

@end
@implementation AllNameCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setBorderView:self.firstView];
    [self setBorderView:self.lastView];
    self.firstNameTF.delegate=self;
    self.lastNameTF.delegate=self;
    self.firstNameTF.placeholder=LocalizationKey(@"请输入");
    self.lastNameTF.placeholder=LocalizationKey(@"请输入");
    self.firstNameTF.font=PingFangMediumFont(15);
    self.lastNameTF.font=PingFangMediumFont(15);
    self.firstNameTF.keyboardType=UIKeyboardTypeASCIICapable;
    self.lastNameTF.keyboardType=UIKeyboardTypeASCIICapable;
    [self.firstNameTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    [self.lastNameTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    [self.firstNameTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingDidEnd];
    [self.lastNameTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingDidEnd];
    
    // Initialization code
}



- (void)textFieldChange:(UITextField *)textField {
    if (textField.tag==0) {
        //姓
        if (self.nameBlock) {
            self.nameBlock(@"lastName", textField.text);
        }
    }else{
        //名
        if (self.nameBlock) {
            self.nameBlock(@"firstName", textField.text);
        }
        
    }
   
}


//编辑结束
- (void)textFieldDidEnd:(UITextField *)textField {
    
    if (textField.tag==0) {
        //姓
        if (self.nameEndBlock) {
            self.nameEndBlock(@"lastName", textField.text);
        }
    }else{
        //名
        if (self.nameEndBlock) {
            self.nameEndBlock(@"firstName", textField.text);
        }
        
    }
   
}



//限制最多32个字符
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *currentText = textField.text;
    NSUInteger newLength = [currentText length] + [string length] - range.length;
    return newLength <= 32;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
