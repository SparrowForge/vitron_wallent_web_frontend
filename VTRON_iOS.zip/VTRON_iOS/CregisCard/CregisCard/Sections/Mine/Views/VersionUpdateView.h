//
//  VersionUpdateView.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface VersionUpdateView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIButton *updateBtn;
@property (weak, nonatomic) IBOutlet UILabel *versionLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property(nonatomic,strong)NSDictionary*dic;
+ (VersionUpdateView *)instanceViewWithFrame:(CGRect)Rect;

@end

NS_ASSUME_NONNULL_END
