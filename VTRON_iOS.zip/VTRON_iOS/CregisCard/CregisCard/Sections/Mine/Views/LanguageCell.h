//
//  LanguageCell.h
//  BytesTrack
//
//  Created by sunliang on 2022/5/23.
//  Copyright © 2022 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface LanguageCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *dotView;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageV;

@end

NS_ASSUME_NONNULL_END
