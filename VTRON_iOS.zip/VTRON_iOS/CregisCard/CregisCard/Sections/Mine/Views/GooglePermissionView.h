//
//  GooglePermissionView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

typedef void(^GoogleBlock)(BOOL success);
NS_ASSUME_NONNULL_BEGIN

@interface GooglePermissionView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIView *pswView;
@property (weak, nonatomic) IBOutlet UIView *codeView;
@property (weak, nonatomic) IBOutlet UITextField *googleTF;
@property (weak, nonatomic) IBOutlet UITextField *codeTF;
@property (weak, nonatomic) IBOutlet UIButton *verifyCodeBtn;
@property (weak, nonatomic) IBOutlet UIView *tipsView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *verifyCodeWidth;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property (nonatomic, copy)   GoogleBlock googleBlock;
@property(nonatomic,assign) int type;// 0 开启谷歌验证 1关闭谷歌验证
@property(nonatomic,retain) dispatch_source_t _timer;
+ (GooglePermissionView *)instanceViewWithFrame:(CGRect)Rect;
-(void)showGoogleViewWitype:(int)type success:(void (^)(BOOL success))success;//type 0 开启谷歌验证 1关闭谷歌验证
//重置验证码
-(void)resetVerifyCode;
@end

NS_ASSUME_NONNULL_END
