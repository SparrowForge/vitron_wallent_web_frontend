//
//  LogisticsInfoCell.m
//  CregisCard
//
//  Created by 孙良 on 2024/11/7.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "LogisticsInfoCell.h"

@implementation LogisticsInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentView.backgroundColor=[UIColor whiteColor];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
    // Initialization code
}



//物流信息
-(void)configlogisticsInfoAtIndexPath:(NSIndexPath *)indexPath withTitleArray:(NSArray*)titleArray withContentArray:(NSArray*)contentArray{
    [self.pasteBtn setBackgroundImage:UIIMAGE(@"copy_gray") forState:UIControlStateNormal];
    NSString*contentString=contentArray[indexPath.row];
    if (indexPath.row<titleArray.count-2) {
        self.trailDistance.constant=10;
        self.btnWidth.constant=0;
        self.pasteBtn.hidden=YES;
    }else{
        //物流单号和地址
        if ([NSString stringIsNull:contentString]||[contentString isEqualToString:@"--"]) {
            self.trailDistance.constant=10;
            self.btnWidth.constant=0;
            self.pasteBtn.hidden=YES;
        }else{
            self.trailDistance.constant=20;
            self.btnWidth.constant=17;
            self.pasteBtn.hidden=NO;
        }
       
    }
    self.titleLabel.text=titleArray[indexPath.row];
    self.detailLabel.text=contentString;
    WEAKSELF
    [self.pasteBtn dn_addActionHandler:^{
        [weakSelf copyClick];
    }];
}


//复制
-(void)copyClick{
 
    if (![NSString stringIsNull:self.detailLabel.text]&&![self.detailLabel.text isEqualToString:@"--"]) {
        UIPasteboard *pboard = [UIPasteboard generalPasteboard];
        pboard.string = self.detailLabel.text;
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
