//
//  InviteView.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface InviteView : UIView

@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIView *lineView1;
@property (weak, nonatomic) IBOutlet UIView *lineView2;
@property (weak, nonatomic) IBOutlet UILabel *rewardLabel;
@property (weak, nonatomic) IBOutlet UILabel *personLabel;
@property (weak, nonatomic) IBOutlet UILabel *rewardDetail;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UIView *tipsView;
@property (weak, nonatomic) IBOutlet UIImageView *tipsImageV;
@property (weak, nonatomic) IBOutlet UIView *inviteCodeView;

@property (weak, nonatomic) IBOutlet UIView *inviteLinkView;

@property (weak, nonatomic) IBOutlet UILabel *inviteCodeLabel;
@property (weak, nonatomic) IBOutlet UILabel *inviteLinkLabel;
@property (weak, nonatomic) IBOutlet UILabel *inviteDescribeLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tipsDistance;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *personTitle;
@property (weak, nonatomic) IBOutlet UILabel *personNumTitle;
@property (weak, nonatomic) IBOutlet UILabel *profitTitle;
@property (weak, nonatomic) IBOutlet UILabel *inviteCodeTitle;
@property (weak, nonatomic) IBOutlet UILabel *inviteLinkTitle;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;

+ (InviteView *)instanceViewWithFrame:(CGRect)Rect;
-(void)configUIWithDic:(NSDictionary*)dataDic;
-(void)configUI;
@end

NS_ASSUME_NONNULL_END
