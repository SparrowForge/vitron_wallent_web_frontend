//
//  PassKeyRenameView.h
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"
NS_ASSUME_NONNULL_BEGIN
typedef void(^NameBlock)(NSString* _Nullable name);

@interface PassKeyRenameView : FWPanPopupView

@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak, nonatomic) IBOutlet UIButton *confirmBtn;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIView *nameView;
@property (weak, nonatomic) IBOutlet UILabel *numLabel;
@property (weak, nonatomic) IBOutlet UITextField *nameTF;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (nonatomic, copy) NameBlock nameBlock;

+ (PassKeyRenameView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
