//
//  PassKeyTipsCell.m
//  CregisCard
//
//  Created by sunliang on 2025/3/3.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "PassKeyTipsCell.h"

@implementation PassKeyTipsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)configDataWithTitle:(NSString*)title withDetail:(NSString*)detail withImage:(NSString*)imageName withStyle:(int)style{
    self.titleLabel.text=title;
    self.detailLabel.text=detail;
    self.passkeyIcon.image=UIIMAGE(imageName);
    self.editBtn.hidden=style==0?YES:NO;
    self.passkeyIcon.hidden=style==0?NO:YES;
    self.passkeyAlreadyIcon.hidden=style==0?YES:NO;
}


@end
