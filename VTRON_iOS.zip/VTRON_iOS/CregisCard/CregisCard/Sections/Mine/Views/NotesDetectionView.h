//
//  NotesDetectionView.h
//  CregisCard
//
//  Created by sunliang on 2025/5/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NotesDetectionView : UIView
@property (weak, nonatomic) IBOutlet UILabel *noteNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *noteIcon;
@property (weak, nonatomic) IBOutlet UIImageView *noteTips;
@property (weak, nonatomic) IBOutlet UIButton *noteBtn;

+ (NotesDetectionView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
