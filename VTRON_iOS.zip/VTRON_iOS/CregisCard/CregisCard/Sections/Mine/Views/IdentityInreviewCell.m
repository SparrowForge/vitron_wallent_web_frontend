//
//  IdentityInreviewCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "IdentityInreviewCell.h"
@implementation IdentityInreviewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.statusView.hidden=YES;//默认隐藏
   

    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
