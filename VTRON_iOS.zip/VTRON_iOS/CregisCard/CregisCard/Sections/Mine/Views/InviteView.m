//
//  InviteView.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/5.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "InviteView.h"
#import "InviteRecordController.h"

@implementation InviteView

+ (InviteView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView = [[NSBundle mainBundle] loadNibNamed:@"InviteView" owner:nil options:nil];
    InviteView*view=[nibView objectAtIndex:0];
    [view.boardView setCornerRadius:10.0];
    view.backgroundColor=[UIColor whiteColor];
    view.boardView.backgroundColor=[UIColor whiteColor];
    view.frame=Rect;
    return view;
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.personLabel.font=PingFangMediumFont(29);
    self.rewardLabel.font=PingFangMediumFont(29);
    self.personTitle.text=LocalizationKey(@"人");
    self.personNumTitle.text=LocalizationKey(@"邀请人数");
    self.profitTitle.text=LocalizationKey(@"佣金");
    self.inviteCodeTitle.text=LocalizationKey(@"邀请码");
    self.inviteLinkTitle.text=LocalizationKey(@"邀请链接");
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self drawLineOfDashByCAShapeLayer:self.lineView1 lineLength:2 lineSpacing:2 lineColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.3] lineDirection:YES];
    [self drawLineOfDashByCAShapeLayer:self.lineView2 lineLength:2 lineSpacing:2 lineColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.3] lineDirection:NO];
        
    });
    self.titleLabel.text=LocalizationKey(@"邀请好友");
    NSString *text = LocalizationKey(@"邀请好友注册VTRON卡，开卡即可获得开卡奖励、好友使用卡消费可获得佣金奖励");
    NSDictionary *attributes = @{
        NSFontAttributeName:PingFangMediumFont(15),
        NSForegroundColorAttributeName: [UIColor blackColor]
    };
    // 创建一个可变的富文本字符串
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
    // 查找并加粗“开卡奖励”
    NSRange range1 = [text rangeOfString:LocalizationKey(@"开卡奖励")];
    [attributedText addAttributes:attributes range:range1];
    // 查找并加粗“交易收益”
    NSRange range2 = [text rangeOfString:LocalizationKey(@"佣金奖励")];
    [attributedText addAttributes:attributes range:range2];
    // 设置行间距
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 3;
    paragraphStyle.alignment = NSTextAlignmentCenter; // 设置文字垂直居中对齐
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    self.inviteDescribeLabel.attributedText=attributedText;
   
}

- (void)layoutSubviews {
    [super layoutSubviews];
    //四边添加阴影
    self.boardView.layer.shadowColor = [UIColor lightGrayColor].CGColor;//阴影颜色
    self.boardView.layer.shadowOffset = CGSizeMake(0, 0);//阴影的偏移量
    self.boardView.layer.shadowOpacity = 0.2;//阴影透明度
    self.boardView.layer.shadowRadius = 10.0;//阴影圆角
    self.boardView.clipsToBounds=NO;//这个属性为NO是必须的，不然阴影不会显示

}


/**
 * 通过 CAShapeLayer 方式绘制虚线
 *
 * param lineView: 需要绘制成虚线的view
 * param lineLength: 虚线的宽度
 * param lineSpacing: 虚线的间距
 * param lineColor: 虚线的颜色
 * param lineDirection 虚线的方向 YES 为水平方向， NO 为垂直方向
 **/
- (void)drawLineOfDashByCAShapeLayer:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor lineDirection:(BOOL)isHorizonal {

    CAShapeLayer *shapeLayer = [CAShapeLayer layer];

    [shapeLayer setBounds:lineView.bounds];

    if (isHorizonal) {

        [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame))];

    } else{
        [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame)/2)];
    }

    [shapeLayer setFillColor:[UIColor clearColor].CGColor];
    // 设置虚线颜色为blackColor
    [shapeLayer setStrokeColor:lineColor.CGColor];
    // 设置虚线宽度
    if (isHorizonal) {
        [shapeLayer setLineWidth:CGRectGetHeight(lineView.frame)];
    } else {

        [shapeLayer setLineWidth:CGRectGetWidth(lineView.frame)];
    }
    [shapeLayer setLineJoin:kCALineJoinRound];
    // 设置线宽，线间距
    [shapeLayer setLineDashPattern:[NSArray arrayWithObjects:[NSNumber numberWithInt:lineLength], [NSNumber numberWithInt:lineSpacing], nil]];
    // 设置路径
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 0, 0);

    if (isHorizonal) {
        CGPathAddLineToPoint(path, NULL,CGRectGetWidth(lineView.frame), 0);
    } else {
        CGPathAddLineToPoint(path, NULL, 0, CGRectGetHeight(lineView.frame));
    }

    [shapeLayer setPath:path];
    CGPathRelease(path);
    // 把绘制好的虚线添加上来
    [lineView.layer addSublayer:shapeLayer];
}

- (IBAction)btnClick:(UIButton *)sender {
    if (sender.tag==0) {
        
        if ([NSString stringIsNull:[UserWrapper shareUserInfo].distributorStatus]) {
            return;
        }
        //邀请列表
        [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:[[InviteRecordController alloc]init] animated:YES];
        
    }else if(sender.tag==1){
        //复制邀请码
        if (![NSString stringIsNull:self.inviteCodeLabel.text]) {
            UIPasteboard *pboard = [UIPasteboard generalPasteboard];
            pboard.string = self.inviteCodeLabel.text;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
          
        }
    }else{
        //复制链接
        if (![NSString stringIsNull:self.inviteLinkLabel.text]) {
            UIPasteboard *pboard = [UIPasteboard generalPasteboard];
            pboard.string = self.inviteLinkLabel.text;
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
          
        }
    }
    
    
}


-(void)configUIWithDic:(NSDictionary*)dataDic{
    
    if ([NSString stringIsNull:[UserWrapper shareUserInfo].distributorStatus]) {
        //未开启分销商
        NSString *text = LocalizationKey(@"您还未开启分销商功能，请联系平台客服咨询");
        // 创建段落样式并设置行间距
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.lineSpacing = 3;
        // 创建属性字符串
        NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
        // 添加行间距属性
        [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, text.length)];
        // 添加文字颜色属性
        [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#FF6900" alpha:1.0] range:NSMakeRange(0, text.length)];
        self.tipsLabel.attributedText=attributedText;
   
        self.tipsView.backgroundColor=[UIColor colorWithHexString:@"#FF6900" alpha:0.04];
        self.tipsImageV.image=UIIMAGE(@"applyAlertIcon");
        self.tipsView.hidden=NO;
        self.inviteCodeView.hidden=YES;
        self.inviteLinkView.hidden=YES;
        self.personLabel.text=@"0";
        self.rewardLabel.text=@"0.00";
        self.tipsDistance.constant=40;
    }else{
        if ([[UserWrapper shareUserInfo].distributorStatus intValue]==1) {
            //分销商功能正常
            self.tipsLabel.text=LocalizationKey(@"");
            self.tipsView.hidden=YES;
            self.inviteCodeView.hidden=YES;//一直隐藏
            self.inviteLinkView.hidden=YES;
            self.personLabel.text=[NSString stringWithFormat:@"%@",dataDic[@"merchantDistributorInfoDetailVo"][@"customerNum"]];
            self.rewardLabel.text=[NSString formattedStringWithDouble:[dataDic[@"merchantDistributorInfoDetailVo"][@"distributorAmount"] doubleValue]];
            self.inviteCodeLabel.text=dataDic[@"merchantDistributorInviteVo"][@"inviteCode"];
            self.inviteLinkLabel.text=dataDic[@"merchantDistributorInviteVo"][@"inviteUrl"];
            self.tipsDistance.constant=0;
        }else{
            //分销商功能被禁用
            NSString *text = LocalizationKey(@"分销商权限被禁用，请联系客服处理");
            // 创建段落样式并设置行间距
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            paragraphStyle.lineSpacing = 3;
            // 创建属性字符串
            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
            // 添加行间距属性
            [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, text.length)];
            // 添加文字颜色属性
            [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#EC312C" alpha:1.0] range:NSMakeRange(0, text.length)];
            self.tipsLabel.attributedText=attributedText;

            self.tipsView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.04];
            self.tipsView.hidden=NO;
            self.tipsImageV.image=UIIMAGE(@"failIcon");
            self.inviteCodeView.hidden=YES;
            self.inviteLinkView.hidden=YES;
            self.personLabel.text=[NSString stringWithFormat:@"%@",dataDic[@"merchantDistributorInfoDetailVo"][@"customerNum"]];
            self.rewardLabel.text=[NSString formattedStringWithDouble:[dataDic[@"merchantDistributorInfoDetailVo"][@"distributorAmount"] doubleValue]];
            self.tipsDistance.constant=40;
        }
       
    }
    
    
}


-(void)configUI{
    
    if ([NSString stringIsNull:[UserWrapper shareUserInfo].distributorStatus]) {
        //未开启分销商
        NSString *text = LocalizationKey(@"您还未开启分销商功能，请联系平台客服咨询");
        // 创建段落样式并设置行间距
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.lineSpacing = 3;
        // 创建属性字符串
        NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
        // 添加行间距属性
        [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, text.length)];
        // 添加文字颜色属性
        [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#FF6900" alpha:1.0] range:NSMakeRange(0, text.length)];
        self.tipsLabel.attributedText=attributedText;
        self.tipsImageV.image=UIIMAGE(@"applyAlertIcon");
        self.tipsView.hidden=NO;
        self.inviteCodeView.hidden=YES;
        self.inviteLinkView.hidden=YES;
        self.personLabel.text=@"0";
        self.rewardLabel.text=@"0.00";
        self.tipsDistance.constant=40;
        self.topDistance.constant=18;
    }else{
        if ([[UserWrapper shareUserInfo].distributorStatus intValue]==1) {
            //分销商功能正常
            self.tipsLabel.text=LocalizationKey(@"");
            self.tipsView.hidden=YES;
            self.inviteCodeView.hidden=YES;//一直隐藏
            self.inviteLinkView.hidden=YES;
            self.tipsDistance.constant=0;
            self.topDistance.constant=0;
        }else{
            //分销商功能被禁用
            NSString *text = LocalizationKey(@"分销商权限被禁用，请联系客服处理");
            // 创建段落样式并设置行间距
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
            paragraphStyle.lineSpacing = 3;
            // 创建属性字符串
            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
            // 添加行间距属性
            [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, text.length)];
            // 添加文字颜色属性
            [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#EC312C" alpha:1.0] range:NSMakeRange(0, text.length)];
            self.tipsLabel.attributedText=attributedText;

            self.tipsView.hidden=NO;
            self.tipsImageV.image=UIIMAGE(@"failIcon");
            self.inviteCodeView.hidden=YES;
            self.inviteLinkView.hidden=YES;
            self.tipsDistance.constant=40;
            self.topDistance.constant=18;
        }
       
    }
    
    
}



@end
