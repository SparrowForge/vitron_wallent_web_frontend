//
//  NotificationAuthView.h
//  CregisCard
//
//  Created by sunliang on 2025/7/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"
#import "NotificationModel.h"


typedef void(^NotificationAuthBlock)(int type);//type 0 拒绝 1 同意
NS_ASSUME_NONNULL_BEGIN

@interface NotificationAuthView : FWPanPopupView
+ (NotificationAuthView *)instanceViewWithFrame:(CGRect)Rect;
@property(nonatomic,strong)NotificationModel*model;
@property (nonatomic, copy) NotificationAuthBlock authBlock;

@end

NS_ASSUME_NONNULL_END
