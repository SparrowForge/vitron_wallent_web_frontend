//
//  GoogleStatusCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/14.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface GoogleStatusCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIButton *statusBtn;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

-(void)setButtonStyle;
@end

NS_ASSUME_NONNULL_END
