//
//  OrderSearchView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/8.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SarchTFBlock)(NSString* _Nullable text);
NS_ASSUME_NONNULL_BEGIN

@interface OrderSearchView : UIView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UITextField *inputTF;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomDistance;

@property (nonatomic, copy)   SarchTFBlock searchblock;
+ (OrderSearchView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
