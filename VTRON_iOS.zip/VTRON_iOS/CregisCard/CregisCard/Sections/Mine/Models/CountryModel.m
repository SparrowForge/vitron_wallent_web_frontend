//
//  CountryModel.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CountryModel.h"

@implementation CountryModel
- (NSDictionary *)utr_modelMapPropertyNames{
    return @{@"ID" : @"id",@"cnName" : @"cname",@"usName" : @"name"
      };
}
@end
