//
//  DetectionModel.m
//  CregisCard
//
//  Created by sunliang on 2025/5/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "DetectionModel.h"

@implementation DetectionModel

@end
