//
//  OrderStatusModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderStatusModel : NSObject
@property(nonatomic,copy)   NSString*name;
@property(nonatomic,copy)   NSString*status;
@property(nonatomic,copy)   NSString*type;
@property(nonatomic,copy)   NSString*createTimeStart;
@property(nonatomic,copy)   NSString*createTimeEnd;
@end

NS_ASSUME_NONNULL_END
