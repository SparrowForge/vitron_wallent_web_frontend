//
//  NotificationModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NotificationModel : NSObject

@property(nonatomic,copy)   NSString*type;//类型：1. 3ds 2.激活码
@property(nonatomic,copy)   NSString*cardNo;
@property(nonatomic,copy)   NSString*opt;//数字码
@property(nonatomic,copy)   NSString*cardId;
@property(nonatomic,assign) double amount;
@property(nonatomic,copy)   NSString*currency;
/**
    * 已读状态：0未读，1已读
    */
@property(nonatomic,copy)   NSString*authStatus;
@property(nonatomic,copy)   NSString*createTime;

@end

NS_ASSUME_NONNULL_END
