//
//  CountryModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/6.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CountryModel : NSObject

@property(nonatomic,copy)NSString*cnName;
@property(nonatomic,copy)NSString*usName;
@property(nonatomic,copy)NSString*code;
@property(nonatomic,copy)NSString*ID;
@property(nonatomic,copy)NSString*abbr2;
@property(nonatomic,copy)NSString*individual;//单张邮费价格
@property(nonatomic,copy)NSString*eco;//2-50张价格
@property(nonatomic,copy)NSString*mass;//51-100张价格

/***筛选城市用的***/
@property(nonatomic,copy)NSString*cityName;
@property(nonatomic,copy)NSString*cityCode;
@property(nonatomic,copy)NSString*countryCode;

@end

NS_ASSUME_NONNULL_END
