//
//  NotificationModel.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NotificationModel.h"

@implementation NotificationModel

@end
