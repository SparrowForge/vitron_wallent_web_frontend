//
//  InviteModel.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/15.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface InviteModel : NSObject
@property(nonatomic,copy)   NSString*headUrl;
@property(nonatomic,copy)   NSString*applyCard;
@property(nonatomic,copy)   NSString*applyCardWay;
@property(nonatomic,copy)   NSString*outCardFeeWay;
@property(nonatomic,copy)   NSString*merchantId;
@property(nonatomic,copy)   NSString*outCardFeeRate;
@property(nonatomic,copy)   NSString*consumerFeeRate;
@property(nonatomic,copy)   NSString*consumerFeeWay;
@property(nonatomic,copy)   NSString*consumerFee;
@property(nonatomic,copy)   NSString*applyCardRate;
@property(nonatomic,copy)   NSString*outCardFee;
@property(nonatomic,copy)NSString*email;
@property(nonatomic,copy)NSString*createTime;
@end

NS_ASSUME_NONNULL_END
