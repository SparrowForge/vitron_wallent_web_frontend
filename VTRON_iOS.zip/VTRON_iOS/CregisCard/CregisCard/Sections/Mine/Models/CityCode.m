//
//  CityCode.m
//  CregisCard
//
//  Created by sunliang on 2025/10/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CityCode.h"

@implementation CityCode

- (NSDictionary *)utr_modelMapPropertyNames{
    return @{@"ID" : @"id"
      };
}

@end
