//
//  OrderStatusModel.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "OrderStatusModel.h"

@implementation OrderStatusModel

@end
