//
//  OrderRecordModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/7.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderRecordModel : NSObject

@property(nonatomic,copy)NSString*ID;
@property(nonatomic,copy)NSString*address;
@property(nonatomic,copy)NSString*status;//1. 确认中 2. 已完成 3.失败 4.待审核

@property(nonatomic,copy)   NSString*realName;
@property(nonatomic,copy)   NSString*createTimeEnd;
@property(nonatomic,assign) double frozenAmount;//冻结金额
@property(nonatomic,copy)   NSString*alias;
@property(nonatomic,copy)   NSString*hashId;
/**
 最新类型如下：
 top_up（充值）
 correction（冲正）
 transfer（转账）
 receive（收款）
 withdrawal（提币）
 create_card（卡片申请）
 deposit_card（卡片充值）
 withdraw_card（卡片提现）
 program_fee_card（卡手续费）
 **/
@property(nonatomic,copy)   NSString*type;
///类型 1充值、2提币、3转账、4冲正、5交易、6卡申请、7交易退款、8冻结、9解冻、10收款 11交易收益 12 开卡收益 13交易退款收益 14卡提款
@property(nonatomic,copy)   NSString*email;
@property(nonatomic,assign) double realAmount;//实际到账金额
//@property(nonatomic,assign) double fee;//手续费
@property(nonatomic,assign) double atmFee;//手续费
@property(nonatomic,assign) double fxFee;//手续费
@property(nonatomic,assign) double refundFee;//退款手续费
@property(nonatomic,assign) double tradeFee;//交易手续费
@property(nonatomic,assign) double txnAmount;//交易金额
@property(nonatomic,assign) double amount;
@property(nonatomic,assign) double totalFee;//总手续费
@property(nonatomic,assign) double fee;
@property(nonatomic,assign) double authAmount;
@property(nonatomic,assign) double billAmount;
@property(nonatomic,copy)   NSString*settlementAmount;//结算金额
@property(nonatomic,copy)   NSString*createTime;
@property(nonatomic,copy)   NSString*cardNo;
@property(nonatomic,copy)   NSString*orderId;
@property(nonatomic,copy)   NSString*createTimeStart;
//账户模块用到
@property(nonatomic,copy)   NSString*tradeId;
@property(nonatomic,copy)   NSString*transId;
@property(nonatomic,assign)   double predictAmount;//预估到账
@property(nonatomic,copy)   NSString*currency;
@property(nonatomic,copy)   NSString*authCurrency;
@property(nonatomic,copy)   NSString*settlementCurrency;
@property(nonatomic,copy)   NSString*totalCurrency;
@property(nonatomic,copy)   NSString*feeCurrency;//卡流水的交易和退款的手续费
@property(nonatomic,copy)   NSString*billCurrency;
@property(nonatomic,copy)   NSString*txnCurrency;
@property(nonatomic,copy)   NSString*remark;//提币拒绝原因
@property(nonatomic,copy)   NSString*transEmail;//交易方
@property(nonatomic,assign) double totalAmount;//总计,订单流水使用

@property(nonatomic,copy)   NSString*mcType;//1.虚拟卡 2.实体卡
@property(nonatomic,copy)   NSString*consumerMerchantName;//商户名称
@property(nonatomic,copy)   NSString*tradeChannel;//交易渠道；ATM POS ECOMMERCE VISA_DIRECT
@property(nonatomic,copy)   NSString*consumerMerchantCountry;//交易地区；
@property(nonatomic,copy)   NSString*consumerMerchantCity;//交易地区；
@property(nonatomic,copy)   NSString*orderNo;//渠道单号；
@property(nonatomic,copy)   NSString*relationOrderId;//关联单号
@property(nonatomic,copy)   NSString*shipType;//卡邮寄类型：single,bulk
@property(nonatomic,copy)   NSString*bulkshipId;//批量邮寄id
@property(nonatomic,copy)   NSString*bulkshipCount;//批量邮寄的数量
@property(nonatomic,copy)   NSString*cardType;
@property(nonatomic,copy)   NSString*firstName;
@property(nonatomic,copy)   NSString*lastName;
@property(nonatomic,copy)   NSString*areaCode;
@property(nonatomic,copy)   NSString*phone;
@property(nonatomic,copy)   NSString*postalCode;
@property(nonatomic,copy)   NSString*country;
@property(nonatomic,copy)   NSString*city;
@property(nonatomic,copy)   NSString*zone;
@property(nonatomic,copy)   NSString*line;
@property(nonatomic,copy)   NSString*mcc;
@property(nonatomic,copy)   NSString*addressChain;//网络
@property(nonatomic,copy)   NSString*withdrawStatus;//提现审核状态 0 待审核 1.审核通过 2.审核拒绝

@property(nonatomic,copy)   NSString*subType;//手续费类型
@end

NS_ASSUME_NONNULL_END
