//
//  InviteModel.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/15.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "InviteModel.h"

@implementation InviteModel

@end
