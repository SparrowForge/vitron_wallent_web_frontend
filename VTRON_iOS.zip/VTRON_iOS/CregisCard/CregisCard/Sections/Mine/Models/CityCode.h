//
//  CityCode.h
//  CregisCard
//
//  Created by sunliang on 2025/10/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CityCode : NSObject
@property(nonatomic,copy)NSString*ID;
@property(nonatomic,copy)NSString*countryCode;
@property(nonatomic,copy)NSString*cityCode;
@property(nonatomic,copy)NSString*cityName;
@property(nonatomic,copy)NSString*parentCode;

@end

NS_ASSUME_NONNULL_END
