//
//  DetectionModel.h
//  CregisCard
//
//  Created by sunliang on 2025/5/21.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

/**
 网络诊断
 */
#import <Foundation/Foundation.h>



@interface DetectionModel : NSObject
@property(nonatomic,copy)   NSString*iconName;
@property(nonatomic,copy)   NSString*name;
@property(nonatomic,copy)   NSString*detail;
@property(nonatomic,copy)   NSString*delayTime;
@property(nonatomic,assign)   int iconStatus;//0 还未检测 1检测中 2正常 3失败

@end
