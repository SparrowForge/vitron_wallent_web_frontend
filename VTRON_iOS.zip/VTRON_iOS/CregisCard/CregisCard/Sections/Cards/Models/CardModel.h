//
//  CardModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/21.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CardModel : NSObject

/**
 01：ACTIVE（正常）  02：CONTROL（管控）  03：PENDING（等待）  04：FROZEN（冻结）    05：INACTIVE（销卡）
 */

@property(nonatomic,copy)NSString*status;
@property(nonatomic,copy)NSString*cardId;
@property(nonatomic,copy)NSString*cardType;
@property(nonatomic,copy)NSString*cardNo;
@property(nonatomic,copy)NSString*type;//1.虚拟卡，2实体卡
@property(nonatomic,copy)NSString*alias;
@property(nonatomic,copy)NSString*belongingPlace;//归属地
@property(nonatomic,copy)NSString*toEmail;
@property(nonatomic,copy)NSString*createTime;
@end

NS_ASSUME_NONNULL_END
