//
//  BinModel.h
//  CregisCard
//
//  Created by 孙良 on 2023/12/4.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BinModel : NSObject
@property(nonatomic,copy)NSString*cardNo;
@property(nonatomic,copy)NSString*baseCancelFeeWay;
@property(nonatomic,copy)NSString*baseCardFeeWay;
@property(nonatomic,copy)NSString*baseConsumeFeeWay;
@property(nonatomic,copy)NSString*currency;
@property(nonatomic,copy)NSString*baseRechargeFeeWay;//基础充值费率收费方式：1.固定 2.比例 3.固定+比例
@property(nonatomic,assign)double  baseRechargeFeeRate;//基础充值费率
@property(nonatomic,copy)NSString*baseRefundFeeWay;
@property(nonatomic,copy)NSString*bin;
@property(nonatomic,copy)NSString*cardType;//Visa,MasterCard
@property(nonatomic,copy)NSString*type;//1.虚拟卡，2实体卡
@property(nonatomic,copy)NSString*status;
@property(nonatomic,assign)double baseRechargeFee;
@property(nonatomic,assign)double baseRefundFee;
@property(nonatomic,assign)double baseCardFee;//虚拟卡基础开卡费固定值
@property(nonatomic,assign)double applyCard;//开卡加点固定值

@property(nonatomic,assign)double baseCancelFee;
@property(nonatomic,assign)double baseCardFeeRate;//基础开卡费率
@property(nonatomic,assign)double minRechargeAmount;//最低充值金额
@property(nonatomic,copy)NSString*ID;
@property(nonatomic,copy)NSString*remark;
@property(nonatomic,copy)NSString*endDate;
@property(nonatomic,copy)NSString*cardUserFeat;//持卡人 0 不需要 1需要
@property(nonatomic,strong)NSDictionary*state;
@property(nonatomic,copy)  NSString*cardUserInfoId;
@property(nonatomic,copy)
/**
     * 持卡人状态,null:未申请    INACTIVE,ACTIVE,PENDING
     */NSString*cardHolderStatus;//持卡人状态
@property(nonatomic,copy)  NSString*cardHolderType;// 持卡人类型，v1,v2,空代表不需要持卡人
@property(nonatomic,assign)double applyCardMinAmount;//开卡充值最低额度
@property(nonatomic,assign)double applyCardMaxAmount;//开卡充值最高额度
/**
  * 充值收费方式 1.固定 2.比例 3.固定+比例
  */
@property(nonatomic,copy)NSString*inCardFeeWay;
/**
     * 充值加点费率
     */
@property(nonatomic,assign)double inCardFeeRate;
/**
     * 充值加点固定值
     */
@property(nonatomic,assign)double inCardFee;

@property(nonatomic,copy)NSString*supportPhysicalCard;//是否支持物理卡：0不支持  1支持

@property(nonatomic,assign)double basePhysicalCardFee;//物理卡基础开卡费固定值
@property(nonatomic,assign)double basePhysicalCardFeeRate;// 物理卡基础开卡费费率
@property(nonatomic,copy)NSString*basePhysicalCardFeeWay;//物理卡基础开卡费收费方式：1.固定 2.比例 3.固定+比例


@end

NS_ASSUME_NONNULL_END
