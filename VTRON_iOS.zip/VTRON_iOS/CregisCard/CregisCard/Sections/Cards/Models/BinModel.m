//
//  BinModel.m
//  CregisCard
//
//  Created by 孙良 on 2023/12/4.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BinModel.h"

@implementation BinModel

- (NSDictionary *)utr_modelMapPropertyNames{
    return @{@"ID" : @"id"
      };
}

@end
