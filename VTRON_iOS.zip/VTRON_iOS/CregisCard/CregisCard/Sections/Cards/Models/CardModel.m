//
//  CardModel.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/21.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CardModel.h"

@implementation CardModel

@end
