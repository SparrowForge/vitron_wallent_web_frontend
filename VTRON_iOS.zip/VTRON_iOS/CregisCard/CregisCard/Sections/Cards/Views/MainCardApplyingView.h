//
//  MainCardApplyingView.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/1.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BinModel.h"

typedef void(^BinBlock)(BinModel*_Nullable model);
typedef void(^RefreshBlock)(void);

NS_ASSUME_NONNULL_BEGIN

@interface MainCardApplyingView : UIView

+ (MainCardApplyingView *)instanceViewWithFrame:(CGRect)Rect;
@property(nonatomic,strong)NSArray*dataArray;
@property (nonatomic, copy) BinBlock binBlock;
@property (nonatomic, copy) RefreshBlock refreshBlock;
-(void)hideTopAlertView;
-(void)showTopAlertViewwithCount:(NSString*)count;
-(void)resetSegmentView;
//获取当前选择的是虚拟卡还是实体卡
-(int)getCurrentSelectedCardType;
-(void) setSegmentBackViewHidden:(BOOL)isHidden;
@end

NS_ASSUME_NONNULL_END
