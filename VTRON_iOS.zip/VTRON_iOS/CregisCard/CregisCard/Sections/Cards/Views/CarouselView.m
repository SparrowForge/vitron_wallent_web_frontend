//
//  CarouselView.m
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CarouselView.h"

@interface CarouselView () <UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) NSArray<UIView *> *cards;
@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, assign) CGFloat cardWidth;
@property (nonatomic, assign) CGFloat cardSpacing;

@end

@implementation CarouselView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupScrollView];
    }
    
    return self;
}

- (void)setupScrollView {
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    self.scrollView.pagingEnabled = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.delegate = self;
    self.scrollView.decelerationRate = UIScrollViewDecelerationRateFast;
    [self addSubview:self.scrollView];
    self.cardSpacing = 24;
    self.cardWidth = self.bounds.size.width * 0.55;
}

#pragma mark - 设置卡片
- (void)setCards:(NSArray<UIView *> *)cards {
    _cards = cards;
    
    // 清空旧卡片
    for (UIView *subview in self.scrollView.subviews) {
        [subview removeFromSuperview];
    }
    
    if (cards.count == 0) return;
    
    for (int i = 0; i < cards.count; i++) {
        UIView *card = cards[i];
        CGFloat x = (self.cardWidth + self.cardSpacing) * i + (self.bounds.size.width - self.cardWidth) / 2.0;
        card.frame = CGRectMake(x, 0, self.cardWidth, self.bounds.size.height);
        card.userInteractionEnabled = YES;
        [self.scrollView addSubview:card];
        
        // 点击手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cardTapped:)];
        [card addGestureRecognizer:tap];
        
        // 蒙版
        UIView *maskView = [[UIView alloc] initWithFrame:card.bounds];
        maskView.backgroundColor = [UIColor colorWithHexString:@"#FFFFFF" alpha:0.9];
        maskView.tag = 999;
        [card addSubview:maskView];
    }
    
    CGFloat contentWidth = (self.cardWidth + self.cardSpacing) * cards.count + (self.bounds.size.width - self.cardWidth);
    self.scrollView.contentSize = CGSizeMake(contentWidth, self.bounds.size.height);
    
    self.currentIndex = 0;
    [self.scrollView setContentOffset:CGPointZero animated:NO];
    
    // 更新蒙版
    [self updateMaskForCurrentIndex];
}

#pragma mark - 点击卡片
- (void)cardTapped:(UITapGestureRecognizer *)gesture {
    UIView *tappedCard = gesture.view;
    NSInteger tappedIndex = [self.scrollView.subviews indexOfObject:tappedCard];
    if (tappedIndex == NSNotFound) return;
    
    self.currentIndex = tappedIndex;
    
    CGFloat targetOffset = (self.cardWidth + self.cardSpacing) * tappedIndex;
    [self.scrollView setContentOffset:CGPointMake(targetOffset, 0) animated:YES];
    
    [self updateMaskForCurrentIndex];
    
    if (self.didSelectCardAtIndex) {
        self.didSelectCardAtIndex(tappedIndex);
    }
}

#pragma mark - 刷新数据
- (void)reloadCards:(NSArray<UIView *> *)newCards {
    [self setCards:newCards];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [self updateCurrentIndex];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (!decelerate) {
        [self updateCurrentIndex];
    }
}

#pragma mark - 更新当前页索引
- (void)updateCurrentIndex {
    CGFloat totalCardWidth = self.cardWidth + self.cardSpacing;
    CGFloat offsetX = self.scrollView.contentOffset.x;
    NSInteger page = round(offsetX / totalCardWidth);
    
    page = MAX(0, MIN(page, self.cards.count - 1)); // 防止越界
    self.currentIndex = page;
    
    CGFloat targetOffset = totalCardWidth * page;
    [self.scrollView setContentOffset:CGPointMake(targetOffset, 0) animated:YES];
    
    [self updateMaskForCurrentIndex];
    
    if (self.didSelectCardAtIndex) {
        self.didSelectCardAtIndex(page);
    }
}

#pragma mark - 更新蒙版
- (void)updateMaskForCurrentIndex {
    for (NSInteger i = 0; i < self.scrollView.subviews.count; i++) {
        UIView *card = self.scrollView.subviews[i];
        UIView *maskView = [card viewWithTag:999];
        if (!maskView) continue;
        
        maskView.alpha = (i == self.currentIndex) ? 0 : 1;
    }
}

#pragma mark - 更新 CarouselView frame
- (void)updateFrame:(CGRect)newFrame {
    // 更新自身 frame
    self.frame = newFrame;
    self.scrollView.frame = self.bounds;
    
    // 重新计算卡片宽度和间距
    self.cardSpacing = 14;
    self.cardWidth = self.bounds.size.width - 14 * 4;
    
    // 根据当前 cards 重新布局
    if (self.cards.count == 0) return;
    
    for (int i = 0; i < self.cards.count; i++) {
        UIView *card = self.cards[i];
        CGFloat x = (self.cardWidth + self.cardSpacing) * i +
                    (self.bounds.size.width - self.cardWidth) / 2.0;
        card.frame = CGRectMake(x, 0, self.cardWidth, self.bounds.size.height);

        UIView *maskView = [card viewWithTag:999];
        if (maskView) {
            maskView.frame = card.bounds;
        }
    }

    CGFloat contentWidth = (self.cardWidth + self.cardSpacing) * self.cards.count +
                           (self.bounds.size.width - self.cardWidth);
    self.scrollView.contentSize = CGSizeMake(contentWidth, self.bounds.size.height);

    // 重新滚动到当前 index 位置
    CGFloat targetOffset = (self.cardWidth + self.cardSpacing) * self.currentIndex;
    [self.scrollView setContentOffset:CGPointMake(targetOffset, 0) animated:NO];

    // 更新蒙版状态
    [self updateMaskForCurrentIndex];
}
@end
