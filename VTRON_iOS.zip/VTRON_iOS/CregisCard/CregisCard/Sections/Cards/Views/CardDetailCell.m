//
//  CardDetailCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/17.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CardDetailCell.h"

@implementation CardDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
  
    // Initialization code
}

-(void)configDataWithTitle:(NSString*)title withContent:(NSString*)content AtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0&&indexPath.row==0) {
//        self.tipsIcon.hidden=NO;
//        self.trailDistance.constant=24;
        self.tipsIcon.hidden=YES;
        self.trailDistance.constant=-4;
    }else{
        self.tipsIcon.hidden=YES;
        self.trailDistance.constant=-4;
    }
    self.titleLabel.text=title;
    self.detailLabel.text=content;
   
    if (indexPath.row==2) {
        //卡状态
        self.detailLabel.textColor=[self getStatusLebelBoardColorWithStatus:content];
        self.backView.backgroundColor=[[self getStatusLebelBoardColorWithStatus:content] colorWithAlphaComponent:0.1];
        self.insideDistance.constant=8;
        self.detailLabel.font=[UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    }else{
        self.detailLabel.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        self.backView.backgroundColor=[UIColor clearColor];
        self.insideDistance.constant=0;
        self.detailLabel.font=[UIFont systemFontOfSize:17 weight:UIFontWeightSemibold];
    }
    
}


//根据状态获取当前状态文字和边框颜色
-(UIColor*)getStatusLebelBoardColorWithStatus:(NSString*)status{
    
    if ([status isEqualToString:LocalizationKey(@"使用中")]) {
        return [UIColor colorWithHexString:@"#6DD400" alpha:1.0];
    }else{
        return [UIColor colorWithHexString:@"#EC312C" alpha:1.0];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
