//
//  ApplCardAnimateView.h
//  CregisCard
//
//  Created by sunliang on 2025/11/18.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ApplCardAnimateView : UIView
@property (weak, nonatomic) IBOutlet UIView *topAlertView;
@property (weak, nonatomic) IBOutlet UILabel *countLabel;
@property (weak, nonatomic) IBOutlet UIView *cardBackView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *TopAlertViewH;

+ (ApplCardAnimateView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
