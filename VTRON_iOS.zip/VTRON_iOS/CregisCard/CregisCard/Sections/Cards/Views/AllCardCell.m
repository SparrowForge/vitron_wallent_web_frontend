//
//  AllCardCell.m
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "AllCardCell.h"

@implementation AllCardCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.dotView setCornerRadius:3];
    self.flagLabel.text=LocalizationKey(@"当前");
    // Initialization code
}

-(void)setModel:(CardModel *)model{
    
    _model=model;
    
    if ([model.type intValue]==1) {
        //虚拟卡
        if ([model.status isEqualToString:@"01"]) {
            //激活状态
            self.backViewImageV.image=UIIMAGE(@"xuni_detail");
            
        }else{
            //其他状态
            self.backViewImageV.image=UIIMAGE(@"xunizhuxiao_detail");
            
        }
        
        
        
    }else{
       //实体卡
        if ([model.status isEqualToString:@"01"]) {
            //激活状态
            self.backViewImageV.image=UIIMAGE(@"shiti_detail");
            
        }else{
            //其他状态
            self.backViewImageV.image=UIIMAGE(@"shitizhuxiao_detail");
            
        }
        
    }
    NSString*flagImageString=[[model.cardType uppercaseString] isEqualToString:@"VISA"]?@"visa_icon":@"visa_bottomIcon";
    self.tipsIcon.image=UIIMAGE(flagImageString);
    NSString*cardNo=model.cardNo;
    self.cardNumLabel.text=[NSString stringWithFormat:@"....%@",[cardNo substringFromIndex:cardNo.length-4]];
    NSString*cardType=[model.type intValue]==1?LocalizationKey(@"虚拟卡"):LocalizationKey(@"实体卡");
    if ([NSString stringIsNull:model.alias]) {
        self.cardTypeLabel.text=cardType;
    }else{
        self.cardTypeLabel.text=[NSString stringWithFormat:@"%@ | %@",cardType,[NSString repalceNULLWithemptyString:model.alias]];
    }
    if ([model.status isEqualToString:@"01"]) {
        //激活
        self.statusLabel.text=LocalizationKey(@"激活");
        self.dotView.backgroundColor=[UIColor colorWithHexString:@"#6DD400" alpha:1.0];
    }else if ([model.status isEqualToString:@"05"]){
        //注销
        self.statusLabel.text=LocalizationKey(@"注销");
        self.dotView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2];
    }else if ([model.status isEqualToString:@"04"]){
        //冻结
        self.statusLabel.text=LocalizationKey(@"冻结");
        self.dotView.backgroundColor=[UIColor colorWithHexString:@"#F7B500" alpha:1.0];
    }else if ([model.status isEqualToString:@"03"]){
        //未激活
        self.statusLabel.text=LocalizationKey(@"未激活");
        self.dotView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0];
    }
  
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
