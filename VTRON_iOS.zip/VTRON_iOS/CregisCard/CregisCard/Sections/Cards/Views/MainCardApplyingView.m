//
//  MainCardApplyingView.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/1.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "MainCardApplyingView.h"
#import "CarouselView.h"
#import "LogoRefreshGifHeader.h"
#import "SelectCardView.h"
#import "CustomSegmentView.h"
#import "ApplyCardCell.h"
#import "ApplyIntroductionCell.h"
#import "IdentityRejectView.h"
#import "TABAnimated.h"
#import "ApplCardAnimateView.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
@interface MainCardApplyingView()<UITableViewDelegate,UITableViewDataSource>{
   
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *segmentBackView;
@property(nonatomic,strong) CarouselView*carousel;
@property(nonatomic,strong) NSArray *virtuaArray;
@property(nonatomic,strong) NSArray *physicalArray;
@property(nonatomic,strong) NSArray *titleArray;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) CustomSegmentView *segment;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *segmentWid;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *segmentViewHeight;

@property(nonatomic,strong) UIView *headerContainer;
@property(nonatomic,strong)   ApplCardAnimateView*holderHeadView;
@end



@implementation MainCardApplyingView

+ (MainCardApplyingView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"MainCardApplyingView" owner:nil options:nil];
    MainCardApplyingView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.segmentWid.constant=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?300:200;
    return view;
}


-(void)awakeFromNib{
    [super awakeFromNib];
     
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.tableView registerNib:[UINib nibWithNibName:@"ApplyCardCell" bundle:nil] forCellReuseIdentifier:@"ApplyCardCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"ApplyIntroductionCell" bundle:nil] forCellReuseIdentifier:@"ApplyIntroductionCell"];
    self.headerContainer = [[UIView alloc] init];
    self.headerContainer.backgroundColor = [UIColor whiteColor];
    self.headerContainer.frame =CGRectMake(0, 0, kWindowW, (kWindowW-14*4)*430/684.00+20);
    self.holderHeadView=[ApplCardAnimateView instanceViewWithFrame:self.headerContainer.bounds];
    [self.headerContainer addSubview:self.holderHeadView];
    self.carousel=[[CarouselView alloc]initWithFrame:CGRectMake(0, 10, kWindowW, (kWindowW-14*4)*430/684.00)];
   
    WEAKSELF
    self.carousel.didSelectCardAtIndex = ^(NSInteger index) {
        NSLog(@"当前选中卡片序号：%ld", (long)index);
        [weakSelf configUIWithIndex:index];
    };
    [self.headerContainer addSubview:self.carousel];
   
    self.tableView.tableHeaderView = self.headerContainer;
    self.topDistance.constant=30;
    self.tableView.tabAnimated= [TABTableAnimated animatedWithCellClass:[ApplyCardCell class] cellHeight:60];
    self.tableView.tabAnimated.showTableHeaderView = YES;//表头动画
    [self.tableView tab_startAnimation];
    //[TABAnimated sharedAnimated].openAnimationTag = YES;
    self.headerContainer.tabAnimated.adjustBlock = ^(TABComponentManager * _Nonnull manager) {
        manager.animation(0).remove();//移除动画
    };
    self.tableView.tableFooterView=[UIView new];
    [self headRefreshWithScrollerView:self.tableView];

    //self.titleArray=@[LocalizationKey(@"开卡费"),LocalizationKey(@"持卡人"),LocalizationKey(@"卡片介绍"),@""];
   // self.contentArray=[@[@"",@"",@"",@""] mutableCopy];
    //[self.tableView reloadData];
   
  
}

- (void)headRefreshWithScrollerView:(UIScrollView *)scrol{
   
    WEAKSELF
    __weak UIScrollView*wealkSelfScrol=scrol;
    LogoRefreshGifHeader*mj_header = [LogoRefreshGifHeader headerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf refreshHeaderAction];
            [wealkSelfScrol.mj_header endRefreshing];
        });
    }];

    mj_header.stateLabel.hidden=YES;
    mj_header.lastUpdatedTimeLabel.hidden = YES;//最后更新时间
    scrol.mj_header =mj_header;
    scrol.mj_header.automaticallyChangeAlpha = YES;
   
}

//下拉刷新
- (void)refreshHeaderAction{
    if (self.refreshBlock) {
        self.refreshBlock();
    }
}

-(void)setDataArray:(NSArray *)dataArray{
   
    _dataArray=dataArray;
    [self.tableView tab_endAnimation];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.tableView.tabAnimated.state=TABViewAnimationEnd;
 
    });
    [self configEmptyViewForTableView];
    self.holderHeadView.cardBackView.hidden=dataArray.count>0?YES:NO;
    self.segmentViewHeight.constant=dataArray.count>0?40:0.01;
    if (dataArray.count>0) {
        self.titleArray=@[LocalizationKey(@"开卡费"),LocalizationKey(@"持卡人"),LocalizationKey(@"卡片介绍"),@""];
        self.contentArray=[@[@"",@"",@"",@""] mutableCopy];
   
    }
    
    //延迟执行
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // NSPredicate *predicate_v = [NSPredicate predicateWithFormat:@"type == %d", 1];//虚拟卡
         NSPredicate *predicate_a = [NSPredicate predicateWithFormat:@"supportPhysicalCard == %d", 1];//实体卡
         self.virtuaArray = dataArray;
         self.physicalArray = [dataArray filteredArrayUsingPredicate:predicate_a];
         //默认显示虚拟卡
         if (self.virtuaArray.count==0) {
             [self reloadShowCardWithDataArray:self.physicalArray withType:2];
         }else{
             [self reloadShowCardWithDataArray:self.virtuaArray withType:1];
         }
        
         if (!self.segment) {
             [self creatSegmentView];
         }
       
     });
 
}

//刷新显示的卡BIN
-(void)reloadShowCardWithDataArray:(NSArray*)cardArray withType:(int)type{
    
    //默认显示虚拟卡
    NSMutableArray *cards = [NSMutableArray array];

    for (int i = 0; i < cardArray.count; i++) {
        
        BinModel*model=cardArray[i];
        SelectCardView*card=[SelectCardView instanceViewWithFrame:CGRectZero];
        [card configModel:model withType:type];
        [cards addObject:card];
    }
    // 设置卡片数组
    [self.carousel setCards:cards];
 
    if (cardArray.count>0) {
        [self configUIWithIndex:0];//默认显示第一个
    }
  
}

-(void)configUIWithIndex:(NSInteger)index{
    
    BinModel*model;
    double openCardFee;
    if (self.segment.selectedIndex==0) {
        //虚拟卡
        model=[self.virtuaArray objectAtIndex:index];
        openCardFee=model.baseCardFee+model.applyCard;
    }else{
        //实体卡
        model=[self.physicalArray objectAtIndex:index];
        openCardFee=model.basePhysicalCardFee+model.applyCard;
    }
    
    [self.contentArray replaceObjectAtIndex:0 withObject:[NSString stringWithFormat:@"%@USD",[NSString formattedStringWithDouble:openCardFee]]];//开卡费
    NSString*cardHolderStatusString=@"";
    if ([NSString stringIsNull:model.cardHolderType]) {
        //不需要持卡人，默认显示已创建
        cardHolderStatusString=LocalizationKey(@"已创建");
      
    }else{
  
        if ([NSString stringIsNull:model.cardHolderStatus]) {
            //未创建持卡人
            cardHolderStatusString=LocalizationKey(@"未创建");
            
        }else if([model.cardHolderStatus isEqualToString:@"INACTIVE"]){
            //持卡人已拒绝
      
            cardHolderStatusString=LocalizationKey(@"已拒绝");
            
        }else if([model.cardHolderStatus isEqualToString:@"ACTIVE"]){
            //持卡人已审核通过
  
            cardHolderStatusString=LocalizationKey(@"已创建");
            
        }else if([model.cardHolderStatus isEqualToString:@"PENDING"]){
            //持卡人审核中
            cardHolderStatusString=LocalizationKey(@"审核中");
            
        }else{
            
            
        }
  
    }
    [self.contentArray replaceObjectAtIndex:1 withObject:cardHolderStatusString];
    [self.contentArray replaceObjectAtIndex:3 withObject:[NSString repalceNULLWithemptyString:model.remark]];//持卡人介绍
    [self.tableView reloadData];
    if (self.binBlock) {
        self.binBlock(model);
    }
    
}

//创建菜单栏
-(void)creatSegmentView{
    
    if (self.physicalArray.count==0&&self.virtuaArray.count==0) {
        return;
    }
    NSArray*titleArray=@[LocalizationKey(@"虚拟卡"), LocalizationKey(@"实体卡")];
    if (self.physicalArray.count==0) {
        titleArray=@[LocalizationKey(@"虚拟卡")];
        self.segmentWid.constant=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?150:100;
    }
    if (self.virtuaArray.count==0) {
        titleArray=@[LocalizationKey(@"实体卡")];
        self.segmentWid.constant=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?150:100;
    }
    self.segmentBackView.backgroundColor=[UIColor whiteColor];
    self.segment = [[CustomSegmentView alloc] initWithItems:titleArray];
    self.segment.frame = CGRectMake(0, 0, self.segmentWid.constant, 40);

    [self.segmentBackView addSubview:self.segment];
    WEAKSELF
    self.segment.onSegmentChanged = ^(NSInteger index) {
        NSLog(@"当前选中: %ld", (long)index);
        if (index==0) {
            [weakSelf reloadShowCardWithDataArray:weakSelf.virtuaArray withType:1];//虚拟卡
        }else{
            NSMutableArray*allData=[[NSMutableArray alloc]init];
            [allData addObjectsFromArray:weakSelf.physicalArray];
            [allData addObjectsFromArray:weakSelf.physicalArray];
            [weakSelf reloadShowCardWithDataArray:weakSelf.physicalArray withType:2];//实体卡
        }
    };
 
}

//0:不显示卡片申请中 1:显示卡片申请中
-(void)setTableHeadViewwithType:(int)type withCount:(NSString*)count{
   
    if (type==0) {
        //无卡片申请中
        self.topDistance.constant=30;
        self.holderHeadView.topAlertView.hidden=YES;
        self.holderHeadView.TopAlertViewH.constant=0;
        self.headerContainer.frame=CGRectMake(0, 0, kWindowW, (kWindowW-14*4)*430/684.00+25);
       [self.carousel updateFrame:CGRectMake(0, 10, kWindowW, (kWindowW-14*4)*430/684.00)];
        
        self.tableView.tableHeaderView=self.headerContainer;
    }else{
       //有卡片申请中
        self.topDistance.constant=5;
        self.holderHeadView.topAlertView.hidden=NO;
        self.holderHeadView.TopAlertViewH.constant=44;
        NSString*allRemark=[NSString stringWithFormat:LocalizationKey(@"有卡片申请中"),count];
        self.headerContainer.frame=CGRectMake(0, 0, kWindowW, 10+44+16+(kWindowW-14*4)*430/684.00+15);
        self.holderHeadView.countLabel.text=allRemark;
        [self.carousel updateFrame:CGRectMake(0, 71, kWindowW, (kWindowW-14*4)*430/684.00)];
        self.tableView.tableHeaderView=self.headerContainer;
        
    }

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row<3) {
        ApplyCardCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ApplyCardCell"];
        cell.titleLabel.text=self.titleArray[indexPath.row];
        cell.contentLabel.text=self.contentArray[indexPath.row];
        return cell;
    }else{
        ApplyIntroductionCell*cell=[tableView dequeueReusableCellWithIdentifier:@"ApplyIntroductionCell"];
        cell.IntroductionLabel.text=self.contentArray[indexPath.row];
        return cell;
        
    }
   
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
  
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewAutomaticDimension;
}


-(void)hideTopAlertView{
    [self setTableHeadViewwithType:0 withCount:0];
}

-(void)showTopAlertViewwithCount:(NSString*)count{

    [self setTableHeadViewwithType:1 withCount:count];

}

-(void)resetSegmentView{
    self.segment.selectedIndex=0;
   
}

//获取当前选择的是虚拟卡还是实体卡
-(int)getCurrentSelectedCardType{
    
    return (int)self.segment.selectedIndex+1;
    
}

-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        emptyView.contentViewY=350;
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}

-(void)setSegmentBackViewHidden:(BOOL)isHidden{
    self.segmentBackView.hidden=isHidden;
}
    
@end
