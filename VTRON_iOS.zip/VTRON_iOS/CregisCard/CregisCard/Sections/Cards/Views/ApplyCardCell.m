//
//  ApplyCardCell.m
//  CregisCard
//
//  Created by sunliang on 2025/11/17.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "ApplyCardCell.h"

@implementation ApplyCardCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
