//
//  BulkMailCardITopCell.m
//  CregisCard
//
//  Created by sunliang on 2025/3/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BulkMailCardITopCell.h"

@implementation BulkMailCardITopCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.text=LocalizationKey(@"卡信息");
    self.titleLabel.font=PingFangMediumFont(13);

    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
