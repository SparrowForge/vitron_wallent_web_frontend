//
//  NOKYCCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface NOKYCCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;

@end

NS_ASSUME_NONNULL_END
