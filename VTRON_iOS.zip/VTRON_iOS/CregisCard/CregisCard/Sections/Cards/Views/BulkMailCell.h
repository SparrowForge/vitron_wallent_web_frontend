//
//  BulkMailCell.h
//  CregisCard
//
//  Created by sunliang on 2025/3/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

typedef void(^SelectBlock)(NSString* _Nullable key,NSString*_Nullable value);
NS_ASSUME_NONNULL_BEGIN

@interface BulkMailCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextField *contentTF;
@property (weak, nonatomic) IBOutlet UIImageView *moreIcon;
@property (weak, nonatomic) IBOutlet UIView *areaCodeView;
@property (weak, nonatomic) IBOutlet UIView *phoneView;
@property (weak, nonatomic) IBOutlet UIView *optionalView;
@property (weak, nonatomic) IBOutlet UIButton *optionalBtn;
@property (weak, nonatomic) IBOutlet UILabel *areaLabel;
@property (weak, nonatomic) IBOutlet UITextField *phoneTF;

@property (nonatomic, copy) SelectBlock selectBlock;
-(void)configDataWithIndexPath:(NSIndexPath*)indexPath withCardsArray:(NSArray*)cardsArray withExpand:(BOOL)isExpand withTitleArray:(NSArray*)titleArray withContentDic:(NSDictionary*)contentDic withPlaceHolderArray:(NSArray*)placeHolderArray withCountryArray:(NSArray*)countryArray withCountryAreaCodeArray:(NSArray*)countryAreaCodeArray;
@end

NS_ASSUME_NONNULL_END
