//
//  ApplyCarouseView.m
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "ApplyCarouseView.h"
#import "MainCardApplyingView.h"
#import "ApplyCardController.h"
#import "OperationVerifyController.h"
#import "HomeCardNetWorkManager.h"
#import "NSObject+UBTrackerModel.h"
#import "BinModel.h"
#import "ApplySuccessView.h"
#import "HolderInfoController.h"
#import "LogoRefreshGifHeader.h"
#import "TABAnimated.h"

@interface ApplyCarouseView ()
@property(nonatomic,strong) MainCardApplyingView*carouseView;
@property (weak, nonatomic) IBOutlet UILabel *btnTips;
@property (weak, nonatomic) IBOutlet UIView *btnView;

@property(nonatomic,strong) BinModel*binModel;
@property(nonatomic,strong) NSArray*binModelArray;
@property(nonatomic,assign) NSString*pendingCount;//申请中的卡片数量
@end


@implementation ApplyCarouseView

+ (ApplyCarouseView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ApplyCarouseView" owner:nil options:nil];
    ApplyCarouseView*view=[nibView objectAtIndex:0];
    view.btnTips.text=LocalizationKey(@"申请卡");
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self setUpUI];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadBINData)name:ReloadBIN object:nil];
    
}


-(void)setUpUI{
    
    TABViewAnimated *viewAnimated = [TABViewAnimated new];
    self.btnView.tabAnimated = viewAnimated;
    [self.btnView tab_startAnimation];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

        self.carouseView=[MainCardApplyingView instanceViewWithFrame:self.backView.bounds];
        self.carouseView.backgroundColor=[UIColor whiteColor];
        // 控制视图初始化
        /*
        [TABAnimated sharedAnimated].openAnimationTag = YES;
        TABViewAnimated *viewAnimated = [TABViewAnimated new];
        self.carouseView.tabAnimated = viewAnimated;
        self.carouseView.tabAnimated.adjustBlock = ^(TABComponentManager * _Nonnull manager) {
            manager.animation(0).remove();
            manager.animation(1).remove();
            manager.animation(6).remove();

        };
        // 开启动画(加载数据时)
        [self.carouseView tab_startAnimation];
         */
        
        [self.carouseView hideTopAlertView];

        WEAKSELF
        self.carouseView.binBlock = ^(BinModel * _Nullable model) {
            weakSelf.binModel=model;
        };
        //下拉刷新
        self.carouseView.refreshBlock = ^{
            [weakSelf refreshHeaderAction];
            
        };
        [self.backView addSubview:self.carouseView];
        [self getAllRequestForFirst:YES];
    });
   
    
}
-(void)getAllRequestForFirst:(BOOL)isFirst{
   
    dispatch_group_t group = dispatch_group_create();
    if (isFirst) {
        [self getAllCardBINwithGroup:group];
    }else{
        [SVProgressHUD customShowWithNone];
        [self getAllCardBINwithGroup:group];
    }
    [self getPendingCardCountwithGroup:group];
    // 全部请求完成后执行
       dispatch_group_notify(group, dispatch_get_main_queue(), ^{
           [SVProgressHUD dismiss];

           [self.carouseView resetSegmentView];
            self.carouseView.dataArray=self.binModelArray;
            [self.btnView tab_endAnimation];
           self.btnView.hidden=self.binModelArray.count==0?YES:NO;
           if (self.binModelArray.count==0) {
               [self.carouseView setSegmentBackViewHidden:YES];
           }else{
               [self.carouseView setSegmentBackViewHidden:NO];
           }
           
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                   self.btnView.tabAnimated.state=TABViewAnimationEnd;
            
               });
          
           if ([self.pendingCount intValue]<=0) {
               [self.carouseView hideTopAlertView];
           }else{
               [self.carouseView showTopAlertViewwithCount:self.pendingCount];
           }

       });
    
}



- (void)refreshHeaderAction{
   // [self.carouseView resetSegmentView];
    [self getAllRequestForFirst:YES];
}

//获取所有卡片信息
-(void)getAllCardBINwithGroup:(dispatch_group_t)group{
    dispatch_group_enter(group);
    //[SVProgressHUD customShowWithStyle];
    [HomeCardNetWorkManager getAllCardBINsuccess:^(id  _Nonnull data) {
        dispatch_group_leave(group);
      //  [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
          self.binModelArray=(NSMutableArray*)[BinModel utr_modelsWithKeyValues:data[@"data"][@"bin"]];
           
        }else{
          
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull error) {
        //[SVProgressHUD dismiss];
        dispatch_group_leave(group);
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
   
    
}

//MARK: 获取申请中的卡片数量
-(void)getPendingCardCountwithGroup:(dispatch_group_t)group{
    dispatch_group_enter(group);
  
    [HomeCardNetWorkManager getPendingCardCountsuccess:^(id  _Nonnull data) {
       
        dispatch_group_leave(group);
        if ([data[@"code"] intValue]==200) {
            self.pendingCount=data[@"data"];
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    
        
    } fail:^(NSError * _Nonnull error) {
        dispatch_group_leave(group);
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}



//申请卡片
- (IBAction)applyClick:(UIButton *)sender {
   
 
    if ([[UserWrapper shareUserInfo].kycStatus intValue]!=5||[[UserWrapper shareUserInfo].isPayPassword intValue]!=1) {
        //实名认证和交易密码只要有一项未完成
        OperationVerifyController*operateVC=[[OperationVerifyController alloc]init];
        operateVC.type=2;
        [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:operateVC animated:YES];
        return;

    }
    
    if ([NSString stringIsNull:self.binModel.cardHolderType]) {
        //不需要持卡人
        ApplyCardController*applyVC=[[ApplyCardController alloc]init];
        applyVC.binModel=self.binModel;
        applyVC.type=[self.carouseView getCurrentSelectedCardType];
        [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:applyVC animated:YES];
    }else{
        if ([NSString stringIsNull:self.binModel.cardHolderStatus]) {
            //未创建持卡人
            ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
            successView.titleLabel.text=LocalizationKey(@"温馨提示");
            successView.detailLabel.text=LocalizationKey(@"卡片持卡人信息未创建，请先创建持卡人");
            successView.tipsImageV.image=UIIMAGE(@"loginForOther");
            WEAKSELF
            [successView.okBtn dn_addActionHandler:^{
                [successView hide];
                //创建持卡人
                HolderInfoController*holderVC=[[HolderInfoController alloc]init];
                holderVC.type=1;
                holderVC.binModel=weakSelf.binModel;
                [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:holderVC animated:YES];
            }];
            [successView show];
            
        }else if([self.binModel.cardHolderStatus isEqualToString:@"INACTIVE"]){
            //持卡人已拒绝
            //修改持卡人
            HolderInfoController*holderVC=[[HolderInfoController alloc]init];
            holderVC.type=1;
            holderVC.binModel=self.binModel;
            [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:holderVC animated:YES];
            
        }else if([self.binModel.cardHolderStatus isEqualToString:@"ACTIVE"]){
            //持卡人已审核通过
          
            ApplyCardController*applyVC=[[ApplyCardController alloc]init];
            applyVC.binModel=self.binModel;
            applyVC.type=[self.carouseView getCurrentSelectedCardType];
            [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:applyVC animated:YES];
            
        }else if([self.binModel.cardHolderStatus isEqualToString:@"PENDING"]){
            //持卡人审核中
            ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 310)];
            successView.titleLabel.text=LocalizationKey(@"温馨提示");
            successView.detailLabel.text=LocalizationKey(@"持卡人信息正在审核中，请稍后再试");
            successView.tipsImageV.image=UIIMAGE(@"loginForOther");
            [successView.okBtn dn_addActionHandler:^{
                [successView hide];
               
            }];
            [successView show];
            
            
        }else{
            
            
        }
        
    }
  
}

//刷新BIN数据
-(void)reloadBINData{
   // [self.carouseView resetSegmentView];
    [self getAllRequestForFirst:YES];
}

//主动刷新数据
-(void)reloadBINDataForActive{
        
 // [self.carouseView resetSegmentView];
  [self getAllRequestForFirst:NO];
        
}

-(void)showNoDataView{
    
   
    
}

@end
