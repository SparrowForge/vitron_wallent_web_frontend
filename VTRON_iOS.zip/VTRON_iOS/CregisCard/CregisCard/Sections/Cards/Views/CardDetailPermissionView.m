//
//  CardDetailPermissionView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CardDetailPermissionView.h"
#import "YCMenuView.h"

@interface CardDetailPermissionView()
{
    int _verifyType;//0 邮箱验证 1谷歌验证；默认邮箱
}
@property(nonatomic,strong) YCMenuView *menuView;
@property (weak, nonatomic) IBOutlet UILabel *emailAlert;
@property (weak, nonatomic) IBOutlet UILabel *codeTitle;
@property (weak, nonatomic) IBOutlet UILabel *btnTips;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indictorView;

@end

@implementation CardDetailPermissionView

+ (CardDetailPermissionView *)instanceViewWithFrame:(CGRect)Rect withVerifyPermissionType:(CardDetailPermissionType)permissionType{
    
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"CardDetailPermissionView" owner:nil options:nil];
    CardDetailPermissionView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    view.permissionType=permissionType;
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self setBorderView:self.codeView];
    self.cancelBtn.titleLabel.font=PingFangMediumFont(15);
    self.btnTips.font=PingFangMediumFont(15);
    [self.verifyTypeBtn setTitle:LocalizationKey(@"邮箱") forState:UIControlStateNormal];
    self.titleLabel.font=PingFangMediumFont(19);// [UIFont systemFontOfSize:19 weight:UIFontWeightMedium];
    self.codeTitle.font=PingFangMediumFont(13);
    self.verifyCodeBtn.titleLabel.font=PingFangMediumFont(13);
    [self.cancelBtn setTitle:LocalizationKey(@"取消") forState:UIControlStateNormal];
    [self.verifyCodeBtn setTitle:LocalizationKey(@"获取") forState:UIControlStateNormal];
    [self.codeTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    self.btnTips.text=LocalizationKey(@"提交");
    self.codeTitle.text=LocalizationKey(@"邮箱验证码");
    self.indictorView.hidden=YES;
    self.okBtn.enabled=NO;
    self.btnTips.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    [self.codeTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
}


-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
    /*
    if (self.permissionType==CardDetail) {
        self.titleLabel.text=LocalizationKey(@"卡详情查看验证");    }
    else if (self.permissionType==AddPasskey){
        self.titleLabel.text=LocalizationKey(@"安全验证");
        
    }else if (self.permissionType==DeletePasskey){
            self.titleLabel.text=LocalizationKey(@"安全验证");
     }
    else if (self.permissionType==LoginServer){
            self.titleLabel.text=LocalizationKey(@"安全验证");
     }
    else{
        
        }
     */
    self.titleLabel.text=LocalizationKey(@"安全验证");//全部改成安全验证
}



- (IBAction)closeClick:(id)sender {
    [self hide];
}


- (IBAction)eventClick:(UIButton *)sender {
    if (sender.tag==1){
        //切换邮箱或谷歌验证
       // [self changeCodeView];
        
    }else if (sender.tag==2){
       //发送邮箱验证码
        [self getEmailVerifyCode];
    }else{
        //点击确定按钮
        [self confirmTowithdraw];
    }
    
}
//MARK: 确定按钮
-(void)confirmTowithdraw{
   
    if ([NSString stringIsNull:self.codeTF.text]) {
        if (_verifyType==0) {
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱验证码"));
        }else{
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入谷歌验证码"));
        }
        return;
    }
    
    if (self.verifyBlock) {
        self.verifyBlock(self.codeTF.text, _verifyType);
    }
   
}


//MARK: 发送邮箱或谷歌验证码
-(void)getEmailVerifyCode{
    
    if (self.permissionType==LoginServer) {
        //登录时候单独调用另外一个接口
        [self getVerifyCodeForLogin];
        return;
    }
    
    NSString*typeString=@"";
    if (self.permissionType==CardDetail) {
        typeString=@"cardDetail";
    }else if (self.permissionType==AddPasskey){
        typeString=@"addPasskey";
        
    }else if (self.permissionType==DeletePasskey){
        typeString=@"deletePasskey";
    }else{
        
    }
    
    [SVProgressHUD customShowWithStyle];
    [LoginNetWorkManager getLogincodeWithloginType:@{@"type":typeString} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[NSString maskEmail:[UserWrapper shareUserInfo].email]];
            self.emailAlert.text=email;
            self.emailAlert.hidden=NO;
            [self CountDown:59];
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

//登录时获取验证码
-(void)getVerifyCodeForLogin{
    
    [SVProgressHUD customShowWithStyle];
    NSDictionary*dic=@{@"email":self.email,@"type":@"login"};
    [LoginNetWorkManager getCodeForLoginWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"发送成功"));
            NSString*email=[NSString stringWithFormat:LocalizationKey(@"已发送至"),[NSString maskEmail:self.email]];
            self.emailAlert.text=email;
            self.emailAlert.hidden=NO;
            [self CountDown:59];
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
    
    
}

/* 倒计时 */
- (void)CountDown:(int)timeDistance{
    __block NSInteger time = timeDistance; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    self._timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    dispatch_source_set_timer(self._timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(self._timer, ^{
        
        if(time <= 0){ //倒计时结束，关闭
            
            dispatch_source_cancel(self._timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置按钮的样式
                [self.verifyCodeBtn setTitle:LocalizationKey(@"重新发送") forState:UIControlStateNormal];
                [self.verifyCodeBtn setTitleColor:[UIColor baseColor] forState:UIControlStateNormal];
                self.verifyCodeBtn.userInteractionEnabled = YES;
                
            });
            
        }else{
            
            int seconds = (int)time ;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //设置按钮显示读秒效果
                [self.verifyCodeBtn setTitle:[NSString stringWithFormat:@"%.2ldS",(long)seconds] forState:UIControlStateNormal];
                [self.verifyCodeBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0] forState:UIControlStateNormal];
                self.verifyCodeBtn.userInteractionEnabled = NO;
            });
            time--;
        }
    });
    dispatch_resume(self._timer);
}



//MARK: 切换验证方式
-(void)changeCodeView{

    WEAKSELF
    UIImage *emailImage =_verifyType==0? UIIMAGE(@"check_account"):UIIMAGE(@"checkNo_account");
    UIImage *googleImage = _verifyType==0? UIIMAGE(@"checkNo_account"):UIIMAGE(@"check_account");
    YCMenuAction*action0 = [YCMenuAction actionWithTitle:LocalizationKey(@"邮箱") image:emailImage handler:^(YCMenuAction *action) {

          self->_verifyType=0;
          weakSelf.tipsView.hidden=NO;
          weakSelf.verifyCodeBtn.hidden=NO;
          weakSelf.verifyCodeWidth.constant=95;
          [weakSelf.verifyTypeBtn setTitle:LocalizationKey(@"邮箱") forState:UIControlStateNormal];
           }];
        YCMenuAction *action1 = [YCMenuAction actionWithTitle:LocalizationKey(@"谷歌") image:googleImage handler:^(YCMenuAction *action) {
            self->_verifyType=1;
            weakSelf.tipsView.hidden=YES;
            weakSelf.verifyCodeBtn.hidden=YES;
            weakSelf.verifyCodeWidth.constant=0;
            [weakSelf.verifyTypeBtn setTitle:LocalizationKey(@"谷歌") forState:UIControlStateNormal];
           }];
           
        NSMutableArray * array =  [NSMutableArray array];
        [array addObject:action0];
        [array addObject:action1];
        self.menuView = [YCMenuView menuWithActions:array width:120 relyonView:self.verifyTypeBtn];
        self.menuView.menuColor=[UIColor whiteColor];
        self.menuView.menuCellHeight=55;
        self.menuView.textColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        self.menuView.maxDisplayCount = 2;
        [self.menuView show];
  
    
}
//切换验证码
- (IBAction)chanegClick:(UIButton *)sender {
    _verifyType=_verifyType==0?1:0;
    if (_verifyType==0) {
        //邮箱验证
        self.codeTitle.text=LocalizationKey(@"邮箱验证码");
        self.verifyCodeBtn.hidden=NO;
        self.verifyCodeWidth.constant=95;
        if (![NSString stringIsNull:self.emailAlert.text]) {
            self.emailAlert.hidden=NO;
        }
    }else{
        //谷歌验证
        self.codeTitle.text=LocalizationKey(@"谷歌验证码");
        self.verifyCodeBtn.hidden=YES;
        self.verifyCodeWidth.constant=0;
        if (!self.emailAlert.hidden) {
            self.emailAlert.hidden=YES;
        }
    }
    
}
-(void)startAnimation{
    self.indictorView.hidden=NO;
    [self.indictorView startAnimating];
    
}
-(void)stopAnimation{
    self.indictorView.hidden=YES;
    [self.indictorView stopAnimating];
    
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    if ([NSString stringIsNull:textField.text]) {
        self.okBtn.enabled=NO;
        self.btnTips.textColor=[UIColor colorWithHexString:@"#000000 " alpha:0.2];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    }else{
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        self.btnTips.textColor=[UIColor whiteColor];
        
    }
    
}


-(void)resetBtnColor{
    
    self.okBtn.enabled=NO;
    self.btnTips.textColor=[UIColor colorWithHexString:@"#000000" alpha:0.2];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];

}


@end
