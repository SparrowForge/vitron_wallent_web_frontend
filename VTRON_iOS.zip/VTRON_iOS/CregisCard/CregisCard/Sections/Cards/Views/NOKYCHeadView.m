//
//  NOKYCHeadView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NOKYCHeadView.h"

@implementation NOKYCHeadView

+ (NOKYCHeadView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"NOKYCHeadView" owner:nil options:nil];
    NOKYCHeadView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    
    return view;
}

@end
