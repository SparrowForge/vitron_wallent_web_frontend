//
//  BulkMailCardInfoCell.h
//  CregisCard
//
//  Created by sunliang on 2025/3/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface BulkMailCardInfoCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UILabel *cardNoLabel;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomDistance;
-(void)configDataWithDic:(NSDictionary*)dic withSelectedArray:(NSArray*)selectedArray;
@end

NS_ASSUME_NONNULL_END
