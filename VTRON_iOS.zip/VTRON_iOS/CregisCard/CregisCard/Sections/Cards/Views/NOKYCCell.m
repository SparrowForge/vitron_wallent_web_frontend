//
//  NOKYCCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NOKYCCell.h"
#import "HolderInfoController.h"
#import "IdentityInreviewController.h"

@implementation NOKYCCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor=[UIColor clearColor];
    self.contentView.backgroundColor=[UIColor clearColor];
    self.boardView.backgroundColor=[[UIColor whiteColor]colorWithAlphaComponent:0.7];
    // Initialization code
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}

//MARK: 去实名认证
- (IBAction)kycBtnClick:(id)sender {
    
    if ([[UserWrapper shareUserInfo].kycStatus intValue]==4||[[UserWrapper shareUserInfo].kycStatus intValue]==7) {
        //未提交或者审核拒绝
        HolderInfoController*identityVC=[[HolderInfoController alloc]init];
        identityVC.type=0;
        [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:identityVC animated:YES];
    }else{
        //审核中或者审核通过
        IdentityInreviewController*identityVC=[[IdentityInreviewController alloc]init];
        [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:identityVC animated:YES];
    }
    
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
