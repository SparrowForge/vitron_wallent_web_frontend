//
//  ApplySuccessView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/22.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "ApplySuccessView.h"

@implementation ApplySuccessView

+ (ApplySuccessView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ApplySuccessView" owner:nil options:nil];
    ApplySuccessView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"0";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 10+HOME_INDICATOR_HEIGHT, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
   
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.titleLabel.text=LocalizationKey(@"卡片已申请");
    self.detailLabel.text=LocalizationKey(@"开卡时间预计5分钟，请稍后在主页查看");
    [self.okBtn setTitle:LocalizationKey(@"确定") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [self setCornerRadius:24.0];
}


@end
