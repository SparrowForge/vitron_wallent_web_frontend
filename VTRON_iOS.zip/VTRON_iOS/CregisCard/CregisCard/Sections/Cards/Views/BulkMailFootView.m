//
//  BulkMailFootView.m
//  CregisCard
//
//  Created by sunliang on 2025/3/27.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BulkMailFootView.h"

@implementation BulkMailFootView

+ (BulkMailFootView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"BulkMailFootView" owner:nil options:nil];
    BulkMailFootView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.feeTitle.text=LocalizationKey(@"邮寄费");
    [view.okBtn setTitle:LocalizationKey(@"卡邮寄") forState:UIControlStateNormal];
    view.okBtn.titleLabel.font=PingFangMediumFont(15);
    view.okBtn.enabled=NO;
    [view.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    view.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    return view;
}


@end
