//
//  HomeCardHeadView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/16.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "HomeCardHeadView.h"
#import "MailingAddressController.h"


@interface HomeCardHeadView ()

@property(nonatomic,strong) NSDictionary*cardDetailDic;

@end

@implementation HomeCardHeadView

+ (HomeCardHeadView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView = [[NSBundle mainBundle] loadNibNamed:@"HomeCardHeadView" owner:nil options:nil];
    HomeCardHeadView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.boardView.backgroundColor=[[UIColor whiteColor] colorWithAlphaComponent:0.7];
    view.alertView.hidden=YES;//默认隐藏
    view.alertH.constant=0;
    view.cardDetailView.hidden=YES;
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.availableTitle.text=[NSString stringWithFormat:@"%@：",LocalizationKey(@"可用资产")];
    self.lookTitle.text=LocalizationKey(@"查看");
    self.chargeTitle.text=LocalizationKey(@"卡充值");
    self.frozenLabel.text=LocalizationKey(@"冻结");
    self.manageTitle.text=LocalizationKey(@"更多");
    self.dateTitle.text=LocalizationKey(@"有效期");
    [self.postBtn setTitle:LocalizationKey(@"卡邮寄") forState:UIControlStateNormal];
    self.postBtn.titleLabel.font=PingFangMediumFont(15);
    self.lookTitle.font=PingFangMediumFont(13);
    self.chargeTitle.font=PingFangMediumFont(13);
    self.manageTitle.font=PingFangMediumFont(13);
    self.frozenLabel.font=PingFangMediumFont(13);
    self.currencyLabel.font=PingFangMediumFont(13);
    self.cardNo1.font=PingFangMediumFont(25);
    self.cardNo2.font=PingFangMediumFont(25);
    self.cardNo3.font=PingFangMediumFont(25);
    self.cardNo4.font=PingFangMediumFont(25);
    self.postBtn.layer.borderWidth=0.33;
    self.postBtn.layer.borderColor=[UIColor colorWithHexString:@"#E11D53" alpha:1.0].CGColor;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    self.topDistance.constant=STATUS_BAR_HEIGHT+15;
   
}

-(void)setDataDic:(NSDictionary *)dataDic{
    //01：ACTIVE（正常）  02：CONTROL（管控）  03：PENDING（等待）  04：FROZEN（冻结）    05：INACTIVE（销卡）
    _dataDic=dataDic;
    if ([dataDic[@"type"] intValue]==1) {
        //虚拟卡
       // self.manageView.hidden=YES;
        //self.manageWidth.constant=0;
         self.frozenImageV.image=UIIMAGE(@"card_frozen");
         self.frozenLabel.text=LocalizationKey(@"冻结");
         
    }else{
        //实体卡
       // self.manageView.hidden=NO;
       // self.manageWidth.constant=kWindowW/4.0;
        self.frozenImageV.image=UIIMAGE(@"card_manage");
        self.frozenLabel.text=LocalizationKey(@"管理");
      
    }
    
    NSString*cardNO=dataDic[@"cardNo"];
    NSString*flagImageString=[[dataDic[@"cardType"] uppercaseString] isEqualToString:@"VISA"]?@"visa_icon":@"visa_bottomIcon";
    self.flagImagV.image=UIIMAGE(flagImageString);
    
    // 设置文本内容
    NSString *text = [cardNO substringFromIndex:cardNO.length-4];
    self.behindLabel.attributedText = [self setStringStylewithText:text withFont:21];
    
    // 设置属性字符串到 UILabel
    self.frontLabel.attributedText = [self setStringStylewithText:@"...." withFont:21];
   
    self.cardNameLabel.text=dataDic[@"alias"];
    if ([dataDic[@"status"] isEqualToString:@"01"]) {
        if ([dataDic[@"type"] intValue]==1){
            //虚拟卡
            self.frozenLabel.text=LocalizationKey(@"冻结");
        }

        if ([dataDic[@"type"] intValue]==1) {
            //虚拟卡
            self.backImageV.image=UIIMAGE(@"nocardIcon_virtual");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_virtual");
        }else{
            //实体卡
            self.backImageV.image=UIIMAGE(@"nocardIcon");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo");
        }
      
      
    }else if ([dataDic[@"status"] isEqualToString:@"04"]){
      //冻结状态
        if ([dataDic[@"type"] intValue]==1){
            //虚拟卡
            self.frozenLabel.text=LocalizationKey(@"解冻");
        }
        if ([dataDic[@"type"] intValue]==1) {
            //虚拟卡
            self.backImageV.image=UIIMAGE(@"closecardIcon_virtual");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_no");
        }else{
            //实体卡
            self.backImageV.image=UIIMAGE(@"closecardIcon");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_no");
        }
      
    }
    else if ([dataDic[@"status"] isEqualToString:@"05"]){
     //注销状态
        if ([dataDic[@"type"] intValue]==1){
            //虚拟卡
            self.frozenLabel.text=LocalizationKey(@"冻结");
        }
        if ([dataDic[@"type"] intValue]==1) {
            //虚拟卡
            self.backImageV.image=UIIMAGE(@"closecardIcon_virtual");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_no");
        }else{
            //实体卡
            self.backImageV.image=UIIMAGE(@"closecardIcon");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_no");
        }
        
    }else{
        //未激活
        
        if ([dataDic[@"type"] intValue]==1){
            //虚拟卡
            self.frozenLabel.text=LocalizationKey(@"冻结");
        }
        if ([dataDic[@"type"] intValue]==1) {
            //虚拟卡
            self.backImageV.image=UIIMAGE(@"closecardIcon_virtual");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_no");
        }else{
            //实体卡
            self.backImageV.image=UIIMAGE(@"closecardIcon");
            self.cardDetailImageV.image=UIIMAGE(@"cardDetailLogo_no");
        }
        
    }
   
    self.chipImageV.hidden=[dataDic[@"type"] intValue]==1?YES:NO;//虚拟卡无芯片图标
    
}

-(void)setBalance:(NSString *)balance{
    _balance=balance;
    if ([UBTNSUserDefaultUtil GetBoolDefaults:HIDDENHOMECARD]) {
        self.eyeBtn.selected=NO;
        [self hiddenHomeCardMoney];
    }else{
        self.eyeBtn.selected=YES;
        [self showHomeCardMoney];
    }
}

//隐藏/显示
- (IBAction)eyeClick:(UIButton*)sender {
    sender.selected=!sender.selected;
    if (sender.selected) {
        [self showHomeCardMoney];
    }else{
        [self hiddenHomeCardMoney];
    }
    [UBTNSUserDefaultUtil PutBoolDefaults:HIDDENHOMECARD Value:!sender.selected];
}

-(void)hiddenHomeCardMoney{
    self.fundLabel.text=@"***";
    
}
-(void)showHomeCardMoney{
    self.fundLabel.text=self.balance;
    
}

//根据状态获取当前状态文字和边框颜色
-(UIColor*)getStatusLebelBoardColorWithStatus:(NSString*)status{
    
    if ([status isEqualToString:@"02"]) {
        return [UIColor baseColor];
    }else if ([status isEqualToString:@"04"]){
        return [UIColor lightGrayColor];
    }else{
        return [UIColor alertColor];
    }
    
}

//点击菜单按钮
- (IBAction)btnClick:(UIButton *)sender {
    

    if (self.btnSelectBlock) {
        self.btnSelectBlock((int)sender.tag);
    }
}

//邮寄卡
- (IBAction)detailClick:(id)sender {
    
    MailingAddressController*mailVC=[[MailingAddressController alloc]init];
    mailVC.currentCardDic=self.dataDic;
    [[UBTrackerFindController findCurrentShowingViewController].navigationController pushViewController:mailVC animated:YES];
}

//根据实体卡发卡状态更新顶部UI
-(void)configUIWithCardDetailDic:(NSDictionary*)dic withpendingCount:(NSString*)pendingCount{

    
    if ([dic[@"type"] intValue]==1) {
        //虚拟卡
        self.alertView.hidden=YES;
        self.alertH.constant=0;
        self.shipViewHeight.constant=0;
        self.shipBtnHeight.constant=0;
        self.shipView.hidden=YES;
        if ([pendingCount intValue]>0){
            self.alertLabel.text=[NSString stringWithFormat:LocalizationKey(@"有卡片申请中"),pendingCount];
            self.alertView.hidden=NO;
            self.alertH.constant=44;
            self.applyAlertImageV.image=UIIMAGE(@"applyIcon_black");
            self.alertView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.04];
            self.alertLabel.textColor=[UIColor colorWithHexString:@"#1F211" alpha:1.0];
  
        }else{
            //隐藏
            self.alertView.hidden=YES;
            self.alertH.constant=0;
        }
 
    }else{
       //实体卡
        if ([pendingCount intValue]>0){
            self.alertLabel.text=[NSString stringWithFormat:LocalizationKey(@"有卡片申请中"),pendingCount];
            self.alertView.hidden=NO;
            self.alertH.constant=44;
            self.applyAlertImageV.image=UIIMAGE(@"applyIcon_black");
            self.alertView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.04];
            self.alertLabel.textColor=[UIColor colorWithHexString:@"#1F211" alpha:1.0];
           
        }else{
            //隐藏
            self.alertView.hidden=YES;
            self.alertH.constant=0;
        }
        
        if ([dic[@"isShip"] intValue]==0&&![dic[@"status"] isEqualToString:@"02"]&&![dic[@"status"] isEqualToString:@"05"]) {
            //未邮寄(已销卡的不包含在内)
            self.shipViewHeight.constant=70;
            self.shipBtnHeight.constant=44;
            self.shipView.hidden=NO;
        }else{
            //已邮寄
            self.shipViewHeight.constant=0;
            self.shipBtnHeight.constant=0;
            self.shipView.hidden=YES;
        }
      
    }
   
}



//隐藏或者显示卡片详情（页面一出现就默认隐藏）
-(void)showCardDetailWithDataDic:(NSDictionary*)dic withIsHide:(BOOL)hide{
    
    self.cardDetailDic=dic;
    self.cardDetailView.hidden=hide;
    self.cvvImageV.image=hide?UIIMAGE(@"CVVIcon_hide"):UIIMAGE(@"CVVIcon");
    if (!hide) {
        NSString*cardNo=dic[@"cardNumber"];
        self.cardNo1.attributedText=[self setStringStylewithText:[cardNo substringToIndex:4] withFont:23];
        self.cardNo2.attributedText=[self setStringStylewithText:[cardNo substringWithRange:NSMakeRange(4, 4)] withFont:23];
        self.cardNo3.attributedText=[self setStringStylewithText:[cardNo substringWithRange:NSMakeRange(8, 4)] withFont:23];
        self.cardNo4.attributedText=  [self setStringStylewithText:[cardNo substringFromIndex:cardNo.length-4] withFont:23];
        self.dateLabel.text=dic[@"expireDate"];
        self.cvvLabel.text=dic[@"cvv"];
        NSString*flagImageString=[[dic[@"cardType"] uppercaseString] isEqualToString:@"VISA"]?@"visa_icon":@"visa_bottomIcon";
        self.visaTypeImagV.image=UIIMAGE(flagImageString);
        
    }
   
}
//复制按钮
- (IBAction)copyClick:(UIButton *)sender {
    NSString*copyString=@"";
    if (sender.tag==0) {
        //有效期
        copyString=self.cardDetailDic[@"expireDate"];
    }else if(sender.tag==1){
        //CVV
        copyString=self.cardDetailDic[@"cvv"];
        
    }else{
        //卡号
        copyString=self.cardDetailDic[@"cardNumber"];
    }
    if (![NSString stringIsNull:copyString]) {
        UIPasteboard *pboard = [UIPasteboard generalPasteboard];
        pboard.string = copyString;
        ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"已复制到剪切板"));
    }
    
}




-(NSMutableAttributedString*)setStringStylewithText:(NSString*)text withFont:(CGFloat)fontSize{
    
    // 创建属性字符串
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:text];
    // 设置字间距
    CGFloat letterSpacing = 1.0; // 字间距，单位为点
    [attributedString addAttribute:NSKernAttributeName value:@(letterSpacing) range:NSMakeRange(0, text.length)];
    [attributedString addAttribute:NSFontAttributeName
                             value:PingFangMediumFont(fontSize)
                             range:NSMakeRange(0, text.length)];
  
    return attributedString;
}






@end
