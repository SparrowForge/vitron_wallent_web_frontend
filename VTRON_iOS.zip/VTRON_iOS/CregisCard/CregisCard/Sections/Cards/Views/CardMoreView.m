//
//  CardMoreView.m
//  CregisCard
//
//  Created by sunliang on 2025/11/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CardMoreView.h"

@interface CardMoreView ()
@property (weak, nonatomic) IBOutlet UILabel *withdrawTitle;
@property (weak, nonatomic) IBOutlet UILabel *frozenTitle;
@property (weak, nonatomic) IBOutlet UILabel *cancelTitle;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;

@end


@implementation CardMoreView

+ (CardMoreView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"CardMoreView" owner:nil options:nil];
    CardMoreView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    FWPopupBaseViewProperty *property = [FWPopupBaseViewProperty manager];
    property.popupAlignment = FWPopupAlignmentBottomCenter;
    property.popupAnimationStyle = FWPopupAnimationStylePosition;
    property.maskViewColor = [UIColor colorWithWhite:0 alpha:0.2];
    property.touchWildToHide = @"1";
    property.popupEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    property.animationDuration = 0.2;
    property.backgroundColor=[UIColor clearColor];
    view.vProperty = property;
    [view setUIText];
    return view;
    
}

-(void)setUIText{
    
    self.tipsLabel.text=LocalizationKey(@"操作");
    self.withdrawTitle.text=LocalizationKey(@"提现");
    self.frozenTitle.text=LocalizationKey(@"冻结");
    self.cancelTitle.text=LocalizationKey(@"注销");
    self.withdrawTitle.font=PingFangMediumFont(13);
    self.frozenTitle.font=PingFangMediumFont(13);
    self.cancelTitle.font=PingFangMediumFont(13);
    
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
}


- (IBAction)btnClick:(UIButton *)sender {
    
    [self hide];
    if (self.btnMenuBlock) {
        self.btnMenuBlock((int)sender.tag);
    }
 
}

-(void)showwithCurrentDic:(NSDictionary*)dic{
   
    if ([dic[@"type"] intValue]==1) {
        //虚拟卡
        self.frozenView.hidden=YES;
        self.frozenWidth.constant=0;
    }else{
        //实体卡
        self.frozenView.hidden=NO;
        self.frozenWidth.constant=100;
        if ([dic[@"status"] isEqualToString:@"04"]) {
            self.frozenTitle.text=LocalizationKey(@"解冻");
        }else{
            self.frozenTitle.text=LocalizationKey(@"冻结");
        }
      
    }
    [self show];
    
}



@end
