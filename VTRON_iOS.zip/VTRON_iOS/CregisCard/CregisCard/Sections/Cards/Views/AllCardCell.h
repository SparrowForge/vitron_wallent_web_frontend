//
//  AllCardCell.h
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "CardModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface AllCardCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *dotView;
@property (weak, nonatomic) IBOutlet UILabel *flagLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardTypeLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIImageView *backViewImageV;
@property (weak, nonatomic) IBOutlet UIImageView *tipsIcon;
@property (weak, nonatomic) IBOutlet UILabel *cardNumLabel;
@property (weak, nonatomic) IBOutlet UIView *flagView;




@property(nonatomic,strong) CardModel*model;
@end

NS_ASSUME_NONNULL_END
