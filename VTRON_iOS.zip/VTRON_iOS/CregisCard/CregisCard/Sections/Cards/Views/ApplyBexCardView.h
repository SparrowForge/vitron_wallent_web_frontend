//
//  ApplyBexCardView.h
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BinModel.h"
NS_ASSUME_NONNULL_BEGIN

typedef void(^AmountBlock)(NSString* _Nullable amount);
typedef void(^CardTipsBlock)(NSString* _Nullable tipsString);
@interface ApplyBexCardView : UIView

+ (ApplyBexCardView *)instanceViewWithFrame:(CGRect)Rect withApplyCard:(BinModel*)card;
@property (nonatomic, copy) AmountBlock amountBlock;
@property (nonatomic, copy) CardTipsBlock cardTipsBlock;
@property(nonatomic,strong) BinModel*card;
@property (weak, nonatomic) IBOutlet UIView *rechargeView;
@property (weak, nonatomic) IBOutlet UIImageView *cardTypeImageV;
@property (weak, nonatomic) IBOutlet UIImageView *cardBackImageV;
@property (weak, nonatomic) IBOutlet UITextField *amountTF;
@property (weak, nonatomic) IBOutlet UIImageView *expandIcon;


@end

NS_ASSUME_NONNULL_END
