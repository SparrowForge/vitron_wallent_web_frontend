//
//  ApplyIntroductionCell.h
//  CregisCard
//
//  Created by sunliang on 2025/11/17.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ApplyIntroductionCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *IntroductionLabel;

@end

NS_ASSUME_NONNULL_END
