//
//  CardDetailCell.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/17.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface CardDetailCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIImageView *tipsIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *insideDistance;
@property (weak, nonatomic) IBOutlet UIView *backView;
-(void)configDataWithTitle:(NSString*)title withContent:(NSString*)content AtIndexPath:(NSIndexPath*)indexPath;

@end

NS_ASSUME_NONNULL_END
