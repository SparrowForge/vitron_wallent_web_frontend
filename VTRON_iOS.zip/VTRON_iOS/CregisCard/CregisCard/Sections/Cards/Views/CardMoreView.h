//
//  CardMoreView.h
//  CregisCard
//
//  Created by sunliang on 2025/11/7.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FWPanPopupView.h"
typedef void(^BtnMenuBlock)(int type);
NS_ASSUME_NONNULL_BEGIN

@interface CardMoreView : FWPanPopupView
+ (CardMoreView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *frozenWidth;
@property (weak, nonatomic) IBOutlet UIView *frozenView;
@property (nonatomic, copy) BtnMenuBlock btnMenuBlock;
-(void)showwithCurrentDic:(NSDictionary*)dic;
@end

NS_ASSUME_NONNULL_END
