//
//  ApplySuccessView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/22.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPopupBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ApplySuccessView : FWPopupBaseView
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIImageView *tipsImageV;

+ (ApplySuccessView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
