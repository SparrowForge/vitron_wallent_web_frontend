//
//  BulkMailHeaderView.m
//  CregisCard
//
//  Created by sunliang on 2025/3/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BulkMailHeaderView.h"

@implementation BulkMailHeaderView

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.text=LocalizationKey(@"邮寄卡数量");
    self.detailLabel.text=LocalizationKey(@"卡信息");
    self.titleLabel.font=PingFangMediumFont(13);
    self.detailLabel.font=PingFangMediumFont(13);
    [self setBorderView:self.boardView];
    // Initialization code
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}
@end
