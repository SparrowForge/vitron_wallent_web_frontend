//
//  CardSectionView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CardSectionView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *backImageV;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIButton *allBtn;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet UILabel *allLabel;
@property (weak, nonatomic) IBOutlet UIButton *tradeBtn;

@property(nonatomic,assign)int cardType;
+ (CardSectionView *)instanceViewWithFrame:(CGRect)Rect withHomeCardType:(int)type;
@end

NS_ASSUME_NONNULL_END
