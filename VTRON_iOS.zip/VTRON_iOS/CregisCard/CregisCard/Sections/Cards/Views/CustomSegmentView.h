//
//  CustomSegmentView.h
//  Badtest
//
//  Created by sunliang on 2025/10/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomSegmentView : UIView
@property (nonatomic, copy) void (^onSegmentChanged)(NSInteger index);
@property (nonatomic, assign) NSInteger selectedIndex;
- (instancetype)initWithItems:(NSArray<NSString *> *)items;
@end

NS_ASSUME_NONNULL_END
