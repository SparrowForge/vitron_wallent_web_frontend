//
//  CardSectionView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CardSectionView.h"

@implementation CardSectionView


+ (CardSectionView *)instanceViewWithFrame:(CGRect)Rect withHomeCardType:(int)type{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"CardSectionView" owner:nil options:nil];
    CardSectionView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    view.boardView.backgroundColor=[[UIColor whiteColor] colorWithAlphaComponent:0.7];
    view.cardType=type;
    view.tradeBtn.titleLabel.font=PingFangMediumFont(17);
    if (type==5) {
        [view.tradeBtn setTitle:LocalizationKey(@"交易") forState:UIControlStateNormal];
    }else{
        [view.tradeBtn setTitle:LocalizationKey(@"交易") forState:UIControlStateNormal];
    }
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];

    self.allLabel.text=LocalizationKey(@"全部");
    self.allLabel.font=PingFangMediumFont(13);
    [self.lineView setCornerRadius:1.5];
}

-(void)layoutSubviews{
    [super layoutSubviews];
    if (self.cardType!=2) {
        [self.boardView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(24, 24)];
    }
  
}



@end
