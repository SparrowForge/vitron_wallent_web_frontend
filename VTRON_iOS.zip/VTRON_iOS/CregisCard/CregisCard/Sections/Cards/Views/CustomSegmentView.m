//
//  CustomSegmentView.m
//  Badtest
//
//  Created by sunliang on 2025/10/13.
//

#import "CustomSegmentView.h"

@interface CustomSegmentView ()

@property (nonatomic, strong) UIView *backgroundView;
@property (nonatomic, strong) UIView *selectedBgView;
@property (nonatomic, strong) NSArray<UIButton *> *buttons;

@end


@implementation CustomSegmentView

- (instancetype)initWithItems:(NSArray<NSString *> *)items {
    self = [super initWithFrame:CGRectZero];
    if (self) {
        self.layer.cornerRadius = 20;
        self.backgroundColor = [UIColor colorWithWhite:0.95 alpha:1.0];
        self.clipsToBounds = YES;

        NSMutableArray *btns = [NSMutableArray array];
        for (int i = 0; i < items.count; i++) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:items[i] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor colorWithWhite:0 alpha:0.4] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
            btn.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
            btn.tag = i;
            [btn addTarget:self action:@selector(segmentTapped:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
            [btns addObject:btn];
        }
        self.buttons = btns;

        self.selectedBgView = [[UIView alloc] init];
        self.selectedBgView.backgroundColor = [UIColor whiteColor];
        self.selectedBgView.layer.cornerRadius = 16;
        self.selectedBgView.layer.shadowColor = [UIColor colorWithWhite:0 alpha:0.1].CGColor;
        self.selectedBgView.layer.shadowOpacity = 1;
        self.selectedBgView.layer.shadowOffset = CGSizeMake(0, 1);
        self.selectedBgView.layer.shadowRadius = 2;
        [self insertSubview:self.selectedBgView atIndex:0];

        self.selectedIndex = 0;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat width = self.bounds.size.width / self.buttons.count;
    CGFloat height = self.bounds.size.height;
    for (int i = 0; i < self.buttons.count; i++) {
        UIButton *btn = self.buttons[i];
        btn.frame = CGRectMake(i * width, 0, width, height);
    }

    [UIView animateWithDuration:0.2 animations:^{
        self.selectedBgView.frame = CGRectMake(self.selectedIndex * width + 3, 3, width - 6, height - 6);
    }];
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    _selectedIndex = selectedIndex;
    for (UIButton *btn in self.buttons) {
        btn.selected = (btn.tag == selectedIndex);
    }
    [self setNeedsLayout];
}

- (void)segmentTapped:(UIButton *)sender {
    if (self.selectedIndex == sender.tag) return;
    self.selectedIndex = sender.tag;
    if (self.onSegmentChanged) {
        self.onSegmentChanged(sender.tag);
    }
}


@end
