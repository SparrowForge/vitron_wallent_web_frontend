//
//  ApplyCarouseView.h
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ApplyCarouseView : UIView
@property (weak, nonatomic) IBOutlet UIView *backView;

+ (ApplyCarouseView *)instanceViewWithFrame:(CGRect)Rect;
//主动刷新数据
-(void)reloadBINDataForActive;
-(void)showNoDataView;
@end

NS_ASSUME_NONNULL_END
