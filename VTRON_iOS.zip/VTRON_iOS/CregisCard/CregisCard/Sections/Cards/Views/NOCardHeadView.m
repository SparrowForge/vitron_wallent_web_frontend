//
//  NOCardHeadView.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/15.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NOCardHeadView.h"

@implementation NOCardHeadView

+ (NOCardHeadView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"NOCardHeadView" owner:nil options:nil];
    NOCardHeadView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:@"申请卡"];
    NSRange strRange = {0,[str length]};
    [str addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:strRange];
    [self.applyBtn setAttributedTitle:str forState:UIControlStateNormal];
}

//MARK: 申请卡
- (IBAction)applyClick:(UIButton *)sender {
    
   
}


@end
