//
//  ApplyBexCardView.m
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "ApplyBexCardView.h"

@interface ApplyBexCardView()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UILabel *cardTypeLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *unitLabel;
@property (weak, nonatomic) IBOutlet UILabel *amountTitle;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardInfoTitle;
@property (weak, nonatomic) IBOutlet UILabel *cardInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardTipsTitle;
@property (weak, nonatomic) IBOutlet UITextField *cardTipsTF;
@property (weak, nonatomic) IBOutlet UIView *cardTipsView;
@property (weak, nonatomic) IBOutlet UIView *cardInfoView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *addtionalHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *cardInfoHeight;
@property (weak, nonatomic) IBOutlet UILabel *numLabel;

@property (nonatomic, assign) BOOL isCardInfoViewExpanded;  //卡产品介绍是否展开
@end


@implementation ApplyBexCardView

+ (ApplyBexCardView *)instanceViewWithFrame:(CGRect)Rect withApplyCard:(BinModel*)card {
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ApplyBexCardView" owner:nil options:nil];
    ApplyBexCardView*view=[nibView objectAtIndex:0];
    view.card=card;
    view.frame=Rect;
    view.backgroundColor=[UIColor whiteColor];
    [view setUpUI];
    view.cardInfoLabel.text=card.remark;
    view.cardInfoHeight.constant = 0;//默认隐藏
    view.cardInfoView.hidden=YES;
    view.addtionalHeight.constant=0;
    return view;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.amountTitle.text=LocalizationKey(@"充值金额");
    self.cardTipsTF.font=PingFangMediumFont(15);
    self.amountTF.font=PingFangMediumFont(15);
    self.cardTypeLabel.font=PingFangMediumFont(19);
    self.cardInfoTitle.font=PingFangMediumFont(13);
    self.amountTitle.font=PingFangMediumFont(13);
    self.cardTipsTitle.font=PingFangMediumFont(13);
    self.cardTipsTF.placeholder=LocalizationKey(@"请输入");
    self.amountTF.placeholder=LocalizationKey(@"请输入");
    self.amountTF.delegate=self;
    [self.amountTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    [self setBorderView:self.cardInfoView];
    [self setBorderView:self.cardTipsView];
    [self setBorderView:self.rechargeView];
    self.unitLabel.text=LocalizationKey(@"USD/张");
    self.cardInfoTitle.text=LocalizationKey(@"卡片介绍");
    self.cardTipsTitle.text=LocalizationKey(@"卡标签");
    [self.cardTipsTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    self.cardTipsTF.delegate=self;
}

-(void)setUpUI{
    
    NSString*cardBackViewImage=[self.card.type intValue]==1?@"applycardshowIcon_virtual":@"applycardshowIcon";
    self.cardBackImageV.image=UIIMAGE(cardBackViewImage);
    NSString*flagImageString=[[self.card.cardType uppercaseString] isEqualToString:@"VISA"]?@"visa_icon":@"visa_bottomIcon";
    self.cardTypeImageV.image=UIIMAGE(flagImageString);
    NSString*cardType=[self.card.type intValue]==1?LocalizationKey(@"虚拟卡"):LocalizationKey(@"实体卡");
    self.cardTypeLabel.text=cardType;
    self.tipsLabel.text=[NSString stringWithFormat:@"%@：%@-%@USD",LocalizationKey(@"充值区间"),[NSString formattedStringWithDouble:self.card.applyCardMinAmount],[NSString formattedStringWithDouble:self.card.applyCardMaxAmount]];
    if ([self.card.type intValue]==1) {
        self.priceLabel.text=[NSString formattedStringWithDouble:(self.card.baseCardFee+self.card.applyCard)];
    }else{
        self.priceLabel.text=[NSString formattedStringWithDouble:(self.card.basePhysicalCardFee+self.card.applyCard)];
    }
    
    
    if (self.card.applyCardMinAmount==0&&self.card.applyCardMaxAmount==0) {
        //不显示充值
        self.amountTitle.hidden=YES;
        self.rechargeView.hidden=YES;
        self.tipsLabel.hidden=YES;
        
    }
   
    
}

//卡产品信息介绍
- (IBAction)cardInfoClick:(id)sender {
    
    
    if ([NSString stringIsNull:self.card.remark]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"暂无该卡段说明"));
        return;
    }
    CGFloat textHeight=[ToolUtil getLabelHeightWithText:self.card.remark width:kWindowW-70 font:[UIFont systemFontOfSize:15]]+1;
    self.isCardInfoViewExpanded=!self.isCardInfoViewExpanded;
    if (self.isCardInfoViewExpanded) {
        //展开
        self.expandIcon.image=UIIMAGE(@"post_upIcon");
        self.cardInfoView.hidden=NO;
        self.addtionalHeight.constant=8;
        [UIView animateWithDuration:0.3 animations:^{
            self.cardInfoHeight.constant = textHeight+30;  // 设置展开后的高度
            [self layoutIfNeeded]; // 激活动画
        } completion:^(BOOL finished) {
           
        }];
    }else{
        //关闭
        self.expandIcon.image=UIIMAGE(@"post_downIcon");
        [UIView animateWithDuration:0.3 animations:^{
            self.cardInfoHeight.constant = 0;  // 设置展开后的高度
            [self layoutIfNeeded]; // 激活动画
        } completion:^(BOOL finished) {
            self.cardInfoView.hidden=YES;
            self.addtionalHeight.constant=0;
        }];
        
    }
    
    
}


- (void)textFieldChange:(UITextField *)textField {
    if ([textField isEqual:self.cardTipsTF]) {
        //卡标签
        self.numLabel.text=[NSString stringWithFormat:@"%lu/15",(unsigned long)textField.text.length];
        if (self.cardTipsBlock) {
            self.cardTipsBlock(textField.text);
        }
    }else{
        
        if (self.amountBlock) {
            self.amountBlock(textField.text);
        }
    }
    
   
}
//限制只能输入2位小数
// 实现UITextFieldDelegate协议方法，控制小数位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
   
    if ([textField isEqual:self.cardTipsTF]) {
        //卡标签
        NSString *currentText = textField.text;
        NSString *newText = [currentText stringByReplacingCharactersInRange:range withString:string];
           
           // 允许完全删除（长度为0）
           if (newText.length == 0) {
               return YES;
           }
           
       // 限制最大长度为15
       return newText.length <= 15;
    }else{
        //充值数量输入框
        NSString *currentText = textField.text;
        NSString *newText = [currentText stringByReplacingCharactersInRange:range withString:string];
        
        // 允许完全删除
        if (newText.length == 0) {
            return YES;
        }
        
        // 检查多个小数点
        NSArray *components = [newText componentsSeparatedByString:@"."];
        if (components.count > 2) {
            return NO; // 超过一个小数点，不允许
        }
        
        // 如果有小数部分，检查小数位数
        if (components.count == 2) {
            NSString *decimalPart = components[1];
            if (decimalPart.length > 2) {
                return NO; // 小数部分超过2位，不允许
            }
        }
        
        // 可选：使用更宽松的数字验证
        NSString *regex = @"^[0-9]*\\.?[0-9]*$";
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
        return [predicate evaluateWithObject:newText];
        
    }
    
}


-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}

@end
