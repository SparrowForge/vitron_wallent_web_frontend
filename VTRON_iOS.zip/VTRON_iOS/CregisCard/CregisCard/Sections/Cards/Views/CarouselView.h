//
//  CarouselView.h
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CarouselView : UIView

/// 设置卡片视图数组（每个元素是 UIView）
- (void)setCards:(NSArray<UIView *> *)cards;

/// 当前选中的卡片索引（轮播中实时更新）
@property (nonatomic, assign, readonly) NSInteger currentIndex;

/// 滑动结束后选中卡片变化的回调
@property (nonatomic, copy) void (^didSelectCardAtIndex)(NSInteger index);
- (void)reloadCards:(NSArray<UIView *> *)newCards;
#pragma mark - 更新 CarouselView frame
- (void)updateFrame:(CGRect)newFrame;
@end

NS_ASSUME_NONNULL_END
