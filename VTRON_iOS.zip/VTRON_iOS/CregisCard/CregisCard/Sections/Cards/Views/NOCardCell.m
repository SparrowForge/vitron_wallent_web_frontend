//
//  NOCardCell.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/16.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "NOCardCell.h"

@implementation NOCardCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.text=LocalizationKey(@"暂无数据");
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
