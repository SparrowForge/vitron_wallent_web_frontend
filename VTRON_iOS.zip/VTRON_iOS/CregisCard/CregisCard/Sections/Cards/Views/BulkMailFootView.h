//
//  BulkMailFootView.h
//  CregisCard
//
//  Created by sunliang on 2025/3/27.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BulkMailFootView : UIView
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UILabel *feeTitle;

+ (BulkMailFootView *)instanceViewWithFrame:(CGRect)Rect;
@end

NS_ASSUME_NONNULL_END
