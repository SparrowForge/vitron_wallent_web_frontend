//
//  SelectCardView.h
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BinModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface SelectCardView : UIView
+ (SelectCardView *)instanceViewWithFrame:(CGRect)Rect;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UIImageView *cardTypeImageV;
@property (weak, nonatomic) IBOutlet UIImageView *cardBackViewImagV;
@property (weak, nonatomic) IBOutlet UIImageView *xinpianImagV;
-(void)configModel:(BinModel*)model withType:(int)type;
//@property(nonatomic,strong) UILabel*binLabel;
@end

NS_ASSUME_NONNULL_END
