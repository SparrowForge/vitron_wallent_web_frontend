//
//  CardDetailPermissionView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/9.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "FWPanPopupView.h"

typedef void(^CardVerifyBlock)(NSString*_Nullable code,int type);//type 0 邮箱验证 1 谷歌验证
NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, CardDetailPermissionType) {
    LoginServer,//登录时获取验证码
    CardDetail,//邮寄实体卡
    AddPasskey,//添加通行密钥
    DeletePasskey,//删除通行密钥
};


@interface CardDetailPermissionView : FWPanPopupView
@property(nonatomic,assign) CardDetailPermissionType permissionType;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIView *codeView;
@property (weak, nonatomic) IBOutlet UITextField *codeTF;
@property (weak, nonatomic) IBOutlet UIButton *verifyCodeBtn;
@property (weak, nonatomic) IBOutlet UIButton *verifyTypeBtn;
@property (weak, nonatomic) IBOutlet UIView *tipsView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *verifyCodeWidth;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (nonatomic, copy)   CardVerifyBlock verifyBlock;
@property(nonatomic,retain) dispatch_source_t _timer;
@property (nonatomic, copy)   NSString* email;
+ (CardDetailPermissionView *)instanceViewWithFrame:(CGRect)Rect withVerifyPermissionType:(CardDetailPermissionType)permissionType;
-(void)startAnimation;//开始转圈
-(void)stopAnimation;//停止转圈
-(void)resetBtnColor;
@end

NS_ASSUME_NONNULL_END
