//
//  CardIdentityDetailCell.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/2.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "CardIdentityDetailCell.h"

@implementation CardIdentityDetailCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.detailLabel.font=[UIFont systemFontOfSize:17 weight:UIFontWeightSemibold];
    // Initialization code
}

-(void)configDataWithTitle:(NSString*)title withContent:(NSString*)content AtIndexPath:(NSIndexPath*)indexPath withDataArray:(NSArray*)dataArray{
   
    self.titleLabel.text=title;
    self.detailLabel.text=content;
//    if (indexPath.row==0) {
//        //延迟执行
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            [self.backView maskRoundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight cornerRedius:CGSizeMake(12, 12)];
//            
//            
//        });
//      
//    }
//    if (indexPath.row==dataArray.count-1) {
//        //延迟执行
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            [self.backView maskRoundingCorners:UIRectCornerBottomLeft|UIRectCornerBottomRight cornerRedius:CGSizeMake(12, 12)];
//       
//        });
//      
//    }
//    
   
}


@end
