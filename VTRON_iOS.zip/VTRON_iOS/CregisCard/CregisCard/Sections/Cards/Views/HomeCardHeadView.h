//
//  HomeCardHeadView.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/16.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^BtnSelectBlock)(int tag);//tag 0 充值 1退款 2冻结 3销卡
NS_ASSUME_NONNULL_BEGIN

@interface HomeCardHeadView : UIView
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIView *cardDetailView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topDistance;
@property (weak, nonatomic) IBOutlet UILabel *frontLabel;
@property (weak, nonatomic) IBOutlet UILabel *secondLabel;

@property (weak, nonatomic) IBOutlet UILabel *behindLabel;
@property (weak, nonatomic) IBOutlet UILabel *frozenLabel;
@property (weak, nonatomic) IBOutlet UIButton *moreBtn;
@property (weak, nonatomic) IBOutlet UILabel *fundLabel;

@property (weak, nonatomic) IBOutlet UILabel *alertLabel;
@property (weak, nonatomic) IBOutlet UIView *alertView;

@property (weak, nonatomic) IBOutlet UIImageView *backImageV;
@property (weak, nonatomic) IBOutlet UIButton *eyeBtn;
@property (weak, nonatomic) IBOutlet UIImageView *chipImageV;

@property (weak, nonatomic) IBOutlet UIButton *detailBtn;
@property (weak, nonatomic) IBOutlet UILabel *cardNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *flagImagV;
@property (weak, nonatomic) IBOutlet UILabel *currencyLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *manageWidth;

@property (weak, nonatomic) IBOutlet UIView *manageView;
@property(nonatomic,strong) NSDictionary*dataDic;
@property (nonatomic, copy) BtnSelectBlock btnSelectBlock;
@property(nonatomic,copy)   NSString*balance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *alertH;
@property (weak, nonatomic) IBOutlet UILabel *availableTitle;
@property (weak, nonatomic) IBOutlet UILabel *lookTitle;
@property (weak, nonatomic) IBOutlet UILabel *chargeTitle;
@property (weak, nonatomic) IBOutlet UILabel *manageTitle;
@property (weak, nonatomic) IBOutlet UIImageView *applyAlertImageV;
@property (weak, nonatomic) IBOutlet UIButton *postBtn;//邮寄按钮
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *shipBtnHeight;
@property (weak, nonatomic) IBOutlet UIView *shipView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *shipViewHeight;

@property (weak, nonatomic) IBOutlet UILabel *cardNo1;
@property (weak, nonatomic) IBOutlet UILabel *cardNo2;
@property (weak, nonatomic) IBOutlet UILabel *cardNo3;
@property (weak, nonatomic) IBOutlet UILabel *cardNo4;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateTitle;
@property (weak, nonatomic) IBOutlet UILabel *cvvLabel;
@property (weak, nonatomic) IBOutlet UIImageView *cardDetailImageV;
@property (weak, nonatomic) IBOutlet UIImageView *visaTypeImagV;
@property (weak, nonatomic) IBOutlet UIImageView *cvvImageV;
@property (weak, nonatomic) IBOutlet UIImageView *frozenImageV;



+ (HomeCardHeadView *)instanceViewWithFrame:(CGRect)Rect;

-(void)configUIWithCardDetailDic:(NSDictionary*)dic withpendingCount:(NSString*)pendingCount;//根据实体卡发卡状态更新顶部UI

//隐藏或者显示卡片详情（页面一出现就默认隐藏）
-(void)showCardDetailWithDataDic:(NSDictionary*)dic withIsHide:(BOOL)hide;

@end

NS_ASSUME_NONNULL_END
