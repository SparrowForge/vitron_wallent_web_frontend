//
//  SelectCardView.m
//  CregisCard
//
//  Created by sunliang on 2025/10/13.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "SelectCardView.h"

@implementation SelectCardView

+ (SelectCardView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"SelectCardView" owner:nil options:nil];
    SelectCardView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    [view setBINLabelUI];
    return view;
}


-(void)layoutSubviews{
    [super layoutSubviews];
    self.layer.cornerRadius=16;
    self.clipsToBounds=YES;
  
    // 先取消 transform，恢复为未旋转状态以正确测量 size
   // self.binLabel.transform = CGAffineTransformIdentity;
    // 让 label 根据文字大小自适应（注意：sizeToFit 以当前 transform = identity 为准）
  //  [self.binLabel sizeToFit];
  //  CGSize labelSize = self.binLabel.bounds.size;
       // 将 layer 的 anchorPoint 设为左上角（0,0），这样旋转会围绕左上角进行
       // 先设置 anchorPoint，再设置 frame
   // self.binLabel.layer.anchorPoint = CGPointMake(0.0, 0.0);
       // 指定 label 在父视图内未旋转时的左上角位置为 (20,20)
       // 因为我们把 anchorPoint 设为 (0,0)，所以直接设置 frame.origin = (20,20) 就是锚点的位置
   // self.binLabel.frame = CGRectMake(40.0, 20.0, labelSize.width, labelSize.height);

       // 最后旋转 90 度（顺时针）；若需要逆时针用 -M_PI_2
   // self.binLabel.transform = CGAffineTransformMakeRotation(M_PI_2);
}

-(void)setBINLabelUI{
//    self.binLabel = [[UILabel alloc] init];
//    self.binLabel.text = @"";
//    self.binLabel.textColor = [UIColor whiteColor];
//    self.binLabel.font = PingFangMediumFont(15);
//    self.binLabel.textAlignment = NSTextAlignmentCenter;
//    [self addSubview:self.binLabel];
}


-(void)configModel:(BinModel*)model withType:(int)type{

    self.titleLabel.text=[NSString stringWithFormat:@"BIN %@",[self substringFirstSixCharacters:model.bin]];
    //self.titleLabel.text=[NSString stringWithFormat:@"BIN %@",model.bin];
    NSString*imageName=[[model.cardType uppercaseString] isEqualToString:@"VISA"]?@"visa_icon":@"visa_bottomIcon";
    self.cardTypeImageV.image=UIIMAGE(imageName);
    NSString*cardBackViewImage=type==1?@"nocardIcon_virtual":@"nocardIcon";
    self.cardBackViewImagV.image=UIIMAGE(cardBackViewImage);
    self.xinpianImagV.hidden=type==1?YES:NO;
}


- (NSString *)substringFirstSixCharacters:(NSString *)string {
    if (!string || string.length == 0) {
        return @"";
    }
    
    // 如果字符串长度小于等于6，返回原字符串
    if (string.length <= 6) {
        return string;
    }
    
    // 截取前6位字符
    return [string substringToIndex:6];
}
@end
