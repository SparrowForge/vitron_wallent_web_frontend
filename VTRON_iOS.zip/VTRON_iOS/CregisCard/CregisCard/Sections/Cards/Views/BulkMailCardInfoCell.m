//
//  BulkMailCardInfoCell.m
//  CregisCard
//
//  Created by sunliang on 2025/3/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BulkMailCardInfoCell.h"
#import "TABAnimated.h"
@implementation BulkMailCardInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setBorderView:self.boardView];
   
    
    // Initialization code
}
-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}

-(void)configDataWithDic:(NSDictionary*)dic withSelectedArray:(NSArray*)selectedArray{
    self.bottomDistance.constant=16;
    self.deleteBtn.userInteractionEnabled=NO;
    self.cardNoLabel.text=dic[@"cardNo"];
    if ([selectedArray  containsObject:dic]) {
        [self.deleteBtn setBackgroundImage:UIIMAGE(@"selectedPostCard") forState:UIControlStateNormal];
    }else{
        [self.deleteBtn setBackgroundImage:UIIMAGE(@"unSelectedPostCard") forState:UIControlStateNormal];
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
