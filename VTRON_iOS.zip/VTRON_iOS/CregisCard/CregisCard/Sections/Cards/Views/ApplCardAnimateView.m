//
//  ApplCardAnimateView.m
//  CregisCard
//
//  Created by sunliang on 2025/11/18.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "ApplCardAnimateView.h"


@interface ApplCardAnimateView()


@end

@implementation ApplCardAnimateView

+ (ApplCardAnimateView *)instanceViewWithFrame:(CGRect)Rect{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ApplCardAnimateView" owner:nil options:nil];
    ApplCardAnimateView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    return view;
}


@end
