//
//  BulkMailCell.m
//  CregisCard
//
//  Created by sunliang on 2025/3/26.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BulkMailCell.h"
#import "CountrysSelectView.h"
#import "MineNetWorkManager.h"
#import "NSObject+UBTrackerModel.h"
#import "CountryModel.h"

@interface BulkMailCell ()
@property(nonatomic,strong) CountrysSelectView*countryView;
@property(nonatomic,strong) CountrysSelectView*countrySelectView;//区号
@property(nonatomic,strong) CountryModel*currentCountry;//当前国家
@property(nonatomic,strong) CountryModel*currentCountryAreaCode;//当前国家手机区号
@property(nonatomic,strong) NSArray*countryArray;
@property(nonatomic,strong) NSArray*countryAreaCodeArray;
@end
@implementation BulkMailCell

- (CountrysSelectView *)countryView {
    if(!_countryView) {
        _countryView=[CountrysSelectView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-10)];
    }
    return _countryView;
}
- (CountrysSelectView *)countrySelectView {
    if(!_countrySelectView) {
        _countrySelectView=[CountrysSelectView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-10)];
    }
    return _countrySelectView;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLabel.font=PingFangMediumFont(13);
    [self.phoneTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    self.contentTF.font=PingFangMediumFont(15);
    self.areaLabel.font=PingFangMediumFont(15);
    [self setBorderView:self.boardView];
    [self setBorderView:self.areaCodeView];
    [self setBorderView:self.phoneView];
    [self.contentTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingChanged];
    [self.phoneTF addTarget:self action:@selector(textFieldDidEnd:) forControlEvents:UIControlEventEditingChanged];
    
    // Initialization code
}

- (void)textFieldDidEnd:(UITextField *)textField {
    
    NSString*typeString=[self getTypeString];
    if ([typeString isEqualToString:@"phone"]) {
        if (self.selectBlock) {
            self.selectBlock(typeString, self.phoneTF.text);
        }
    }else{
        if (self.selectBlock) {
            self.selectBlock(typeString, self.contentTF.text);
        }
    }
   
    
}
-(NSString*)getTypeString{
    
    if ([self.titleLabel.text isEqualToString:LocalizationKey(@"手机号")]) {
        return @"phone";
    }else if ([self.titleLabel.text isEqualToString:LocalizationKey(@"城市")]){
        return @"city";
    }else if ([self.titleLabel.text isEqualToString:LocalizationKey(@"地区")]){
        return @"zone";
    }else if ([self.titleLabel.text isEqualToString:LocalizationKey(@"地址")]){
        return @"address";
    }else if ([self.titleLabel.text isEqualToString:LocalizationKey(@"邮政编码")]){
        return @"postalCode";
    }else{
        return @"";
    }
    
}
-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}

-(void)configDataWithIndexPath:(NSIndexPath*)indexPath withCardsArray:(NSArray*)cardsArray withExpand:(BOOL)isExpand withTitleArray:(NSArray*)titleArray withContentDic:(NSDictionary*)contentDic withPlaceHolderArray:(NSArray*)placeHolderArray withCountryArray:(NSArray*)countryArray withCountryAreaCodeArray:(NSArray*)countryAreaCodeArray{
    
    self.contentTF.tag=indexPath.row;
    if (isExpand) {
        //展开
        int index;
        if (cardsArray.count>0) {
            index=(int)indexPath.row-1-(int)cardsArray.count;

        }else{
            index=(int)indexPath.row;

        }
        self.titleLabel.text=titleArray[index];
        [self.contentTF setStyleWithPlaceholder:placeHolderArray[index]];
        
    }else{
        //关闭
        int index;
        if (cardsArray.count>0) {
            index=(int)indexPath.row-1;

        }else{
            index=(int)indexPath.row;

        }
        self.titleLabel.text=titleArray[index];
        [self.contentTF setStyleWithPlaceholder:placeHolderArray[index]];
        
    }
    self.countryAreaCodeArray=countryAreaCodeArray;
    self.countryArray=countryArray;

    if ([self.titleLabel.text isEqualToString:LocalizationKey(@"国家")]) {
       //

    }
    self.moreIcon.hidden=[self.titleLabel.text isEqualToString:LocalizationKey(@"国家")]?NO:YES;
    self.optionalBtn.hidden=[self.titleLabel.text isEqualToString:LocalizationKey(@"国家")]?NO:YES;
    self.contentTF.userInteractionEnabled=[self.titleLabel.text isEqualToString:LocalizationKey(@"国家")]?NO:YES;
    self.optionalView.hidden=[self.titleLabel.text isEqualToString:LocalizationKey(@"手机号")]?NO:YES;
    self.boardView.hidden=[self.titleLabel.text isEqualToString:LocalizationKey(@"手机号")]?YES:NO;
    
    if ([self.titleLabel.text isEqualToString:LocalizationKey(@"手机号")]) {
        self.phoneTF.text=contentDic[@"phone"];
        self.areaLabel.text=[NSString stringWithFormat:@"+%@",contentDic[@"areaCode"]];
    }else if ([self.titleLabel.text isEqualToString:LocalizationKey(@"国家")]){
        NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?contentDic[@"usName"]:contentDic[@"cnName"];
        self.contentTF.text=countryName;
    }
    else{
        NSString*typeString=[self getTypeString];
        self.contentTF.text=[contentDic objectForKey:typeString];
    }
    
    self.contentTF.keyboardType=[self.titleLabel.text isEqualToString:LocalizationKey(@"邮政编码")]?UIKeyboardTypeNumberPad:UIKeyboardTypeASCIICapable;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

//选择手机号区号
- (IBAction)areaClick:(UIButton *)sender {
    if (self.countryAreaCodeArray.count>0){
        [self.countrySelectView show];
        [self.countrySelectView  reloadDataWithArray:self.countryAreaCodeArray withDefalutModel:self.currentCountryAreaCode withType:1];
        WEAKSELF
        self.countrySelectView.countryBlock = ^(CountryModel *country) {
            //手机区号
            weakSelf.currentCountryAreaCode=country;
            weakSelf.areaLabel.text=[NSString stringWithFormat:@"+%@",country.code];
            if (weakSelf.selectBlock) {
                weakSelf.selectBlock(@"areaCode", country.code);
            }
            
        };
        
        
    }else{
        [self getAllCountrysAreaCode];

    }
    
}

//选择国家
- (IBAction)countryClick:(UIButton *)sender {
    if (self.countryArray.count>0) {
        [self.countryView show];
        [self.countryView  reloadDataWithArray:self.countryArray withDefalutModel:self.currentCountry withType:0];
        WEAKSELF
        self.countryView.countryBlock = ^(CountryModel *country) {
            weakSelf.currentCountry=country;
            if (weakSelf.selectBlock) {
                weakSelf.selectBlock(@"country", country.code);
                weakSelf.selectBlock(@"cnName", country.cnName);
                weakSelf.selectBlock(@"usName", country.usName);
            }
           
            NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?country.usName:country.cnName;
            weakSelf.contentTF.text=countryName;

            
        };
    }else{
        [self getAllCountrys];
    }
  
}
//MARK: 获取支持的全部国家
-(void)getAllCountrys{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getShipListsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*countryArray=(NSMutableArray*)[CountryModel utr_modelsWithKeyValues:data[@"data"]];
            [self.countryView show];
            [self.countryView  reloadDataWithArray:countryArray withDefalutModel:self.currentCountry withType:0];
            WEAKSELF
            self.countryView.countryBlock = ^(CountryModel *country) {
                weakSelf.currentCountry=country;
                if (weakSelf.selectBlock) {
                    weakSelf.selectBlock(@"country", country.code);
                    weakSelf.selectBlock(@"cnName", country.cnName);
                    weakSelf.selectBlock(@"usName", country.usName);
                }
               
                NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?country.usName:country.cnName;
                weakSelf.contentTF.text=countryName;

                
            };
            
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
    }];
    
    
  
}

//MARK: 获取支持的全部国家区号
-(void)getAllCountrysAreaCode{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getCardShipWithcountryAreaCodesuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*countryArray=(NSMutableArray*)[CountryModel utr_modelsWithKeyValues:data[@"data"]];
            [self.countrySelectView show];
            [self.countrySelectView  reloadDataWithArray:countryArray withDefalutModel:self.currentCountryAreaCode withType:1];
            WEAKSELF
            self.countrySelectView.countryBlock = ^(CountryModel *country) {
                //手机区号
                weakSelf.currentCountryAreaCode=country;
                weakSelf.areaLabel.text=[NSString stringWithFormat:@"+%@",country.code];
                if (weakSelf.selectBlock) {
                    weakSelf.selectBlock(@"areaCode", country.code);
                }
                
            };
            
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
    }];
  
}


-(void)setCountryArray:(NSArray *)countryArray{
    _countryArray=countryArray;
    if (countryArray.count>0) {
        self.currentCountry=[countryArray firstObject];
    }
  
    //找国家对应的手机区号
    [self.countryAreaCodeArray enumerateObjectsUsingBlock:^(CountryModel* obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.abbr2 isEqualToString:self.currentCountry.code]) {
            self.currentCountryAreaCode=obj;
            *stop=YES;
        }
            
    }];
  
}

@end
