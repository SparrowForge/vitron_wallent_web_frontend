//
//  ApplyCardController.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/17.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"
#import "BinModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ApplyCardController : BaseViewController
@property(nonatomic,strong)BinModel*binModel;
@property (weak, nonatomic) IBOutlet UILabel *applyTitle;
@property (weak, nonatomic) IBOutlet UILabel *applyLabel;

@property(nonatomic,assign)int type;
//1:虚拟卡 2:实体卡

@end

NS_ASSUME_NONNULL_END
