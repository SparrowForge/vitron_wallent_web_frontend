//
//  CardPINController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/17.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "CardPINController.h"
#import "YCMenuView.h"
#import "VerifyPermissionView.h"
#import "MineNetWorkManager.h"


@interface CardPINController ()<UITextFieldDelegate>
{
    BOOL _pINCorrect;//上方一个输入框的pin格式是否正确
}
@property(nonatomic,strong) VerifyPermissionView*verifyView;
@property (weak, nonatomic) IBOutlet UIView *pinView;
@property (weak, nonatomic) IBOutlet UIView *confirmPinView;
@property (weak, nonatomic) IBOutlet UILabel *tipLabel;
@property (weak, nonatomic) IBOutlet UITextField *pinTF;
@property (weak, nonatomic) IBOutlet UITextField *confirmPinTF;
@property (weak, nonatomic) IBOutlet UILabel *pinTitle;
@property (weak, nonatomic) IBOutlet UILabel *confirmTitle;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIView *tips1View;
@property (weak, nonatomic) IBOutlet UIView *tips2View;
@property (weak, nonatomic) IBOutlet UILabel *tips1Label;
@property (weak, nonatomic) IBOutlet UILabel *tips2Label;
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *defaultHeight;
@property (weak, nonatomic) IBOutlet UILabel *pinAlertLabel1;
@property (weak, nonatomic) IBOutlet UILabel *pinAlertLabel2;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pinAlertLabelHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pinTopDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pinBottomDistance;



@property (nonatomic, assign) BOOL isPswViewExpanded;  // 用于跟踪视图是否展开
@end

@implementation CardPINController

- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:SetCardPINCode];
    }
    return _verifyView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"设置PIN码");
    self.pinAlertLabel1.text=LocalizationKey(@"PIN码格式不正确");
    self.pinAlertLabel2.text=LocalizationKey(@"PIN码格式不正确");
    //[self RightsetupNavgationItemWithImage:UIIMAGE(@"wenhao_account") withColor:[UIColor blackColor]];
    self.okBtn.enabled=NO;
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.defaultHeight.priority = UILayoutPriorityRequired;
    self.defaultHeight.constant=0;
    self.boardView.hidden=YES;
    self.isPswViewExpanded=NO;
    self.pinAlertLabel1.hidden=YES;
    self.pinAlertLabelHeight.constant=0;
    self.pinAlertLabel2.hidden=YES;
    [self setTextFieldObserverWithtextField:self.pinTF];
    [self setTextFieldObserverWithtextField:self.confirmPinTF];
    [self setBorderView:self.pinView];
    [self setBorderView:self.confirmPinView];
    self.tips1Label.text=LocalizationKey(@"不能按顺序排列三个或更多 (例：123674)");
    self.tips2Label.text=LocalizationKey(@"不能连续重复三次或更多 (例：111441)");
    NSString *text = LocalizationKey(@"密码格式说明：\n不能按顺序排列三个或更多（例：123674）\n不能连续重复三次或更多（例：111441）");

    // 创建一个可变的富文本字符串
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
    // 设置行间距
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 6;
    paragraphStyle.alignment = NSTextAlignmentLeft;
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    self.tipLabel.attributedText=attributedText;
    self.pinTitle.text=LocalizationKey(@"新PIN码");
    self.confirmTitle.text=LocalizationKey(@"确认PIN码");
    self.pinTitle.font=PingFangMediumFont(13);
    self.confirmTitle.font=PingFangMediumFont(13);
    [self.pinTF setStyleWithPlaceholder:LocalizationKey(@"请输入6位数字")];
    [self.confirmPinTF setStyleWithPlaceholder:LocalizationKey(@"请再次输入")];
    [self.okBtn setTitle:LocalizationKey(@"保存") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.pinTopDistance.constant=0;
    self.pinBottomDistance.constant=0;
    _pINCorrect=YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
}

-(void)setTextFieldObserverWithtextField:(UITextField *)textField{
    [textField addTarget:self action:@selector(textFieldDidBegin:) forControlEvents:UIControlEventEditingDidBegin];
    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [textField addTarget:self action:@selector(textFieldDidEndEditingAction:) forControlEvents:UIControlEventEditingDidEnd];
}

-(void)rightTouchEvent{

    NSString*showString=LocalizationKey(@"PIN码用于实体卡在POS、ATM等场景使用时的密码验证，请妥善保存。");
    YCMenuAction*action = [YCMenuAction actionWithTitle:showString image:nil handler:^(YCMenuAction *action) {
        
           }];
        NSMutableArray * array =  [NSMutableArray array];
        [array addObject:action];
        CGFloat height=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?150:100;
        YCMenuView*menuView = [YCMenuView menuWithActions:array width:230 relyonView:self.navigationItem.rightBarButtonItem];
        menuView.menuColor=[UIColor whiteColor];
        menuView.menuCellHeight=height;
        menuView.showType=2;
        menuView.textColor=[UIColor blackColor];
        menuView.maxDisplayCount =1;
        [menuView show];
    
}

-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}

//保存
- (IBAction)toSave:(id)sender {
  
  
    if ([NSString stringIsNull:self.pinTF.text]||self.pinTF.text.length!=6) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入6位数字PIN码"));
        return;
    }
    
    if ([NSString stringIsNull:self.confirmPinTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请再次输入6位数字PIN码"));
        return;
    }
    if (![self.pinTF.text isEqualToString:self.confirmPinTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"两个PIN码不一致"));
        return;
    }
    
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
        
        [weakSelf setUpCardPINWithpayPassword:payPassword withcode:code withType:type];
        
    };
    
}


//设置PIN码
-(void)setUpCardPINWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    if ([NSString stringIsNull:self.cardDetailDic[@"cardId"]]) {
        return;
    }
    NSString*codeType=type==0?@"code":@"googleCode";
    [SVProgressHUD customShowWithNone];
    [self.verifyView startAnimation];
    NSDictionary*dic=@{@"cardId":self.cardDetailDic[@"cardId"],@"payPassword":payPassword,codeType:code,@"pin":self.pinTF.text};
    
    [MineNetWorkManager updatePINWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.verifyView hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"设置成功"));
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self.navigationController popViewControllerAnimated:YES];
            });
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
         }
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            [self.verifyView stopAnimation];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
 }];

}

//MARK: 监听输入框开始编辑
- (void)textFieldDidBegin:(UITextField *)textField {
    if ([textField isEqual:self.pinTF]) {
        if (!self.isPswViewExpanded) {
            [self showAlertView];
        }

    }else{
        //确认密码
      
        
    }
    NSLog(@"开始编辑--%@",textField.text);
    
}
//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    if ([textField isEqual:self.pinTF]) {
        //pin码
        [self judgeCorrectpassword:self.pinTF.text withView:self.pinView];
        [self setAletViewAlpha];
    }else{
        //确认密码
        [self judgeCorrectpassword:self.confirmPinTF.text withView:self.confirmPinView];
    }
    [self judgeBtnStatus];
    
}
// 代理方法：监听 textField 失去第一响应者
- (void)textFieldDidEndEditingAction:(UITextField *)textField {
    if ([textField isEqual:self.pinTF]) {
        [self hideAlertView];
    }
}
- (IBAction)hideEyeClick:(UIButton *)sender {
    if (sender.tag==0) {
        sender.selected=!sender.selected;
        self.pinTF.secureTextEntry=sender.selected?NO:YES;
    }else {
        sender.selected=!sender.selected;
        self.confirmPinTF.secureTextEntry=sender.selected?NO:YES;
    }
    
}


//显示
-(void)showAlertView{
    self.pinTopDistance.constant=10;
    self.pinBottomDistance.constant=10;
    self.isPswViewExpanded=YES;
    self.boardView.hidden=NO;
    self.defaultHeight.priority = 250;
   
    [UIView animateWithDuration:0.3 animations:^{
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        [self.tips1View setCornerRadius:self.tips1View.mj_h/2.0];
        [self.tips2View setCornerRadius:self.tips2View.mj_h/2.0];
    }];
    
  
}

//隐藏
-(void)hideAlertView{
    
    if (_pINCorrect) {
        self.pinTopDistance.constant=0;
    }else{
        self.pinTopDistance.constant=10;
    }
    
    self.pinBottomDistance.constant=0;
    self.isPswViewExpanded=NO;
    self.defaultHeight.priority = UILayoutPriorityRequired;
    [UIView animateWithDuration:0.3 animations:^{
        // 设置 redView 的高度约束为 0
        self.defaultHeight.constant=0;
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.boardView.hidden=YES;

    }];
    
}

//判断按钮的可点击状态
-(void)judgeBtnStatus{
    
    if ([self isPasswordValid:self.pinTF.text]&&[self isPasswordValidForRepeatedDigits:self.pinTF.text]&&[self isPasswordValid:self.confirmPinTF.text]&&[self isPasswordValidForRepeatedDigits:self.confirmPinTF.text]&&self.pinTF.text.length==6&&self.confirmPinTF.text.length==6) {
        //可点击
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }else{
       //不可点击
        self.okBtn.enabled=NO;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    }
  
}
//判断密码格式是否正确
-(void)judgeCorrectpassword:(NSString*)password withView:(UIView*)view{
    
    if ([self isPasswordValid:password]&&[self isPasswordValidForRepeatedDigits:password]&&password.length==6) {
        //格式正确
        view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        view.backgroundColor=[UIColor whiteColor];
        if ([view isEqual:self.pinView]) {
            self.pinAlertLabel1.hidden=YES;
            self.pinAlertLabelHeight.constant=0;
            self.pinTopDistance.constant=10;
            self.pinBottomDistance.constant=0;
            _pINCorrect=YES;
            
        }else{
            self.pinAlertLabel2.hidden=YES;
        }
        
    }else{
        //格式错误
        view.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        view.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        if ([view isEqual:self.pinView]) {
            self.pinAlertLabel1.hidden=NO;
            self.pinAlertLabelHeight.constant=15;
            self.pinTopDistance.constant=10;
            self.pinBottomDistance.constant=10;
            _pINCorrect=NO;
        }else{
            self.pinAlertLabel2.hidden=NO;
        }
    }
 
}


-(void)setAletViewAlpha{
    
    self.tips1View.alpha=[self isPasswordValid:self.pinTF.text]?1:0.4;
    self.tips2View.alpha=[self isPasswordValidForRepeatedDigits:self.pinTF.text]?1:0.4;
    
}

//检查三个字符是否为递增或递减的连续数字
- (BOOL)isPasswordValid:(NSString *)password {
    // 遍历 password 的每个连续三位子字符串
    if (password.length <3) {
        return NO;
    }
    for (NSInteger i = 0; i <= password.length - 3; i++) {
        NSString *subString = [password substringWithRange:NSMakeRange(i, 3)];
        
        // 确保子字符串只包含数字
        if ([subString length] == 3 &&
            isdigit([subString characterAtIndex:0]) &&
            isdigit([subString characterAtIndex:1]) &&
            isdigit([subString characterAtIndex:2])) {
            
            // 获取每位数字的整数值
            NSInteger firstDigit = [subString characterAtIndex:0] - '0';
            NSInteger secondDigit = [subString characterAtIndex:1] - '0';
            NSInteger thirdDigit = [subString characterAtIndex:2] - '0';
            
            // 检查是否为连续递增或递减的数字序列
            BOOL isIncreasing = (secondDigit == firstDigit + 1) && (thirdDigit == secondDigit + 1);
            BOOL isDecreasing = (secondDigit == firstDigit - 1) && (thirdDigit == secondDigit - 1);
            
            if (isIncreasing || isDecreasing) {
                return NO; // 包含递增或递减的连续三位数，返回 NO
            }
        }
    }
    return YES; // 不包含递增或递减的连续三位数，返回 YES
}

//判断是否有连续三个重复的数字
- (BOOL)isPasswordValidForRepeatedDigits:(NSString *)password {
    // 遍历 password 的每个连续三位子字符串
    if (password.length <3) {
        return NO;
    }
    for (NSInteger i = 0; i <= password.length - 3; i++) {
        NSString *subString = [password substringWithRange:NSMakeRange(i, 3)];
        
        // 确保子字符串只包含数字
        if ([subString length] == 3 &&
            isdigit([subString characterAtIndex:0]) &&
            isdigit([subString characterAtIndex:1]) &&
            isdigit([subString characterAtIndex:2])) {
            
            // 检查三个字符是否相同
            unichar firstChar = [subString characterAtIndex:0];
            unichar secondChar = [subString characterAtIndex:1];
            unichar thirdChar = [subString characterAtIndex:2];
            
            if (firstChar == secondChar && secondChar == thirdChar) {
                return NO; // 找到连续三个重复的数字，返回 NO
            }
        }
    }
    return YES; // 没有连续三个重复的数字，返回 YES
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
