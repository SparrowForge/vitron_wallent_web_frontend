//
//  AllCardController.m
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "AllCardController.h"
#import "CardCarouselController.h"
#import "FilterItemCell.h"
#import "FilterItem.h"
#import "TABAnimated.h"
#import "FilterListView.h"
#import "AllCardCell.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "HomeCardNetWorkManager.h"
#import "NSObject+UBTrackerModel.h"


@interface AllCardController ()

{
    int _pageNO;
}
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) FilterListView*filterTypeView;
@property(nonatomic,strong) FilterListView*filterStatusView;
@property(nonatomic,strong) NSMutableDictionary*otherDic;
@property (nonatomic, strong) NSMutableArray *filterItems;
@property(nonatomic,strong)  NSArray*allCardArray;//全部的原始卡片数据

@end

@implementation AllCardController

-(NSMutableDictionary*)otherDic{
    if (!_otherDic) {
        _otherDic=[[NSMutableDictionary  alloc]init];
    }
    return _otherDic;
}

- (FilterListView *)filterTypeView {
    if(!_filterTypeView) {
        _filterTypeView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 3*68+HOME_INDICATOR_HEIGHT+60)withSelectMenuType:TypeForAllCard];
        _filterTypeView.currentDic=@{@"name":LocalizationKey(@"所有类型"),@"kind":@"-1"};
       
    }
    return _filterTypeView;
}

- (FilterListView *)filterStatusView {
    if(!_filterStatusView) {
        _filterStatusView=[FilterListView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 5*68+HOME_INDICATOR_HEIGHT+60)withSelectMenuType:StatusForAllCard];
        _filterStatusView.currentDic=@{@"name":LocalizationKey(@"所有状态"),@"kind":@"-1"};
    }
    return _filterStatusView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"全部卡片");
    [self RightsetupNavgationItemWithImage:UIIMAGE(@"addcards_panel") withColor:[UIColor blackColor]];
    [self configTopView];
    [self setTableViewConfig];
    [self getAllCards];
    // Do any additional setup after loading the view from its nib.
}


//申请卡
-(void)rightTouchEvent{
    
    [self.navigationController pushViewController:[[CardCarouselController alloc]init] animated:YES];
}

-(void)setTableViewConfig{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"AllCardCell" bundle:nil] forCellReuseIdentifier:@"AllCardCell"];
   
    self.tableView.tableFooterView=[UIView new];
    self.tableView.rowHeight=90;
    self.tableView.backgroundColor=[UIColor whiteColor];
    self.tableView.tabAnimated=[TABTableAnimated animatedWithCellClassArray:@[[AllCardCell class]] cellHeightArray:@[@90.0] animatedCountArray:@[@10]];
    [self headRefreshWithScrollerView:self.tableView];
    [self footRefreshWithScrollerView:self.tableView];
    [self.tableView tab_startAnimation];
   
}

-(void)configTopView{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumInteritemSpacing = 8;
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[FilterItemCell class] forCellWithReuseIdentifier:@"FilterItemCell"];
    FilterItem*typeItem=[[FilterItem alloc]init];
    typeItem.name=LocalizationKey(@"所有类型");
    typeItem.type=@"-1";
    typeItem.kind=0;
    
    FilterItem*statusItem=[[FilterItem alloc]init];
    statusItem.name=LocalizationKey(@"所有状态");
    statusItem.status=@"-1";
    statusItem.kind=1;
    
    self.filterItems=[@[typeItem,statusItem] mutableCopy];
    [self.collectionView reloadData];
    
}


//获取全部卡片
-(void)getAllCards{
    
    [HomeCardNetWorkManager getmerchantCardListsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.tableView tab_endAnimation];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
     
        });
        [self configEmptyViewForTableView];
       
        if ([data[@"code"] intValue]==200) {
            NSArray*cardArray=[CardModel utr_modelsWithKeyValues:data[@"data"]];
            self.allCardArray=cardArray;
            self.contentArray=[[NSMutableArray alloc]initWithArray:cardArray];
            [self.tableView reloadData];

            
        }else{
            
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            [self.tableView tab_endAnimation];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
         
            });
            [self configEmptyViewForTableView];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
  }];
    
    
}
-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}

#pragma mark - UICollectionView Delegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.filterItems.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FilterItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FilterItemCell" forIndexPath:indexPath];
    FilterItem *item = self.filterItems[indexPath.item];
    FilterItemCellType type =FilterItemCellTypeNormal;
    if (indexPath.item==0){
        //类型
        if ([item.type isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else{
        
        //状态
        if ([item.status isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }
    cell.type=type;
    cell.text = item.name;
    
    WEAKSELF
    cell.onCloseTapped = ^{
        NSLog(@"点击了第 %ld 个叉号", (long)indexPath.item);
        if (indexPath.item==0) {
            //类型
            FilterItem *item =[weakSelf.filterItems firstObject];
            item.type=@"-1";
            item.name=LocalizationKey(@"所有类型");
            [weakSelf.otherDic setValue:@"" forKey:@"typeString"];
            weakSelf.filterTypeView.currentDic=@{@"name":LocalizationKey(@"所有类型"),@"kind":@"-1"};
            [weakSelf.filterTypeView reloadTableView];
            [weakSelf getLastDataArray];
            
        }else{
            //状态
            FilterItem *item =[weakSelf.filterItems objectAtIndex:1];
            item.status=@"-1";
            item.name=LocalizationKey(@"所有状态");
            [weakSelf.otherDic setValue:@"" forKey:@"status"];
            weakSelf.filterStatusView.currentDic=@{@"name":LocalizationKey(@"所有状态"),@"kind":@"-1"};
            [weakSelf.filterStatusView reloadTableView];
            [weakSelf getLastDataArray];

        }
   
        [weakSelf.collectionView reloadData];
        
    };
    
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    FilterItem *item = self.filterItems[indexPath.item];
    NSString *text = item.name;
    FilterItemCellType type =FilterItemCellTypeDeletable;
    if (indexPath.item==0){
        //类型
        if ([item.type isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else if (indexPath.item==1){
        
        //状态
        if ([item.status isEqualToString:@"-1"]) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
        
    }else{
        //时间
        if (!item.isCustom ) {
            type=FilterItemCellTypeNormal;
        }else{
            type=FilterItemCellTypeDeletable;
        }
    }
    
    CGSize textSize = [text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:13]}];
    CGFloat base = textSize.width + 16*2; // padding
    if (type == FilterItemCellTypeDeletable) {
        base += 14 + 6; // 叉号 + 间距
    }
    return CGSizeMake(base, 32);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    WEAKSELF
    if (indexPath.item==0) {
        //类型
        [self.filterTypeView show];
        self.filterTypeView.filterMenuBlock = ^(NSString * _Nullable name, NSString * _Nullable type) {
            NSLog(@"类型--%@--%@",name,type);
            FilterItem *item =[weakSelf.filterItems firstObject];
            item.name=name;
            item.type=type;
            [weakSelf.collectionView reloadData];
            type= [type isEqualToString:@"-1"]?@"":type;
            [weakSelf.otherDic setValue:type forKey:@"typeString"];
            [weakSelf getLastDataArray];

            
        };
        
    }else {
        //状态
        [self.filterStatusView show];
        self.filterStatusView.filterMenuBlock = ^(NSString * _Nullable name, NSString * _Nullable status) {
            NSLog(@"状态--%@--%@",name,status);
            FilterItem *item =[weakSelf.filterItems objectAtIndex:1];
            item.name=name;
            item.status=status;
            [weakSelf.collectionView reloadData];
            status= [status isEqualToString:@"-1"]?@"":status;
            [weakSelf.otherDic setValue:status forKey:@"status"];
            [weakSelf getLastDataArray];
        };
        
    }
    
    
}


//获取最新的数据
-(void)getLastDataArray{
    
    NSString*status=self.otherDic[@"status"];
    NSString*type=self.otherDic[@"typeString"];
    NSLog(@"当前状态--%@,当前类型--%@",status,type);
    NSArray*lastArray=[self filterModels:self.allCardArray withStatus:status type:type];
    self.contentArray=[[NSMutableArray alloc]initWithArray:lastArray];
    [self.tableView reloadData];
   
}

- (NSArray *)filterModels:(NSArray *)models
               withStatus:(NSString *)status
                     type:(NSString *)type {
    if (!models || models.count == 0) return @[];
       
       NSMutableArray *result = [NSMutableArray array];
       
       for (id model in models) {
           id modelStatus = [model valueForKey:@"status"];
           id modelType   = [model valueForKey:@"type"];
           
           // 统一转成字符串，防止类型错误导致崩溃
           NSString *statusString = ([modelStatus isKindOfClass:[NSNumber class]] ?
                                     [modelStatus stringValue] :
                                     (NSString *)modelStatus);
           NSString *typeString   = ([modelType isKindOfClass:[NSNumber class]] ?
                                     [modelType stringValue] :
                                     (NSString *)modelType);
           
           BOOL matchStatus = YES;
           BOOL matchType   = YES;
           
           // 只有当status有值时才筛选
           if (status != nil && status.length > 0) {
               matchStatus = [statusString isEqualToString:status];
           }
           
           // 只有当type有值时才筛选
           if (type != nil && type.length > 0) {
               matchType = [typeString isEqualToString:type];
           }
           
           if (matchStatus && matchType) {
               [result addObject:model];
           }
       }
       
       return result;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
  
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    AllCardCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AllCardCell"];
    CardModel*model=self.contentArray[indexPath.row];
    cell.model=model;
    cell.flagView.hidden=[model.cardId isEqualToString:self.cardDetailDic[@"cardId"]]?NO:YES;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CardModel*model=self.contentArray[indexPath.row];
    if (self.selectCardBlock) {
        self.selectCardBlock(model);
    }
    [self.navigationController popViewControllerAnimated:YES];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
