//
//  ApplyCardController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/17.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "ApplyCardController.h"
#import "HomeCardNetWorkManager.h"
#import "ApplyBexCardView.h"
#import "VerifyPermissionView.h"
#import "ApplySuccessView.h"

@interface ApplyCardController ()

{
    
    NSString*_cardTips;//卡标签
}
@property(nonatomic,strong) ApplyBexCardView*applyCardView;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property(nonatomic,strong) VerifyPermissionView*verifyView;

@property (weak, nonatomic) IBOutlet UIView *bottomView;

@end

@implementation ApplyCardController

- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:CardToOpen];
    }
    return _verifyView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _cardTips=@"";
    self.binModel.type=[NSString stringWithFormat:@"%d",self.type];//重置type，适配UI显示虚拟卡还是实体卡
    self.title=LocalizationKey(@"卡片申请标题");
    self.applyTitle.text=LocalizationKey(@"申请费用");
    self.applyTitle.font=PingFangMediumFont(13);
    self.applyLabel.font=PingFangMediumFont(17);
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self.okBtn setTitle:LocalizationKey(@"申请卡") forState:UIControlStateNormal];
    self.okBtn.enabled=YES;
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];/**https://www.jianshu.com/p/8b3b3aeb2430**/
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
     
        UIScrollView*scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NAVIGATION_BAR_HEIGHT, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-HOME_INDICATOR_HEIGHT-200)];
        scrollView.backgroundColor=[UIColor whiteColor];
        [self.view addSubview:scrollView];
        scrollView.contentSize=CGSizeMake(kWindowW,700);
        self.applyCardView=[ApplyBexCardView instanceViewWithFrame:CGRectMake(0, 0, kWindowW,700)withApplyCard:self.binModel];
        WEAKSELF
      
        self.applyCardView.cardTipsBlock = ^(NSString * _Nullable tipsString) {
            [weakSelf judgeBtnStatuswithtype:1 withContent:tipsString];
            
        };
        [scrollView addSubview:self.applyCardView];
        [self.view bringSubviewToFront:self.bottomView];
      
    });
    self.applyLabel.text=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:(self.binModel.baseCardFee+self.binModel.applyCard)]];
    if (self.type==1) {
        self.applyLabel.text=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:(self.binModel.baseCardFee+self.binModel.applyCard)]];
        NSLog(@"虚拟卡...");
    }else{
        self.applyLabel.text=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:(self.binModel.basePhysicalCardFee+self.binModel.applyCard)]];
        NSLog(@"实体卡...");
    }
    NSLog(@"这是类型--%d",self.type);
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];

}


-(void)judgeBtnStatuswithtype:(int)type withContent:(NSString*)content{
    _cardTips=content;
  
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = NO;
}

//提交申请
- (IBAction)submitClick:(UIButton *)sender {
    
    
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
       
        [weakSelf applyOpenCardWithpayPassword:payPassword withcode:code withType:type];
        
    };
    
}

//申请开卡
-(void)applyOpenCardWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    [SVProgressHUD customShowWithNone];
    [self.verifyView startAnimation];
    NSString*codeType=type==0?@"code":@"googleCode";
    NSString*cardType=self.type==1?@"VIRTUAL_CARD":@"PHYSICAL_CARD";
    [HomeCardNetWorkManager applyOpenCardWithparams:@{@"cardBinId":self.binModel.ID,@"amount":@"0",@"payPassword":payPassword,codeType:code,@"alias":_cardTips,@"cardType":cardType} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView hide];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.view endEditing:YES];
            ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
            successView.titleLabel.text=LocalizationKey(@"温馨提示");
            successView.detailLabel.text=LocalizationKey(@"您的卡片已申请成功");
            successView.tipsImageV.image=UIIMAGE(@"orderSuccess");
            WEAKSELF
            [successView.okBtn dn_addActionHandler:^{
                [successView hide];
                [weakSelf.navigationController popViewControllerAnimated:YES];
            }];
            [successView show];
            [[NSNotificationCenter defaultCenter] postNotificationName:ReloadBIN object:nil];
            
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
   
}







/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
