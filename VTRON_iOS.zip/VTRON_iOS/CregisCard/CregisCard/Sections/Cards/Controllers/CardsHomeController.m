//
//  CardsHomeController.m
//  CregisCard
//
//  Created by 孙良 on 2023/11/2.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import "CardsHomeController.h"
#import "NOKYCHeadView.h"
#import "AccountOtherCell.h"
#import "NOKYCCell.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "NOCardHeadView.h"
#import "CardSectionView.h"
#import "HomeCardHeadView.h"
#import "NOCardCell.h"
#import "HomeCardNetWorkManager.h"
#import "YCMenuView.h"
#import "CardCarouselController.h"
#import "AllCardController.h"
#import "LoginOverdueView.h"
#import "LoginController.h"
#import "VerifyPermissionView.h"
#import "HomeCardNetWorkManager.h"
#import "OrderRecordModel.h"
#import "NSObject+UBTrackerModel.h"
#import "TransactionDetailController.h"
#import "TransactionViewController.h"
#import "FWPopupWindow.h"
#import "MailingAddressController.h"
#import "MineNetWorkManager.h"
#import "AccountNetWorkManager.h"
#import "ApplyCarouseView.h"
#import "TABAnimated.h"
#import "CardRechargeController.h"
#import "CardWithdrawController.h"
#import "CardOperationController.h"
#import "CardMoreView.h"


@interface CardsHomeController ()<UIGestureRecognizerDelegate,UITableViewDelegate,UITableViewDataSource>

{
    int _pageNO;
    BOOL _isHideCardNum;
}

@property (weak, nonatomic)  IBOutlet UIView *barView;
@property (weak, nonatomic)  IBOutlet NSLayoutConstraint *barHeight;
@property (weak, nonatomic)  IBOutlet NSLayoutConstraint *topDistance;
@property(nonatomic,assign)  HomeCardType cardType;
@property (strong, nonatomic)   UITableView *tableView;
@property (weak, nonatomic)  IBOutlet UILabel *statusLabel;
@property (weak, nonatomic)  IBOutlet UIButton *rightButton;
@property (weak, nonatomic)  IBOutlet UILabel *aliasLabel;
@property(nonatomic,strong)  NSMutableArray*contentArray;
@property(nonatomic,strong)  HomeCardHeadView*cardHeadView;
@property(nonatomic,strong)  NSDictionary*currentCardDic;
@property(nonatomic,strong)  ApplyCarouseView *mainApplyingView;
@property(nonatomic,strong)  VerifyPermissionView*verifyView;
@property(nonatomic,strong)  NSDictionary*cardDetailDic;//卡详情
@property (nonatomic, strong) UIView *overlayView;  // 遮罩视图
@property (nonatomic, strong) CardMoreView *cardMoreView;
@property(nonatomic,assign) NSString*pendingCount;//申请中的卡片数量
@end

@implementation CardsHomeController

- (ApplyCarouseView *)mainApplyingView {
    if(!_mainApplyingView) {
        _mainApplyingView=[ApplyCarouseView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-TAB_BAR_HEIGHT-HOME_INDICATOR_HEIGHT)];
        _mainApplyingView.translatesAutoresizingMaskIntoConstraints = NO;
        _mainApplyingView.backgroundColor=[UIColor whiteColor];
    }
    return _mainApplyingView;
}
- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:CardDetail];
    }
    return _verifyView;
}


- (CardMoreView *)cardMoreView {
    if(!_cardMoreView) {
        _cardMoreView=[CardMoreView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 200)];
        WEAKSELF
        _cardMoreView.btnMenuBlock = ^(int type) {
            [weakSelf btnMenuClick:type];
        };
    }
    return _cardMoreView;
}
-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _pageNO=1;
    _isHideCardNum=YES;
    [self setTableViewConfig];
    [self startFrameAnimation];
    self.cardType=-1;//默认
    [self getCardListForFirst:YES];
    [self getPendingCardCount];//获取申请中卡片数量
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPendingCardCount)name: ReloadBIN object:nil];
   
    // Do any additional setup after loading the view from its nib.
}


// 启动帧动画
- (void)startFrameAnimation {
    self.animateImageV=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
    self.animateImageV.dn_centerX=self.view.dn_centerX;
    self.animateImageV.dn_centerY=self.view.dn_centerY;
    self.animateImageV.image=UIIMAGE(@"mo-0");
    [self.view addSubview:self.animateImageV];
    // 加载帧图片
    NSMutableArray *frames = [NSMutableArray array];
    for (int i = 0; i<20; i++) {
        NSString *imageName = [NSString stringWithFormat:@"mo-%d.png", i];
        UIImage *frameImage = [UIImage imageNamed:imageName];
        [frames addObject:frameImage];
    }
    
    // 设置动画图片、动画时长和循环次数
    self.animateImageV.animationImages = frames;  // 设置动画帧
    self.animateImageV.animationDuration = 2.0;  // 动画总时长
    self.animateImageV.animationRepeatCount = 0;  // 循环次数为0表示无限循环
    // 启动动画
    [self.animateImageV startAnimating];
}

// 停止帧动画
- (void)stopFrameAnimation {
    
    [self.animateImageV stopAnimating];
    [self.animateImageV removeFromSuperview];
    self.tableView.hidden=NO;
    return;
    // 停止动画
      [UIView animateWithDuration:0.4 animations:^{
          self.animateImageV.frame=CGRectMake(0, 0, 60, 60);
          self.animateImageV.dn_centerX=self.view.dn_centerX;
    } completion:^(BOOL finished) {
      
        [self.animateImageV stopAnimating];
        [self.animateImageV removeFromSuperview];
        self.tableView.hidden=NO;
        
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    [self getCardListForFirst:NO];
    [self.cardHeadView showCardDetailWithDataDic:[NSDictionary new] withIsHide:YES];//每次都默认隐藏
    self->_isHideCardNum=YES;
    if ([[UserWrapper shareUserInfo].kycStatus intValue]!=5) {
        [self getMemberInfo];//刷新kyc状态
    }
}

-(void)setTableViewConfig{
    self.tableView= [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.view addSubview:self.tableView];
    [self.tableView registerNib:[UINib nibWithNibName:@"AccountRecordCell" bundle:nil] forCellReuseIdentifier:@"AccountRecordCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AccountOtherCell" bundle:nil] forCellReuseIdentifier:@"AccountOtherCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"NOKYCCell" bundle:nil] forCellReuseIdentifier:@"NOKYCCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"NOCardCell" bundle:nil] forCellReuseIdentifier:@"NOCardCell"];
    self.tableView.tabAnimated=[TABTableAnimated animatedWithCellClassArray:@[[AccountOtherCell class]] cellHeightArray:@[@120.0] animatedCountArray:@[@10]];
    [self.tableView tab_startAnimation];
    self.tableView.tableFooterView=[UIView new];
    self.tableView.backgroundColor=[UIColor whiteColor];
    
}

-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}
//MARK: 设置表头
-(void)setTableHeaderView{
   
    if (self.cardType==NOKYCTypeCard) {
        //未KYC认证
        UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, NAVIGATION_BAR_HEIGHT+24+(kWindowW-24*2)*215/342.0)];
        NOKYCHeadView*kycHeadView=[NOKYCHeadView instanceViewWithFrame:headView.bounds];
        [headView addSubview:kycHeadView];
        self.tableView.tableHeaderView=headView;
    }else if(self.cardType==NOCARDTypeCard){
        //未申请卡片
        UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, NAVIGATION_BAR_HEIGHT+24+(kWindowW-24*2)*215/342.0)];
        NOCardHeadView*noCardHeadView=[NOCardHeadView instanceViewWithFrame:headView.bounds];
        [headView addSubview:noCardHeadView];
        self.tableView.tableHeaderView=headView;
        
    }else{
        //正常状态
        CGFloat alertViewHeight=0;
        if ([self.pendingCount intValue]>0) {
            alertViewHeight=44;
        }
        CGFloat shipButtonHeight=([self.cardDetailDic[@"type"] intValue]==2&&[self.cardDetailDic[@"isShip"] intValue]==0&&![self.currentCardDic[@"status"] isEqualToString:@"02"]&&![self.currentCardDic[@"status"] isEqualToString:@"05"])?(70-10):0;
        
        UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 15+alertViewHeight+60+(kWindowW-24*2)*215/342.0+120+shipButtonHeight-2)];
        self.cardHeadView=[HomeCardHeadView instanceViewWithFrame:headView.bounds];
        NSLog(@"--------%@",self.cardDetailDic);
        if (self.currentCardDic) {
            self.cardHeadView.dataDic=self.currentCardDic;//重置数据
            self.cardHeadView.balance=[NSString formattedStringWithDouble:[self.cardDetailDic[@"balance"] doubleValue]];//该卡片资产
            self.cardHeadView.currencyLabel.text=self.cardDetailDic[@"currency"];
        }
        WEAKSELF
        [self.cardHeadView.moreBtn dn_addActionHandler:^{
            [weakSelf showMoreMenuView];
        }];
        self.cardHeadView.btnSelectBlock = ^(int tag) {
            [weakSelf cardHomeViewBtnMenuWithTag:tag];
        };
        [headView addSubview:self.cardHeadView];
        self.tableView.tableHeaderView=headView;

        
        if (!self.tableView.mj_header) {
            [self headRefreshWithScrollerView:self.tableView];
           // [self footRefreshWithScrollerView:self.tableView];
        }
        
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.cardType==NORMALTypeCard) {
        return  self.contentArray.count>0?self.contentArray.count:1;
    }
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.cardType==NOKYCTypeCard) {
        NOKYCCell*cell=[tableView dequeueReusableCellWithIdentifier:@"NOKYCCell"];
        return cell;
    }else if (self.cardType==NOCARDTypeCard){
        NOCardCell*cell=[tableView dequeueReusableCellWithIdentifier:@"NOCardCell"];
        return cell;
        
    }else{
        
        if (self.contentArray.count>0) {
            
            AccountOtherCell*cell=[tableView dequeueReusableCellWithIdentifier:@"AccountOtherCell"];
            [cell configDataWithModel:self.contentArray[indexPath.row] withType:1];
            return cell;
          
        }else{
            NOCardCell*cell=[tableView dequeueReusableCellWithIdentifier:@"NOCardCell"];
            return cell;
      
        }
     
    }
  
}


-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    UIView*view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW,60)];
    view.backgroundColor=[UIColor whiteColor];
    CardSectionView*sectionView=[CardSectionView instanceViewWithFrame:view.bounds withHomeCardType:(int)self.cardType];
    WEAKSELF
    //全部
    [sectionView.allBtn dn_addActionHandler:^{
        TransactionViewController*allCountVC=[[TransactionViewController alloc]init];
        allCountVC.type=1;
        allCountVC.cardId=weakSelf.currentCardDic[@"cardId"];
        [weakSelf.navigationController pushViewController:allCountVC animated:YES];
    }];
    [view addSubview:sectionView];
   
    return self.cardType==NOKYCTypeCard?[[UIView alloc]init]:view;

  }

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

      return self.cardType==NOKYCTypeCard?0.01:60;
 }

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.contentArray.count>0&&self.cardType==NORMALTypeCard) {
        TransactionDetailController*detailVC=[[TransactionDetailController alloc]init];
        detailVC.type=1;
        detailVC.orderModel=self.contentArray[indexPath.row];
        [self.navigationController pushViewController:detailVC animated:YES];
    }
   
    
}



-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.cardType==NORMALTypeCard) {
        if (self.contentArray.count>0) {
           
            return 106;
        }else{
            return 200;
        }
    }else if (self.cardType==NOKYCTypeCard){
        return (kWindowH-(NAVIGATION_BAR_HEIGHT+24+(kWindowW-24*2)*215/342.0));
    }else{
        return (kWindowH-(NAVIGATION_BAR_HEIGHT+24+(kWindowW-24*2)*215/342.0)-90);
    }
  
}
//MARK: 获取卡片列表
-(void)getCardListForFirst:(BOOL)isFirst{
    
    if (isFirst) {
        self.tableView.hidden=YES;
    }
    [HomeCardNetWorkManager getmerchantCardListsuccess:^(id  _Nonnull data) {
        if ([data[@"code"] intValue]==200) {
            if (self.tableView.hidden) {
                [self stopFrameAnimation];
            }
          
            NSArray*dataArray=data[@"data"];
           // NSArray*dataArray=@[];
            if (dataArray.count>0) {
                if (isFirst||!self.currentCardDic) {
                    NSDictionary*defalutDic=[dataArray objectAtIndex:0];
                    self.aliasLabel.text=defalutDic[@"alias"];
                    self.currentCardDic=defalutDic;
                    self.cardHeadView.dataDic=defalutDic;
                    [self LeftsetupNavgationItemWithImage:UIIMAGE(@"leftAllcards") withColor:[UIColor blackColor]];
                    [self RightsetupNavgationItemWithImage:UIIMAGE(@"addCards") withColor:[UIColor blackColor]];
                    
                    
                }else{
                    [dataArray enumerateObjectsUsingBlock:^(NSDictionary* dic, NSUInteger idx, BOOL * _Nonnull stop) {
                        if ([dic[@"cardId"] isEqualToString:self.currentCardDic[@"cardId"]]) {
                            self.currentCardDic=dic;
                            self.aliasLabel.text=dic[@"alias"];
                            self.cardHeadView.dataDic=dic;
                            *stop=YES;
                        }
                    }];
                    
                }
                if (self.cardType!=NORMALTypeCard) {
                    self.cardType=NORMALTypeCard;
                    [self setTableHeaderView];//重置表头
                    [self.tableView reloadData];
                }
                [self getCardBalance];//获取资金总额
                self->_pageNO=1;
                [self.tableView.mj_footer resetNoMoreData];
                [self getCardFlowList];//获取卡片流水
            }else{
                //未申请卡片
                [self.tableView tab_endAnimation];
                [self configEmptyViewForTableView];
                if (self.cardType!=NOCARDTypeCard) {
                    self.cardType=NOCARDTypeCard;
                    [self setTableHeaderView];//重置表头
                    [self.tableView reloadData];
                }
                
            }
            if (!self.tableView.tableHeaderView) {
                //未设置表头
                [self setTableHeaderView];
                [self.tableView reloadData];
            }
            if (dataArray.count<=0) {
                [self setUpMainApplyingView];
            }else{
                
                if (self.mainApplyingView) {
                    [self.mainApplyingView  removeFromSuperview];
                }
            }
           
        }else{
            
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            if (isFirst) {
                [self.animateImageV stopAnimating];
                [self.animateImageV removeFromSuperview];
            }
        }
        
        
        } fail:^(NSError * _Nonnull eporror) {
            [self setUpMainApplyingView];//请求出错时候也要显示占位
            if (isFirst) {
                [self.animateImageV stopAnimating];
                [self.animateImageV removeFromSuperview];
            }
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
  }];
    
}
//MARK: 获取卡片列表
-(void)getCardListForFirst1:(BOOL)isFirst{
    
    if (isFirst) {
        self.tableView.hidden=YES;
    }
    [SVProgressHUD customShowWithStyle];
    [HomeCardNetWorkManager getmerchantCardListsuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            if (self.tableView.hidden) {
               /* self.tableView.hidden=NO*/;
                [self stopFrameAnimation];
            }
          NSArray*dataArray=data[@"data"];
            if (dataArray.count>0) {
                if (isFirst||!self.currentCardDic) {
                    NSDictionary*defalutDic=[dataArray objectAtIndex:0];
                    self.aliasLabel.text=defalutDic[@"alias"];
                    self.currentCardDic=defalutDic;
                    self.cardHeadView.dataDic=defalutDic;
                    [self LeftsetupNavgationItemWithImage:UIIMAGE(@"leftAllcards") withColor:[UIColor blackColor]];
                    [self RightsetupNavgationItemWithImage:UIIMAGE(@"addCards") withColor:[UIColor blackColor]];
                    
                    
                }else{
                    [dataArray enumerateObjectsUsingBlock:^(NSDictionary* dic, NSUInteger idx, BOOL * _Nonnull stop) {
                        if ([dic[@"cardId"] isEqualToString:self.currentCardDic[@"cardId"]]) {
                            self.currentCardDic=dic;
                            self.aliasLabel.text=dic[@"alias"];
                            self.cardHeadView.dataDic=dic;
                            *stop=YES;
                        }
                    }];
                    
                }
                if (self.cardType!=NORMALTypeCard) {
                    self.cardType=NORMALTypeCard;
                    [self setTableHeaderView];//重置表头
                    [self.tableView reloadData];
                }
                [self getCardBalance];//获取资金总额
                self->_pageNO=1;
                [self.tableView.mj_footer resetNoMoreData];
                [self getCardFlowList];//获取卡片流水
            }else{
                //未申请卡片
                [self.tableView tab_endAnimation];
                [self configEmptyViewForTableView];
                if (self.cardType!=NOCARDTypeCard) {
                    self.cardType=NOCARDTypeCard;
                    [self setTableHeaderView];//重置表头
                    [self.tableView reloadData];
                }
            }
            if (!self.tableView.tableHeaderView) {
                //未设置表头
                [self setTableHeaderView];
                [self.tableView reloadData];
            }
            if (dataArray.count<=0) {
                self.navigationItem.leftBarButtonItem = nil;
                self.navigationItem.rightBarButtonItem = nil;
                [self setUpMainApplyingView];
            }else{
                
                if (self.mainApplyingView) {
                    [self.mainApplyingView  removeFromSuperview];
                }
            }
            
        }else{
            
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
    } fail:^(NSError * _Nonnull eporror) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}
//MARK:获取卡片流水
-(void)getCardFlowList{
    
    if ([NSString stringIsNull:self.currentCardDic[@"cardId"]]) {
        return;
    }

    NSMutableDictionary*dic=[@{@"pageIndex":@(_pageNO),@"pageSize":@(10),@"cardId":self.currentCardDic[@"cardId"]} mutableCopy];
 
    [MineNetWorkManager getCardRecordListWithParams:dic success:^(id  _Nonnull data) {
        [self.tableView tab_endAnimation];
        [self configEmptyViewForTableView];

        if ([data[@"code"] intValue]==200) {
            
            if(self->_pageNO==1){
                [self.contentArray removeAllObjects];
            }
            NSArray*onceArray=[OrderRecordModel utr_modelsWithKeyValues:data[@"data"][@"records"]];
            if(onceArray.count>0){
                [self.contentArray addObjectsFromArray:onceArray];
            }
            [self.tableView reloadData];
            if(self.contentArray.count==[data[@"data"][@"total"] intValue]){
                [self.tableView.mj_footer endRefreshingWithNoMoreData];
            }
            
        }else{
            
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [self.tableView tab_endAnimation];
        [self configEmptyViewForTableView];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}
//查看全部卡片
-(void)LefttouchEvent{
    
    [self showPanel];
   
}
//全部菜单
-(void)rightTouchEvent{
   
    [self showMoreMenuView];
    
}
//MARK: 上拉加载更多
- (void)refreshFooterAction{
    _pageNO+=1;
    [self getCardFlowList];
}

//MARK: 下拉刷新
- (void)refreshHeaderAction{
    _pageNO=1;
    [self.tableView.mj_footer resetNoMoreData];
    [self getCardFlowList];
    [self getCardBalance];
    [self getCardListForFirst:NO];
    [self getPendingCardCount];//获取申请中卡片数量

}


//MARK: 点击更多按钮菜单
-(void)showMoreMenuView{
    
    [self.navigationController pushViewController:[[CardCarouselController alloc] init] animated:YES];
    
}

//MARK: 登录下线提醒
-(void)showLoginOverdueView{
  
    [SVProgressHUD dismiss];
    UIView* attachedView = [FWPopupWindow sharedWindow].attachView;
    UIView *foundView = [attachedView viewWithTag:19029];//防止多次弹窗
    if (foundView) {
        return;
    }
    LoginOverdueView*overdueView=[LoginOverdueView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2,300)];
    overdueView.tag=19029;
    WEAKSELF
    [overdueView.okBtn dn_addActionHandler:^{
        [overdueView hide];
        [weakSelf logout];
    }];
    [overdueView show];
}

//MARK: MoreView按钮点击事件
-(void)btnMenuClick:(int)type{
    
    if (type==0) {
        //提现
        if(!self.cardDetailDic){
            return;
        }
        CardWithdrawController*cardWithdrawVC=[[CardWithdrawController alloc]init];
        cardWithdrawVC.cardDetailDic=self.cardDetailDic;
        [self.navigationController pushViewController:cardWithdrawVC animated:YES];
        
    }else if (type==1){
        //冻结
        [self dealWithFrozenOrUnFrozen];
      
    }else{
        //注销卡
        if ([self.currentCardDic[@"status"] isEqualToString:@"05"]){
            //如果当前已经是注销状态
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"该卡暂不支持该操作！"));
            return;
        }
        WEAKSELF
        CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        VerifyPermissionView*verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 400+extraHeight+addtionalHeight) withVerifyPermissionType:CardUnsubscribe];
         __block typeof(verifyView) strongVerifyView = verifyView;
         verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
             [weakSelf applyTocloseCardWithpayPassword:payPassword withcode:code withType:type withPermissionView:strongVerifyView];
         };
          [verifyView show];
    }
    
    
}

//MARK: 首页卡片菜单按钮点击事件
-(void)cardHomeViewBtnMenuWithTag:(int)tag{
    
    if (tag==0) {
        //安全码
        if (_isHideCardNum) {
            //去显示
            [self.verifyView show];
            [self.verifyView resetBtnColor];
            WEAKSELF
            self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
                [weakSelf getCardCloseDetailwithpayPassword:payPassword withType:type];
            };
        }else{
            //去隐藏
            [self.cardHeadView showCardDetailWithDataDic:[NSDictionary new] withIsHide:YES];
            self->_isHideCardNum=YES;
        }
       

    }else if (tag==1){
       //卡充值
        if(!self.currentCardDic){
            return;
        }
        CardRechargeController*cardRechargeVC=[[CardRechargeController alloc]init];
        cardRechargeVC.cardDetailDic=self.currentCardDic;
        [self.navigationController pushViewController:cardRechargeVC animated:YES];

    }else if (tag==2){
        if ([self.currentCardDic[@"type"] intValue]==1) {
            //虚拟卡
            [self dealWithFrozenOrUnFrozen];
            
        }else{
            //实体卡
           //实体卡管理
            if (!self.cardDetailDic) {
                return;
            }
            CardOperationController*cardManageVC=[[CardOperationController alloc]init];
            cardManageVC.cardDetailDic=self.cardDetailDic;
            [self.navigationController pushViewController:cardManageVC animated:YES];
            
            
        }
      
        
    }else{
        //更多
        if (!self.currentCardDic) {
            return;
        }
        [self.cardMoreView showwithCurrentDic:self.currentCardDic];
       
    }
  
}

//处理冻结或者解冻显示
-(void)dealWithFrozenOrUnFrozen{
    
    //正常状态，去冻结
    WEAKSELF
    if ([self.currentCardDic[@"status"] isEqualToString:@"01"]||[self.currentCardDic[@"status"] isEqualToString:@"02"]||[self.currentCardDic[@"status"] isEqualToString:@"03"]) {
        if ([weakSelf.currentCardDic[@"frozenFeat"] intValue]==0) {
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"该卡暂不支持冻结"));
            return;
        }
        //去冻结
       CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
       CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
       VerifyPermissionView*verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 400+extraHeight+addtionalHeight) withVerifyPermissionType:CardFreeze];
        __block typeof(verifyView) strongVerifyView = verifyView;
        verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
            [weakSelf modifyCardStatus:@"0" WithpayPassword:payPassword withcode:code withType:type withPermissionView:strongVerifyView];
        };
         [verifyView show];
        
    }else if ([self.currentCardDic[@"status"] isEqualToString:@"04"]){
        //冻结状态，去解冻
        if ([weakSelf.currentCardDic[@"frozenFeat"] intValue]==0) {
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"该卡暂不支持解冻"));
            return;
        }
        CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
         VerifyPermissionView*verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 400+extraHeight+addtionalHeight) withVerifyPermissionType:CardThaw];
        __block typeof(verifyView) strongVerifyView = verifyView;
        verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
           
            [weakSelf modifyCardStatus:@"1" WithpayPassword:payPassword withcode:code withType:type withPermissionView:strongVerifyView];
        };
        [verifyView show];
    }
    else if ([self.currentCardDic[@"status"] isEqualToString:@"05"]){
        //当前是销卡状态
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"该卡暂不支持该操作！"));
    }else{
        //其他状态
        //去冻结
       CGFloat addtionalHeight= [[ChangeLanguage userLanguage] isEqualToString:@"en"]?15:0;
       CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
       VerifyPermissionView*verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 400+extraHeight+addtionalHeight) withVerifyPermissionType:CardFreeze];
        __block typeof(verifyView) strongVerifyView = verifyView;
        verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
            [weakSelf modifyCardStatus:@"0" WithpayPassword:payPassword withcode:code withType:type withPermissionView:strongVerifyView];
        };
         [verifyView show];
    }
    
    
    
}

//销卡
-(void)applyTocloseCardWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type withPermissionView:(VerifyPermissionView*)permissionView{
    [SVProgressHUD customShowWithNone];
    [permissionView startAnimation];
    NSString*codeType=type==0?@"code":@"googleCode";
    [HomeCardNetWorkManager applyCloseCardWithparams:@{@"payPassword":payPassword,codeType:code,@"cardId":self.currentCardDic[@"cardId"]} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [permissionView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [permissionView hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"操作成功"));
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self getCardListForFirst:NO];//延迟执行，等待状态改变，刷新数据
                
            });
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [permissionView stopAnimation];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
   
}

//MARK:卡解冻，卡冻结
-(void)modifyCardStatus:(NSString*)status WithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type withPermissionView:(VerifyPermissionView*)permissionView{
    
    [SVProgressHUD customShowWithNone];
    [permissionView startAnimation];
    NSString*codeType=type==0?@"code":@"googleCode";
    [HomeCardNetWorkManager changeCardStatusWithparams:@{@"status":status,@"payPassword":payPassword,codeType:code,@"cardId":self.currentCardDic[@"cardId"]} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [permissionView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [permissionView hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"操作成功"));
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                //延迟两秒刷新状态（状态不一定及时变化）
                [self getCardListForFirst:NO];//刷新数据
                
            });
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [permissionView stopAnimation];
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];

}

//MARK: 获取申请中的卡片数量
-(void)getPendingCardCount{
  
    [HomeCardNetWorkManager getPendingCardCountsuccess:^(id  _Nonnull data) {
       
        if ([data[@"code"] intValue]==200) {
            self.pendingCount=data[@"data"];
            [self setTableHeaderView];//重置表头
            [self.tableView reloadData];
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    
        
    } fail:^(NSError * _Nonnull error) {
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}

//MARK:获取卡片资金
-(void)getCardBalance{
 
    if ([NSString stringIsNull:self.currentCardDic[@"cardId"]]) {
        return;
    }
    [HomeCardNetWorkManager getCardCloseDetailWithparams:@{@"cardId":self.currentCardDic[@"cardId"]} success:^(id  _Nonnull data) {
        if ([data[@"code"] intValue]==200) {
            self.cardHeadView.balance=[NSString formattedStringWithDouble:[data[@"data"][@"balance"] doubleValue]];//该卡片资产
            self.cardHeadView.currencyLabel.text=data[@"data"][@"currency"];
            self.cardDetailDic=data[@"data"];
            [self setTableHeaderView];
            [self.cardHeadView configUIWithCardDetailDic:data[@"data"] withpendingCount:self.pendingCount];
            
        }else{
            
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
        
        } fail:^(NSError * _Nonnull error) {
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
  }];
    
}

//MARK: 获取卡号详情
-(void)getCardCloseDetailwithpayPassword:(NSString*)payPassword withType:(int)type{
    [SVProgressHUD customShowWithNone];
    [self.verifyView startAnimation];
   
    NSDictionary*dic=@{@"cardId":self.currentCardDic[@"cardId"],@"payPassword":payPassword};
    
    [HomeCardNetWorkManager getCardOpenDetailWithparams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
         [self.verifyView hide];
            NSMutableDictionary*dic=[[NSMutableDictionary alloc]initWithDictionary:data[@"data"]];
            [dic setValue:self.currentCardDic[@"cardType"] forKey:@"cardType"];
            [dic setValue:self.currentCardDic[@"type"] forKey:@"type"];
            [self.cardHeadView showCardDetailWithDataDic:dic withIsHide:NO];
            self->_isHideCardNum=NO;
            
        }else{
            
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
        
     } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            [self.verifyView stopAnimation];
           // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
  }];
    
    
}



//获取个人信息
-(void)getMemberInfo{
 
    [MineNetWorkManager getMemberInfosuccess:^(id  _Nonnull data) {
     
        if ([data[@"code"] intValue]==200) {
            [UserWrapper shareUserInfo].kycStatus=data[@"data"][@"kycStatus"];
            
            [UserWrapper saveUser:[UserWrapper shareUserInfo]];

        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
 
        //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}


//全部卡片
- (void)showPanel {
    
    AllCardController*allCardVC=[[AllCardController alloc]init];
    WEAKSELF
    allCardVC.selectCardBlock = ^(CardModel * _Nullable card) {
        NSDictionary*dic=[card utr_modelToKeyValue];
        weakSelf.currentCardDic=dic;
        [weakSelf getCardListForFirst1:NO];
        weakSelf.aliasLabel.text=dic[@"alias"];
        weakSelf.cardHeadView.dataDic=dic;//刷新数据
        [weakSelf getCardBalance];//刷新资金
        self->_pageNO=1;
        [weakSelf.tableView.mj_footer resetNoMoreData];
        [weakSelf getCardFlowList];//获取卡片流水
        
    };
    allCardVC.cardDetailDic=self.cardDetailDic;
    [self.navigationController pushViewController:allCardVC animated:YES];
   
}


-(void)toLogout{
 
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self logout];
        
    });
}
//MARK:退出登录
-(void)logout{
    
    if(![UserWrapper isLogIn]){
        return;
    }
    [UserWrapper logout];
    [self initRootViewController];
}

-(void)initRootViewController{
    LoginController*loginVC=[[LoginController alloc]init];
    BaseNavigationController*loginNav=[[BaseNavigationController alloc]initWithRootViewController:loginVC];
    APPLICATION.window.rootViewController = loginNav;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
   // [self.navigationController setNavigationBarHidden:NO animated:NO];
  //  [self.tableView removeObserver:self forKeyPath:@"contentOffset" context:nil];
}

-(void)setUpMainApplyingView{
    
    [self.view addSubview:self.mainApplyingView];//添加申请卡页面
    // 设置自定义视图的约束，使其在安全区域内
        [NSLayoutConstraint activateConstraints:@[
            [self.mainApplyingView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
            [self.mainApplyingView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
            [self.mainApplyingView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
            [self.mainApplyingView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor]
        ]];
    
    [self.mainApplyingView reloadBINDataForActive];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
