//
//  CardLogisticsController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/17.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "CardLogisticsController.h"
#import "LogisticsInfoCell.h"
#import "LYEmptyView.h"
#import "UIScrollView+LYEmpty.h"
#import "MineNetWorkManager.h"
#import "TABAnimated.h"

@interface CardLogisticsController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) NSMutableArray*titleArray;
@property(nonatomic,strong) NSMutableArray*contentArray;
@end

@implementation CardLogisticsController

-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"物流信息");
    self.titleArray=[@[LocalizationKey(@"姓名"),LocalizationKey(@"手机号"),LocalizationKey(@"国家"),LocalizationKey(@"区域"),LocalizationKey(@"城市"),LocalizationKey(@"地址"),LocalizationKey(@"地址第二行"),LocalizationKey(@"邮编"),LocalizationKey(@"物流单号"),LocalizationKey(@"物流查询网站")] mutableCopy];
   
    
    UIView*fakeDotView = [[UIView alloc] init];
    [self.view insertSubview:fakeDotView atIndex:0];
    [self setTableViewConfig];
    [self getLogistics];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
}
-(void)setTableViewConfig{
   
    [self.tableView registerNib:[UINib nibWithNibName:@"LogisticsInfoCell" bundle:nil] forCellReuseIdentifier:@"LogisticsInfoCell"];
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 15)];
    self.tableView.tableHeaderView=headView;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.estimatedRowHeight=90;
    self.tableView.tabAnimated= [TABTableAnimated animatedWithCellClass:[LogisticsInfoCell class] cellHeight:90.0];
    [self.tableView tab_startAnimation];

}

//获取物流信息
-(void)getLogistics{
    
    if ([NSString stringIsNull:self.cardDetailDic[@"cardId"]]) {
        return;
    }
    //[SVProgressHUD customShowWithStyle];
    NSDictionary*dic=@{@"cardId":self.cardDetailDic[@"cardId"]};
    [MineNetWorkManager getCardlogisticsWithParams:dic success:^(id  _Nonnull data) {
        //[SVProgressHUD dismiss];
        [self.tableView tab_endAnimation];
        //延迟执行
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.tableView.tabAnimated.state=TABViewAnimationEnd;
        });
        [self configEmptyViewForTableView];
        if ([data[@"code"] intValue]==200) {
            
            if ([NSString stringIsNull:data[@"data"][@"id"]]) {
                //无物流信息
               
            }else{
                [self configDataWithDic:data[@"data"]];
            }
            [self.tableView reloadData];
           
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
           
          }
        } fail:^(NSError * _Nonnull error) {
            //[SVProgressHUD dismiss];
            [self.tableView tab_endAnimation];
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.tableView.tabAnimated.state=TABViewAnimationEnd;
            });
            [self configEmptyViewForTableView];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
   }];
}

-(void)configDataWithDic:(NSDictionary*)dic{
    
    NSString*name=[NSString stringWithFormat:@"%@%@",dic[@"firstName"],dic[@"lastName"]];
    NSString*phone=[NSString stringWithFormat:@"+%@ %@",dic[@"areaCode"],dic[@"phone"]];
    NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?dic[@"country"][@"usName"]:dic[@"country"][@"cnName"];//默认美国
    self.contentArray=[@[name,phone,countryName,dic[@"zone"],dic[@"city"],dic[@"address"],dic[@"address2"],dic[@"postCode"],[NSString repalceNULLWithlineString:dic[@"shipNo"]],[NSString repalceNULLWithlineString:dic[@"shipUrl"]]] mutableCopy];
    
    
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    LogisticsInfoCell*cell=[tableView dequeueReusableCellWithIdentifier:@"LogisticsInfoCell"];
    [cell configlogisticsInfoAtIndexPath:indexPath withTitleArray:self.titleArray withContentArray:self.contentArray];
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewAutomaticDimension;
}

-(void)configEmptyViewForTableView{
    
    if (!self.tableView.ly_emptyView) {
        LYEmptyView * emptyView=[LYEmptyView emptyViewWithImageStr:@"NoData_icon" titleStr:LocalizationKey(@"暂无数据")];
        emptyView.titleLabTextColor = [UIColor lightGrayColor];
        self.tableView.ly_emptyView = emptyView;
        [self.tableView reloadData];
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
