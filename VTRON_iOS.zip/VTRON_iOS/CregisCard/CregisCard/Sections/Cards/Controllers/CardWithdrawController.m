//
//  CardWithdrawController.m
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CardWithdrawController.h"
#import "VerifyPermissionView.h"
#import "HomeCardNetWorkManager.h"

@interface CardWithdrawController ()<UITextFieldDelegate>

{
    NSDictionary*_dataDic;
}
@property(nonatomic,strong)VerifyPermissionView*verifyView;
@property (weak, nonatomic) IBOutlet UITextField *amountTF;
@property (weak, nonatomic) IBOutlet UITextField *cardNoTF;

@end

@implementation CardWithdrawController

- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:BeexWithdrawCard];
    }
    return _verifyView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"卡片提现");
    self.cardTitle.text=LocalizationKey(@"卡号");
    self.amountTitle.text=LocalizationKey(@"提现金额");
    self.tipsLabel.text=LocalizationKey(@"可用：");
    self.feeTitle.text=LocalizationKey(@"提现手续费");
    self.totalTitle.text=LocalizationKey(@"到账金额");
    [self.okBtn setTitle:LocalizationKey(@"提现") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    self.amountTF.placeholder=LocalizationKey(@"请输入");
    self.cardTitle.font=PingFangMediumFont(13);
    self.amountTitle.font=PingFangMediumFont(13);
    self.cardNoTF.font=PingFangMediumFont(15);
    self.amountTF.font=PingFangMediumFont(15);
    self.feeTitle.font=PingFangMediumFont(13);
    self.totalTitle.font=PingFangMediumFont(13);
    self.balanceLabel.font=PingFangMediumFont(13);
    self.feeLabel.font=PingFangMediumFont(15);
    self.totalLabel.font=PingFangMediumFont(17);
    self.unitLabel.font=PingFangMediumFont(17);
    [self setBorderView:self.cardView];
    [self setBorderView:self.amountView];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.06];
    [self.amountTF addTarget:self action:@selector(textFieldChange:) forControlEvents:UIControlEventEditingChanged];
    self.amountTF.delegate=self;
    NSString*cardNo=self.cardDetailDic[@"cardNo"];
    self.cardNoTF.text=[NSString stringWithFormat:@"....%@",[cardNo substringFromIndex:cardNo.length-4]];
    self.balanceLabel.text=[NSString stringWithFormat:@"%@ %@",[NSString formattedStringWithDouble:[self.cardDetailDic[@"balance"] doubleValue]],self.cardDetailDic[@"currency"]];//卡资产
    [self getWithdrawData];
    // Do any additional setup after loading the view from its nib.
}



//MARK: 获取提现页面配置数据
-(void)getWithdrawData{
    
   [SVProgressHUD customShowWithStyle];
    NSDictionary*dic=@{@"cardId":self.cardDetailDic[@"cardId"]};
    [HomeCardNetWorkManager getcardWithdrawDataWithparams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            self->_dataDic=data[@"data"];
            
            [self calculationChargeFeeWithAmount:@""];
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
    }];
    
}



//提现
- (IBAction)toSubmit:(id)sender {
    
    if ([self.amountTF.text doubleValue]<=0) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"提现金额不能为0"));
        return;
    }
    if ([self.amountTF.text doubleValue]>[self.cardDetailDic[@"balance"] doubleValue]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"提现金额不能大于可用金额"));
        return;
    }
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
        [weakSelf.verifyView hide];
        [weakSelf toWithdrawWithpayPassword:payPassword withcode:code withType:type];
    };
    
}


//提现
-(void)toWithdrawWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    [SVProgressHUD customShowWithStyle];
    NSString*codeType=type==0?@"code":@"googleCode";
    [HomeCardNetWorkManager applyTowithdrawCardWithparams:@{@"amount":self.amountTF.text,@"cardId":self.cardDetailDic[@"cardId"],@"payPassword":payPassword,codeType:code} success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.view endEditing:YES];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"提现成功"));
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self.navigationController popViewControllerAnimated:YES];
            });
  
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
  
    
}


- (void)textFieldChange:(UITextField *)textField {
    
    if ([NSString stringIsNull:textField.text]) {
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.06];
    }else{
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    [self calculationChargeFeeWithAmount:textField.text];
}

//计算充值手续费
-(void)calculationChargeFeeWithAmount:(NSString*)amount{
    
    double chargeFee;
    double inCardFee;//充值加点
    if (![NSString stringIsNull:amount]) {
        if ([_dataDic[@"baseCancelFeeWay"] intValue]==1) {
            //固定
            chargeFee=[_dataDic[@"baseCancelFee"] doubleValue];
            
            
        }else if ([_dataDic[@"baseCancelFeeWay"] intValue]==2){
            //比例
            chargeFee=[_dataDic[@"baseCancelFeeRate"] doubleValue] *[amount doubleValue]/100.00;

            
        }else{
            //固定+比例
            chargeFee=[_dataDic[@"baseCancelFee"] doubleValue]+[_dataDic[@"baseCancelFeeRate"] doubleValue]*[amount doubleValue]/100.00;
        }
        
        
        
        if ([_dataDic[@"cancelCardFeeWay"] intValue]==1) {
            //固定
            inCardFee=[_dataDic[@"cancelCardFee"] doubleValue];
            
            
        }else if ([_dataDic[@"cancelCardFeeWay"] intValue]==2){
            //比例
            inCardFee=[_dataDic[@"cancelCardFeeRate"] doubleValue]*[amount doubleValue]/100.00;

            
        }else{
            //固定+比例
            inCardFee=[_dataDic[@"cancelCardFee"] doubleValue]+[_dataDic[@"cancelCardFeeRate"] doubleValue]*[amount doubleValue]/100.00;
        }
    }else{
        
        chargeFee=0;
        inCardFee=0;
        
    }
   
    self.feeLabel.text=[NSString stringWithFormat:@"%@ USD",[NSString formattedStringWithDouble:chargeFee+inCardFee]];
    self.totalLabel.text=[NSString stringWithFormat:@"%@",[NSString formattedStringWithDouble:([self.amountTF.text doubleValue]-chargeFee-inCardFee)]];
    
}




//限制只能输入2位小数
// 实现UITextFieldDelegate协议方法，控制小数位数
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // 获取当前输入的文本
    NSString *currentText = [textField.text stringByReplacingCharactersInRange:range withString:string];

    // 检查是否是有效的数字，以及小数位数是否超过两位
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    NSNumber *number = [formatter numberFromString:currentText];

    if (number || [currentText isEqualToString:@""]) { // 检查是否是有效的数字或为空
        NSArray *components = [currentText componentsSeparatedByString:@"."];
        if (components.count > 1) {
            NSString *decimalPart = components[1];
            return decimalPart.length <= 2; // 限制小数位数为两位
        }
        return YES;
    } else {
        return NO; // 输入无效，不允许修改
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
