//
//  CardPINController.h
//  CregisCard
//
//  Created by 孙良 on 2024/7/17.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CardPINController : BaseViewController
@property(nonatomic,strong) NSDictionary*cardDetailDic;//卡详情
@end

NS_ASSUME_NONNULL_END
