//
//  MailingAddressController.m
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "MailingAddressController.h"
#import "IdentityInputCell.h"
#import "AllNameCell.h"
#import "PhoneInfoCell.h"
#import "IdentityHeadView.h"
#import "AllNameHeadView.h"
#import "IdentityRejectView.h"
#import "VerifyPermissionView.h"
#import "MineNetWorkManager.h"
#import "CountrysSelectView.h"
#import "NSObject+UBTrackerModel.h"
#import "CountryModel.h"
#import "HomeCardNetWorkManager.h"
#import "ApplySuccessView.h"

@interface MailingAddressController ()
@property(nonatomic,strong) NSMutableArray*titleArray;
@property(nonatomic,strong) NSArray*placeholderArray;
@property(nonatomic,strong) NSMutableArray*contentArray;
@property(nonatomic,strong) NSMutableDictionary*contentDic;
@property(nonatomic,strong) UIButton*okBtn;
@property(nonatomic,strong) VerifyPermissionView*verifyView;

@property(nonatomic,strong) CountrysSelectView*countrySelectView;
@property(nonatomic,strong)NSArray*countryArray;
@property(nonatomic,strong) CountryModel*currentCountry;//手机号对应的国家地区

@end

@implementation MailingAddressController

- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:EmailCard];
    }
    return _verifyView;
}
- (CountrysSelectView *)countrySelectView {
    if(!_countrySelectView) {
        _countrySelectView=[CountrysSelectView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-NAVIGATION_BAR_HEIGHT-10)];
    }
    return _countrySelectView;
}

-(NSMutableArray*)contentArray{
    if (!_contentArray) {
        _contentArray=[[NSMutableArray  alloc]init];
    }
    return _contentArray;
}
-(NSMutableDictionary*)contentDic{
    if (!_contentDic) {
        _contentDic=[[NSMutableDictionary  alloc]init];
    }
    return _contentDic;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"邮寄地址");
    [self backBtnNoNavBar:NO normalBack:YES];
    [self setUpUI];
    self.titleArray=[@[LocalizationKey(@"卡号"),@"",LocalizationKey(@"手机号"),LocalizationKey(@"国家/地区"),LocalizationKey(@"区域"),LocalizationKey(@"城市"),LocalizationKey(@"地址"),LocalizationKey(@"地址第二行"),LocalizationKey(@"邮政编码")]mutableCopy];
    self.placeholderArray=[@[@"",@"",@"",LocalizationKey(@"请选择"),LocalizationKey(@"州、县、省或地区"),LocalizationKey(@"城市、地区或城镇"),LocalizationKey(@"公寓、楼层、建筑名称、门牌号"),LocalizationKey(@"街道、区"),LocalizationKey(@"请输入")]mutableCopy];
    NSString*cardNo=self.currentCardDic[@"cardNo"];
    self.contentArray=[@[[NSString stringWithFormat:@"....%@",[cardNo substringFromIndex:cardNo.length-4]],@"",@"",@"",@"",@"",@"",@"",@""]mutableCopy];
    [self.contentDic setValue:@"1" forKey:@"areaCode"];//默认区号
}


-(void)setUpUI{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"AllNameCell" bundle:nil] forCellReuseIdentifier:@"AllNameCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityInputCell" bundle:nil] forCellReuseIdentifier:@"IdentityInputCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"PhoneInfoCell" bundle:nil] forCellReuseIdentifier:@"PhoneInfoCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"IdentityHeadView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"IdentityHeadView"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AllNameHeadView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"AllNameHeadView"];
    self.tableView.rowHeight=50;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    UIView*footView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, 100)];
    self.tableView.tableFooterView=footView;
    NSString*allRemark=[NSString stringWithFormat:@"%@",LocalizationKey(@"表格只能用英文填写")];
    CGFloat height=[ToolUtil getLabelHeightWithText:allRemark width:(kWindowW-(20+16)*2-16-8) font:[UIFont systemFontOfSize:15] withLineSpacing:5];
    UIView*headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, ceilf(height)+50)];
    IdentityRejectView*rejectView=[IdentityRejectView instanceViewWithFrame:headView.bounds];
    [rejectView configcardholderUIForBulkMail];
    NSMutableAttributedString *attriString =
    [[NSMutableAttributedString alloc] initWithString:allRemark];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:5];
    //设置距离
    [attriString addAttribute:NSParagraphStyleAttributeName
                        value:paragraphStyle
                        range:NSMakeRange(0, [allRemark length])];
    rejectView.reasonLabel.attributedText=attriString;
    [headView addSubview:rejectView];
    self.tableView.tableHeaderView=headView;
    self.okBtn=[[UIButton alloc]initWithFrame:CGRectMake(20, 30, kWindowW-40, 50)];
    [self.okBtn setCornerRadius:25];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    [self.okBtn setTitle:LocalizationKey(@"保存") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    
    WEAKSELF
    [self.okBtn dn_addActionHandler:^{
        [weakSelf toVerifyCode];
       
    }];
    [footView addSubview:self.okBtn];
    
}

-(void)toVerifyCode{
    
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
        [weakSelf toShipCardWithpayPassword:payPassword withcode:code withType:type];
        
    };
    
}

//邮寄实体卡
-(void)toShipCardWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    NSString*codeType=type==0?@"code":@"googleCode";

    [self.contentDic setValue:self.currentCardDic[@"cardId"] forKey:@"cardId"];
    [self.contentDic setValue:payPassword forKey:@"payPassword"];
    [self.contentDic setValue:code forKey:codeType];
    [SVProgressHUD  customShowWithNone];
    [self.verifyView startAnimation];
   
    NSLog(@"当前选择的--%@",self.contentDic);
    [HomeCardNetWorkManager  shipCardWithparams:self.contentDic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.verifyView hide];
            //延迟执行
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self showShipCardSuccessView];
            });
            
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}

//MARK: 显示申请成功提示
-(void)showShipCardSuccessView{
    
    ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 310)];
    successView.titleLabel.text=LocalizationKey(@"邮寄订单已生成");
    successView.detailLabel.text=LocalizationKey(@"卡片邮寄中，请耐心等待");
    successView.tipsImageV.image=UIIMAGE(@"orderSuccess");
    [successView.okBtn dn_addActionHandler:^{
        [successView hide];
        [[UBTrackerFindController findCurrentShowingViewController].navigationController popToRootViewControllerAnimated:YES];
    }];
    [successView show];
    
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.titleArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    WEAKSELF
    if (indexPath.section==1) {
        //姓名
        AllNameCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AllNameCell"];
        cell.nameBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString) {
            [weakSelf.contentDic setValue:valueString forKey:typeString];
            [weakSelf juadgeBtnStatus];
            AllNameHeadView *headerView = (AllNameHeadView*)[self.tableView headerViewForSection:1];
            [headerView configDataInSection:0 withDataDic:self.contentDic];//更新区头显示的数据
            
            NSLog(@"这是--%@--%@",typeString,valueString);
            
        };
        
        return cell;
    }else if (indexPath.section==2)
    {
        //手机号
        PhoneInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PhoneInfoCell"];
        cell.phoneNumBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString) {
          
            [weakSelf.contentArray replaceObjectAtIndex:2 withObject:valueString];
            [weakSelf.contentDic setValue:valueString forKey:typeString];
            [weakSelf juadgeBtnStatus];
        };
        cell.phoneAreablock = ^(NSString * _Nullable typeString, CountryModel*_Nullable areaModel) {
            
            [weakSelf.contentArray replaceObjectAtIndex:2 withObject:areaModel.code];
            [weakSelf.contentDic setValue:areaModel.code forKey:typeString];
            [weakSelf juadgeBtnStatus];
        };
        return cell;
        
    }else{
        IdentityInputCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentityInputCell"];
        cell.identityAuthenticationBlock = ^(NSString * _Nullable typeString, NSString * _Nullable valueString, int indexPathSection) {
            NSLog(@"这是-%@--%@--%d",typeString,valueString,indexPathSection);
            [weakSelf.contentArray replaceObjectAtIndex:indexPathSection withObject:valueString];
            [weakSelf.contentDic setValue:valueString forKey:typeString];
            [weakSelf juadgeBtnStatus];
            
        };
        [cell configCardMailDataAtIndexPath:indexPath withContentArray:self.contentArray withplaceholderArray:self.placeholderArray];
        return cell;
        
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 50;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section==1) {
        AllNameHeadView*sectionView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"AllNameHeadView"];
        [sectionView configCardMailDataInSection:section];
        return sectionView;
    }else{
        IdentityHeadView*sectionView=[tableView  dequeueReusableHeaderFooterViewWithIdentifier:@"IdentityHeadView"];
        [sectionView configCardShipInSection:section withtitleArray:self.titleArray];
        return sectionView;
        
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section==3) {
        //选择国家
        [self.view endEditing:YES];
        if (self.countryArray.count==0) {
            [self  getPostalAllCountrys];
        }else{
            [self.countrySelectView show];
            [self.countrySelectView clearTextFieldContent];
            [self.countrySelectView  reloadDataWithArray:self.countryArray withDefalutModel:self.currentCountry withType:0];
            WEAKSELF
            self.countrySelectView.countryBlock = ^(CountryModel *country) {
                weakSelf.currentCountry=country;
                NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?country.usName:country.cnName;
                [weakSelf.contentDic setValue:country.ID forKey:@"countryId"];
                [weakSelf.contentArray replaceObjectAtIndex:3 withObject:countryName];
                [weakSelf.tableView reloadData];
                [weakSelf juadgeBtnStatus];
               
              
            };
           
        }
    }
    
    
}

//MARK: 获取支持的全部国家
-(void)getPostalAllCountrys{
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getAllcountrysuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        if ([data[@"code"] intValue]==200) {
            
            NSArray*countryArray=(NSMutableArray*)[CountryModel utr_modelsWithKeyValues:data[@"data"]];
            self.countryArray=countryArray;
            [self.countrySelectView show];
            [self.countrySelectView  reloadDataWithArray:countryArray withDefalutModel:self.currentCountry withType:0];
            WEAKSELF
            self.countrySelectView.countryBlock = ^(CountryModel *country) {
                weakSelf.currentCountry=country;
                NSString*countryName=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?country.usName:country.cnName;
                [weakSelf.contentArray replaceObjectAtIndex:3 withObject:countryName];
                [weakSelf.contentDic setValue:country.ID forKey:@"countryId"];
                [weakSelf.tableView reloadData];
                [weakSelf juadgeBtnStatus];
            };
            
            
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
    }];

}

//判断按钮的可点击状态
-(void)juadgeBtnStatus{
    
    if (![NSString stringIsNull:self.contentDic[@"lastName"]]&&![NSString stringIsNull:self.contentDic[@"firstName"]]&&![NSString stringIsNull:self.contentDic[@"areaCode"]]&&![NSString stringIsNull:self.contentDic[@"phone"]]&&![NSString stringIsNull:self.contentDic[@"countryId"]]&&![NSString stringIsNull:self.contentDic[@"zone"]]&&![NSString stringIsNull:self.contentDic[@"city"]]&&![NSString stringIsNull:self.contentDic[@"address"]]&&![NSString stringIsNull:self.contentDic[@"address2"]]&&![NSString stringIsNull:self.contentDic[@"postCode"]]) {
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }else{
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.06];
        
    }
   
    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
