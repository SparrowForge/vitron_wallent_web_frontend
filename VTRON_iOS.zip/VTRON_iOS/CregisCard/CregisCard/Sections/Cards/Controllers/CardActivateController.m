//
//  CardActivateController.m
//  CregisCard
//
//  Created by 孙良 on 2024/7/17.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "CardActivateController.h"
#import "VerifyPermissionView.h"
#import "MineNetWorkManager.h"
#import "ApplySuccessView.h"

@interface CardActivateController ()
@property (weak, nonatomic) IBOutlet UIView *cardNoView;
@property (weak, nonatomic) IBOutlet UIView *activeCodeView;
@property (weak, nonatomic) IBOutlet UITextField *cardNoTF;
@property (weak, nonatomic) IBOutlet UITextField *codeTF;
@property (weak, nonatomic) IBOutlet UILabel *cardNumTitle;
@property (weak, nonatomic) IBOutlet UILabel *codeTitle;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@property(nonatomic,strong) VerifyPermissionView*verifyView;
@property(nonatomic,strong) VerifyPermissionView*recertifyView;//重新获取验证码
@end

@implementation CardActivateController

- (VerifyPermissionView *)verifyView {
    if(!_verifyView) {
        CGFloat extraHeight=[[UserWrapper shareUserInfo].emailCheck intValue]==1?80:-40;
        _verifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+extraHeight) withVerifyPermissionType:ActivateCard];
    }
    return _verifyView;
}
//获取激活码
- (VerifyPermissionView *)recertifyView {
    if(!_recertifyView) {
        _recertifyView=[VerifyPermissionView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 350+50+105) withVerifyPermissionType:GetActivateCardCode];
    }
    return _recertifyView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"实体卡激活");
    self.cardNumTitle.text=LocalizationKey(@"卡号");
    self.codeTitle.text=LocalizationKey(@"激活码");
    self.cardNumTitle.font=PingFangMediumFont(15);
    self.codeTitle.font=PingFangMediumFont(15);
    [self.cardNoTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.codeTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    self.tipsLabel.text=LocalizationKey(@"激活码丢失？");
    [self.resetBtn setTitle:LocalizationKey(@"重新获取") forState:UIControlStateNormal];
    [self.okBtn setTitle:LocalizationKey(@"激活") forState:UIControlStateNormal];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self setBorderView:self.cardNoView];
    [self setBorderView:self.activeCodeView];
    //[self.cardNoTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
   // [self.codeTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    self.cardNoTF.userInteractionEnabled=NO;
    self.okBtn.enabled=YES;
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
    [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    NSString*cardNo=self.cardDetailDic[@"cardNo"];
    self.cardNoTF.text=[NSString stringWithFormat:@"....%@",[cardNo substringFromIndex:cardNo.length-4]];
    self.cardNoView.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.04];
    // Do any additional setup after loading the view from its nib.
}
-(void)setBorderView:(UIView*)view{
    
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12.0];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
}
- (void)setupNavigationBarTheme {
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground]; // 配置不透明背景
        appearance.backgroundColor = [UIColor whiteColor]; // 设置背景颜色
        appearance.shadowColor = [UIColor clearColor]; // 去掉黑线
        // 设置普通标题属性
        NSDictionary *titleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:18]
        };
        appearance.titleTextAttributes = titleTextAttributes;

        // 设置大标题属性
        NSDictionary *largeTitleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:29]
        };//系统默认的大标题（Large Title）的字体大小为 34 points
        appearance.largeTitleTextAttributes = largeTitleTextAttributes;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // iOS 13 以下版本，使用 shadowImage 方式去掉黑线
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

- (IBAction)btnClick:(UIButton *)sender {
    if (sender.tag==0) {
        //重新获取激活码
        [self getActivateCode];
        
    }else{
        //去激活
        [self toActivateCard];
    }
    
    
}
//重新获取激活码
-(void)getActivateCode{

    [self.recertifyView show];
    NSString*email=[NSString stringWithFormat:LocalizationKey(@"实体卡激活码如丢失，可以重新获取\n激活码会发送到您的%@的邮箱"),[self maskEmail:[UserWrapper shareUserInfo].email]];
    self.recertifyView.activateCardString=email;
    WEAKSELF
    self.recertifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
       
        [weakSelf toGetActivateCodeWithpayPassword:payPassword withcode:code withType:type];
        
    };
   
    
}


//去激活
-(void)toActivateCard{
    
   
    [self.verifyView show];
    WEAKSELF
    self.verifyView.verifyBlock = ^(NSString * _Nullable payPassword, NSString * _Nullable code, int type) {
       
        [weakSelf toActivateCardWithpayPassword:payPassword withcode:code withType:type];
        
    };
    
    
}

//激活卡
-(void)toActivateCardWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    if ([NSString stringIsNull:self.cardDetailDic[@"cardId"]]) {
        return;
    }
    NSString*codeType=type==0?@"code":@"googleCode";
    [SVProgressHUD customShowWithNone];
    [self.verifyView startAnimation];
    NSDictionary*dic=@{@"cardId":self.cardDetailDic[@"cardId"],@"payPassword":payPassword,codeType:code,@"status":@"1"};
    [MineNetWorkManager toActiveCardWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.verifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.verifyView hide];
            ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 300)];
            successView.titleLabel.text=LocalizationKey(@"温馨提示");
            successView.detailLabel.text=LocalizationKey(@"实体卡激活成功");
            successView.tipsImageV.image=UIIMAGE(@"orderSuccess");
            WEAKSELF
            [successView.okBtn dn_addActionHandler:^{
                [successView hide];
                [weakSelf.navigationController popViewControllerAnimated:YES];
            }];
            [successView show];
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
            
        }
        } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            [self.verifyView stopAnimation];

            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
 }];
    
    
}

//重新获取激活码
-(void)toGetActivateCodeWithpayPassword:(NSString*)payPassword withcode:(NSString*)code withType:(int)type{
    
    NSString*codeType=type==0?@"code":@"googleCode";
    [SVProgressHUD customShowWithNone];
    [self.recertifyView startAnimation];
    NSDictionary*dic=@{@"cardId":self.cardDetailDic[@"cardId"],@"payPassword":payPassword,codeType:code};
    [MineNetWorkManager getCardActiveCodeWithParams:dic success:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        [self.recertifyView stopAnimation];
        if ([data[@"code"] intValue]==200) {
            [self.recertifyView hide];
            ShowToastWithPopupTypeAndMessage(PopupTypeSuccess,LocalizationKey(@"获取成功，请查看邮箱"));
          
        }else{
            NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
        }
    } fail:^(NSError * _Nonnull error) {
            [SVProgressHUD dismiss];
            [self.recertifyView stopAnimation];
            //ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
            
 }];
    
}


-(NSString *)maskEmail:(NSString *)email {
    NSArray<NSString *> *components = [email componentsSeparatedByString:@"@"];
    if (components.count != 2) {
        return email; // 如果不是有效的邮箱地址，返回nil
    }
    
    NSString *localPart = components[0];
    NSString *domainPart = components[1];
    
    if (localPart.length < 3) {
        return email; // 如果本地部分少于3个字符，返回nil
    }
    
    NSString *maskedLocalPart = [NSString stringWithFormat:@"%@****", [localPart substringToIndex:3]];
    
    return [NSString stringWithFormat:@"%@@%@", maskedLocalPart, domainPart];
}

//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    
    [self judgeBtnStatus];
}

-(void)judgeBtnStatus{
    
    if ([NSString stringIsNull:self.codeTF.text]||[NSString stringIsNull:self.cardNoTF.text]) {
        self.okBtn.enabled=NO;
        [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    }else{
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
   
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
