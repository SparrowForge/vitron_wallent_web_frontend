//
//  CardOperationController.h
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CardOperationController : BaseViewController
@property(nonatomic,strong) NSDictionary*cardDetailDic;//卡详情
@property (weak, nonatomic) IBOutlet UILabel *pinLabel;
@property (weak, nonatomic) IBOutlet UILabel *activeLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardNoLabel;
@property (weak, nonatomic) IBOutlet UILabel *toActiveLabel;
@property (weak, nonatomic) IBOutlet UILabel *activedLabel;
@property (weak, nonatomic) IBOutlet UIImageView *cardBackViewImage;
@property (weak, nonatomic) IBOutlet UIImageView *cardTypeImageV;
@property (weak, nonatomic) IBOutlet UIView *activatedView;

@end

NS_ASSUME_NONNULL_END
