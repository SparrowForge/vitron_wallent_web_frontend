//
//  CardsHomeController.h
//  CregisCard
//
//  Created by 孙良 on 2023/11/2.
//  Copyright © 2023 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, HomeCardType) {
    NOKYCTypeCard,//没有kyc认证
    NOCARDTypeCard,//没有申请卡
    NORMALTypeCard //正常状态
};

@interface CardsHomeController : UIViewController
@property (strong, nonatomic)  UIImageView *animateImageV;


@end

NS_ASSUME_NONNULL_END
