//
//  AllCardController.h
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"
#import "CardModel.h"
typedef void(^SelectCardBlock)(CardModel* _Nullable card);
NS_ASSUME_NONNULL_BEGIN

@interface AllCardController : BaseViewController
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) NSDictionary*cardDetailDic;//卡详情
@property(nonatomic,copy) SelectCardBlock selectCardBlock;
@end

NS_ASSUME_NONNULL_END
