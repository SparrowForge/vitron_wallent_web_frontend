//
//  CardOperationController.m
//  CregisCard
//
//  Created by sunliang on 2025/10/10.
//  Copyright © 2025 BytesLink Anhui. All rights reserved.
//

#import "CardOperationController.h"
#import "CardLogisticsController.h"
#import "CardActivateController.h"
#import "CardPINController.h"
#import "ApplySuccessView.h"

@interface CardOperationController ()
@property (weak, nonatomic) IBOutlet UIView *boardView;

@end

@implementation CardOperationController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=LocalizationKey(@"管理");
    [self.boardView setborderColor:[UIColor colorWithHexString:@"000000" alpha:0.2] withborderWidth:0.33];
    [self.boardView setCornerRadius:12.0];
    self.pinLabel.text=LocalizationKey(@"设置PIN码");
    self.activeLabel.text=LocalizationKey(@"激活卡片");
    self.emailLabel.text=LocalizationKey(@"邮寄信息");
    self.toActiveLabel.text=LocalizationKey(@"去激活");
    self.activedLabel.text=LocalizationKey(@"已激活");
    NSString*cardBackViewImage=[self.cardDetailDic[@"status"] isEqualToString:@"01"]?@"applycardshowIcon":@"applycard_entity_close";
    self.cardBackViewImage.image=UIIMAGE(cardBackViewImage);
    NSString*flagImageString=[[self.cardDetailDic[@"cardType"] uppercaseString] isEqualToString:@"VISA"]?@"visa_icon":@"visa_bottomIcon";
    self.cardTypeImageV.image=UIIMAGE(flagImageString);
    NSString*cardNo=self.cardDetailDic[@"cardNo"];
    self.cardNoLabel.text=[NSString stringWithFormat:@"....%@",[cardNo substringFromIndex:cardNo.length-4]];
    self.cardNoLabel.font=PingFangMediumFont(17);
    self.pinLabel.font=PingFangMediumFont(17);
    self.activeLabel.font=PingFangMediumFont(17);
    self.emailLabel.font=PingFangMediumFont(17);
    if ([self.cardDetailDic[@"status"] isEqualToString:@"01"]) {
        //已激活
        self.activatedView.hidden=NO;
    }else{
        self.activatedView.hidden=YES;
     
    }
    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    [self setupNavigationBarTheme];
}

- (void)setupNavigationBarTheme {
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
        [appearance configureWithOpaqueBackground]; // 配置不透明背景
        appearance.backgroundColor = [UIColor whiteColor]; // 设置背景颜色
        appearance.shadowColor = [UIColor clearColor]; // 去掉黑线
        // 设置普通标题属性
        NSDictionary *titleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:18]
        };
        appearance.titleTextAttributes = titleTextAttributes;

        // 设置大标题属性
        NSDictionary *largeTitleTextAttributes = @{
            NSForegroundColorAttributeName: [UIColor blackColor],
            NSFontAttributeName: [UIFont boldSystemFontOfSize:29]
        };//系统默认的大标题（Large Title）的字体大小为 34 points
        appearance.largeTitleTextAttributes = largeTitleTextAttributes;

        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    } else {
        // iOS 13 以下版本，使用 shadowImage 方式去掉黑线
        [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

- (IBAction)btnClick:(UIButton *)sender {
    if (sender.tag==0) {
        //设置PIN码
        CardPINController*pINVC=[[CardPINController alloc]init];
        pINVC.cardDetailDic=self.cardDetailDic;
        [self.navigationController pushViewController:pINVC animated:YES];
    }else if (sender.tag==1){
        //激活卡片
        if ([self.cardDetailDic[@"status"] isEqualToString:@"03"]) {
          //去激活
            CardActivateController*activateVC=[[CardActivateController alloc]init];
            activateVC.cardDetailDic=self.cardDetailDic;
            [self.navigationController pushViewController:activateVC animated:YES];
        }else{
           // [self showInthemakingView];
            
        }
      
        
    }else{
       //邮寄信息
        CardLogisticsController*logisticsVC=[[CardLogisticsController alloc]init];
        logisticsVC.cardDetailDic=self.cardDetailDic;
        [self.navigationController pushViewController:logisticsVC animated:YES];
    }
    
}


//MARK: 显示正在制作中
-(void)showInthemakingView{
    
    ApplySuccessView*successView=[ApplySuccessView instanceViewWithFrame:CGRectMake(16, 0, kWindowW-16*2, 310)];
    successView.titleLabel.text=LocalizationKey(@"温馨提示");
    successView.detailLabel.text=LocalizationKey(@"实体卡正在制作中，暂时不能激活");
    [successView.okBtn dn_addActionHandler:^{
        [successView hide];
       
    }];
    [successView show];
   
    
}









/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
