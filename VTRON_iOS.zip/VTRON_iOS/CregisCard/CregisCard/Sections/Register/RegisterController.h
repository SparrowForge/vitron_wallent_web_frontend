//
//  RegisterController.h
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface RegisterController : BaseViewController
@property(nonatomic,assign)int type;//0 注册 1忘记密码
@end

NS_ASSUME_NONNULL_END
