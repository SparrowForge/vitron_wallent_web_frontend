//
//  RegisterController.m
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "RegisterController.h"
#import "RegisterInputView.h"
#import "Masonry.h"
#import "SelectMenuView.h"
#import "LoginAuthenticationView.h"
#import "MineNetWorkManager.h"
#import "CustomTabBarController.h"

@interface RegisterController () <UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIView *boardView;
@property (weak, nonatomic) IBOutlet UIButton *okBtn;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@property(nonatomic,strong) UIScrollView*scrollView;
@property(nonatomic,strong) UIButton*countryBtn;
@property(nonatomic,strong) RegisterInputView*inpuView;
@property(nonatomic,strong) UIImageView*countryImageV;
@property(nonatomic,strong) SelectMenuView*selectView;
@property(nonatomic,strong) LoginAuthenticationView*loginAuthView;
@property(nonatomic,strong) NSDictionary*currentLanguageDic;
@end

@implementation RegisterController

- (SelectMenuView *)selectView {
    if(!_selectView) {
        _selectView=[SelectMenuView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 160+15*2+HOME_INDICATOR_HEIGHT)withSelectMenuType:SelectLanguage];
    }
    return _selectView;
}

- (LoginAuthenticationView *)loginAuthView {
    if(!_loginAuthView) {
        int type=self.type+1;
        _loginAuthView=[LoginAuthenticationView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, 320+0) withVerifyPermissionType:type withGoogleVerify:NO];
    }
    return _loginAuthView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.okBtn.enabled=NO;
    [self.okBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:0.2] forState:UIControlStateNormal];
    self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
    self.okBtn.titleLabel.font=PingFangMediumFont(15);
    [self setLanguage];
    [self setRightBar];
    CGFloat scrollViewHeight=self.type==0?800:600;
    //延迟执行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.scrollView=[[UIScrollView alloc]initWithFrame:self.boardView.bounds];
        self.scrollView.delegate = self;
        self.scrollView.contentSize=CGSizeMake(0, scrollViewHeight);
        self.scrollView.bounces=NO;
        [self.boardView addSubview:self.scrollView];
        self.inpuView=[RegisterInputView instanceViewWithFrame:CGRectMake(0, 0, kWindowW, scrollViewHeight)withType:self.type];
        WEAKSELF
        self.inpuView.statusBlock = ^(int status) {
            if (status==0) {
                weakSelf.okBtn.enabled=NO;
                weakSelf.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.10];
                [weakSelf.okBtn setTitleColor:[UIColor colorWithHexString:@"#000000 " alpha:0.2] forState:UIControlStateNormal];
            }else{
                weakSelf.okBtn.enabled=YES;
                weakSelf.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
                [weakSelf.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }
            
        };
        [self.scrollView addSubview:self.inpuView];
#if DEBUG == 1
        self.inpuView.accountTF.text = @"1825571811@qq.com";
        self.inpuView.pswTF.text=@"Aa123456";
        self.okBtn.enabled=YES;
        self.okBtn.backgroundColor=[UIColor colorWithHexString:@"#1F211F" alpha:1.0];
        [self.okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
#endif
    });
   

    // Do any additional setup after loading the view from its nib.
}


-(void)setRightBar{
    
    NSString*languageString=[ChangeLanguage userLanguage];
    NSString*countrySting;
    UIImage*countryImage;
    if ([languageString isEqualToString:@"zh-Hans"]) {
        countryImage=UIIMAGE(@"languageIcon");
        countrySting=LocalizationKey(@"简体中文");
    }else{
        countryImage=UIIMAGE(@"languageIcon");
        countrySting=LocalizationKey(@"English");

    }
    UIView*boardView=[[UIView alloc]init];
    self.countryBtn=[[UIButton alloc]init];
    self.countryBtn.userInteractionEnabled=NO;
    [self.countryBtn setTitle:countrySting forState:UIControlStateNormal];
    [self.countryBtn setTitleColor:[UIColor colorWithHexString:@"#1F211F" alpha:1.0] forState:UIControlStateNormal];
    self.countryBtn.titleLabel.font=PingFangMediumFont(13);
    [boardView addSubview:self.countryBtn];
    boardView.layer.borderWidth=1;
    boardView.layer.borderColor=[[UIColor colorWithHexString:@"#1F211F" alpha:1.0] colorWithAlphaComponent:0.1].CGColor;
    [boardView setCornerRadius:16.0];
    self.countryImageV=[[UIImageView alloc]init];
    self.countryImageV.image=countryImage;
    [boardView addSubview:self.countryImageV];
    [boardView mas_makeConstraints:^(MASConstraintMaker *make) {
     make.height.mas_equalTo(32);
     }];

    [self.countryBtn mas_makeConstraints:^(MASConstraintMaker *make) {
     make.right.equalTo((boardView).mas_right).offset(-10);
     make.centerY.equalTo(boardView.mas_centerY).offset(0);
     }];
    [self.countryImageV mas_makeConstraints:^(MASConstraintMaker *make) {
     make.right.equalTo(self.countryBtn.mas_left).offset(-5);
     make.centerY.equalTo(boardView.mas_centerY).offset(0);
     make.size.mas_equalTo(CGSizeMake(16, 16));
     make.left.equalTo(boardView.mas_left).offset(10);
     }];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:boardView];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture:)];
    [boardView addGestureRecognizer:tapGesture];
    self.currentLanguageDic=[[ChangeLanguage userLanguage] isEqualToString:@"en"]?@{@"English":@"en"}:@{@"简体中文":@"zh-Hans"};//初始化
  
}

//选择语言
 -(void)tapGesture:(id)sender
 {
    [self showLanguageSelectView];
 }

//MARK: 选择语言
-(void)showLanguageSelectView{
    
    [self.selectView show];
    self.selectView.currentDic=self.currentLanguageDic;
    [self.selectView reloadDataWithArray:@[@{@"简体中文":@"zh-Hans"},@{@"English":@"en"}]];
    WEAKSELF
    self.selectView.selectMenuBlock = ^(NSDictionary * _Nullable dic) {
        NSString*key= [[dic allKeys] objectAtIndex:0];
        [weakSelf.countryBtn setTitle:key forState:UIControlStateNormal];
        [weakSelf setLanguageWithString:[dic objectForKey:key]];
        weakSelf.currentLanguageDic=dic;
        
    };
    
}


// 监听scrollView的滑动
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    // 获取 y 轴的偏移量
    CGFloat yOffset = scrollView.contentOffset.y;
    NSLog(@"Y Offset: %f", yOffset);
    if (yOffset>80) {
        self.title=self.type==0?LocalizationKey(@"注册"):LocalizationKey(@"重置密码");
    }else{
        self.title=@"";
    }
    // 可以根据 yOffset 值执行其他操作
}

//点击注册
- (IBAction)okClick:(id)sender {
   
    if ([NSString stringIsNull:self.inpuView.accountTF.text]) {
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入邮箱"));
        return;
    }
    if ([NSString stringIsNull:self.inpuView.pswTF.text]) {
       
        ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"请输入密码"));
        return;
    }
   [self.loginAuthView showWithAccount:self.inpuView.accountTF.text withPassword:self.inpuView.pswTF.text withinviteCode:self.inpuView.inviteTF.text];
    WEAKSELF
    weakSelf.loginAuthView.verifyBlock = ^(NSDictionary * _Nullable data) {
        [UBTNSUserDefaultUtil PutDefaults:ACCESS_TOKEN Value:[NSString stringWithFormat:@"%@%@",data[@"data"][@"token_type"],data[@"data"][@"access_token"]]];
        [UBTNSUserDefaultUtil PutDefaults:REFRESH_TOKEN Value:[NSString stringWithFormat:@"%@",data[@"data"][@"refresh_token"]]];
        [self getMemberInfo];
       
    };
   
}

//获取个人信息
-(void)getMemberInfo{
   
    [SVProgressHUD customShowWithStyle];
    [MineNetWorkManager getMemberInfosuccess:^(id  _Nonnull data) {
        [SVProgressHUD dismiss];
        
        if ([data[@"code"] intValue]==200) {
            [UserWrapper getuserInfoWithDic:data[@"data"]];//存储用户信息
            [self initRootViewController];
          
        }else{
           NSString*message=[NSString stringWithFormat:@"%@ (%@)",data[@"msg"],data[@"code"]];
            ShowToastWithPopupTypeAndMessage(PopupTypeFailure,message);
         
        }
    } fail:^(NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
       // ShowToastWithPopupTypeAndMessage(PopupTypeFailure,LocalizationKey(@"网络不可用，请检查网络"));
        
    }];
    
}


-(void)initRootViewController{
  
    CustomTabBarController *tabbar = [[CustomTabBarController alloc] init];
    APPLICATION.window.rootViewController = tabbar;
    
   }



//MARK: 设置语言
-(void)setLanguageWithString:(NSString*)language{
    
    [ChangeLanguage setUserlanguage:language];
    [self setLanguage];
   
}

/**
 多语言
 */
-(void)setLanguage{
    // 获取 y 轴的偏移量
    CGFloat yOffset = self.scrollView.contentOffset.y;
    NSLog(@"Y Offset: %f", yOffset);
    if (yOffset>80) {
        self.title=self.type==0?LocalizationKey(@"注册"):LocalizationKey(@"重置密码");
    }else{
        self.title=@"";
    }
    [self.okBtn setTitle:LocalizationKey(@"注册") forState:UIControlStateNormal];
    NSString*btnTitle=self.type==0?LocalizationKey(@"注册"):LocalizationKey(@"重置");
    [self.okBtn setTitle:btnTitle forState:UIControlStateNormal];
    NSString*foreText=LocalizationKey(@"已有账号？");
    NSString*suffixText=LocalizationKey(@"登录");
    NSString*totalText=[NSString stringWithFormat:@"%@%@",foreText,suffixText];
    NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] initWithString:totalText];
    // 设置第一个部分的颜色
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"000000" alpha:0.6] range:NSMakeRange(0, foreText.length)];
    // 设置第二个部分的颜色和下划线
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:[UIColor baseColor] range:NSMakeRange(foreText.length, totalText.length-foreText.length)];
   // [attributedTitle addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(foreText.length, totalText.length-foreText.length)];
    UIFont *boldFont =PingFangMediumFont(15);
    [attributedTitle addAttribute:NSFontAttributeName
                            value:boldFont
                            range:NSMakeRange(foreText.length, totalText.length-foreText.length)];
    // 将富文本字符串设置为按钮的标题
    [self.loginBtn setAttributedTitle:attributedTitle forState:UIControlStateNormal];
   [self.inpuView setLanguage];
    
    
}
- (IBAction)toLogin:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
