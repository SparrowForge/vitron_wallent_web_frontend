//
//  PasswordAlertCell.m
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "PasswordAlertCell.h"

@implementation PasswordAlertCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
    [self.boardView setCornerRadius:13];
    self.boardView.backgroundColor=[UIColor colorWithHexString:@"#F6F6F6" alpha:1.0];
    
    // Initialization code
}

-(void)configDataWithIndexpath:(NSIndexPath*)indexpath withpassword:(NSString*)password{
    if (indexpath.row==0) {
        self.titleLabel.text=LocalizationKey(@"8-20位字符");
        self.boardView.alpha=[self judgeMinimumCharactersWithpassword:password]?1:0.4;
        
    }else if (indexpath.row==1){
        self.titleLabel.text=LocalizationKey(@"至少一个大写字母(A-Z)");
        self.boardView.alpha=[self judgeCapitalLetterWithpassword:password]?1:0.4;
    }else if (indexpath.row==2){
        self.titleLabel.text=LocalizationKey(@"至少一个小写字母(a-z)");
        self.boardView.alpha=[self judgeLowercaseLetterWithpassword:password]?1:0.4;
    }else{
        self.titleLabel.text=LocalizationKey(@"至少一个数字");
        self.boardView.alpha=[self judgeDigitWithpassword:password]?1:0.4;
    }
   
}

//8-20位字符
-(BOOL)judgeMinimumCharactersWithpassword:(NSString*)password{
    if (password.length >= 8&&password.length<=20) {
           return YES;
       } else {
           return NO;
       }
  
}

//至少一个大写字母(A-Z)
-(BOOL)judgeCapitalLetterWithpassword:(NSString*)password{
    
    // 使用正则表达式检查是否包含至少一个大写字母
       NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[A-Z]"
                                                                              options:0
                                                                                error:nil];
       NSUInteger matchCount = [regex numberOfMatchesInString:password options:0 range:NSMakeRange(0, password.length)];
       
       // 如果找到至少一个大写字母，返回 YES
       return matchCount > 0;
    
    
}

//至少一个小写字母(a-z)
-(BOOL)judgeLowercaseLetterWithpassword:(NSString*)password{
    // 使用正则表达式检查是否包含至少一个小写字母
       NSRegularExpression *lowercaseRegex = [NSRegularExpression regularExpressionWithPattern:@"[a-z]"
                                                                                    options:0
                                                                                      error:nil];
       NSUInteger lowercaseMatchCount = [lowercaseRegex numberOfMatchesInString:password options:0 range:NSMakeRange(0, password.length)];
       
       // 如果找到至少一个小写字母，返回 YES
       return lowercaseMatchCount > 0;
 
    
}
//至少一个数字
-(BOOL)judgeDigitWithpassword:(NSString*)password{
    NSRegularExpression *digitRegex = [NSRegularExpression regularExpressionWithPattern:@"[0-9]"
                                                                             options:0
                                                                               error:nil];
      NSUInteger digitMatchCount = [digitRegex numberOfMatchesInString:password options:0 range:NSMakeRange(0, password.length)];
      
      // 如果找到至少一个数字，返回 YES
      return digitMatchCount > 0;
   
}

@end
