//
//  RegisterInputView.h
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^BtnStatusBlock)(int status);

NS_ASSUME_NONNULL_BEGIN

@interface RegisterInputView : UIView
@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UIView *accountView;

@property (weak, nonatomic) IBOutlet UITextField *pswTF;
@property (weak, nonatomic) IBOutlet UIView *pswView;

@property (weak, nonatomic) IBOutlet UITextField *inviteTF;
@property (weak, nonatomic) IBOutlet UIView *pswAlertView;
@property (weak, nonatomic) IBOutlet UIView *inviteView;
@property (weak, nonatomic) IBOutlet UILabel *emailAlertLabel;
@property (weak, nonatomic) IBOutlet UILabel *pswAlertLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *inviteHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswAlertHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emailTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswTitleHeight;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UIView *inviteTitleView;
@property (weak, nonatomic) IBOutlet UILabel *accountLabel;
@property (weak, nonatomic) IBOutlet UILabel *pswLabel;
@property (weak, nonatomic) IBOutlet UILabel *inviteLabel;

@property (nonatomic, copy) BtnStatusBlock statusBlock;
+ (RegisterInputView *)instanceViewWithFrame:(CGRect)Rect withType:(int)type;//0 注册 1忘记密码
@property(nonatomic,assign)int type;

-(void)setLanguage;

@end

NS_ASSUME_NONNULL_END
