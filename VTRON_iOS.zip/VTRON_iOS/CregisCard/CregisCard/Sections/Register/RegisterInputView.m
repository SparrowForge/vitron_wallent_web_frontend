//
//  RegisterInputView.m
//  CregisCard
//
//  Created by 孙良 on 2024/10/30.
//  Copyright © 2024 BytesLink Anhui. All rights reserved.
//

#import "RegisterInputView.h"
#import "PasswordAlertCell.h"
@interface RegisterInputView ()<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, assign) BOOL isInviteViewExpanded;  // 用于跟踪视图是否展开
@property (nonatomic, assign) BOOL isPswViewExpanded;  // 用于跟踪视图是否展开
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *inviteTopDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tipsDistance;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tips2Distance;

@end



@implementation RegisterInputView

+ (RegisterInputView *)instanceViewWithFrame:(CGRect)Rect withType:(int)type{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"RegisterInputView" owner:nil options:nil];
    RegisterInputView*view=[nibView objectAtIndex:0];
    view.frame=Rect;
    [view setBorderView:view.accountView];
    [view setBorderView:view.pswView];
    [view setBorderView:view.inviteView];
    CGRect frame = view.inviteView.frame;
    frame.size.height = 0;
    // 初始设置，将高度约束设为 0，并隐藏 view
    view.isInviteViewExpanded = NO;
    view.isPswViewExpanded = NO;
    view.inviteHeight.constant = 0;
    view.inviteView.hidden = YES; // 初始隐藏
    view.pswAlertHeight.constant = 0; //
    view.pswAlertView.hidden=YES;
    view.pswAlertLabel.hidden=YES;
    view.emailAlertLabel.hidden=YES;
    view.emailTitleHeight.constant=0;
    view.tipsDistance.constant=0;
    view.pswTitleHeight.constant=0;
    view.tips2Distance.constant=0;
    [view setTextFieldObserverWithtextField:view.accountTF];
    [view setTextFieldObserverWithtextField:view.pswTF];
    [view setUptableView];
    view.pswTF.secureTextEntry=YES;
    view.type=type;
    view.inviteTitleView.hidden=type==0?YES:YES;//全部隐藏
    [view setLanguage];
    view.accountLabel.font=PingFangMediumFont(13);
    view.pswLabel.font=PingFangMediumFont(13);
    view.inviteLabel.font=PingFangMediumFont(13);
    return view;
}

-(void)setUptableView{
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PasswordAlertCell" bundle:nil] forCellReuseIdentifier:@"PasswordAlertCell"];
    self.tableView.rowHeight=32;
    self.tableView.tableFooterView=[UIView new];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    //self.tableView.backgroundColor=[UIColor redColor];
}


-(void)setBorderView:(UIView*)view{
    view.layer.borderWidth=0.5;
    view.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
    [view setCornerRadius:12];
}
-(void)setTextFieldObserverWithtextField:(UITextField *)textField{
    [textField addTarget:self action:@selector(textFieldDidBegin:) forControlEvents:UIControlEventEditingDidBegin];
    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [textField addTarget:self action:@selector(textFieldDidEndEditingAction:) forControlEvents:UIControlEventEditingDidEnd];
}

- (IBAction)inviteCodeClick:(UIButton *)sender {

    if (self.isInviteViewExpanded) {
         [self collapseInviteView];
     } else {
         [self expandInviteView];
     }
}
// 展开 view
- (void)expandInviteView {
    self.inviteView.hidden = NO; // 先显示 view
    [UIView animateWithDuration:0.3 animations:^{
        self.inviteHeight.constant = 50;  // 设置展开后的高度
        [self layoutIfNeeded]; // 激活动画
    } completion:^(BOOL finished) {
        self.isInviteViewExpanded = YES;
    }];
}

// 收起 view
- (void)collapseInviteView {
    [UIView animateWithDuration:0.3 animations:^{
        self.inviteHeight.constant = 0; // 设置高度为 0
        [self layoutIfNeeded]; // 激活动画

    } completion:^(BOOL finished) {
        self.inviteView.hidden = YES; // 动画结束后隐藏
        self.isInviteViewExpanded = NO;
    }];
}

//隐藏或显示密码
- (IBAction)eyeClick:(UIButton *)sender {
    sender.selected=!sender.selected;
    self.pswTF.secureTextEntry=sender.selected?NO:YES;
   
}

// 展开 view
- (void)expandPswAlertView {
    self.pswAlertView.hidden = NO; // 先显示 view
    [UIView animateWithDuration:0.3 animations:^{
        self.pswAlertHeight.constant = 130;  // 设置展开后的高度
        [self layoutIfNeeded]; // 激活动画
    } completion:^(BOOL finished) {
        self.isPswViewExpanded=YES;
    }];
}

// 收起 view
- (void)collapsePswAlertView {
    [UIView animateWithDuration:0.3 animations:^{
        self.pswAlertHeight.constant = 0; // 设置高度为 0
        [self layoutIfNeeded]; // 激活动画

    } completion:^(BOOL finished) {
        self.pswAlertView.hidden = YES; // 动画结束后隐藏
        self.isPswViewExpanded=NO;
    }];
}
//MARK: 监听输入框开始编辑
- (void)textFieldDidBegin:(UITextField *)textField {
    if ([textField isEqual:self.accountTF]) {
        //邮箱

    }else{
        //密码
        if (!self.isPswViewExpanded) {
            [self expandPswAlertView];
        }
        
    }
    NSLog(@"开始编辑--%@",textField.text);
    
}
//MARK: 监听输入框内容变化
- (void)textFieldDidChange:(UITextField *)textField {
    if ([textField isEqual:self.accountTF]) {
        //邮箱
        [self judgeCorrectEmail:[ToolUtil matchEmail:textField.text]];
    }else{
        //密码
        [self judgeCorrectPassword:[ToolUtil isOrNoPasswordStyle:textField.text]];
        [self.tableView reloadData];
    }
    [self judgeBtnStatus];
    NSLog(@"内容变化--%@",textField.text);
    
}
// 代理方法：监听 textField 失去第一响应者
- (void)textFieldDidEndEditingAction:(UITextField *)textField {
    if ([textField isEqual:self.pswTF]) {
        [self collapsePswAlertView];
    }
    NSLog(@"TextField 失去第一响应者");
}

//判断电子邮件是否正确
-(void)judgeCorrectEmail:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.emailAlertLabel.hidden=YES;
        self.accountView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.accountView.backgroundColor=[UIColor whiteColor];
        self.emailTitleHeight.constant=0;
        self.tipsDistance.constant=0;
    }else{
        self.emailAlertLabel.hidden=NO;
        self.accountView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.accountView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.emailTitleHeight.constant=15;
        self.tipsDistance.constant=8;
    }
   
}


//判断密码格式是否正确
-(void)judgeCorrectPassword:(BOOL)isCorrect{
    
    if (isCorrect) {
        self.pswAlertLabel.hidden=YES;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#1F211F" alpha:0.2].CGColor;
        self.pswView.backgroundColor=[UIColor whiteColor];
        self.pswTitleHeight.constant=0;
        self.tips2Distance.constant=0;
    }else{
        self.pswAlertLabel.hidden=NO;
        self.pswView.layer.borderColor=[UIColor colorWithHexString:@"#EC312C" alpha:1.0].CGColor;
        self.pswView.backgroundColor=[UIColor colorWithHexString:@"#EC312C" alpha:0.06];
        self.pswTitleHeight.constant=15;
        self.tips2Distance.constant=8;
    }
    
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PasswordAlertCell*cell=[tableView dequeueReusableCellWithIdentifier:@"PasswordAlertCell"];
    [cell configDataWithIndexpath:indexPath withpassword:self.pswTF.text];
    return cell;
    
}

//判断按钮的可点击状态
-(void)judgeBtnStatus{
    
    if ([ToolUtil matchEmail:self.accountTF.text]&&[ToolUtil isOrNoPasswordStyle:self.pswTF.text]) {
        //可点击
        if (self.statusBlock) {
            self.statusBlock(1);
        }
    }else{
       //不可点击
        self.statusBlock(0);
    }
  
}

-(void)setLanguage{
    
    self.titleLabel.text=self.type==0?LocalizationKey(@"注册"):LocalizationKey(@"重置密码");
    self.detailLabel.text=self.type==0?LocalizationKey(@"欢迎加入VTRON"):LocalizationKey(@"欢迎使用VTRON");
    self.accountLabel.text=LocalizationKey(@"邮箱");
    self.pswLabel.text=LocalizationKey(@"登录密码");
    self.emailAlertLabel.text=LocalizationKey(@"电子邮件格式不正确");
    self.pswAlertLabel.text=LocalizationKey(@"密码规则不正确");
    self.inviteLabel.text=LocalizationKey(@"邀请码（选填）");
    [self.accountTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.pswTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
    [self.inviteTF setStyleWithPlaceholder:LocalizationKey(@"请输入")];
}

@end
